(function () {
  'use strict';

  var SITE = 'https://reanime.to';
  var PLAYER = 'https://flixcloud.cc';
  var USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36';

  function headers(referer, origin) {
    return {
      'User-Agent': USER_AGENT,
      'Accept': 'application/json, text/plain, text/html, */*',
      'Accept-Language': 'en-US,en;q=0.8',
      'Referer': referer || SITE + '/',
      'Origin': origin || SITE,
    };
  }

  async function responseBody(response) {
    if (!response) throw new Error('ReAnime returned no response.');
    if (typeof response.body === 'string' && response.body) return response.body;
    if (typeof response.text === 'function') {
      var text = await response.text();
      if (text) return String(text);
    }
    if (typeof response.json === 'function') return JSON.stringify(await response.json());
    return '';
  }

  async function requestText(url, requestHeaders) {
    var response = await fetchv2(url, requestHeaders || headers(SITE + '/'), 'GET', null);
    var status = Number(response && response.status ? response.status : 0);
    var body = await responseBody(response);
    if (status < 200 || status >= 300 || !body) {
      throw new Error('Request failed (' + status + ') for ' + url);
    }
    return body;
  }

  async function requestJson(url, requestHeaders) {
    var body = await requestText(url, requestHeaders);
    try {
      return JSON.parse(body);
    } catch (_) {
      throw new Error('Expected JSON from ' + url);
    }
  }

  function text(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&#39;/g, "'")
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function titleOf(value) {
    var title = value && value.title ? value.title : {};
    return text(title.english || title.user_preferred || title.romaji || title.native || 'Untitled');
  }

  function coverOf(value) {
    var cover = value && value.cover_image ? value.cover_image : {};
    return cover.extra_large || cover.large || cover.medium || '';
  }

  function slugOf(value) {
    var raw = String(value || '').trim();
    var match = /\/anime\/([^/?#]+)/i.exec(raw) || /\/watch\/([^/?#]+)/i.exec(raw);
    return match ? match[1] : raw.replace(/^rean ime-series:/i, '');
  }

  function pageUrl(slug) {
    return SITE + '/anime/' + encodeURIComponent(slug);
  }

  function numberOf(value) {
    var number = Number(value);
    if (!isFinite(number) || number <= 0) throw new Error('Invalid ReAnime episode number.');
    return Math.floor(number);
  }

  function episodeRef(slug, number, anilistId) {
    return 'reanime-episode:' + encodeURIComponent(slug) + ':' + number + ':' + encodeURIComponent(String(anilistId));
  }

  function decodeEpisodeRef(value) {
    var parts = String(value || '').split(':');
    if (parts.length !== 4 || parts[0] !== 'reanime-episode') {
      throw new Error('Invalid ReAnime episode reference.');
    }
    return {
      slug: decodeURIComponent(parts[1]),
      number: numberOf(parts[2]),
      anilistId: decodeURIComponent(parts[3]),
    };
  }

  async function searchResults(query) {
    var value = String(query || '').trim();
    if (!value) return [];
    var data = await requestJson(SITE + '/api/v1/search?limit=30&q=' + encodeURIComponent(value), headers(SITE + '/search'));
    var rows = data && Array.isArray(data.results) ? data.results : [];
    return rows.map(function (item) {
      var slug = String(item.anime_id || '').trim();
      return {
        id: slug,
        href: pageUrl(slug),
        title: titleOf(item),
        image: coverOf(item),
        poster: coverOf(item),
        type: String(item.format || 'TV').toLowerCase(),
      };
    }).filter(function (item) { return item.id && item.title && item.image; });
  }

  async function extractDetails(seriesHref) {
    var slug = slugOf(seriesHref);
    if (!slug) throw new Error('ReAnime details require an anime slug.');
    var data = await requestJson(SITE + '/api/v1/anime/' + encodeURIComponent(slug) + '/meta', headers(SITE + '/'));
    if (!data || !data.anime_id) throw new Error('ReAnime metadata was incomplete.');
    var description = '';
    try {
      var watchData = await requestJson(SITE + '/api/v1/watch/' + encodeURIComponent(slug) + '?ep=1&tz=UTC', headers(SITE + '/'));
      description = text(watchData && watchData.anime && watchData.anime.description);
    } catch (_) {}
    return {
      id: String(data.anime_id),
      href: pageUrl(String(data.anime_id)),
      title: titleOf(data),
      image: coverOf(data),
      poster: coverOf(data),
      description: description,
    };
  }

  async function anilistIdFor(slug) {
    var html = await requestText(SITE + '/watch/' + encodeURIComponent(slug) + '?ep=1', headers(SITE + '/'));
    var match = /anilist_id\s*:\s*(\d+)/i.exec(html) || /anilist\s*:\s*(\d+)/i.exec(html);
    if (!match || !match[1]) throw new Error('ReAnime watch page did not expose an Anilist ID.');
    return match[1];
  }

  async function extractEpisodes(seriesHref) {
    var slug = slugOf(seriesHref);
    if (!slug) throw new Error('ReAnime episodes require an anime slug.');
    var anilistId = await anilistIdFor(slug);
    var data = await requestJson(SITE + '/api/v1/anime/' + encodeURIComponent(slug) + '/episodes?limit=2000', headers(SITE + '/'));
    var rows = data && Array.isArray(data.data) ? data.data : [];
    if (!rows.length) throw new Error('ReAnime returned no episodes.');
    return rows.filter(function (item) {
      return item && item.playable !== false && Number(item.episode_number) > 0;
    }).map(function (item) {
      var number = numberOf(item.episode_number);
      return {
        number: number,
        title: text(item.title || ('Episode ' + number)),
        href: episodeRef(slug, number, anilistId),
        subAvailable: item.subbed === true,
        dubAvailable: item.dubbed === true,
      };
    });
  }

  function sourceIds(embedUrl, embedHtml) {
    var ids = [];
    var pathMatch = /\/e\/([^/?#]+)/i.exec(embedUrl);
    if (pathMatch) ids.push(pathMatch[1]);
    var patterns = [
      /(?:source[_-]?id|sourceId)\s*[:=]\s*["']([^"']+)/i,
      /video_id\s*[:=]\s*["']([^"']+)/i,
      /\baid\s*[:=]\s*["']([^"']+)/i,
    ];
    patterns.forEach(function (pattern) {
      var match = pattern.exec(embedHtml || '');
      if (match && match[1]) ids.push(match[1]);
    });
    return ids.filter(function (id, index, list) { return id && list.indexOf(id) === index; });
  }

  function parseSourcePayload(value) {
    if (value && typeof value === 'object') return value;
    if (typeof value !== 'string') return null;
    var raw = value.trim();
    if (!raw) return null;
    try { return JSON.parse(raw); } catch (_) {}
    return null;
  }

  function bytesFromBase64(value) {
    var raw = String(value || '').replace(/\s+/g, '');
    var binary = typeof atob === 'function' ? atob(raw) : null;
    if (binary == null && typeof Buffer !== 'undefined') binary = Buffer.from(raw, 'base64').toString('binary');
    if (binary == null) throw new Error('FlixCloud runtime has no base64 decoder.');
    var out = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i) & 255;
    return out;
  }

  function utf8(value) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(String(value));
    var encoded = unescape(encodeURIComponent(String(value)));
    var out = new Uint8Array(encoded.length);
    for (var i = 0; i < encoded.length; i += 1) out[i] = encoded.charCodeAt(i) & 255;
    return out;
  }

  function hex(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i += 1) out += ('0' + bytes[i].toString(16)).slice(-2);
    return out;
  }

  async function sha256(value) {
    if (typeof crypto === 'undefined' || !crypto.subtle || !crypto.subtle.digest) {
      throw new Error('FlixCloud resolver requires WebCrypto SHA-256 support.');
    }
    return new Uint8Array(await crypto.subtle.digest('SHA-256', utf8(value)));
  }

  async function sha256Hex(value) { return hex(await sha256(value)); }

  async function flixFieldMap(seed) {
    var first = seed;
    for (var i = 0; i < 3; i += 1) first = await sha256Hex(first + i);
    var second = first;
    for (var j = 0; j < 3; j += 1) second = await sha256Hex(second + j);
    return {
      videoField: 'vf_' + first.slice(0, 8),
      keyField: 'kf_' + first.slice(8, 16),
      ivField: 'ivf_' + first.slice(16, 24),
      containerName: 'cd_' + first.slice(24, 32),
      arrayName: 'ad_' + first.slice(32, 40),
      objectName: 'od_' + first.slice(40, 48),
      tokenField: first.slice(48, 64) + '_' + first.slice(56, 64),
      keyFrag2Field: second.slice(0, 16) + '_' + second.slice(16, 24),
    };
  }

  function quotedField(html, field) {
    var escaped = String(field).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var match = new RegExp("(?:[\\\"']|\\b)" + escaped + "(?:[\\\"'])?\\s*:\\s*[\\\"']([^\\\"']+)", 'i').exec(html);
    return match && match[1] ? match[1] : '';
  }

  async function resolveFlixCloudEncrypted(embedHtml) {
    var seedMatch = /obfuscation_seed\s*:\s*["']([^"']+)["']/i.exec(embedHtml);
    var wasmMatch = /w_payload\s*:\s*["']([^"']+)["']/i.exec(embedHtml);
    if (!seedMatch || !wasmMatch) throw new Error('FlixCloud embed omitted its resolver payload.');
    if (typeof WebAssembly === 'undefined' || typeof WebAssembly.instantiate !== 'function') {
      throw new Error('FlixCloud resolver requires WebAssembly support in the module runtime.');
    }
    var fields = await flixFieldMap(seedMatch[1]);
    var token = quotedField(embedHtml, fields.tokenField);
    if (!token) throw new Error('FlixCloud token field was not found.');
    var config = await requestJson(PLAYER + '/api/m3u8/' + encodeURIComponent(token), headers(PLAYER + '/', PLAYER));
    var videoKey = (await sha256Hex(token + 'vid')).slice(0, 10);
    var dataKey = (await sha256Hex(token + 'key')).slice(0, 10);
    var videoPart = config && config[videoKey];
    var keyPart = config && config[dataKey];
    var keyFrag = quotedField(embedHtml, fields.keyField);
    var keyFrag2 = quotedField(embedHtml, fields.keyFrag2Field);
    var iv = quotedField(embedHtml, fields.ivField);
    var fragMatch = /obfuscated_crypto_data\s*:\s*\{\s*cd_[^:]+\s*:\s*\{\s*ad_[^:]+\s*:\s*\[\s*\{\s*od_[^:]+\s*:\s*\{\s*(?:["'][^"']+["']|[A-Za-z0-9_]+)\s*:\s*["']([^"']+)["']/i.exec(embedHtml);
    var frag1 = fragMatch && fragMatch[1];
    if (!videoPart || !keyPart || !keyFrag || !keyFrag2 || !iv || !frag1) throw new Error('FlixCloud resolver fields were incomplete.');
    var wasm = (await WebAssembly.instantiate(bytesFromBase64(wasmMatch[1]), {})).instance;
    var memory = wasm.exports.memory;
    var input = [bytesFromBase64(frag1), bytesFromBase64(keyFrag2), bytesFromBase64(keyPart)];
    var offset = 1000;
    var pointers = [];
    for (var n = 0; n < input.length; n += 1) {
      while (memory.buffer.byteLength < offset + input[n].length) memory.grow(1);
      new Uint8Array(memory.buffer).set(input[n], offset);
      pointers.push(offset);
      offset += input[n].length;
    }
    var output = offset;
    var wasmOutputLength = input[0].length;
    while (memory.buffer.byteLength < output + wasmOutputLength) memory.grow(1);
    wasm.exports._s(parseInt(seedMatch[1].slice(0, 8), 16));
    wasm.exports._r(pointers[0], pointers[1], pointers[2], output, wasmOutputLength);
    var wasmKey = new Uint8Array(memory.buffer.slice(output, output + wasmOutputLength));
    var derived = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: utf8(seedMatch[1]), iterations: 1000, hash: 'SHA-256' }, await crypto.subtle.importKey('raw', wasmKey, { name: 'PBKDF2' }, false, ['deriveBits']), 256);
    var mixed = new Uint8Array(derived);
    for (var k = 0; k < mixed.length; k += 1) mixed[k] ^= seedMatch[1].charCodeAt(k % seedMatch[1].length);
    var aesKey = new Uint8Array(await crypto.subtle.digest('SHA-256', mixed));
    var cryptoKey = await crypto.subtle.importKey('raw', aesKey, { name: 'AES-CBC' }, false, ['decrypt']);
    var plain = await crypto.subtle.decrypt({ name: 'AES-CBC', iv: bytesFromBase64(iv) }, cryptoKey, bytesFromBase64(videoPart));
    var streamUrl = typeof TextDecoder !== 'undefined' ? new TextDecoder().decode(plain).trim() : String.fromCharCode.apply(null, new Uint8Array(plain)).trim();
    if (!/^https?:\/\//i.test(streamUrl)) throw new Error('FlixCloud decrypted URL was invalid.');
    return streamUrl;
  }

  async function resolveFlixCloudStream(sourceData) {
    var data = parseSourcePayload(sourceData) || sourceData;
    if (!data || !Array.isArray(data.sources) || !data.sources.length) {
      throw new Error('Invalid or unparsed stream source format');
    }
    var primary = data.sources[0] || {};
    var streamUrl = primary.file || primary.url || '';
    if (!/^https?:\/\//i.test(streamUrl) || !/\.(?:m3u8|mp4)(?:[?#]|$)/i.test(streamUrl)) {
      throw new Error('FlixCloud source was not a direct HLS or MP4 URL.');
    }
    var streamHeaders = {
      'User-Agent': USER_AGENT,
      'Referer': PLAYER + '/',
      'Origin': PLAYER,
    };
    var result = {
      url: streamUrl,
      headers: streamHeaders,
      streamType: /\.m3u8(?:[?#]|$)/i.test(streamUrl) ? 'hls' : 'mp4',
      quality: primary.quality || 'Auto',
      streams: [{ label: 'Auto (HD)', url: streamUrl, headers: streamHeaders }],
    };
    if (Array.isArray(data.subtitles)) {
      result.subtitles = data.subtitles.filter(function (track) {
        return track && /^https?:\/\//i.test(String(track.url || ''));
      }).map(function (track) {
        return { url: track.url, language: track.language || track.lang || 'English', format: track.format || 'vtt' };
      });
    }
    return result;
  }

  async function extractStreamUrl(episodeHref, lang) {
    var episode = decodeEpisodeRef(episodeHref);
    var desired = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';
    var provider = await requestJson(SITE + '/api/flix/' + encodeURIComponent(episode.anilistId) + '/' + episode.number, headers(SITE + '/'));
    var servers = provider && Array.isArray(provider.servers) ? provider.servers : [];
    var selected = servers.filter(function (server) { return String(server.dataType || '').toLowerCase() === desired; })[0];
    if (!selected || !selected.dataLink) throw new Error('ReAnime has no ' + desired.toUpperCase() + ' FlixCloud server for episode ' + episode.number + '.');
    var embedUrl = String(selected.dataLink);
    if (!/^https:\/\/flixcloud\.cc\/e\//i.test(embedUrl)) throw new Error('ReAnime returned an unsupported FlixCloud URL.');
    var embedHtml = await requestText(embedUrl, headers(SITE + '/', SITE));
    var streamUrl = await resolveFlixCloudEncrypted(embedHtml);
    return await resolveFlixCloudStream({ sources: [{ file: streamUrl, quality: 'Auto' }] });
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
}());
