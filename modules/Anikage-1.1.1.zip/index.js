(() => {
  'use strict';

  const MODULE_NAME = 'Anikage';
  const BASE_URL = 'https://anikage.cc';
  const PROXY_CDN = 'https://og.bakayaro.live';
  const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(message) {
    try {
      if (typeof debugPrint === 'function') debugPrint('[' + MODULE_NAME + '] ' + String(message || ''));
      else if (typeof console !== 'undefined' && console.log) console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function decodeHtml(text) {
    return String(text || '')
      .replace(/&#0?39;|&#x27;|&apos;/g, "'")
      .replace(/&#8217;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .trim();
  }

  // ---------- HTTP bridge with host-scoped rate-limit cooldown ----------
  const cooldowns = {};

  function rateLimitError(until) {
    const error = new Error(MODULE_NAME + ': source rate limited; retry in ' +
      Math.max(1, Math.ceil((until - Date.now()) / 1000)) + ' seconds');
    error.rateLimited = true;
    return error;
  }

  function retryAfterMs(res) {
    const headers = res && res.headers;
    let raw = '';
    if (headers && typeof headers.get === 'function') raw = headers.get('retry-after');
    else if (headers) {
      const key = Object.keys(headers).find((name) => name.toLowerCase() === 'retry-after');
      if (key) raw = headers[key];
    }
    raw = String(raw || '').trim();
    if (/^\d+$/.test(raw) && isFinite(Number(raw))) return Math.max(1000, Number(raw) * 1000);
    const date = raw ? Date.parse(raw) : NaN;
    return isFinite(date) && date > Date.now() ? date - Date.now() : 60000;
  }

  async function requestJson(url, extraHeaders) {
    const host = (String(url).match(/^https?:\/\/([^/]+)/i) || [])[1] || '';
    if (cooldowns[host] > Date.now()) throw rateLimitError(cooldowns[host]);
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Referer': BASE_URL + '/',
      'Origin': BASE_URL,
    }, extraHeaders || {});

    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }

    const status = Number((res && res.status) || 0);

    if (status === 429) {
      cooldowns[host] = Date.now() + retryAfterMs(res);
      throw rateLimitError(cooldowns[host]);
    }

    if (status < 200 || status >= 400) {
      throw new Error(MODULE_NAME + ': request failed (HTTP ' + status + ') for ' + url);
    }

    if (res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j !== null && j !== undefined) return j;
      } catch (_) {}
    }
    if (res && res.json && typeof res.json === 'object') return res.json;

    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;

    if (text) {
      try { return JSON.parse(text); } catch (_) {}
    }
    throw new Error(MODULE_NAME + ': response from ' + url + ' was not valid JSON');
  }

  // ---------- helpers ----------

  async function resolveAnimeSlug(rawSlug) {
    let slug = String(rawSlug || '').trim();
    if (!slug) throw new Error(MODULE_NAME + ': empty anime slug');

    if (slug.startsWith('http://') || slug.startsWith('https://')) {
      const m = slug.match(/\/(?:anime\/)?(?:watch|info)\/([^/?#]+)/i) || slug.match(/\/watch\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?(anime\/)?(watch|info)\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error(MODULE_NAME + ': empty anime slug');

    // If slug is a 10-character Anikage ID or valid slug, check if valid
    try {
      const test = await requestJson(BASE_URL + '/api/media/anime/' + slug);
      if (test && (test.anime || test.slug || test.anilistId)) return slug;
    } catch (error) {
      if (error && error.rateLimited) throw error;
    }

    // Never substitute an unrelated first search result after a failed lookup.
    const searchRes = await searchResults(slug.replace(/[-_]+/g, ' '));
    const normalize = (value) => String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
    const exact = searchRes.filter((item) => normalize(item.title) === normalize(slug));
    if (exact.length === 1) return exact[0].id;

    return slug;
  }

  function formatTitle(titleObj, fallback) {
    if (!titleObj || typeof titleObj !== 'object') return fallback || 'Anime';
    return titleObj.english || titleObj.userPreferred || titleObj.romaji || titleObj.native || fallback || 'Anime';
  }

  function formatImage(coverObj) {
    if (!coverObj) return '';
    if (typeof coverObj === 'string') return coverObj;
    return coverObj.extraLarge || coverObj.large || coverObj.medium || '';
  }

  // ---------- search ----------

  async function searchResults(query) {
    const q = String(query || '').trim();
    const url = BASE_URL + '/api/media/anime/browse?' + (q ? 'q=' + encodeURIComponent(q) : 'sort=TRENDING_DESC');
    const data = await requestJson(url);
    const results = (data && data.data) || [];

    return results.map((item) => {
      const title = formatTitle(item.title, item.slug);
      const poster = formatImage(item.coverImage);
      return {
        id: item.slug,
        href: BASE_URL + '/anime/info/' + item.slug,
        title: title,
        image: poster,
        poster: poster,
      };
    });
  }

  // ---------- details ----------

  async function extractDetails(urlOrId) {
    const slug = await resolveAnimeSlug(urlOrId);
    const data = await requestJson(BASE_URL + '/api/media/anime/' + slug);
    const anime = (data && data.anime) || data || {};

    const title = formatTitle(anime.title, slug);
    const poster = formatImage(anime.coverImage);
    const banner = anime.bannerImage || anime.fanart || poster;

    return {
      id: slug,
      href: BASE_URL + '/anime/info/' + slug,
      title: title,
      description: anime.description ? decodeHtml(anime.description.replace(/<[^>]*>/g, '')) : 'Watch on Anikage',
      image: poster,
      poster: poster,
      banner: banner,
      genres: Array.isArray(anime.genres) ? anime.genres : [],
      anilistId: anime.anilistId || 0,
      totalEpisodes: anime.episodes_total || anime.totalEpisodes || 0,
    };
  }

  // ---------- episodes ----------

  async function extractEpisodes(seriesId) {
    const slug = await resolveAnimeSlug(seriesId);
    const rawEpisodes = await requestJson(BASE_URL + '/api/media/anime/' + slug + '/episodes');
    const list = Array.isArray(rawEpisodes) ? rawEpisodes : [];

    return list.map((ep, idx) => {
      const epNum = ep.number || ep.episodeInSeason || (idx + 1);
      const epTitle = ep.title ? ('Episode ' + epNum + ': ' + ep.title) : ('Episode ' + epNum);

      return {
        id: slug + ':ep:' + epNum,
        number: epNum,
        title: 'S1E' + epNum + ': ' + epTitle,
        href: 'anikage-stream:' + JSON.stringify({ slug: slug, ep: epNum }),
        hasSub: true,
        hasDub: typeof ep.hasDub === 'boolean' ? ep.hasDub : undefined,
        subAvailable: true,
        dubAvailable: typeof ep.hasDub === 'boolean' ? ep.hasDub : undefined,
        image: ep.img || ep.image || '',
      };
    });
  }

  function unpackPacker(code) {
    try {
      const match = String(code || '').match(/eval\(function\(p,a,c,k,e,[rd]\)\{.*\}\('(.*)',\s*(\d+),\s*(\d+),\s*'([^']*)'\.split\('\|'\)/);
      if (!match) return null;
      let [_, p, a, c, k] = match;
      a = parseInt(a, 10);
      c = parseInt(c, 10);
      k = k.split('|');
      const e = function(c) {
        return (c < a ? '' : e(parseInt(c / a, 10))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
      };
      while (c--) {
        if (k[c]) {
          p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
        }
      }
      return p;
    } catch (_) {
      return null;
    }
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return new Promise(function (resolve) {
      const timer = setTimeout(function () { resolve(fallback); }, waitMs);
      Promise.resolve(promise).then(function (value) {
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        resolve(value);
      }, function () {
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        resolve(fallback);
      });
    });
  }

  function mediaUrl(reference, base) {
    const raw = decodeHtml(reference);
    if (/^https?:\/\//i.test(raw)) return raw;
    const origin = String(base || '').match(/^(https?:\/\/[^/]+)/i);
    if (!origin || !raw || /^[a-z][a-z0-9+.-]*:/i.test(raw)) return '';
    if (raw.indexOf('//') === 0) return origin[1].split(':')[0] + ':' + raw;
    const full = raw[0] === '/' ? raw : String(base).slice(origin[1].length).split(/[?#]/)[0].replace(/[^/]*$/, '') + raw;
    const suffix = full.match(/[?#].*$/);
    const parts = [];
    full.split(/[?#]/)[0].split('/').forEach(function (part) {
      if (part === '..') parts.pop();
      else if (part && part !== '.') parts.push(part);
    });
    return origin[1] + '/' + parts.join('/') + (suffix ? suffix[0] : '');
  }

  function subtitleEntries(data, embedUrl) {
    const params = {};
    String(embedUrl || '').split('?').slice(1).join('?').split('#')[0].split('&').forEach(function (part) {
      const at = part.indexOf('=');
      if (at < 0) return;
      try { params[decodeURIComponent(part.slice(0, at))] = decodeURIComponent(part.slice(at + 1)); } catch (_) {}
    });
    const tracks = [], seen = {};
    function add(file, label, language, preferred) {
      // Provider tokens are not relative paths. Only use supplied HTTP caption URLs.
      if (!/^https?:\/\//i.test(String(file || '')) || seen[file]) return;
      seen[file] = true;
      const name = label || language || 'Subtitles';
      const code = language || (/^english\b/i.test(name) ? 'en' : 'und');
      tracks.push({ url: file, file: file, label: name, language: code, lang: code,
        format: /\.srt(?:[?#]|$)/i.test(file) ? 'srt' : 'vtt', kind: 'captions',
        default: preferred === true, headers: { 'User-Agent': USER_AGENT } });
    }
    Object.keys(params).forEach(function (key) {
      const caption = key.match(/^caption_(\d+)$/i), file = key.match(/^c(\d+)_file$/i);
      if (caption) add(params[key], params['sub_' + caption[1]]);
      else if (file) add(params[key], params['c' + file[1] + '_label']);
      else if (key === 'sub') add(params[key], 'English', 'en');
    });
    (Array.isArray(data && data.subtitles) ? data.subtitles : []).forEach(function (track) {
      if (!track || (track.embedUrl && track.embedUrl !== embedUrl)) return;
      add(track.file || track.url, track.label, track.lang || track.language, track.default);
    });
    return tracks;
  }

  function marker(range) {
    if (!range || typeof range.start !== 'number' || typeof range.end !== 'number' ||
        !isFinite(range.start) || !isFinite(range.end) || range.start < 0 || range.end <= range.start) return null;
    return { start: range.start, end: range.end };
  }

  async function validateStreamPlayback(streamUrl, headers, isM3u8, depth, active) {
    depth = depth || 0;
    if (depth > 4 || (active && !active())) return false;
    try {
      if (isM3u8) {
        let playlistText = '';
        if (typeof fetchv2 === 'function') {
          const res = await fetchv2(streamUrl, headers, 'GET', null);
          if (!res || (res.status !== 200 && res.status !== 206)) return false;
          if (typeof res.text === 'function') playlistText = await res.text();
          else if (typeof res.body === 'string') playlistText = res.body;
        } else if (typeof fetch === 'function') {
          const res = await fetch(streamUrl, { headers });
          if (!res || !res.ok) return false;
          playlistText = await res.text();
        }
        if (!playlistText || !playlistText.includes('#EXTM3U')) return false;

        const lines = playlistText.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
        let segmentOrVariantUrl = '';
        for (let i = 0; i < lines.length; i += 1) {
          const line = lines[i];
          if (line.startsWith('#')) continue;
          if (line.startsWith('http://') || line.startsWith('https://')) {
            segmentOrVariantUrl = line;
            break;
          }
          segmentOrVariantUrl = mediaUrl(line, streamUrl);
          break;
        }
        if (!segmentOrVariantUrl) return false;

        if (segmentOrVariantUrl.includes('.m3u8')) {
          return validateStreamPlayback(segmentOrVariantUrl, headers, true, depth + 1, active);
        }

        if (active && !active()) return false;

        const probeHeaders = Object.assign({}, headers, { Range: 'bytes=0-4095' });
        let probeRes = null;
        if (typeof fetchv2 === 'function') {
          probeRes = await fetchv2(segmentOrVariantUrl, probeHeaders, 'GET', null);
        } else if (typeof fetch === 'function') {
          probeRes = await fetch(segmentOrVariantUrl, { headers: probeHeaders });
        }
        if (!probeRes) return false;
        const status = Number(probeRes.status || 0);
        if (status !== 200 && status !== 206) return false;

        let bodyText = '';
        if (typeof probeRes.text === 'function') { try { bodyText = await probeRes.text(); } catch (_) {} }
        else if (typeof probeRes.body === 'string') bodyText = probeRes.body;
        if (bodyText && (bodyText.includes('"error"') || bodyText.includes('domain forbidden') || bodyText.includes('Website Access Blocked'))) {
          return false;
        }

        const cType = String(probeRes.contentType || (probeRes.headers && (probeRes.headers['content-type'] || probeRes.headers['Content-Type'])) || '').toLowerCase();
        if (cType.includes('text/html') || cType.includes('image/') || cType.includes('application/json')) return false;
        return true;
      } else {
        const probeHeaders = Object.assign({}, headers, { Range: 'bytes=0-4095' });
        let probeRes = null;
        if (typeof fetchv2 === 'function') {
          probeRes = await fetchv2(streamUrl, probeHeaders, 'GET', null);
        } else if (typeof fetch === 'function') {
          probeRes = await fetch(streamUrl, { headers: probeHeaders });
        }
        if (!probeRes) return false;
        const status = Number(probeRes.status || 0);
        if (status !== 200 && status !== 206) return false;
        const cType = String(probeRes.contentType || (probeRes.headers && (probeRes.headers['content-type'] || probeRes.headers['Content-Type'])) || '').toLowerCase();
        if (cType.includes('text/html') || cType.includes('image/') || cType.includes('application/json')) return false;
        return true;
      }
    } catch (e) {
      log('validateStreamPlayback probe error: ' + (e && e.message ? e.message : String(e)));
      return false;
    }
  }

  // ---------- embed resolvers ----------

  async function resolveEmbedUrl(embedUrl) {
    const raw = String(embedUrl || '').trim();
    if (!raw || !/^https?:\/\//i.test(raw)) throw new Error('Invalid embed URL: ' + raw);

    const baseHeaders = {
      'User-Agent': USER_AGENT,
      'Referer': BASE_URL + '/',
    };

    // 1. Otaku / Playmogo family (OtakuHG, OtakuVid, Playmogo) -> unpack packer to get direct CDN HLS
    if (/otakuhg|otakuvid|playmogo/i.test(raw)) {
      let pageHtml = '';
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(raw, baseHeaders, 'GET', null);
        if (res && typeof res.text === 'function') pageHtml = await res.text();
        else if (res && typeof res.body === 'string') pageHtml = res.body;
      } else if (typeof fetch === 'function') {
        const res = await fetch(raw, { headers: baseHeaders });
        if (res.ok) pageHtml = await res.text();
      }

      const unpacked = unpackPacker(pageHtml) || pageHtml;
      const m3u8Match = unpacked.match(/https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*/i);
      if (m3u8Match) {
        const streamUrl = m3u8Match[0].replace(/\\/g, '');
        const streamHeaders = { 'User-Agent': USER_AGENT, 'Referer': raw };
        return {
          url: streamUrl,
          headers: streamHeaders,
          isM3U8: true,
          quality: 'Auto',
          label: 'Direct HD (Otaku)',
        };
      }
    }

    // 2. BibiEmb / ViviBebe family
    if (/bibiemb|vivibebe/i.test(raw)) {
      let pageHtml = '';
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(raw, baseHeaders, 'GET', null);
        if (res && typeof res.text === 'function') pageHtml = await res.text();
        else if (res && typeof res.body === 'string') pageHtml = res.body;
      } else if (typeof fetch === 'function') {
        const res = await fetch(raw, { headers: baseHeaders });
        if (res.ok) pageHtml = await res.text();
      }

      const m3u8Match = pageHtml.match(/https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*/i);
      if (m3u8Match) {
        const streamUrl = m3u8Match[0].replace(/\\/g, '');
        const streamHeaders = { 'User-Agent': USER_AGENT, 'Referer': raw };
        return {
          url: streamUrl,
          headers: streamHeaders,
          isM3U8: true,
          quality: 'Auto',
          label: 'Direct HD (Bibi)',
        };
      }
    }

    // 3. MegaPlay family
    if (/megaplay/i.test(raw)) {
      let pageHtml = '';
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(raw, baseHeaders, 'GET', null);
        if (res && typeof res.text === 'function') pageHtml = await res.text();
        else if (res && typeof res.body === 'string') pageHtml = res.body;
      } else if (typeof fetch === 'function') {
        const res = await fetch(raw, { headers: baseHeaders });
        if (res.ok) pageHtml = await res.text();
      }

      const realIdM = pageHtml.match(/data-realid=["']([^"']+)["']/i) || pageHtml.match(/data-id=["']([^"']+)["']/i);
      const realId = realIdM ? realIdM[1] : '';
      if (realId) {
        const srcUrl = 'https://megaplay.buzz/stream/getSources?id=' + encodeURIComponent(realId);
        const sJson = await requestJson(srcUrl, { 'Referer': 'https://megaplay.buzz/', 'Origin': 'https://megaplay.buzz' });
        const file = (sJson && sJson.sources && sJson.sources[0] && sJson.sources[0].file) || (sJson && sJson.file);
        if (file && file.startsWith('http')) {
          const streamHeaders = { 'User-Agent': USER_AGENT, 'Referer': 'https://megaplay.buzz/', 'Origin': 'https://megaplay.buzz' };
          return {
            url: file,
            headers: streamHeaders,
            isM3U8: true,
            quality: 'HD',
            label: 'Direct HD (MegaPlay)',
          };
        }
      }
    }

    // 4. Vidtube / other direct m3u8 embed
    if (/vidtube/i.test(raw)) {
      let pageHtml = '';
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(raw, baseHeaders, 'GET', null);
        if (res && typeof res.text === 'function') pageHtml = await res.text();
        else if (res && typeof res.body === 'string') pageHtml = res.body;
      } else if (typeof fetch === 'function') {
        const res = await fetch(raw, { headers: baseHeaders });
        if (res.ok) pageHtml = await res.text();
      }

      const m3u8Match = pageHtml.match(/https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*/i);
      if (m3u8Match) {
        const streamUrl = m3u8Match[0].replace(/\\/g, '');
        const streamHeaders = { 'User-Agent': USER_AGENT, 'Referer': raw };
        return {
          url: streamUrl,
          headers: streamHeaders,
          isM3U8: true,
          quality: 'HD',
          label: 'Direct HD (Vidtube)',
        };
      }
    }

    throw new Error('Unsupported embed: ' + raw);
  }

  // ---------- stream resolution ----------

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    let slug = '';
    let epNum = NaN;

    if (raw.startsWith('anikage-stream:')) {
      const parsed = JSON.parse(raw.slice('anikage-stream:'.length));
      slug = parsed.slug;
      epNum = parsed.ep;
    } else if (raw.includes(':ep:')) {
      const parts = raw.split(':ep:');
      slug = parts[0];
      epNum = Number(parts[1]);
    } else {
      const m = raw.match(/\/watch\/([^\/]+)\/([0-9]+)/i) || raw.match(/([^\/]+)\/episode\/([0-9]+)/i);
      if (m) {
        slug = m[1];
        epNum = Number(m[2]);
      }
    }

    epNum = Number(epNum);
    if (!/^[a-zA-Z0-9_-]+$/.test(String(slug || '')) || !isFinite(epNum) || epNum < 1 || Math.floor(epNum) !== epNum) {
      throw new Error(MODULE_NAME + ': invalid episode reference');
    }

    const targetLang = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';

    // Try fallbacks only when a provider has no checked routes. Resolve its actual
    // embed alternatives with two workers, retaining each route's own metadata.
    const providers = ['neko', 'wave', 'koto', 'zen', 'dib', 'kiwi', 'megg'];
    const deadline = Date.now() + 22000;
    const remaining = () => Math.max(0, deadline - Date.now());

    for (const provider of providers) {
      if (!remaining()) break;
      try {
        const queryUrl = BASE_URL + '/api/media/anime/' + encodeURIComponent(slug) + '/episodes/' + epNum + '/sources?provider=' + provider + '&lang=' + targetLang;
        const outcome = await settleWithin(requestJson(queryUrl, {
          'Referer': BASE_URL + '/anime/watch/' + slug,
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'en-US,en;q=0.9',
        }).then((data) => ({ data: data }), (error) => ({ error: error })), Math.min(5000, remaining()), null);
        if (outcome && outcome.error) throw outcome.error;
        const data = outcome && outcome.data;
        if (!data || !remaining()) continue;
        if (data.subType && String(data.subType).toLowerCase() !== targetLang) continue;
        if ((data.slug && data.slug !== slug) || (data.number != null && Number(data.number) !== epNum)) continue;

        const intro = marker(data.intro), outro = marker(data.outro);
        const candidates = [], seenEmbeds = {};
        function addEmbed(entry) {
          if (!entry) return;
          const url = entry.embedUrl || entry.url;
          if (!/^https?:\/\//i.test(String(url || '')) || seenEmbeds[url]) return;
          if (entry.type === 'dub' && targetLang !== 'dub') return;
          if (/^(softsub|hardsub|sub)$/.test(entry.type || '') && targetLang === 'dub') return;
          seenEmbeds[url] = true;
          candidates.push({ url: url, name: entry.server || entry.label || 'Server ' + (candidates.length + 1) });
        }
        (Array.isArray(data.embeds) ? data.embeds : []).forEach(addEmbed);
        (Array.isArray(data.sources) ? data.sources : []).filter((entry) => entry && entry.embedUrl).forEach(addEmbed);
        (Array.isArray(data.embedOptions) ? data.embedOptions : []).forEach(addEmbed);
        candidates.sort((a, b) => {
          const score = (u) => /otakuhg|otakuvid|playmogo/i.test(u) ? 4 : (/bibiemb|vivibebe/i.test(u) ? 3 : 1);
          return score(b.url) - score(a.url);
        });
        (Array.isArray(data.sources) ? data.sources : []).forEach(function (entry) {
          if (!entry || !/^https?:\/\//i.test(entry.url || '')) return;
          if (entry.type === 'dub' && targetLang !== 'dub') return;
          if (/^(softsub|hardsub|sub)$/.test(entry.type || '') && targetLang === 'dub') return;
          candidates.push({ url: entry.url, direct: true, isM3U8: entry.isM3U8 !== false,
            headers: Object.assign({ 'User-Agent': USER_AGENT, Referer: BASE_URL + '/' }, data.headers || {}, entry.headers || {}),
            name: entry.server || entry.quality || 'Direct' });
        });
        let next = 0, closed = false;
        const routes = [];
        const active = () => !closed && remaining() > 0;
        async function worker() {
          while (next < candidates.length && active()) {
            const order = next++, candidate = candidates[order];
            let candidateClosed = false;
            const candidateActive = () => active() && !candidateClosed;
            async function resolveCandidate() {
              const resolved = candidate.direct ? candidate : await resolveEmbedUrl(candidate.url);
              if (!resolved || !candidateActive()) return null;
              const valid = await validateStreamPlayback(resolved.url, resolved.headers, resolved.isM3U8 !== false, 0, candidateActive);
              if (!valid || !candidateActive()) return null;
              return { name: candidate.name + ' (' + provider + ')', url: resolved.url, headers: resolved.headers,
                streamType: resolved.isM3U8 !== false ? 'hls' : 'mp4', quality: 'Auto', lang: targetLang,
                subtitles: subtitleEntries(data, candidate.url), intro: intro, outro: outro,
                introStartSeconds: intro ? intro.start : null, introEndSeconds: intro ? intro.end : null,
                outroStartSeconds: outro ? outro.start : null, outroEndSeconds: outro ? outro.end : null };
            }
            const route = await settleWithin(resolveCandidate(), Math.min(4500, remaining()), null);
            candidateClosed = true;
            if (route && active()) routes.push({ order: order, route: route });
          }
        }
        await settleWithin(Promise.all([worker(), worker()]), Math.max(1, remaining()), null);
        closed = true;
        routes.sort((a, b) => a.order - b.order);
        const seen = {}, servers = [];
        routes.forEach(function (entry) {
          if (seen[entry.route.url]) return;
          seen[entry.route.url] = true; servers.push(entry.route);
        });
        if (servers.length) {
          const primary = servers[0];
          return Object.assign({}, primary, { server: primary.name, servers: servers });
        }
      } catch (error) {
        if (error && error.rateLimited) throw error;
        log('Provider ' + provider + ' unavailable; trying next provider');
      }
    }

    throw new Error(MODULE_NAME + ': no checked ' + targetLang + ' stream available for this episode; try again later');
  }

  // ---------- discovery ----------

  async function discoveryHome() {
    const [trending, popular, topRated] = await Promise.all([
      requestJson(BASE_URL + '/api/media/anime/browse?sort=TRENDING_DESC&page=1'),
      requestJson(BASE_URL + '/api/media/anime/browse?sort=POPULARITY_DESC&page=1'),
      requestJson(BASE_URL + '/api/media/anime/browse?sort=SCORE_DESC&page=1'),
    ]);

    const trendingItems = (trending && trending.data) || [];
    const popularItems = (popular && popular.data) || [];
    const topRatedItems = (topRated && topRated.data) || [];

    const mapItem = (item) => ({
      id: item.slug,
      href: BASE_URL + '/anime/info/' + item.slug,
      title: formatTitle(item.title, item.slug),
      image: formatImage(item.coverImage),
    });

    const sections = [];

    // 1. Hero Featured Carousel
    sections.push({
      id: 'featured_trending',
      title: 'Featured Anime',
      style: 'hero',
      viewAll: { mode: 'feed', feedId: 'trending' },
      items: trendingItems.slice(0, 8).map(mapItem),
    });

    // 2. Top 10 Popular
    sections.push({
      id: 'top10_popular',
      title: 'Top 10 Most Popular',
      style: 'top10',
      viewAll: { mode: 'feed', feedId: 'popular' },
      items: popularItems.slice(0, 10).map(mapItem),
    });

    // 3. Trending Now
    sections.push({
      id: 'trending_now',
      title: 'Trending on Anikage',
      style: 'poster',
      viewAll: { mode: 'feed', feedId: 'trending' },
      items: trendingItems.slice(0, 24).map(mapItem),
    });

    // 4. Top Rated
    sections.push({
      id: 'top_rated',
      title: 'Top Rated Anime',
      style: 'poster',
      viewAll: { mode: 'feed', feedId: 'top_rated' },
      items: topRatedItems.slice(0, 24).map(mapItem),
    });

    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    const pageNum = Math.max(1, Number(page) || 1);
    let sort = 'TRENDING_DESC';

    if (feedId === 'popular') sort = 'POPULARITY_DESC';
    else if (feedId === 'top_rated') sort = 'SCORE_DESC';
    else if (feedId === 'favourites') sort = 'FAVOURITES_DESC';

    const data = await requestJson(BASE_URL + '/api/media/anime/browse?sort=' + sort + '&page=' + pageNum);
    const results = (data && data.data) || [];

    return {
      items: results.map((item) => ({
        id: item.slug,
        href: BASE_URL + '/anime/info/' + item.slug,
        title: formatTitle(item.title, item.slug),
        image: formatImage(item.coverImage),
      })),
      page: pageNum,
      hasMore: results.length >= 20,
    };
  }

  // ---------- Exports on globalThis ----------

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
  globalThis.extractHome = discoveryHome;
  globalThis.extractFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
      extractHome: discoveryHome,
      extractFeed: discoveryFeed,
    };
  }
})();
