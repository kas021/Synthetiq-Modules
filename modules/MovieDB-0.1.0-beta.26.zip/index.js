/* ============================================================================
 * MovieDB (moviedb.wiki) — SP-VID-083-MOVIEDB
 * Fast + reliable Movies & TV module.
 *
 * Architecture (see PLAN.md):
 *  - Catalogue: moviedb.wiki (TMDB-id routes, HTML server-rendered).
 *  - Resolve:   api.vidlove.cc one-call JSON -> source.url (HLS master) +
 *               inline manifest + full multi-language subtitle list.
 *  - Fallback:  per-source variants (&sources=<key>) raced bounded.
 *  - Playback:  direct-id routing (mdb:movie:<tmdb> / mdb:tv:<tmdb>:<s>:<e>),
 *               segment byte-sniff validation, caches, prefetch-on-details.
 *
 * Module-only code: no app changes, no backend.
 * ========================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------------ */
  /* Constants                                                          */
  /* ------------------------------------------------------------------ */

  var SITE = 'https://www.moviedb.wiki';
  var API = 'https://api.vidlove.cc';
  var VIDZEN = 'https://vidzen.fun';
  var PLAYER_REF = 'https://player.vidlove.cc/';
  var TMDB = 'https://api.themoviedb.org/3';
  var TMDB_KEY = 'e716f19ab4d25edc5247239a8f3494f8';
  var VIDORA = 'https://moviesapi.to/api/vidora';
  var VIDORA_KEY = '3a67e8866ae1d2bb9e81fe7f73315a56eb3bdf5e3e755c7554c8be6910aa6b13';
  var USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  // The resolve API enforces a header fingerprint (bare requests get 403
  // from every region; measured 2026-09-22). Always send exactly these.
  function apiHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Referer: PLAYER_REF,
      Origin: 'https://player.vidlove.cc',
      Accept: 'application/json',
    };
  }

  function siteHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Referer: SITE + '/',
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
    };
  }

  function streamHeaders() {
    return { 'User-Agent': USER_AGENT, Referer: PLAYER_REF };
  }

  // Source keys behind &sources= (from the player's own roster, speed-ordered
  // by measurement: auto best, vidapi fastest fallback).
  var SOURCE_KEYS = ['vidapi', 'megaknight', 'warden', 'cinefreak', 'moviebox2', 'ipcloud', 'tcloud'];

  // Caches (module-lifetime; the app reloads modules per session).
  var PAGE_TTL = 6 * 60 * 1000;       // catalogue pages
  var RESOLVE_TTL = 6 * 60 * 1000;    // resolved routes (below token TTL)
  var NEG_TTL = 25 * 1000;            // negative results
  var INTERNAL_DEADLINE = 15000;      // < tester 20s cap, app 30s budget

  var PAGES = Object.create(null);    // url -> {at, text}
  var RESOLVE = Object.create(null);  // key -> {at, data}
  var NEG = Object.create(null);      // key -> {at, msg}
  var INFLIGHT = Object.create(null);// key -> Promise
  var IMG_CACHE = Object.create(null);
  var VIDPOP_RETRY_AT = 0;
  var VIDPOP_CAPTION_RETRY_AT = 0;

  var ADULT_RE = /\b(porn|xxx|hentai(?!.*\bno\b)|jav\b|adult[\s-]?video)\b/i;

  /* ------------------------------------------------------------------ */
  /* Utilities                                                          */
  /* ------------------------------------------------------------------ */

  function now() {
    return typeof Date !== 'undefined' && Date.now ? Date.now() : new Date().getTime();
  }

  function log(msg) {
    try {
      if (typeof console !== 'undefined' && console.log) console.log('[moviedb] ' + msg);
    } catch (_) {}
  }

  // Portable sleep: resolve the timer through the scope first (the Node
  // sandbox leaves globalThis an empty object; the app runtime has it bare).
  function sleep(ms) {
    var wait = Math.max(0, Number(ms) || 0);
    if (wait <= 0) return Promise.resolve();
    return new Promise(function (resolve) {
      var timer = null;
      try {
        if (typeof setTimeout === 'function') timer = setTimeout;
      } catch (_) {}
      if (!timer) {
        try {
          if (typeof globalThis !== 'undefined' && globalThis && typeof globalThis.setTimeout === 'function') {
            timer = globalThis.setTimeout;
          }
        } catch (_) {}
      }
      if (!timer) {
        resolve();
        return;
      }
      timer(function () {
        resolve();
      }, wait);
    });
  }

  function enc(s) {
    try {
      return encodeURIComponent(String(s || ''));
    } catch (_) {
      return String(s || '').replace(/[^A-Za-z0-9._~-]/g, function (ch) {
        return '%' + ch.charCodeAt(0).toString(16).toUpperCase();
      });
    }
  }

  function cleanText(s) {
    return String(s || '')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#0?39;/g, "'")
      .replace(/&apos;/g, "'")
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, function (_, n) {
        var code = parseInt(n, 10);
        return code >= 32 && code < 0x10000 ? String.fromCharCode(code) : ' ';
      })
      .replace(/\s+/g, ' ')
      .trim();
  }

  function absUrl(u) {
    var s = String(u || '').trim();
    if (!s) return '';
    if (s.indexOf('//') === 0) return 'https:' + s;
    if (s.indexOf('http') === 0) return s;
    if (s.charAt(0) === '/') return SITE + s;
    return SITE + '/' + s;
  }

  function decodeAmp(s) {
    // Attribute values in HTML carry &amp; for &, &#38; numerics too.
    return String(s || '')
      .replace(/&amp;/g, '&')
      .replace(/&#38;/g, '&')
      .replace(/&#x26;/gi, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#x27;/gi, "'");
  }

  /* ------------------------------------------------------------------ */
  /* HTTP (ported wrapper: fetchv2 -> text/body/json fallthrough,         */
  /* because JSON responses arrive with an empty body and only json())    */
  /* ------------------------------------------------------------------ */

  async function request(url, options) {
    var cfg = options || {};
    var method = cfg.method || 'GET';
    var headers = Object.assign({ 'User-Agent': USER_AGENT }, cfg.headers || {});
    var body = cfg.body === undefined ? null : cfg.body; // NEVER '' on GET

    if (typeof fetchv2 === 'function') {
      var res = await fetchv2(url, headers, method, body, {
        followRedirects: cfg.followRedirects !== false,
        maxBytesHint: cfg.maxBytesHint,
        timeoutMs: cfg.timeoutMs,
      });
      var textBody = '';
      if (res && typeof res.text === 'function') {
        try {
          textBody = await res.text();
        } catch (_) {
          textBody = '';
        }
      } else if (res && typeof res.body === 'string') {
        textBody = res.body;
      }
      var jsonBody = res && typeof res.json === 'object' ? res.json : null;
      if (textBody) {
        try {
          jsonBody = JSON.parse(textBody);
        } catch (_) {}
      }
      if (jsonBody === null && res && typeof res.json === 'function') {
        try {
          jsonBody = await res.json();
        } catch (_) {}
      }
      var ok = !!(res && (res.ok || (res.status >= 200 && res.status < 300)));
      return {
        ok: ok,
        status: Number((res && res.status) || 0),
        text: textBody || '',
        json: jsonBody,
        headers: (res && res.headers) || {},
        finalUrl: (res && (res.finalUrl || res.url)) || url,
      };
    }

    if (typeof fetch === 'function') {
      var res2 = await fetch(url, {
        method: method,
        headers: headers,
        body: body,
        redirect: cfg.followRedirects === false ? 'manual' : 'follow',
      });
      var t2 = await res2.text();
      var j2 = null;
      try {
        j2 = JSON.parse(t2);
      } catch (_) {}
      return {
        ok: res2.ok,
        status: Number(res2.status || 0),
        text: t2 || '',
        json: j2,
        headers: {},
        finalUrl: res2.url || url,
      };
    }

    throw new Error('No HTTP transport available (fetchv2/fetch missing)');
  }

  async function fetchPage(url) {
    var hit = PAGES[url];
    if (hit && now() - hit.at < PAGE_TTL) return hit.text;
    var res = await request(url, { headers: siteHeaders() });
    if (!res.ok && res.status !== 0) {
      // 404 -> honest miss; let caller decide
      if (hit) return hit.text;
      throw new Error('MovieDB page HTTP ' + res.status + ' for ' + url);
    }
    var text = res.text || '';
    if (text.length > 1500) PAGES[url] = { at: now(), text: text };
    return text;
  }

  /* ------------------------------------------------------------------ */
  /* Reference parsing (accepts bare, URL-wrapped, and watch-URL forms)  */
  /* ------------------------------------------------------------------ */

  // mdb:movie:299536 | mdb:tv:1399:1:1 | https://www.moviedb.wiki/home/movie/299536-slug
  // https://www.moviedb.wiki/home/tv/1399-game-of-thrones | .../home/watch/movie/299536
  // .../home/watch/tv/1399/1/1 | <baseHost>/match:mdb:movie:299536  (URL-wrapped scheme)
  function parseRef(ref) {
    var s = String(ref || '');
    var m = s.match(/mdb:(movie|tv):(\d+)(?::(\d+))?(?::(\d+))?/i);
    if (m) {
      return {
        kind: m[1].toLowerCase(),
        id: m[2],
        season: m[3] ? parseInt(m[3], 10) : null,
        episode: m[4] ? parseInt(m[4], 10) : null,
      };
    }
    m = s.match(/\/home\/watch\/tv\/(\d+)(?:\/(\d+)\/(\d+))?/i);
    if (m) {
      return {
        kind: 'tv',
        id: m[1],
        season: m[2] ? parseInt(m[2], 10) : null,
        episode: m[3] ? parseInt(m[3], 10) : null,
      };
    }
    m = s.match(/\/home\/watch\/movie\/(\d+)/i);
    if (m) return { kind: 'movie', id: m[1], season: null, episode: null };
    m = s.match(/\/home\/(movie|tv)\/(\d+)(?:-([^\/?#\s]*))?/i);
    if (m) {
      return {
        kind: m[1].toLowerCase(),
        id: m[2],
        slug: m[3] || '',
        season: null,
        episode: null,
      };
    }
    return null;
  }

  function cardHref(kind, id, slug) {
    return SITE + '/home/' + kind + '/' + id + (slug ? '-' + slug : '');
  }

  /* ------------------------------------------------------------------ */
  /* Catalogue parsing (tolerant multi-shape)                            */
  /* ------------------------------------------------------------------ */

  function parseCards(html) {
    var out = [];
    var seen = Object.create(null);
    if (!html) return out;

    // Primary path: the site's own card markup —
    //   <article class=poster-card data-id=299534 data-type=movie
    //     data-title="Avengers: Endgame" data-poster="https://image.tmdb.org/t/p/w342/…">
    //   with a poster link inside. Exact titles/posters, dedup by href.
    var cardRe = /<article\b[^>]*poster-card[^>]*>([\s\S]*?)<\/article>/gi;
    var cm;
    while ((cm = cardRe.exec(html))) {
      var tagEnd = cm[0].indexOf('>');
      var tag = tagEnd >= 0 ? cm[0].slice(0, tagEnd + 1) : '';
      var idM2 = tag.match(/data-id=(?:"(\d+)"|'?(\d+)'?)/);
      var typeM = tag.match(/data-type=(?:"(movie|tv)"|'?(movie|tv)'?)/i);
      // NB: the site leaves single-word attributes UNQUOTED (data-title=Colony)
      var titleM = tag.match(/data-title="([^"]*)"/) || tag.match(/data-title=([^\s>]+)/);
      var posterM = tag.match(/data-poster="([^"]*)"/) || tag.match(/data-poster=([^\s>]+)/);
      var hrefM = cm[1].match(/href="([^"]*\/home\/(?:movie|tv)\/[^"]+)"/) || tag.match(/href="([^"]+)"/);
      var id2 = idM2 ? idM2[1] || idM2[2] : null;
      if (!id2 || !titleM) continue;
      var kind2 = typeM ? (typeM[1] || typeM[2]).toLowerCase() : null;
      if (!kind2 && hrefM) {
        var hk = hrefM[1].match(/\/home\/(movie|tv)\//i);
        kind2 = hk ? hk[1].toLowerCase() : null;
      }
      if (!kind2) continue;
      var slug2 = hrefM ? (hrefM[1].match(/\/home\/(?:movie|tv)\/\d+-([^"\/?#]*)/) || [])[1] || '' : '';
      var hrefKey2 = '/home/' + kind2 + '/' + id2;
      if (seen[hrefKey2]) continue;
      seen[hrefKey2] = true;
      out.push({
        href: cardHref(kind2, id2, slug2),
        title: cleanText(titleM[1]),
        image: posterM ? absUrl(decodeAmp(posterM[1])) : '',
        year: null,
        kind: kind2,
        tmdbId: id2,
      });
    }

    var aRe = /<a\b([^>]*)href="([^"]+)"([^>]*)>/gi;
    var m;
    var starts = [];
    while ((m = aRe.exec(html))) {
      starts.push({ index: m.index, end: aRe.lastIndex, attrs: m[1] + ' ' + m[3], href: decodeAmp(m[2]) });
    }

    for (var i = 0; i < starts.length; i++) {
      var h = starts[i].href || '';
      var kind = null;
      var idM = h.match(/\/home\/(movie|tv)\/(\d+)(?:-([^\/?#"]*))?/i);
      if (idM) {
        kind = idM[1].toLowerCase();
      }
      if (!kind) continue;
      if (/\/home\/watch\//i.test(h)) continue;

      var hrefKey = '/home/' + kind + '/' + idM[2];
      if (seen[hrefKey]) continue;

      // inner HTML: from this anchor tag to its closing </a> (bounded)
      var chunk = html.slice(starts[i].end, Math.min(html.length, starts[i].end + 2500));
      var closeIdx = chunk.search(/<\/a>/i);
      if (closeIdx >= 0) chunk = chunk.slice(0, closeIdx);

      var img = '';
      var imgM = chunk.match(/<img\b[^>]*>/i);
      if (imgM) {
        // Rocket-Loader keeps the real URL in data-pagespeed-lazy-src while
        // src points at a placeholder gif — prefer the lazy attribute.
        var srcM = imgM[0].match(/(?:data-pagespeed-lazy-src|data-src|data-lazy-src|data-original|src)="([^"]+)"/i);
        if (srcM) img = decodeAmp(srcM[1]);
      }
      if (!img) {
        // image sometimes precedes the anchor (card wrapper layouts)
        var pre = html.slice(Math.max(0, starts[i].index - 900), starts[i].index);
        var preImg = pre.match(/<img\b[^>]*>/gi);
        if (preImg && preImg.length) {
          var last = preImg[preImg.length - 1];
          var srcM2 = last.match(/(?:data-pagespeed-lazy-src|data-src|data-lazy-src|data-original|src)="([^"]+)"/i);
          if (srcM2) img = decodeAmp(srcM2[1]);
        }
      }
      if (img && img.indexOf('/pagespeed_static/') >= 0) img = ''; // placeholder, not artwork

      var title = '';
      var tAttr = starts[i].attrs.match(/title="([^"]*)"/i);
      if (tAttr && cleanText(tAttr[1])) title = cleanText(tAttr[1]);
      if (!title && imgM) {
        var altM = imgM[0].match(/alt="([^"]*)"/i);
        if (altM) title = cleanText(altM[1]);
      }
      if (!title) title = cleanText(chunk);
      title = title.replace(/\s*\((19|20)\d{2}\)\s*$/, function (w) { return w; });
      if (!title || title.length < 2) continue;

      var yearM = (starts[i].attrs + ' ' + chunk).match(/\b(19|20)\d{2}\b/);
      var slug = idM[3] || '';

      seen[hrefKey] = true;
      out.push({
        href: cardHref(kind, idM[2], slug),
        title: title,
        image: img ? absUrl(img) : '',
        year: yearM ? parseInt(yearM[0], 10) : null,
        kind: kind,
        tmdbId: idM[2],
      });
    }
    return out;
  }

  function filterAdult(cards) {
    var out = [];
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i];
      if (!c) continue;
      if (ADULT_RE.test(c.title || '') || ADULT_RE.test(c.href || '')) continue;
      out.push(c);
    }
    return out;
  }

  function toCards(items, cap) {
    var out = [];
    var seen = Object.create(null);
    for (var i = 0; i < items.length && out.length < (cap || 40); i++) {
      var it = items[i];
      if (!it || !it.href || seen[it.href]) continue;
      seen[it.href] = true;
      out.push({ href: it.href, title: it.title, image: it.image || '' });
    }
    return out;
  }

  function parseHomeSections(html) {
    var sections = [];
    if (!html) return sections;
    var headRe = /<h[1-4][^>]*>([\s\S]{0,140}?)<\/h[1-4]>/gi;
    var heads = [];
    var hm;
    while ((hm = headRe.exec(html))) {
      heads.push({ index: hm.index, end: headRe.lastIndex, title: cleanText(hm[1]) });
    }
    if (!heads.length) {
      var all = filterAdult(parseCards(html));
      if (all.length) sections.push({ title: 'Trending', items: all, viewAll: '' });
      return sections;
    }
    // content before the first heading (hero area) — useful when the first
    // rail has no <h> of its own
    if (heads[0].index > 4000) {
      var pre = filterAdult(parseCards(html.slice(0, heads[0].index)));
      if (pre.length >= 4) sections.push({ title: 'Featured', items: pre, viewAll: '' });
    }
    for (var i = 0; i < heads.length; i++) {
      var start = heads[i].end;
      var stop = i + 1 < heads.length ? heads[i + 1].index : Math.min(html.length, start + 60000);
      var body = html.slice(start, stop);
      var cards = filterAdult(parseCards(body));
      if (cards.length < 3) continue;
      var title = heads[i].title || 'Featured';
      if (title.length > 80) title = title.slice(0, 80);
      // skip tiny/pagination/nav blocks mis-detected as rails
      if (/^(home|movies|tv shows|genres?|search|login|sign up)$/i.test(title) && cards.length < 8) continue;
      var viewAll = '';
      var vaHead = body.slice(0, 2200); // view-all sits in the rail's head block
      // NB: the site's HTML uses UNQUOTED attributes (class=view-all); href is quoted.
      var vaM = vaHead.match(/<a\b[^>]*view-all[^>]*href="([^"]+)"/i);
      if (!vaM) vaM = vaHead.match(/<a\b[^>]*href="([^"]+)"[^>]*view-all[^>]*>/i);
      if (vaM) viewAll = decodeAmp(vaM[1]);
      sections.push({ title: title, items: cards, viewAll: viewAll });
    }
    return sections;
  }

  /* ---- feed registry (viewAll links -> paginated site pages) -------------- */

  var FEEDS = Object.create(null); // feedId -> site-relative href (paginatable)

  function fnv1a(s) {
    var h = 0x811c9dc5;
    for (var i = 0; i < String(s).length; i++) {
      h = (h ^ String(s).charCodeAt(i)) >>> 0;
      if (typeof Math.imul === 'function') h = Math.imul(h, 16777619) >>> 0;
      else h = ((h * 16777619) >>> 0);
    }
    return h >>> 0;
  }

  function feedIdFor(href) {
    return 'f' + fnv1a(href).toString(36);
  }

  function registerFeedViews(sections) {
    for (var i = 0; i < sections.length; i++) {
      var va = sections[i].viewAll;
      if (!va) continue;
      var href = String(va).trim();
      if (!href || /^(javascript:|#)/i.test(href)) continue;
      FEEDS[feedIdFor(href)] = href;
    }
  }

  function pagedUrl(href, page) {
    var h = String(href || '');
    if (h.indexOf('http') !== 0) h = SITE + (h.charAt(0) === '/' ? h : '/' + h);
    var joiner = h.indexOf('?') >= 0 ? '&' : '?';
    return h + joiner + 'page=' + Math.max(1, parseInt(page || 1, 10) || 1);
  }

  function sectionId(title, idx) {
    var s = String(title || 'section').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
    if (!s || s.length > 40) s = 'section';
    return s.slice(0, 48) + '-' + idx;
  }

  /* ------------------------------------------------------------------ */
  /* Details parsing                                                    */
  /* ------------------------------------------------------------------ */

  function metaContent(html, nameOrProp) {
    var esc = nameOrProp.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var re = new RegExp(
      '<meta[^>]+(?:name|property)=["\']' + esc + '["\'][^>]*content=["\']([^"\']*)["\']',
      'i'
    );
    var m = html.match(re);
    if (m) return decodeAmp(m[1]);
    var re2 = new RegExp(
      '<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:name|property)=["\']' + esc + '["\']',
      'i'
    );
    var m2 = html.match(re2);
    return m2 ? decodeAmp(m2[1]) : '';
  }

  function jsonLdBlocks(html) {
    var out = [];
    var re = /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
    var m;
    while ((m = re.exec(html))) {
      try {
        out.push(JSON.parse(m[1]));
      } catch (_) {}
    }
    return out;
  }

  function ldFind(blocks, predicate) {
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      var list = Array.isArray(b) ? b : [b];
      for (var j = 0; j < list.length; j++) {
        var v = list[j];
        if (v && predicate(v)) return v;
        if (v && v['@graph'] && Array.isArray(v['@graph'])) {
          for (var k = 0; k < v['@graph'].length; k++) {
            if (v['@graph'][k] && predicate(v['@graph'][k])) return v['@graph'][k];
          }
        }
      }
    }
    return null;
  }

  // Deterministic extraction of a <p class=...cls...>…</p> by the class
  // fragment. (A raw regex with [^"']* bounds slides past the tag when the
  // paragraph text or later markup contains quotes — walk the tag instead.)
  function extractClassParagraph(html, cls) {
    var from = 0;
    while (true) {
      var idx = html.indexOf(cls, from);
      if (idx < 0) return '';
      var start = html.lastIndexOf('<p', idx);
      var tagEnd = html.indexOf('>', start);
      if (start >= 0 && tagEnd > start && idx < tagEnd) {
        var endTag = html.indexOf('</p>', tagEnd);
        if (endTag > tagEnd && endTag - tagEnd < 6000) {
          var text = cleanText(html.slice(tagEnd + 1, endTag));
          if (text.length > 30) return text;
        }
      }
      from = idx + cls.length;
    }
  }

  function parseTitleData(html) {
    var m = html.match(/<script[^>]*id=["']?titleData["']?[^>]*>([\s\S]*?)<\/script>/i);
    if (!m) return null;
    try {
      return JSON.parse(m[1]);
    } catch (_) {
      return null;
    }
  }

  function parseDetailsPage(html, ref) {
    var out = { title: '', description: '', image: '', year: null, genres: [] };
    var ldBlocks = jsonLdBlocks(html);
    var ld = ldFind(ldBlocks, function (v) {
      var t = String(v['@type'] || '');
      return t === 'Movie' || t === 'TVSeries' || t === 'TVShow' || t === 'CreativeWork';
    });
    var td = parseTitleData(html);

    var ogTitle = metaContent(html, 'og:title');
    var titleTag = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '';
    var h1 = (html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '';
    var title = cleanText((td && td.title) || (ld && ld.name) || ogTitle || h1 || titleTag);
    title = title.replace(/\s*[|\-–]\s*(MovieDB|moviedb\.wiki|Watch.*)\s*$/i, '').trim();
    out.title = title;

    var desc = '';
    // the site's own untruncated overview beats og/JSON-LD (both get ellipsised)
    desc = extractClassParagraph(html, 'detail-overview');
    if (!desc && ld && typeof ld.description === 'string') desc = cleanText(ld.description);
    if (!desc || desc.length < 40) {
      var ogDesc = metaContent(html, 'og:description') || metaContent(html, 'description');
      if (ogDesc && cleanText(ogDesc).length > (desc ? desc.length : 0)) desc = cleanText(ogDesc);
    }
    if (!desc || desc.length < 40) {
      var pRe = /<p\b[^>]*>([\s\S]*?)<\/p>/gi;
      var pm;
      while ((pm = pRe.exec(html))) {
        var cand = cleanText(pm[1]);
        if (cand.length > 120 && !/cookie|javascript|subscribe|sign in|dmca|disclaimer/i.test(cand)) {
          desc = cand;
          break;
        }
      }
    }
    out.description = desc || '';

    var img = '';
    if (td && td.poster) {
      img = String(td.poster);
      if (img.indexOf('http') !== 0 && img.charAt(0) === '/') img = 'https://image.tmdb.org/t/p/w500' + img;
      if (img.indexOf('//') === 0) img = 'https:' + img;
    }
    if (!img) img = metaContent(html, 'og:image');
    if (!img && ld && ld.image) {
      img = typeof ld.image === 'string' ? ld.image : (ld.image && ld.image.url) || '';
    }
    if (!img) {
      var im = html.match(/<img\b[^>]*class="[^"]*(?:poster|cover|backdrop)[^"]*"[^>]*>/i);
      if (im) {
        var srcM = im[0].match(/(?:data-src|src)="([^"]+)"/i);
        if (srcM) img = srcM[1];
      }
    }
    out.image = img ? absUrl(img) : '';

    var yearM = String((ld && ld.datePublished) || '').match(/\b(19|20)\d{2}\b/);
    if (!yearM) yearM = cleanText(html.slice(0, 20000)).match(/\b(19|20)\d{2}\b/);
    out.year = yearM ? parseInt(yearM[0], 10) : null;

    if (ld && ld.genre) {
      out.genres = Array.isArray(ld.genre) ? ld.genre.slice(0, 8) : [String(ld.genre)];
    }
    return out;
  }

  function parseSeasons(html) {
    // Season picker: <select ... data-tv-id="1399"> <option ...>Season 1 (10 eps)</option>
    var seasons = [];
    var seen = Object.create(null);
    var selM = html.match(/<select\b[^>]*data-tv-id=["']\d+["'][^>]*>([\s\S]*?)<\/select>/i);
    var scopes = [];
    if (selM) scopes.push(selM[1]);
    // secondary: labelled "Season 1 (10 eps)" anywhere
    scopes.push(html);

    for (var s = 0; s < scopes.length; s++) {
      var optRe = /<option\b([^>]*)>([\s\S]*?)<\/option>/gi;
      var om;
      while ((om = optRe.exec(scopes[s]))) {
        var attrs = om[1] || '';
        var label = cleanText(om[2]);
        var num = null;
        var nM = label.match(/season\s*(\d+)/i) || attrs.match(/data-season-number=["']?(\d+)/i) || attrs.match(/value=["']?(\d+)/i);
        if (nM) num = parseInt(nM[1], 10);
        if (!num && /^\d+$/.test(label.trim())) num = parseInt(label.trim(), 10);
        if (!num) continue;
        var cntM = label.match(/\((\d+)\s*eps?\)/i) || attrs.match(/data-episode-count=["']?(\d+)/i) || attrs.match(/data-count=["']?(\d+)/i);
        var count = cntM ? parseInt(cntM[1], 10) : null;
        if (seen[num]) continue;
        seen[num] = true;
        seasons.push({ season: num, count: count });
      }
      if (seasons.length) break;
    }
    // tertiary: JSON-LD seasons array
    if (!seasons.length) {
      var ldBo = jsonLdBlocks(html);
      var ldS = ldFind(ldBo, function (v) {
        return v && Array.isArray(v.seasons);
      });
      if (ldS) {
        for (var q = 0; q < ldS.seasons.length; q++) {
          var sn = ldS.seasons[q];
          if (!sn) continue;
          var snm = parseInt(sn.season_number, 10);
          if (!snm || seen[snm]) continue;
          seen[snm] = true;
          seasons.push({ season: snm, count: sn.episode_count ? parseInt(sn.episode_count, 10) : null });
        }
      }
    }
    seasons.sort(function (a, b) {
      return a.season - b.season;
    });
    return seasons;
  }

  /* ------------------------------------------------------------------ */
  /* VidLove resolve engine                                             */
  /* ------------------------------------------------------------------ */

  function parseManifest(text) {
    // returns {variants: [{height,width,bandwidth,codecs,url}], hasSegments}
    var out = { variants: [], hasSegments: false };
    if (!text || text.indexOf('#EXTM3U') < 0) return null;
    var lines = text.split(/\r?\n/);
    var pending = null;
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i].trim();
      if (!ln) continue;
      if (ln.indexOf('#EXT-X-STREAM-INF:') === 0) {
        pending = ln.slice('#EXT-X-STREAM-INF:'.length);
        continue;
      }
      if (ln.charAt(0) === '#') {
        if (ln.indexOf('#EXTINF:') === 0) out.hasSegments = true;
        continue;
      }
      if (pending !== null) {
        var h = 0;
        var w = 0;
        var bw = 0;
        var rM = pending.match(/RESOLUTION=(\d+)x(\d+)/i);
        if (rM) {
          w = parseInt(rM[1], 10);
          h = parseInt(rM[2], 10);
        }
        var bM = pending.match(/BANDWIDTH=(\d+)/i);
        if (bM) bw = parseInt(bM[1], 10);
        var cM = pending.match(/CODECS="([^"]*)"/i);
        out.variants.push({ width: w, height: h, bandwidth: bw, codecs: cM ? cM[1] : '', url: ln });
        pending = null;
      } else {
        // URL with no STREAM-INF => looked like a media playlist line
        out.hasSegments = true;
      }
    }
    return out;
  }

  function qualityLabel(w, h) {
    if (h > 0) return String(h) + 'p';
    if (w > 0) {
      if (w >= 1800) return '1080p';
      if (w >= 1200) return '720p';
      if (w >= 900) return '540p';
      if (w >= 600) return '480p';
      if (w >= 400) return '360p';
      return 'Auto';
    }
    return 'Auto';
  }

  function sniffMedia(head) {
    if (!head || typeof head !== 'string' || head.length < 4) return null;
    var c0 = head.charCodeAt(0);
    // fetchv2 decodes bytes as UTF-8, so packet offsets cannot be validated
    // here. Reject printable errors; this is a binary hint, not decode proof.
    var binaryHint = /[\x00-\x08\x0e-\x1f\ufffd]/.test(head.slice(0, 480));
    if (c0 === 71 && head.length >= 188 && binaryHint) return 'ts';
    var probe = head.slice(0, 480);
    var b2 = head.charCodeAt(2), b3 = head.charCodeAt(3);
    var boxSize = b2 * 256 + b3;
    if (c0 === 0 && head.charCodeAt(1) === 0 && b2 <= 255 && b3 <= 255 &&
        boxSize >= 8 && /^(?:ftyp|styp|moof)$/.test(probe.slice(4, 8))) return 'mp4';
    if (c0 === 60) return 'html';
    var t = head.slice(0, 40).trim();
    if (t.charAt(0) === '{' || t.charAt(0) === '[') return 'json';
    return null;
  }


  // Faststart MP4s carry the video track's pixel height as a 16.16 fixed-point value inside
  // the 'tkhd' box near the file start — inside the same Range: bytes=0-65535 window the
  // route probe already fetches. fetchv2 decodes the body as UTF-8, so only bytes <0x80
  // survive intact: a height like 1080 (0x0438) always does, while widths containing 0x80
  // may not — hence height-only, with a small ±16 window to absorb decode drift and a
  // plausibility gate (integral 16.16, 144..5000) so matrix noise cannot false-positive.
  function mp4VideoDims(head) {
    if (!head || typeof head !== 'string' || head.length < 256) return null;
    var pos = head.indexOf('tkhd');
    while (pos >= 4) {
      var ver = head.charCodeAt(pos + 4);
      if ((ver === 0 || ver === 1) && pos + 104 <= head.length) {
        var base = pos + (ver === 1 ? 96 : 84);
        for (var off = base; off <= base + 16; off += 4) {
          var u = ((head.charCodeAt(off) << 24) | (head.charCodeAt(off + 1) << 16) |
                   (head.charCodeAt(off + 2) << 8) | head.charCodeAt(off + 3)) >>> 0;
          if (u % 65536 === 0) {
            var hh = u / 65536;
            if (hh >= 144 && hh <= 5000) return { height: Math.round(hh) };
          }
        }
      }
      pos = head.indexOf('tkhd', pos + 4);
    }
    return null;
  }

  // True when a response's own content-type says audio/video — the last signal
  // for direct media when the bridge dropped an over-cap body before any bytes.
  function responseIsVideo(res) {
    var rh = (res && res.headers) || {};
    for (var hk in rh) {
      if (String(hk).toLowerCase() === 'content-type' && /^(?:video|audio)\//i.test(String(rh[hk]))) return true;
    }
    return false;
  }

  function absorbAgainst(base, rel) {
    if (!rel) return '';
    if (rel.indexOf('http') === 0) return rel;
    if (rel.indexOf('//') === 0) return 'https:' + rel;
    var m = String(base || '').match(/^(https?:\/\/[^\/]+)(\/.*)?$/);
    if (!m) return rel;
    var origin = m[1];
    var path = m[2] || '/';
    if (rel.charAt(0) === '/') return origin + rel;
    var dir = path.replace(/[^\/]*$/, '');
    return origin + dir + rel;
  }

  // (aliased helper name used by the route walkers below)
  function absAgainst(base, rel) {
    return absorbAgainst(base, rel);
  }

  async function probeSegment(segUrl, headers) {
    var res = await request(segUrl, {
      headers: Object.assign({}, headers || streamHeaders(), { Range: 'bytes=0-4095' }),
      maxBytesHint: 4 * 1024 * 1024,
    });
    if (!res.ok && res.status >= 400) return { ok: false, why: 'http ' + res.status };
    var responseHeaders = res.headers || {};
    if (/^(?:GIF8|\x89PNG|\xff\xd8\xff)/.test(res.text || '')) return { ok: false, why: 'image bytes' };
    var kind = sniffMedia(res.text || '');
    if (kind === 'ts' || kind === 'mp4') return { ok: true, kind: kind };
    // Byte-first: a misleading content-type or suffix must not discard real media.
    // Reject on image/* labels only after the bytes showed no media signature.
    for (var key in responseHeaders) {
      if (key.toLowerCase() === 'content-type' && /^image\//i.test(String(responseHeaders[key]))) return { ok: false, why: 'image segment response' };
    }
    return { ok: false, why: kind || 'unknown bytes' };
  }

  async function requestPlaylist(url, headers, deadline) {
    var res = await request(url, { headers: headers, maxBytesHint: 4 * 1024 * 1024 });
    // The source intermittently returns 5xx for a valid playlist. One bounded
    // retry avoids discarding that rung; never retry access/rate-limit errors.
    if (res.status >= 500 && res.status <= 599 && now() + 350 < deadline) {
      await sleep(250);
      res = await request(url, { headers: headers, maxBytesHint: 4 * 1024 * 1024 });
    }
    return res;
  }

  // Walk a playlist route: master -> variant -> segment, byte-verified.
  // Handles direct media playlists (relative segments resolved) too.
  async function probeRoute(srcUrl, headers, deadline) {
    if (now() > deadline) return null;
    var text = '';
    var isVideoCT = false;
    try {
      /* Range-first: VidLove's moviebox flavor serves some titles as plain MP4 (The Mentalist
       * S1E1 = a 626 MB video/mp4) and the bridge DROPS an over-cap body, so never drag one
       * through the client. 64 KB of a playlist still parses; 64 KB of an MP4 still carries
       * ftyp/moof. CDNs that reject Range fall back to a plain fetch below. */
      var rOpts = { headers: Object.assign({}, headers || {}, { Range: 'bytes=0-65535' }), maxBytesHint: 4 * 1024 * 1024 };
      var res = await request(srcUrl, rOpts);
      if (res.status >= 500 && res.status <= 599 && now() + 350 < deadline) {
        await sleep(250);
        res = await request(srcUrl, rOpts);
      }
      text = res.ok || res.status === 206 ? res.text || '' : '';
      if (!text && (res.status === 403 || res.status === 401)) return null;
      isVideoCT = responseIsVideo(res);
      if (!text && !isVideoCT && now() + 500 < deadline) {
        var pOpts = { headers: headers || {}, maxBytesHint: 4 * 1024 * 1024 };
        var res2 = await request(srcUrl, pOpts);
        text = res2.ok || res2.status === 206 ? res2.text || '' : '';
        isVideoCT = isVideoCT || responseIsVideo(res2);
      }
    } catch (e) {
      return null;
    }
    var man = parseManifest(text);
    if (!man) {
      /* Not a playlist: decide by bytes (4 KB probe), then by content-type for the case where
       * the bridge dropped the body BEFORE any bytes reached the module. */
      var sn = sniffMedia(text);
      var pr = null;
      if (sn !== 'mp4' && sn !== 'ts') {
        try {
          pr = await probeSegment(srcUrl, headers);
        } catch (e2) {
          pr = null;
        }
      }
      var kind = sn === 'mp4' || sn === 'ts' ? sn : pr && pr.ok ? pr.kind : null;
      if (!kind && isVideoCT) kind = 'mp4';
      if (!kind) return null;
      // A direct file has no ladder; read its REAL resolution from the already-fetched bytes so
      // the quality menu shows e.g. 1080p instead of a generic 'Auto' (owner report: The Mentalist).
      var directDims = kind === 'mp4' ? mp4VideoDims(text) : null;
      return {
        variants: [{ width: 0, height: directDims ? directDims.height : 0, bandwidth: 0, codecs: '', url: srcUrl, direct: true }],
        probed: { kind: kind, url: srcUrl },
      };
    }
    var variants = (man.variants || []).slice();
    // Master playlists may carry RELATIVE variant paths (vidzen sv-pi does);
    // normalize them against the master URL — the app needs absolute URLs.
    for (var nv = 0; nv < variants.length; nv++) {
      if (variants[nv] && variants[nv].url) {
        variants[nv] = Object.assign({}, variants[nv], { url: absAgainst(srcUrl, variants[nv].url) });
      }
    }
    if (!variants.length && man.hasSegments) {
      variants = [{ width: 0, height: 0, bandwidth: 0, codecs: '', url: srcUrl, direct: true }];
    }
    if (!variants.length) return null;
    variants.sort(function (a, b) {
      return (b.bandwidth || b.width * b.height) - (a.bandwidth || a.width * a.height);
    });
    var probed = null;
    var verified = [];
    for (var vi = 0; vi < variants.length && vi < 8; vi++) {
      if (now() > deadline) break;
      var vUrl = variants[vi].url;
      var vText = '';
      var vres = null;
      if (variants[vi].direct) {
        vText = text;
      } else {
        try {
          vres = await requestPlaylist(vUrl, headers, deadline);
          vText = vres.ok ? vres.text || '' : '';
        } catch (e) {
          vText = '';
        }
      }
      if (vText.indexOf('#EXTM3U') < 0) {
        /* A variant can answer with DIRECT media instead of a sub-playlist. Never
         * format-gate a playable file: classify by bytes, then by the response
         * content-type when the body was dropped, and keep it as a verified route. */
        var dSn = sniffMedia(vText);
        var dOk = dSn === 'ts' || dSn === 'mp4';
        if (!dOk && dSn !== 'html' && dSn !== 'json') {
          try {
            var dPr = await probeSegment(vUrl, headers);
            if (dPr && dPr.ok) {
              dOk = true;
              dSn = dPr.kind;
            }
          } catch (e2) {
            dOk = false;
          }
        }
        if (!dOk && !vText && responseIsVideo(vres)) {
          dOk = true;
          dSn = 'mp4';
        }
        if (dOk) {
          if (!probed) probed = { kind: dSn, url: vUrl };
          var kept = Object.assign({}, variants[vi], { url: vUrl, direct: true });
          if (dSn === 'mp4' && !kept.height) {
            var dDims = mp4VideoDims(vText);
            if (dDims) kept.height = dDims.height;
          }
          verified.push(kept);
        }
        continue;
      }
      var segM = vText.match(/#EXTINF[^\n]*\n([^\n#][^\n]*)/);
      if (!segM) continue;
      var segUrl = absAgainst(vUrl, segM[1].trim());
      var probe = null;
      try {
        probe = await probeSegment(segUrl, headers);
      } catch (e) {
        probe = { ok: false, why: 'probe error' };
      }
      if (probe && probe.ok) {
        if (!probed) probed = { kind: probe.kind, url: vUrl };
        verified.push(variants[vi]);
      }
    }
    // Never select a failed high rung just because a lower rung worked.
    return verified.length ? { variants: verified, probed: probed } : null;
  }

  function hasSubs(data) {
    return !!(data && data.subtitles && data.subtitles.length);
  }

  // VidLove attempt with the flaky-subtitle retry (the API intermittently
  // answers 0 tracks for the same item; a second fresh call often fills them).
  async function vidloveAttempt(ref, key, deadline) {
    var data = await callApi(ref, key, deadline);
    if (!data) return null;
    var retryP = null;
    if (!hasSubs(data) && now() < deadline) {
      retryP = callApi(ref, key, deadline);
    }
    var ok = await validateSource(data, deadline);
    if (!ok) return null;
    if (retryP) {
      try {
        // Subtitle enrichment must not consume the entire playback budget.
        var d2 = await Promise.race([
          retryP,
          sleep(Math.min(250, Math.max(0, deadline - now()))).then(function () { return null; }),
        ]);
        if (d2 && hasSubs(d2)) ok.subs = mapSubs(d2.subtitles);
      } catch (_) {}
    }
    return ok;
  }

  // Independent second provider (vidzen.fun): plain JSON, ready playlist,
  // per-source Referer. Ranked #1 in the 2026-09-22 roster probe.
  async function vidzenAttempt(ref, server, deadline) {
    if (now() > deadline) return null;
    var vu = VIDZEN + '/api/sources?type=' + enc(ref.kind) + '&id=' + enc(ref.id);
    if (ref.kind === 'tv') vu += '&season=' + enc(ref.season || 1) + '&episode=' + enc(ref.episode || 1);
    vu += '&server=' + enc(server) + '&renew=true';
    var res;
    try {
      res = await request(vu, {
        headers: {
          'User-Agent': USER_AGENT,
          Referer: VIDZEN + '/' + (ref.kind === 'tv' ? 'tv' : 'movie') + '/' + ref.id,
          Origin: VIDZEN,
          Accept: 'application/json',
        },
      });
    } catch (e) {
      return null;
    }
    if (!res.ok || !res.json) return null;
    var list = res.json.sources;
    var entry = null;
    if (Array.isArray(list)) {
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].url) {
          entry = list[i];
          break;
        }
      }
    }
    if (!entry) return null;
    var srcUrl = String(entry.url);
    if (srcUrl.indexOf('http') !== 0) {
      // sv-pi returns paths relative to vidzen.fun (e.g. /api/stream/<token>)
      srcUrl = absAgainst(VIDZEN + '/', srcUrl);
    }
    if (srcUrl.indexOf('http') !== 0) return null;
    var referer = String(entry._referer || '');
    var hdr = {
      'User-Agent': USER_AGENT,
      Referer: referer ? absAgainst(VIDZEN + '/', referer) : VIDZEN + '/',
    };
    var pr = await probeRoute(srcUrl, hdr, deadline);
    if (!pr) return null;
    var label = String(entry.label || 'VidZen ' + server);
    if (pr.variants.length === 1 && !pr.variants[0].height) {
      var hl = label.match(/(\d{3,4})p/i);
      if (hl) pr.variants[0].height = parseInt(hl[1], 10);
    }
    return {
      variants: pr.variants,
      masterUrl: srcUrl,
      subs: mapSubs(res.json.subtitles),
      srcName: 'VidZen · ' + label,
      headers: hdr,
      probed: pr.probed,
    };
  }

  // Validate one VidLove source payload -> route object or null
  async function validateSource(data, deadline) {
    var srcUrl = String((data.source && data.source.url) || '');
    var srcName = 'VidLove · ' + String((data.source && (data.source.label || data.source.source)) || 'VidAPI');
    if (!srcUrl || srcUrl.indexOf('http') !== 0) return null;

    // Structure check on the inline manifest: reject only an obvious error page.
    // A non-HLS inline payload must not discard the source — the route URL is
    // byte-verified below and direct media is a first-class route.
    var inline = typeof data.source.manifest === 'string' ? data.source.manifest : '';
    if (inline && inline.indexOf('#EXTM3U') < 0 && sniffMedia(inline) === 'html') return null;

    if (now() > deadline) return null;
    var pr = await probeRoute(srcUrl, streamHeaders(), deadline);
    if (!pr) return null;
    return {
      variants: pr.variants,
      masterUrl: srcUrl,
      subs: mapSubs(data.subtitles),
      srcName: srcName,
      probed: pr.probed,
    };
  }

  function subsLanguageMap() {
    return {
      english: 'en', arabic: 'ar', french: 'fr', spanish: 'es', italian: 'it', german: 'de',
      portuguese: 'pt', protuguese: 'pt', japanese: 'ja', korean: 'ko', chinese: 'zh',
      mandarin: 'zh', cantonese: 'zh', hindi: 'hi', turkish: 'tr', russian: 'ru',
      persian: 'fa', farsi: 'fa', dutch: 'nl', hebrew: 'he', greek: 'el', serbian: 'sr',
      croatian: 'hr', romanian: 'ro', ukrainian: 'uk', bulgarian: 'bg', hungarian: 'hu',
      czech: 'cs', slovak: 'sk', finnish: 'fi', swedish: 'sv', norwegian: 'no',
      danish: 'da', vietnamese: 'vi', thai: 'th', indonesian: 'id', malay: 'ms',
      bengali: 'bn', tamil: 'ta', telugu: 'te', urdu: 'ur', filipino: 'tl',
      tagalog: 'tl', polish: 'pl', estonian: 'et', latvian: 'lv', lithuanian: 'lt',
      slovene: 'sl', albanian: 'sq', macedonian: 'mk', georgian: 'ka', armenian: 'hy',
      azerbaijani: 'az', kazakh: 'kk', uzbek: 'uz', nepali: 'ne', sinhala: 'si',
      burmese: 'my', khmer: 'km', lao: 'lo', mongolian: 'mn', icelandic: 'is',
      irish: 'ga', welsh: 'cy', catalan: 'ca', basque: 'eu', galician: 'gl',
      malayalam: 'ml', kannada: 'kn', marathi: 'mr', punjabi: 'pa', gujarati: 'gu',
      swahili: 'sw', yoruba: 'yo', zulu: 'zu', afrikaans: 'af', amharic: 'am',
      somali: 'so', pashto: 'ps', kurdish: 'ku', bosnian: 'bs', montenegrin: 'me',
    };
  }

  function mapSubs(rawList) {
    var out = [];
    var seen = Object.create(null);
    var perLang = Object.create(null);
    var undCount = 0;
    var names = subsLanguageMap();
    var rows = Array.isArray(rawList) ? rawList : [];
    log('mapSubs in=' + rows.length);
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      if (!row || typeof row !== 'object') continue;
      var rawFile = String(row.file || row.url || row.src || '').trim();
      if (!rawFile) continue;
      var file = rawFile.indexOf('//') === 0 ? 'https:' + rawFile : rawFile.indexOf('http') === 0 ? rawFile : '';
      if (!file) continue;
      if (/\/thumbs?\/|sprite|thumbnail/i.test(file)) continue;
      if (seen[file]) continue;
      seen[file] = true;

      var raw = cleanText(row.label || row.language || row.lang || '').toLowerCase();
      var baseLang = raw.replace(/\(.*?\)/g, ' ').replace(/\s+/g, ' ').trim();
      // Providers frequently ship numbered variants: 'English2'…'English8',
      // 'English 2', 'Spanish3'. Strip the trailing number for the lookup so
      // these classify as their language (and stay EN-first).
      var baseLangNoNum = baseLang.replace(/[\s-]*\d+$/g, '').trim();
      var lang = names[raw] || names[baseLang] || names[baseLangNoNum] || (/^[a-z]{2,3}(?:[-_][a-z0-9]+)*$/i.test(baseLang) ? baseLang.replace(/_/g, '-') : 'und');
      var declaredLang = cleanText(row.language || row.lang || '').toLowerCase().replace(/_/g, '-');
      if (/^[a-z]{2,3}(?:-[a-z0-9]+)*$/.test(declaredLang)) lang = declaredLang;

      if (lang === 'und') {
        if (undCount >= 8) continue;
        undCount += 1;
      } else {
        perLang[lang] = (perLang[lang] || 0) + 1;
        if (perLang[lang] > 4) continue;
      }
      if (out.length >= 200) break;

      var captionHeaders = { 'User-Agent': USER_AGENT, Accept: 'text/vtt,text/plain,application/x-subrip,*/*' };
      if (row.headers && typeof row.headers === 'object' && !Array.isArray(row.headers)) {
        for (var headerName in row.headers) {
          var headerValue = row.headers[headerName];
          if (typeof headerValue === 'string' && /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(headerName) && !/[\r\n]/.test(headerValue) && !/^(?:host|content-length|authorization|cookie|proxy-authorization)$/i.test(headerName)) captionHeaders[headerName] = headerValue;
        }
      }
      out.push({
        label: cleanText(row.label || row.language || 'Unknown language'),
        language: lang,
        lang: lang,
        url: file,
        file: file,
        kind: 'captions',
        headers: captionHeaders,
      });
    }
    // English first, then alphabetical by label
    out.sort(function (a, b) {
      var ae = a.lang === 'en' ? 0 : 1;
      var be = b.lang === 'en' ? 0 : 1;
      if (ae !== be) return ae - be;
      return String(a.label).localeCompare(String(b.label));
    });
    return out;
  }

  async function callApi(ref, sourceKey, deadline) {
    if (now() > deadline) return null;
    var url;
    if (ref.kind === 'tv') {
      url = API + '/tv?id=' + enc(ref.id) + '&season=' + enc(ref.season || 1) + '&episode=' + enc(ref.episode || 1) + '&mode=json';
    } else {
      url = API + '/movie?id=' + enc(ref.id) + '&mode=json';
    }
    if (sourceKey) url += '&sources=' + enc(sourceKey);
    var res;
    try {
      res = await request(url, { headers: apiHeaders() });
    } catch (e) {
      log('api error ' + (e && e.message ? e.message : e));
      return null;
    }
    if (!res.ok || !res.json) {
      log('api http ' + res.status + ' key=' + (sourceKey || 'auto'));
      return null;
    }
    var data = res.json;
    if (!data || !data.source || !data.source.url) {
      log('api no source key=' + (sourceKey || 'auto'));
      return null;
    }
    log(
      'api ok key=' +
        (sourceKey || 'auto') +
        ' subs=' +
        (data.subtitles && data.subtitles.length ? data.subtitles.length : 0) +
        (data.subtitles && data.subtitles.length ? ' sub0=' + Object.keys(data.subtitles[0] || {}).join('/') : '')
    );
    return data;
  }

  function buildResult(ok, extras) {
    extras = (extras || []).slice();
    for (var ei = 0; ei < extras.length; ei++) {
      var alternate = extras[ei];
      if (alternate && alternate.variants && alternate.variants.length &&
          (alternate.variants[0].height || 0) > (ok.variants[0].height || 0)) {
        extras[ei] = ok;
        ok = alternate;
      }
    }
    var streamsArray = [];
    var qualities = [];
    var headers = ok.headers || streamHeaders();
    for (var i = 0; i < ok.variants.length; i++) {
      var v = ok.variants[i];
      var label = qualityLabel(v.width, v.height);
      // keep duplicates distinct when the source ships several same-bucket rungs
      var lbl = label;
      if (i > 0 && lbl === qualities[qualities.length - 1].label) lbl = label + ' (' + (i + 1) + ')';
      var option = {
        label: lbl,
        height: v.height || 0,
        width: v.width || 0,
        url: v.url,
        headers: headers,
      };
      streamsArray.push(lbl, v.url);
      qualities.push(option);
    }
    var primary = ok.variants[0];
    var primaryType = ok.probed && ok.probed.kind === 'mp4' ? 'mp4' : 'hls';
    var servers = [
      {
        name: ok.srcName,
        url: primary.url,
        headers: headers,
        subtitles: ok.subs || [],
        streamType: primaryType,
      },
    ];
    for (var e = 0; e < (extras || []).length; e++) {
      var x = extras[e];
      if (!x || !x.variants || !x.variants.length) continue;
      var xu = x.variants[0].url;
      var dup = false;
      for (var d = 0; d < servers.length; d++) {
        if (servers[d].url === xu) dup = true;
      }
      if (dup) continue;
      servers.push({
        name: x.srcName || 'Alternate',
        url: xu,
        headers: x.headers || headers,
        subtitles: x.subs || [],
        streamType: x.probed && x.probed.kind === 'mp4' ? 'mp4' : 'hls',
      });
    }
    return {
      url: primary.url,
      stream: primary.url,
      quality: qualityLabel(primary.width, primary.height),
      streamType: primaryType,
      streams: streamsArray,
      headers: headers,
      subtitles: ok.subs || [],
      qualities: qualities,
      servers: servers,
    };
  }

  function usableOnly(arr) {
    var out = [];
    for (var i = 0; i < (arr || []).length; i++) {
      if (arr[i]) out.push(arr[i]);
    }
    return out;
  }

  async function resolveFresh(ref) {
    var deadline = now() + INTERNAL_DEADLINE;

    // Use the player's current ordinary API before the legacy mirrors.
    // Video selection stays bounded to ten seconds; a ready video can wait for
    // its concurrent captions within the existing overall resolve deadline.
    var current = await firstUsable([vidpopAttempt(ref, Math.min(deadline, now() + 10000), deadline)], 0, deadline);
    if (current[0]) return buildResult(current[0], []);

    // A slow primary must not hide an already verified independent route.
    var initial = await firstUsable([
      vidoraAttempt(ref, deadline),
      vidloveAttempt(ref, null, deadline),
      vidzenAttempt(ref, 'sv-ps', deadline),
      vidzenAttempt(ref, 'sv-pi', deadline),
    ], 350, deadline);
    var ready = usableOnly(initial);
    if (ready.length) return buildResult(ready[0], ready.slice(1));
    if (now() >= deadline) throw new Error('MovieDB: resolve budget exceeded');

    // Additional sources start only after the initial attempts have failed.
    var batches = [SOURCE_KEYS.slice(0, 1), SOURCE_KEYS.slice(1, 4), SOURCE_KEYS.slice(4)];
    for (var b = 0; b < batches.length; b++) {
      if (now() > deadline) break;
      var settled = await firstUsable(
        batches[b].map(function (key) {
          return vidloveAttempt(ref, key, deadline);
        }),
        250,
        deadline
      );
      var successes = usableOnly(settled);
      if (successes.length) return buildResult(successes[0], successes.slice(1));
    }
    throw new Error('MovieDB: no playable stream found for this title (source-side)');
  }

  function firstUsable(promises, graceMs, deadline) {
    return new Promise(function (resolve) {
      var settled = new Array(promises.length);
      var remaining = promises.length;
      var finished = false;
      var graceTimer = null;
      var deadlineTimer = null;
      function finish() {
        if (finished) return;
        finished = true;
        // Some module runtimes expose timers without a cancellation function.
        try {
          if (typeof clearTimeout === 'function') {
            if (graceTimer !== null) clearTimeout(graceTimer);
            if (deadlineTimer !== null) clearTimeout(deadlineTimer);
          }
        } catch (_) {}
        resolve(settled.slice());
      }
      function onSettle(index, res) {
        if (finished) return;
        if (!res || !res.variants || !res.variants.length) res = null;
        settled[index] = res;
        remaining -= 1;
        if (res && res.variants && res.variants.length) {
          if (graceTimer === null) graceTimer = setTimeout(finish, Math.max(0, Number(graceMs) || 0));
          if (remaining <= 0) finish();
          return;
        }
        if (remaining <= 0) finish();
      }
      if (typeof deadline === 'number') {
        deadlineTimer = setTimeout(finish, Math.max(0, deadline - now()));
      }
      if (!remaining) finish();
      promises.forEach(function (p, index) {
        Promise.resolve(p).then(
          function (res) {
            onSettle(index, res);
          },
          function () {
            onSettle(index, null);
          }
        );
      });
    });
  }

  function resolveKey(ref) {
    return ref.kind + ':' + ref.id + (ref.kind === 'tv' ? ':' + (ref.season || 1) + ':' + (ref.episode || 1) : '');
  }

  // Background subtitle top-up: when a prefetch resolve lands with zero
  // tracks (the API's subtitle answer is flaky), quietly re-ask a couple of
  // times and patch the cached result — off the user's critical path.
  function upgradeSubsInBackground(ref, key, triesLeft, expectedData) {
    if (triesLeft <= 0) return;
    callApi(ref, null, now() + INTERNAL_DEADLINE).then(
      function (d) {
        if (d && hasSubs(d)) {
          var hit = RESOLVE[key];
          if (hit && hit.data === expectedData) hit.data.subtitles = mapSubs(d.subtitles);
        } else {
          if (RESOLVE[key] && RESOLVE[key].data === expectedData) {
            upgradeSubsInBackground(ref, key, triesLeft - 1, expectedData);
          }
        }
      },
      function () {}
    );
  }

  function resolveStream(ref, background, bypassCache) {
    var key = resolveKey(ref);
    var t = now();
    if (bypassCache === true) {
      delete RESOLVE[key];
      delete NEG[key];
      delete INFLIGHT[key];
    }
    var hit = RESOLVE[key];
    if (hit && t - hit.at < RESOLVE_TTL && (background || (hit.data.subtitles && hit.data.subtitles.length))) return Promise.resolve(hit.data);
    var cachedVideo = hit && t - hit.at < RESOLVE_TTL ? hit.data : null;
    var neg = NEG[key];
    // Prefetch failures may be cached, but an explicit user open must retry.
    if (background && neg && t - neg.at < NEG_TTL) return Promise.reject(new Error(neg.msg));
    var inflight = INFLIGHT[key];
    if (inflight) return inflight;

    var p = resolveFresh(ref).then(
      function (data) {
        // A replaced prefetch must not overwrite a newer explicit retry.
        if (INFLIGHT[key] === p) {
          RESOLVE[key] = { at: now(), data: data };
          delete NEG[key];
          delete INFLIGHT[key];
          if (background && data && (!data.subtitles || !data.subtitles.length)) {
            upgradeSubsInBackground(ref, key, 2, data);
          }
        }
        return data;
      },
      function (err) {
        if (INFLIGHT[key] === p) {
          // A caption refresh must not remove a still-cached video. Explicit
          // fresh retries deleted the hit above and cannot use this fallback.
          if (cachedVideo && hit && now() - hit.at < RESOLVE_TTL) {
            delete NEG[key];
            delete INFLIGHT[key];
            return cachedVideo;
          }
          NEG[key] = { at: now(), msg: (err && err.message) || 'resolve failed' };
          delete INFLIGHT[key];
        }
        throw err;
      }
    );
    INFLIGHT[key] = p;
    return p;
  }

  /* ------------------------------------------------------------------ */
  /* Public exports                                                     */
  /* ------------------------------------------------------------------ */


  /* ---- TMDB catalogue fallback (site is Cloudflare-403 since 2026-10) ---- */
  function tmdbImage(path, size) {
    return path ? 'https://image.tmdb.org/t/p/' + (size || 'w500') + path : '';
  }

  async function tmdbGet(path) {
    var res = await request(TMDB + path + (path.indexOf('?') >= 0 ? '&' : '?') + 'api_key=' + TMDB_KEY, {
      headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
    });
    if (!res.ok || !res.json) throw new Error('TMDB ' + res.status);
    return res.json;
  }

  async function tmdbSearch(q, pageIndex) {
    var pg = Math.max(1, (parseInt(pageIndex, 10) || 0) + 1);
    var data = await tmdbGet('/search/multi?query=' + enc(q) + '&page=' + pg + '&include_adult=false');
    var out = [];
    var rows = Array.isArray(data.results) ? data.results : [];
    for (var i = 0; i < rows.length && out.length < 40; i++) {
      var r = rows[i];
      if (!r || (r.media_type !== 'movie' && r.media_type !== 'tv')) continue;
      var title = r.title || r.name || '';
      if (!title) continue;
      out.push({
        href: 'mdb:' + r.media_type + ':' + r.id,
        title: title,
        image: tmdbImage(r.poster_path, 'w500'),
        year: (r.release_date || r.first_air_date || '').slice(0, 4),
      });
    }
    return out;
  }

  async function tmdbTrending(kind, windowKey) {
    var data = await tmdbGet('/trending/' + kind + '/' + (windowKey || 'week'));
    var rows = Array.isArray(data.results) ? data.results : [];
    var out = [];
    for (var i = 0; i < rows.length && out.length < 30; i++) {
      var r = rows[i];
      if (!r || !r.poster_path) continue;
      var title = r.title || r.name || '';
      if (!title) continue;
      out.push({ href: 'mdb:' + kind + ':' + r.id, title: title, image: tmdbImage(r.poster_path, 'w500') });
    }
    return out;
  }

  async function tmdbDetails(ref) {
    var data = await tmdbGet('/' + ref.kind + '/' + enc(ref.id));
    return {
      title: data.title || data.name || 'MovieDB',
      description: data.overview || '',
      image: tmdbImage(data.poster_path, 'w500'),
      year: parseInt((data.release_date || data.first_air_date || '').slice(0, 4), 10) || null,
      genres: (data.genres || []).map(function (g) { return g.name; }),
      url: 'mdb:' + ref.kind + ':' + ref.id,
      href: 'mdb:' + ref.kind + ':' + ref.id,
      id: ref.id,
      kind: ref.kind,
    };
  }

  async function tmdbEpisodes(ref) {
    var show = await tmdbGet('/tv/' + enc(ref.id));
    var seasons = Array.isArray(show.seasons) ? show.seasons : [];
    var out = [];
    var used = 0;
    for (var i = 0; i < seasons.length && used < 40; i++) {
      var sn = seasons[i];
      if (!sn || !sn.season_number || sn.season_number < 1 || !sn.episode_count) continue;
      used += 1;
      var cap = Math.min(sn.episode_count, 2000);
      for (var e = 1; e <= cap; e++) {
        out.push({
          number: e,
          season: sn.season_number,
          href: 'mdb:tv:' + ref.id + ':' + sn.season_number + ':' + e,
          title: 'S' + sn.season_number + 'E' + e,
          subAvailable: true,
          dubAvailable: false,
        });
        if (out.length >= 4000) break;
      }
      if (out.length >= 4000) break;
    }
    if (!out.length) throw new Error('MovieDB: no episode list available');
    return out;
  }

  /* ---- MoviesAPI / VidSpark provider (public player key, verified 2026-10) ---- */
  async function vidoraDraw(ref, budgetMs, injectDeadline) {
    if (now() > injectDeadline) return null;
    var isTv = ref.kind === 'tv';
    var path = isTv
      ? '/v1/tv/' + enc(ref.id) + '/' + enc(ref.season || 1) + '/' + enc(ref.episode || 1)
      : '/v1/movie/' + enc(ref.id);
    var referer = 'https://moviesapi.to/' + (isTv
      ? 'tv/' + ref.id + '/' + (ref.season || 1) + '/' + (ref.episode || 1)
      : 'movie/' + ref.id);
    var res;
    try {
      res = await request(VIDORA + path, {
        timeoutMs: Math.max(1, Math.min(budgetMs, injectDeadline - now())),
        headers: {
          'User-Agent': USER_AGENT,
          Accept: 'application/json',
          'x-player-key': VIDORA_KEY,
          Origin: 'https://moviesapi.to',
          Referer: referer,
        },
      });
    } catch (e) { log('vidora request error ' + (e && e.message ? e.message : e)); return null; }
    var data = res && res.json;
    if (!res || !res.ok || !data || data.result !== true) return null;
    if (data.tmdb_id != null && String(data.tmdb_id) !== String(ref.id)) return null;
    if (data.type && String(data.type).toLowerCase() !== ref.kind) return null;
    if (isTv && ((data.season != null && Number(data.season) !== Number(ref.season || 1)) ||
        (data.episode != null && Number(data.episode) !== Number(ref.episode || 1)))) return null;
    var sources = Array.isArray(data.sources) ? data.sources : [];
    for (var i = 0; i < sources.length && i < 4 && now() < injectDeadline; i++) {
      var sourceDeadline = Math.min(injectDeadline, now() + 4500);
      var settled = await firstUsable([vidoraSource(sources[i], sourceDeadline)], 0, sourceDeadline);
      if (settled[0]) return settled[0];
    }
    return null;
  }

  async function vidoraSource(src, deadline, providerHeaders, shouldStop) {
    if (!src || !src.url) return null;
    if (shouldStop && shouldStop()) return null;
    var master = String(src.url);
    var hdrs = Object.assign({ 'User-Agent': USER_AGENT, Accept: '*/*', Referer: 'https://moviesapi.to/', Origin: 'https://moviesapi.to' }, providerHeaders || {});
    // Playlist-level validation: this CDN serves AES-128 HLS whose segment bytes cannot be
    // byte-probed without the key, and its Range handling is inconsistent. Verify the master AND
    // the first variant playlist parse as real HLS (playback itself is verified by the tester).
    var mres = await request(master, { headers: hdrs, timeoutMs: Math.max(1, Math.min(4500, deadline - now())) });
    if (now() >= deadline || (shouldStop && shouldStop())) return null;
    if (providerHeaders && !publicHttps(mres.finalUrl || master)) return null;
    if (!mres.ok || !mres.text || mres.text.indexOf('#EXTM3U') < 0) {
      log('vidora master not hls on ' + master.split('/')[2]);
      return null;
    }
    var man = parseManifest(mres.text);
    if (!man) return null;
    var vars = (man.variants || []).slice();
    for (var vn = 0; vn < vars.length; vn++) {
      if (vars[vn] && vars[vn].url) vars[vn] = Object.assign({}, vars[vn], { url: absAgainst(master, vars[vn].url) });
    }
    if (providerHeaders) vars = vars.filter(function (v) { return v && publicHttps(v.url); });
    if (!vars.length && man.hasSegments) {
      vars = [{ width: 0, height: 0, bandwidth: 0, codecs: '', url: master, direct: true }];
    }
    if (!vars.length) return null;
    var vres = vars[0].url === master ? mres : await request(vars[0].url, { headers: hdrs, timeoutMs: Math.max(1, Math.min(4500, deadline - now())) });
    if (now() >= deadline || (shouldStop && shouldStop())) return null;
    if (providerHeaders && !publicHttps(vres.finalUrl || vars[0].url)) return null;
    if (!vres.ok || !vres.text || vres.text.indexOf('#EXTM3U') < 0 || vres.text.indexOf('#EXTINF') < 0) {
      log('vidora variant playlist failed on ' + vars[0].url.split('/')[2]);
      return null;
    }
    vars.sort(function (a, b) {
      return (b.bandwidth || b.width * b.height) - (a.bandwidth || a.width * a.height);
    });
    var tracks = (src.tracks || []).map(function (t) {
      return { file: t.file || t.src || t.url, label: t.label || t.language || 'Subtitles', language: t.language || t.lang, headers: t.headers };
    });
    return {
      variants: vars,
      masterUrl: master,
      subs: mapSubs(tracks),
      srcName: 'MoviesAPI',
      probed: { kind: 'hls', url: vars[0].url },
      headers: hdrs,
    };
  }

  // The provider rotates CDN hosts per call and individual hosts rate-limit (429), so take two
  // independent draws in parallel and use whichever probe verifies first.
  async function vidoraAttempt(ref, deadline) {
    var results = await firstUsable([
      vidoraDraw(ref, 6000, deadline),
      sleep(500).then(function () { return vidoraDraw(ref, 6000, deadline); }),
    ], 0, deadline);
    return results[0] || results[1] || null;
  }

var SHA_K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
];

function ror(x, n) {
  return ((x >>> n) | (x << (32 - n))) >>> 0;
}

function sha256Bytes(bytes) {
  var msg = bytes.slice(0);
  var bitLen = msg.length * 8;
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  msg.push(0, 0, 0, 0);
  msg.push((bitLen >>> 24) & 0xff, (bitLen >>> 16) & 0xff, (bitLen >>> 8) & 0xff, bitLen & 0xff);

  var h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
  var h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

  var w = new Array(64);
  for (var off = 0; off < msg.length; off += 64) {
    for (var i = 0; i < 16; i++) {
      w[i] = ((msg[off + i * 4] << 24) | (msg[off + i * 4 + 1] << 16) | (msg[off + i * 4 + 2] << 8) | msg[off + i * 4 + 3]) >>> 0;
    }
    for (i = 16; i < 64; i++) {
      var s0 = (ror(w[i - 15], 7) ^ ror(w[i - 15], 18) ^ (w[i - 15] >>> 3)) >>> 0;
      var s1 = (ror(w[i - 2], 17) ^ ror(w[i - 2], 19) ^ (w[i - 2] >>> 10)) >>> 0;
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    var a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
    for (i = 0; i < 64; i++) {
      var S1 = (ror(e, 6) ^ ror(e, 11) ^ ror(e, 25)) >>> 0;
      var ch = ((e & f) ^ (~e & g)) >>> 0;
      var t1 = (h + S1 + ch + SHA_K[i] + w[i]) >>> 0;
      var S0 = (ror(a, 2) ^ ror(a, 13) ^ ror(a, 22)) >>> 0;
      var maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0;
      var t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0;
      d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
  }
  var out = [];
  [h0, h1, h2, h3, h4, h5, h6, h7].forEach(function (x) {
    out.push((x >>> 24) & 0xff, (x >>> 16) & 0xff, (x >>> 8) & 0xff, x & 0xff);
  });
  return out;
}

  function publicHttps(url) {
    if (/[\u0000-\u0020\u007f\\]/.test(String(url || ''))) return false;
    var m = String(url || '').match(/^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?#]|$)/i);
    if (!m) return false;
    var host = m[1].toLowerCase();
    return /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i.test(host) &&
      !/(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host) &&
      !/\.(?:localhost|local|internal|test|invalid)$/.test(host);
  }

  function vidpopToken(token, media) {
    if (typeof token !== 'string' || token.length > 32768 || !/^[A-Za-z0-9_+/=-]+$/.test(token)) return '';
    if (!Array.isArray(media._k) || !media._k.length || media._k.length > 256) return '';
    var pass = [];
    for (var p = 0; p < media._k.length; p++) {
      if (!Number.isInteger(media._k[p]) || media._k[p] < 0 || media._k[p] > 255) return '';
      pass.push(media._k[p] ^ 0x5a);
    }
    var key = sha256Bytes(pass), raw = [], acc = 0, bits = 0;
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var encoded = token.replace(/-/g, '+').replace(/_/g, '/').replace(/=+$/, '');
    for (var i = 0; i < encoded.length; i++) {
      var n = alphabet.indexOf(encoded.charAt(i));
      if (n < 0) return '';
      acc = (acc << 6) | n;
      bits += 6;
      if (bits >= 8) { bits -= 8; raw.push((acc >>> bits) & 255); }
    }
    var url = '';
    for (var j = 0; j < raw.length; j++) url += String.fromCharCode(raw[j] ^ key[j % key.length]);
    return publicHttps(url) ? url : '';
  }

  async function vidpopAttempt(ref, deadline, captionDeadline) {
    if (now() < VIDPOP_RETRY_AT || now() >= deadline) return null;
    var captionUntil = typeof captionDeadline === 'number' ? captionDeadline : deadline;
    var base = 'https://www.vidpop.stream';
    var page = base + '/' + (ref.kind === 'tv' ? 'show/' + ref.id + '/' + ref.season + '/' + ref.episode : 'movie/' + ref.id);
    function remaining() { return Math.max(1, deadline - now()); }
    var res = await request(page, { timeoutMs: remaining(), maxBytesHint: 1048576 });
    if (res.status === 401 || res.status === 403 || res.status === 451) VIDPOP_RETRY_AT = now() + 30 * 60000;
    if (res.status === 429) {
      var pageHeaders = res.headers || {}, pageRetry = typeof pageHeaders.get === 'function' ? pageHeaders.get('retry-after') : pageHeaders['retry-after'] || pageHeaders['Retry-After'];
      var pageDelay = /^\d+$/.test(String(pageRetry || '')) ? Number(pageRetry) * 1000 : Date.parse(pageRetry) - now();
      VIDPOP_RETRY_AT = now() + (isFinite(pageDelay) && pageDelay > 0 ? pageDelay : 60000);
    }
    if (!res.ok || now() >= deadline || !publicHttps(res.finalUrl || page)) return null;
    var match = res.text.match(/window\.VIDPOP_BOOT\s*=\s*(\{[\s\S]*?\});/);
    if (!match) return null;
    var boot;
    try { boot = JSON.parse(match[1]); } catch (_) { return null; }
    var media = boot.MEDIA;
    if (!media || String(media.tmdb_id) !== String(ref.id) || media.type !== (ref.kind === 'tv' ? 'show' : 'movie')) return null;
    if (ref.kind === 'tv' && (Number(media.season) !== Number(ref.season) || Number(media.episode) !== Number(ref.episode))) return null;
    var headers = { 'User-Agent': USER_AGENT, Referer: page, Origin: base };
    var subs = [];
    var captionQuery = '?tmdb_id=' + enc(ref.id) + '&type=' + media.type +
      (ref.kind === 'tv' ? '&season=' + enc(ref.season) + '&episode=' + enc(ref.episode) : '');
    var captions = null;
    async function loadCaptions() {
      if (now() < VIDPOP_CAPTION_RETRY_AT) return;
      var r;
      for (var attempt = 0; attempt < 2 && now() < captionUntil && now() >= VIDPOP_RETRY_AT; attempt++) {
        try {
          r = await request(base + '/api/subtitles' + captionQuery, { headers: headers, timeoutMs: Math.max(1, captionUntil - now()), maxBytesHint: 1048576 });
        } catch (_) { r = { ok: false, status: 0 }; }
        if (now() >= captionUntil) return;
        if (r.status === 401 || r.status === 403 || r.status === 451 || r.status === 429) {
          var ch = r.headers || {}, cr = typeof ch.get === 'function' ? ch.get('retry-after') : ch['retry-after'] || ch['Retry-After'];
          var cd = /^\d+$/.test(String(cr || '')) ? Number(cr) * 1000 : Date.parse(cr) - now();
          VIDPOP_CAPTION_RETRY_AT = now() + (r.status === 429 ? (isFinite(cd) && cd > 0 ? cd : 60000) : 30 * 60000);
          if (r.status === 429) VIDPOP_RETRY_AT = VIDPOP_CAPTION_RETRY_AT;
          return;
        }
        if (r.ok && r.json && Array.isArray(r.json.subtitles)) break;
        var transient = r.status === 0 || r.status === 408 || (r.status >= 500 && r.status <= 599);
        if (!transient || attempt > 0 || now() + 500 >= captionUntil) return;
        await sleep(300);
      }
      if (!r || !r.ok || !r.json || r.json.success === false || !Array.isArray(r.json.subtitles)) return;
      var d = r.json;
      if (d.tmdb_id != null && String(d.tmdb_id) !== String(ref.id)) return;
      var returnedType = d.type || d.media_type;
      if (returnedType && String(returnedType).toLowerCase().replace(/^show$/, 'tv') !== ref.kind) return;
      if (ref.kind === 'tv' && ((d.season != null && Number(d.season) !== Number(ref.season)) ||
          (d.episode != null && Number(d.episode) !== Number(ref.episode)))) return;
      // IDs are opaque: some contain an upstream caption URL. Encode them only
      // into this player's file endpoint, never use them as a request target.
      var rows = r.json.subtitles.slice(0, 1000).filter(function (s) {
        var id = s && String(s.id || s.file_id || '');
        return id && id.length <= 2048 && !/[\u0000-\u001f\u007f]/.test(id);
      });
      rows.sort(function (a, b) { return (a.language === 'en' ? 0 : 1) - (b.language === 'en' ? 0 : 1); });
      subs = mapSubs(rows.map(function (s) {
        return { file: base + '/api/subtitle/file?id=' + enc(s.id || s.file_id), label: s.label || s.language || 'Subtitles', language: s.language, headers: headers };
      }));
    }
    var servers = (Array.isArray(boot.SERVERS) ? boot.SERVERS : []).filter(function (s) {
      return s && s.enabled !== false && s.enabled !== 0 && s.enabled !== '0' && /^\d{1,4}$/.test(String(s.id));
    }).slice(0, 2);
    var denied = false;
    async function tryServer(server, until) {
        if (now() >= until || denied || now() < VIDPOP_RETRY_AT) return null;
        // Queue video first; caption metadata must not consume its server budget.
        var sourceRequest = request(base + '/api/source', { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers), body: JSON.stringify(Object.assign({}, media, { server_id: server.id })), timeoutMs: Math.max(1, until - now()), maxBytesHint: 1048576 });
        if (!captions) captions = loadCaptions();
        var response = await sourceRequest;
        if (response.status === 401 || response.status === 403 || response.status === 451 || response.status === 429) {
          denied = true;
          if (response.status !== 429) VIDPOP_RETRY_AT = now() + 30 * 60000;
          if (response.status === 429) {
            var rh = response.headers || {}, retry = typeof rh.get === 'function' ? rh.get('retry-after') : rh['retry-after'] || rh['Retry-After'];
            var delay = /^\d+$/.test(String(retry || '')) ? Number(retry) * 1000 : Date.parse(retry) - now();
            VIDPOP_RETRY_AT = now() + (isFinite(delay) && delay > 0 ? delay : 60000);
          }
          return null;
        }
        if (denied || now() < VIDPOP_RETRY_AT) return null;
        if (now() >= until || !response.ok || !response.json || response.json.success !== true) return null;
        var data = response.json, url = data.proxy_url || vidpopToken(data.stream_token, media);
        if (!publicHttps(url)) return null;
        var result = await vidoraSource({ url: url, tracks: [] }, until, headers, function () { return denied || now() < VIDPOP_RETRY_AT; });
        if (result) result.srcName = 'VidPop ' + cleanText(server.name || 'Server');
        return result;
    }
    if (!servers.length) return null;
    var draws = [tryServer(servers[0], deadline)];
    if (servers[1]) draws.push(sleep(1000).then(function () { return tryServer(servers[1], deadline); }));
    var results = await firstUsable(draws, 0, deadline);
    var result = results[0] || results[1];
    if (!result) return null;
    // Keep a small margin so ready video is returned before the outer deadline.
    var captionWait = Math.max(0, captionUntil - now() - 100);
    if (captions && captionWait > 0) await Promise.race([captions, sleep(captionWait)]);
    result.subs = subs;
    return result;
  }

  async function searchResults(query, page) {
    var q = String(query || '').trim();
    var pageIndex = Math.max(0, parseInt(page, 10) || 0);
    try {
      if (!q) {
        // legacy home row: the app calls searchResults('') for its home list;
        // there is only one "page" of that surface.
        if (pageIndex > 0) return [];
        try {
          var home = await fetchPage(SITE + '/home/');
          var secs = parseHomeSections(home);
          var flat = [];
          for (var i = 0; i < secs.length; i++) {
            for (var j = 0; j < secs[i].items.length; j++) flat.push(secs[i].items[j]);
          }
          var hcards = toCards(flat, 40);
          if (hcards.length) return hcards;
        } catch (_) {}
        var tr = await tmdbTrending('movie');
        var trTv = await tmdbTrending('tv');
        return tr.concat(trTv).slice(0, 40);
      }
      var url = SITE + '/home/search?q=' + enc(q);
      if (pageIndex > 0) {
        // The site's own search repeats a few results between pages; a "next
        // page" must not re-serve what earlier pages already showed.
        var seenHrefs = Object.create(null);
        for (var pg = 1; pg <= pageIndex; pg++) {
          try {
            var pHtml = await fetchPage(pg === 1 ? url : url + '&page=' + pg);
            var pCards = filterAdult(parseCards(pHtml));
            for (var pi = 0; pi < pCards.length; pi++) seenHrefs[pCards[pi].href] = true;
          } catch (_) {}
        }
        var htmlP = await fetchPage(url + '&page=' + (pageIndex + 1));
        var cardsP = filterAdult(parseCards(htmlP));
        var outP = [];
        for (var ci = 0; ci < cardsP.length; ci++) {
          if (seenHrefs[cardsP[ci].href]) continue;
          outP.push(cardsP[ci]);
        }
        return toCards(outP, 40);
      }
      var html = await fetchPage(url);
      var cards = filterAdult(parseCards(html));
      if (!cards.length) {
        try {
          var fb = await tmdbSearch(q, pageIndex);
          if (fb.length) { log('search via TMDB: ' + fb.length); return fb; }
        } catch (_) {}
      }
      return toCards(cards, 40);
    } catch (e) {
      log('searchResults failed: ' + (e && e.message ? e.message : e));
      try {
        var fb2 = await tmdbSearch(q, pageIndex);
        if (fb2.length) { log('search via TMDB: ' + fb2.length); return fb2; }
      } catch (_) {}
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    var ref = parseRef(urlOrId);
    if (!ref) throw new Error('MovieDB: unrecognized reference');
    var pageUrl = cardHref(ref.kind, ref.id, ref.slug || '');
    var parsed;
    try {
      var html = await fetchPage(pageUrl);
      parsed = parseDetailsPage(html, ref);
      if (!parsed || !parsed.title) throw new Error('empty details');
    } catch (e) {
      log('details page failed, TMDB fallback: ' + (e && e.message ? e.message : e));
      parsed = await tmdbDetails(ref);
      pageUrl = 'mdb:' + ref.kind + ':' + ref.id;
    }

    if (!parsed.image) {
      // rare: fall back to the provider meta (one cheap call) — never a logo.
      try {
        var deadline = now() + 6000;
        var data = await callApi(ref, null, deadline);
        var mp = data && data.meta && data.meta.poster_path;
        if (mp && typeof mp === 'string') {
          parsed.image = mp.indexOf('http') === 0 ? mp : 'https://image.tmdb.org/t/p/w500' + mp;
        }
      } catch (_) {}
    }

    // Prefetch: warm the resolve path for movies while the user reads the page
    // (subscription top-ups keep working in the background from here).
    if (ref.kind === 'movie') {
      try {
        resolveStream({ kind: 'movie', id: ref.id, season: null, episode: null }, true).catch(function () {});
      } catch (_) {}
    }

    return {
      title: parsed.title || 'MovieDB',
      description: parsed.description || '',
      image: parsed.image || '',
      year: parsed.year || null,
      genres: parsed.genres || [],
      url: pageUrl,
      href: pageUrl,
      id: ref.id,
      kind: ref.kind,
    };
  }

  async function extractEpisodes(seriesId) {
    var ref = parseRef(seriesId);
    if (!ref) throw new Error('MovieDB: unrecognized reference');

    // Movies play as a single synthetic episode (module contract convention).
    if (ref.kind === 'movie') {
      var movieTitle = '';
      try {
        var d = await extractDetails(seriesId);
        movieTitle = d && d.title ? d.title : '';
      } catch (_) {}
      return [
        {
          number: 1,
          season: 1,
          title: movieTitle || 'Full Movie',
          href: 'mdb:movie:' + ref.id,
          isMovie: true,
          mediaType: 'movie',
          subAvailable: true,
          dubAvailable: false,
        },
      ];
    }

    var pageUrl = cardHref('tv', ref.id, ref.slug || '');
    var seasons;
    try {
      var html = await fetchPage(pageUrl);
      seasons = parseSeasons(html);
      if (!seasons || !seasons.length) throw new Error('no seasons on page');
    } catch (e) {
      log('episode page failed, TMDB fallback: ' + (e && e.message ? e.message : e));
      return tmdbEpisodes(ref);
    }
    var out = [];
    for (var s = 0; s < seasons.length; s++) {
      var season = seasons[s];
      if (!season.count || season.count < 1) continue;
      var cap = Math.min(season.count, 2000);
      for (var e = 1; e <= cap; e++) {
        out.push({
          number: e,
          season: season.season,
          href: 'mdb:tv:' + ref.id + ':' + season.season + ':' + e,
          title: 'S' + season.season + 'E' + e,
          subAvailable: true,
          dubAvailable: false,
        });
        if (out.length >= 4000) break;
      }
    }
    if (!out.length) {
      throw new Error('MovieDB: no episode list available for this series (source-side)');
    }
    return out;
  }

  async function extractStreamUrl(episodeHref, lang, bypassCache) {
    var ref = parseRef(episodeHref);
    if (!ref) throw new Error('MovieDB: unrecognized episode reference');
    if (ref.kind === 'tv' && (!ref.season || !ref.episode)) {
      throw new Error('MovieDB: an explicit season and episode are required');
    }
    log('resolve ' + resolveKey(ref));
    var data = await resolveStream(ref, false, bypassCache);
    return data;
  }

  async function discoveryHome() {
    try {
      var home = await fetchPage(SITE + '/home/');
      var sections = parseHomeSections(home);
      if (!sections.length) throw new Error('no home sections');
      registerFeedViews(sections);
      var out = [];
      // hero first (app inserts Continue Watching after the first hero)
      var first = sections[0];
      var heroItems = toCards(first.items, 8);
      // hero art: the app prefers backdropUrl then posterUrl — upscale the
      // TMDB sibling for full-width banner use
      for (var h = 0; h < heroItems.length; h++) {
        var img = heroItems[h].image || '';
        if (img.indexOf('image.tmdb.org') >= 0) {
          heroItems[h].backdropUrl = img.replace('/t/p/w342/', '/t/p/w780/').replace('/t/p/w500/', '/t/p/w780/');
        }
      }
      out.push({
        id: 'featured',
        title: first.title || 'Featured',
        style: 'hero',
        items: heroItems,
      });
      for (var i = 1; i < sections.length; i++) {
        var sec = sections[i];
        var items = toCards(sec.items, 30);
        if (items.length < 3) continue;
        var item = {
          id: sectionId(sec.title, i),
          title: (sec.title || 'Section').slice(0, 80),
          style: 'poster',
          items: items,
        };
        if (sec.viewAll) {
          var fid = feedIdFor(sec.viewAll);
          item.viewAll = { mode: 'feed', feedId: fid };
        }
        out.push(item);
        if (out.length >= 12) break;
      }
      return { sections: out };
    } catch (e) {
      log('discoveryHome site failed, TMDB fallback: ' + (e && e.message ? e.message : e));
      try {
        var movies = await tmdbTrending('movie');
        var shows = await tmdbTrending('tv');
        var fb = [];
        if (movies.length) fb.push({ id: 'trending-movies', title: 'Trending Movies', style: 'poster', items: movies });
        if (shows.length) fb.push({ id: 'trending-tv', title: 'Trending TV', style: 'poster', items: shows });
        if (fb.length) return { sections: fb };
      } catch (_) {}
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    var pg = Math.max(1, parseInt(page || 1, 10) || 1);
    try {
      var fid = String(feedId || '');
      if (fid === 'home') {
        var h0 = await fetchPage(SITE + '/home/');
        var secs0 = parseHomeSections(h0);
        var flat = [];
        for (var i = 0; i < secs0.length; i++) {
          for (var j = 0; j < secs0[i].items.length; j++) flat.push(secs0[i].items[j]);
        }
        return { items: toCards(flat, 50), page: pg, hasMore: false };
      }

      // rebuild the feed registry if this instance hasn't served home yet
      if (!FEEDS[fid]) {
        var h1 = await fetchPage(SITE + '/home/');
        registerFeedViews(parseHomeSections(h1));
      }
      var href = FEEDS[fid];
      if (!href) return { items: [], page: pg, hasMore: false };

      var url = pagedUrl(href, pg);
      var html = await fetchPage(url);
      var cards = filterAdult(parseCards(html));
      var items = toCards(cards, 50);
      // hasMore: trust the page's own next-link signal first
      var hasNext = /rel=["']next["']/i.test(html);
      var hasMore = items.length > 0 && (hasNext || items.length >= 15);
      return { items: items, page: pg, hasMore: hasMore };
    } catch (e) {
      log('discoveryFeed failed: ' + (e && e.message ? e.message : e));
      return { items: [], page: pg, hasMore: false };
    }
  }

  /* ------------------------------------------------------------------ */
  /* Global exports                                                     */
  /* ------------------------------------------------------------------ */

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();


/* ------------------------------------------------------------------------
 * Backup stream provider (added in 0.1.0-beta.26).
 * When this source's own servers return nothing playable, the same title is
 * asked of the movy.sx "original audio" servers by its TMDB id. The provider
 * code below is the Movy 0.1.0-beta.4 module, isolated: its exports stay in a
 * private object and never replace this module's handlers. Original audio only;
 * a Dub request is never answered with it.
 * ---------------------------------------------------------------------- */
;(function () {
  'use strict';
  var hostResolve = globalThis.extractStreamUrl;
  var backup = (function (realGlobal) {
    var globalThis = Object.create(realGlobal);
    /**
     * Movy 0.1.0-beta.3 - movies and TV from movy.sx.
     * Catalogue: TMDB (movy.sx uses TMDB ids; db.wecollege.net is the site's own
     * TMDB mirror and is used only when TMDB is unreachable).
     * Streams: the site's "original audio" servers on api.wecollege.net. Every
     * play fetches one short-lived seed, asks servers in small waves, decrypts the
     * answer and probes the stream before returning it.
     * German/French/Hindi/Spanish servers are not used: they are not English dub.
     */
    (function () {
      'use strict';
    
      var MODULE = 'Movy';
      var SITE = 'https://www.movy.sx';
      var API = 'https://api.wecollege.net';
      var TMDB = 'https://api.themoviedb.org/3';
      var TMDB_KEY = 'e1a8efff4415028c5c266b3fcd50db6e';
      var TMDB_MIRROR = 'https://db.wecollege.net/3';
      var MAGIC = [109, 118, 109, 49];
      var UA =
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
      var FAKE = /tiktokcdn|ibyteimg|ad-site-i18n|\/obj\/ad-site|blank\.mp4|\.png(?:\?|$)/i;
      // Site order and labels ("Original audio"). Asked in waves so a play costs
      // one seed and a few requests; later waves run only when earlier ones fail.
      var SERVER_WAVES = [
        [
          { path: 'miami', name: 'Miami' },
          { path: 'boise', name: 'Boise' },
          { path: 'atlanta', name: 'Atlanta' },
          { path: 'phoenix', name: 'Phoenix' },
        ],
        [
          { path: 'oakland', name: 'Oakland' },
          { path: 'vegas', name: 'Vegas' },
          { path: 'reno', name: 'Reno' },
          { path: 'seattle', name: 'Seattle' },
        ],
        [
          { path: 'portland', name: 'Portland' },
          { path: 'austin', name: 'Austin' },
          { path: 'tampa', name: 'Tampa' },
          { path: 'orlando', name: 'Orlando' },
        ],
      ];
      // The site's language servers. For a film whose original language matches,
      // they carry the original audio and join the first wave. Otherwise they are
      // a labelled last resort when no original-audio stream exists.
      var LANGUAGE_SERVERS = [
        { path: 'delhi', name: 'Delhi', audio: 'hi', serves: ['hi', 'ta', 'te', 'ml', 'kn', 'bn', 'mr', 'pa'] },
        { path: 'cancun', name: 'Cancun', audio: 'es', serves: ['es'] },
        { path: 'paris', name: 'Paris', audio: 'fr', serves: ['fr'] },
        { path: 'munich', name: 'Munich', audio: 'de', serves: ['de'], extra: { language: 'german' } },
        { path: 'berlin', name: 'Berlin', audio: 'de', serves: ['de'], germanTitle: true },
      ];
      var ENOUGH_SERVERS = 2;
      var REQUEST_LIMIT = 48;
      var RESOLVE_MS = 26000;
      var SEED_COOLDOWN_MS = 120000;
      var metadataCache = {};
      var seedCache = {};
      var inflight = {};
      var seedRetryAt = 0;
      var mirrorPreferredUntil = 0;
      var hostRetryAt = {};
      var transportActive = 0;
      var transportQueue = [];
    
      function releaseTransport() {
        transportActive -= 1;
        while (transportQueue.length && transportActive < 4) {
          var entry = transportQueue.shift();
          if (entry.token.closed || !active(entry.ctx)) { entry.resolve(false); continue; }
          transportActive += 1;
          entry.resolve(true);
        }
      }
    
      function acquireTransport(ctx, token) {
        if (token.closed || !active(ctx)) return Promise.resolve(false);
        if (transportActive < 4) { transportActive += 1; return Promise.resolve(true); }
        return new Promise(function (resolve) { transportQueue.push({ ctx: ctx, token: token, resolve: resolve }); });
      }
    
      function cooldownUntil(response) {
        var value = String(header(response, 'retry-after') || '').trim();
        var delay = /^\d+$/.test(value) ? Number(value) * 1000 : Date.parse(value) - Date.now();
        return Date.now() + (isFinite(delay) && delay > 0 ? delay : SEED_COOLDOWN_MS);
      }
    
      function log(msg) {
        try { console.log('[' + MODULE + '] ' + String(msg || '')); } catch (_) {}
      }
    
      function clean(value) {
        return String(value == null ? '' : value).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      }
    
      function headers(extra) {
        var out = { 'User-Agent': UA, Accept: '*/*' };
        var src = extra || {};
        Object.keys(src).forEach(function (k) { out[k] = src[k]; });
        return out;
      }
    
      function apiHeaders() {
        return { 'User-Agent': UA, Accept: 'application/json,text/plain,*/*',
          Origin: SITE, Referer: SITE + '/' };
      }
    
      // Every Movy CDN answers 403 without the site's Origin and Referer.
      function streamHeaders() {
        return { 'User-Agent': UA,
          Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
          Origin: SITE, Referer: SITE + '/' };
      }
    
      async function readBody(response) {
        if (!response) return '';
        if (typeof response.body === 'string' && response.body) return response.body;
        if (response.json && typeof response.json !== 'function') {
          try { return JSON.stringify(response.json); } catch (_) {}
        }
        if (typeof response.text === 'function') {
          try {
            var text = await response.text();
            if (typeof text === 'string' && text) return text;
          } catch (_) {}
        }
        if (typeof response.json === 'function') {
          try {
            var json = await response.json();
            if (json != null) return typeof json === 'string' ? json : JSON.stringify(json);
          } catch (_) {}
        }
        return '';
      }
    
      function header(response, name) {
        var values = response && response.headers;
        if (!values) return '';
        if (typeof values.get === 'function') return values.get(name) || '';
        var key = Object.keys(values).filter(function (k) { return k.toLowerCase() === name; })[0];
        return key ? String(values[key]) : '';
      }
    
      function failure(code, stage, status, text) {
        return { ok: false, status: status || 0, text: text || '', json: null, code: code, stage: stage };
      }
    
      function active(ctx) {
        return !ctx || (!ctx.closed && Date.now() < ctx.deadline && ctx.requests < REQUEST_LIMIT);
      }
    
      function withTimeout(promise, ms, fallback) {
        var timer;
        return Promise.race([promise, new Promise(function (resolve) {
          timer = setTimeout(function () { resolve(fallback); }, Math.max(1, ms));
        })]).then(function (value) {
          if (typeof clearTimeout === 'function') clearTimeout(timer);
          return value;
        }, function (error) {
          if (typeof clearTimeout === 'function') clearTimeout(timer);
          throw error;
        });
      }
    
      async function request(url, extraHeaders, ctx, stage) {
        stage = stage || 'metadata';
        if (!active(ctx)) return failure('budget_exhausted', stage);
        if (!safeUrl(url)) return failure('invalid_url', stage);
        var host = String(url).match(/^https:\/\/([^/?#]+)/i)[1].toLowerCase();
        if (Date.now() < (hostRetryAt[host] || 0)) {
          if (ctx) ctx.failure = failure('rate_limited', stage, 429);
          return failure('rate_limited', stage, 429);
        }
        if (ctx) ctx.requests += 1;
        var start = Date.now();
        var cap = ctx && ctx.catalogue ? 3500 : (stage === 'segment' || stage === 'variant' || stage === 'playlist' ? 6000 : 9000);
        var timeout = Math.min(cap, ctx ? ctx.deadline - start : cap);
        var token = { closed: false };
        var result = await withTimeout((async function () {
          if (!(await acquireTransport(ctx, token))) return failure('budget_exhausted', stage);
          try {
            if (token.closed || !active(ctx)) return failure('budget_exhausted', stage);
            if (Date.now() < (hostRetryAt[host] || 0)) return failure('rate_limited', stage, 429);
            if (typeof fetchv2 !== 'function') return failure('transport_missing', stage);
            var response = await fetchv2(url, headers(extraHeaders), 'GET', null,
              { maxBytesHint: 1500000, responseClass: stage === 'segment' ? 'binary' : 'text' });
            var status = Number(response && response.status) || 0;
            if (status === 429 || (status === 503 && header(response, 'retry-after'))) {
              var until = cooldownUntil(response);
              hostRetryAt[host] = Math.max(hostRetryAt[host] || 0, until);
              if (host === 'api.wecollege.net') seedRetryAt = Math.max(seedRetryAt, until);
              if (ctx) ctx.failure = failure('rate_limited', stage, status);
              return failure('rate_limited', stage, status);
            }
            if (ctx && (ctx.closed || Date.now() >= ctx.deadline)) return failure('budget_exhausted', stage);
            var text = await readBody(response);
            if (ctx && (ctx.closed || Date.now() >= ctx.deadline)) return failure('budget_exhausted', stage);
            if (status < 200 || status >= 300) {
              return failure(status === 429 ? 'rate_limited' : 'http_error', stage, status, text.slice(0, 200));
            }
            var json = null;
            try { json = JSON.parse(text); } catch (_) {}
            return { ok: true, status: status, text: text, json: json, stage: stage,
              contentType: header(response, 'content-type') };
          } catch (_) { return failure('transport_error', stage); }
          finally { releaseTransport(); }
        })(), timeout, failure('timeout', stage));
        token.closed = true;
        if (ctx && !ctx.closed) {
          if (result.code === 'timeout' && (!ctx.failure || ctx.failure.code !== 'rate_limited')) {
            ctx.failure = result;
          }
          ctx.diagnostics.push({ stage: stage, status: result.status, code: result.code || 'ok',
            ms: Date.now() - start });
        }
        return result;
      }
    
      function safeUrl(value) {
        var match = String(value || '').match(/^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?#]|$)/i);
        if (!match || /[\s\\]/.test(value)) return false;
        var host = match[1].toLowerCase();
        return host.indexOf('.') > 0 && !/^[\d.]+$/.test(host) &&
          !/(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host);
      }
    
      // ---- Catalogue (TMDB) -------------------------------------------------
    
      async function tmdb(path, ctx) {
        if (!active(ctx)) throw new Error('Metadata request budget exhausted.');
        var cached = metadataCache[path];
        if (cached && cached.expires > Date.now()) return cached.data;
        var sep = path.indexOf('?') >= 0 ? '&' : '?';
        var urls = [
          TMDB + path + sep + 'api_key=' + encodeURIComponent(TMDB_KEY) + '&language=en-US',
          TMDB_MIRROR + path + sep + 'language=en',
        ];
        if (Date.now() < mirrorPreferredUntil) urls.reverse();
        var last = null;
        for (var i = 0; i < urls.length; i += 1) {
          if (!active(ctx)) break;
          var mirror = urls[i].indexOf(TMDB_MIRROR) === 0;
          var res = await request(urls[i], mirror ? apiHeaders() : { Accept: 'application/json' }, ctx, 'metadata');
          var identity = path.match(/^\/(?:movie|tv)\/(\d+)(?:\?|$)/);
          var seasonIdentity = path.match(/^\/tv\/\d+\/season\/(\d+)(?:\?|$)/);
          if (res.ok && res.json && ((identity && String(res.json.id) !== identity[1]) ||
              (seasonIdentity && (!Array.isArray(res.json.episodes) ||
                (res.json.season_number != null && Number(res.json.season_number) !== Number(seasonIdentity[1])))))) {
            res = failure('metadata_identity_mismatch', 'metadata', res.status);
          }
          if (res.ok && res.json && typeof res.json === 'object' && !res.json.status_code) {
            if (!active(ctx)) break;
            // TMDB failed and the mirror answered: try the mirror first for a while.
            if (mirror) mirrorPreferredUntil = Date.now() + 600000;
            var keys = Object.keys(metadataCache);
            if (keys.length >= 40) delete metadataCache[keys[0]];
            metadataCache[path] = { data: res.json, expires: Date.now() + 300000 };
            return res.json;
          }
          last = res.ok ? failure('invalid_json', 'metadata', res.status) : res;
        }
        var error = new Error('Metadata is unavailable.');
        error.result = last;
        throw error;
      }
    
      function href(type, id, season, episode) {
        var base = SITE + '/' + type + '/' + id;
        if (type === 'tv' && season && episode) return base + '/' + season + '/' + episode;
        return base;
      }
    
      /**
       * Accepts Movy links (with locale prefix and ?play=true), TMDB links and the
       * short "tv:ID:S:E" form, e.g. https://www.movy.sx/tv/247718/2/5?play=true.
       */
      function parseHref(value) {
        var raw = String(value || '').trim();
        var m = raw.match(/^(movie|tv):([1-9]\d*)(?::([1-9]\d*):([1-9]\d*))?$/i);
        if (!m) {
          m = raw.match(/^(?:https?:\/\/)?(?:www\.)?movy\.[a-z]+\/(?:[a-z]{2}\/)?(movie|tv)\/([1-9]\d*)(?:\/([1-9]\d*)\/([1-9]\d*))?\/?(?:[?#].*)?$/i);
        }
        if (!m) {
          var tm = raw.match(/^https:\/\/(?:www\.)?themoviedb\.org\/(movie|tv)\/([1-9]\d*)\/?(?:\?season=([1-9]\d*)&episode=([1-9]\d*))?(?:#.*)?$/i);
          if (tm) m = tm;
        }
        if (!m) return null;
        var type = m[1].toLowerCase();
        if (type === 'movie' && (m[3] || m[4])) return null;
        return {
          type: type,
          id: String(m[2]),
          season: m[3] ? Number(m[3]) : null,
          episode: m[4] ? Number(m[4]) : null,
        };
      }
    
      function image(path, size) {
        return path ? 'https://image.tmdb.org/t/p/' + (size || 'w500') + path : '';
      }
    
      function mapItem(row, forcedType) {
        if (!row) return null;
        var type = String(forcedType || row.media_type || '').toLowerCase();
        if (type !== 'movie' && type !== 'tv') return null;
        if (row.adult === true) return null;
        var id = Number(row.id);
        var title = clean(row.title || row.name || row.original_title || row.original_name);
        if (!Number.isSafeInteger(id) || id < 1 || !title) return null;
        var year = String(row.release_date || row.first_air_date || '').slice(0, 4);
        var poster = image(row.poster_path);
        return {
          id: href(type, id),
          href: href(type, id),
          title: title + (year ? ' (' + year + ')' : ''),
          image: poster,
          poster: poster,
          backdrop: image(row.backdrop_path, 'w1280'),
          type: type,
          mediaType: type,
          year: year || undefined,
          tmdbId: id,
        };
      }
    
      // ---- Source decryption (same scheme as the site's player) ---------------
    
      function u32(x) { return x >>> 0; }
    
      function imul(a, b) {
        if (typeof Math.imul === 'function') return Math.imul(a, b) >>> 0;
        a = a >>> 0;
        b = b >>> 0;
        var ah = (a >>> 16) & 0xffff, al = a & 0xffff;
        var bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
        return ((al * bl + (((ah * bl + al * bh) << 16) >>> 0)) >>> 0) >>> 0;
      }
    
      function mix(e) {
        e = u32(e);
        e ^= e >>> 16;
        e = imul(e, 2246822507);
        e ^= e >>> 13;
        e = imul(e, 3266489909);
        e ^= e >>> 16;
        return u32(e);
      }
    
      function rotl(e, t) {
        e = u32(e);
        t = t & 31;
        if (!t) return e;
        return u32((e << t) | (e >>> (32 - t)));
      }
    
      function b64Decode(input) {
        var s = String(input || '').replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '');
        var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        var out = [], buf = 0, bits = 0;
        for (var i = 0; i < s.length; i += 1) {
          var ch = s.charAt(i);
          if (ch === '=') break;
          var v = alphabet.indexOf(ch);
          if (v < 0) continue;
          buf = ((buf << 6) | v) & 0xffffff;
          bits += 6;
          if (bits >= 8) {
            bits -= 8;
            out.push((buf >>> bits) & 0xff);
          }
        }
        return out;
      }
    
      function utf8Decode(bytes) {
        var out = '';
        var i = 0;
        while (i < bytes.length) {
          var c = bytes[i];
          i += 1;
          if (c < 0x80) out += String.fromCharCode(c);
          else if (c < 0xe0) {
            out += String.fromCharCode(((c & 0x1f) << 6) | (bytes[i] & 0x3f));
            i += 1;
          } else if (c < 0xf0) {
            out += String.fromCharCode(((c & 0x0f) << 12) | ((bytes[i] & 0x3f) << 6) | (bytes[i + 1] & 0x3f));
            i += 2;
          } else {
            var cp = ((c & 7) << 18) | ((bytes[i] & 0x3f) << 12) | ((bytes[i + 1] & 0x3f) << 6) | (bytes[i + 2] & 0x3f);
            i += 3;
            cp -= 0x10000;
            out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
          }
        }
        return out;
      }
    
      function keystate(seed, mediaId) {
        var S = Object.create(null);
        var fnv = 2166136261;
        var seedStr = String(seed || '');
        for (var i = 0; i < seedStr.length; i += 1) fnv = imul(fnv ^ seedStr.charCodeAt(i), 16777619);
        var a = mix(mix(fnv) ^ mix(u32(Number(mediaId) || 0) ^ 2654435769));
        for (var e = 0; e < 8; e += 1) {
          var slot = a % 61;
          a = rotl(u32(a + 2654435769), 7 + (7 & e));
          S[slot] = u32(a ^ mix(a));
          a = mix(u32(a + slot));
        }
        return { S: S, acc: mix(u32(2779096485 ^ a)) };
      }
    
      function nextWord(state, counter) {
        var r = state.S;
        var o = state.acc;
        var n = o % 61;
        var present = Object.prototype.hasOwnProperty.call(r, n);
        var mask = present ? 0xffffffff : 0;
        var l = present ? u32(r[n]) : 0;
        var aVal = u32(l ^ imul(2654435769, counter + 1));
        var d = u32(u32(o ^ aVal) | u32(o & aVal & mask));
        d = u32(rotl(u32(d + o), 31 & n) ^ rotl(o, 31 & imul(n, 7)));
        o = mix(u32(d + 2654435769));
        r[n] = o;
        state.acc = o;
        return o;
      }
    
      function decrypt(payload, seed, mediaId) {
        var raw = b64Decode(String(payload || '').trim().replace(/^"|"$/g, ''));
        if (raw.length <= MAGIC.length) throw new Error('empty payload');
        var state = keystate(seed, mediaId);
        var counter = 0;
        for (var i = 0; i < raw.length;) {
          var w = nextWord(state, counter);
          counter += 1;
          raw[i] ^= w & 255; i += 1;
          if (i < raw.length) { raw[i] ^= (w >>> 8) & 255; i += 1; }
          if (i < raw.length) { raw[i] ^= (w >>> 16) & 255; i += 1; }
          if (i < raw.length) { raw[i] ^= (w >>> 24) & 255; i += 1; }
        }
        for (var m = 0; m < MAGIC.length; m += 1) {
          if (raw[m] !== MAGIC[m]) throw new Error('decrypt magic mismatch');
        }
        return utf8Decode(raw.slice(MAGIC.length));
      }
    
      // ---- Seeds ------------------------------------------------------------
    
      /** One seed per title for its lifetime, as the site does; /seed is rate limited. */
      async function getSeed(mediaId, ctx, fresh) {
        if (Date.now() < seedRetryAt) {
          ctx.failure = failure('rate_limited', 'seed', 429);
          return '';
        }
        var cached = seedCache[mediaId];
        if (!fresh && cached && cached.expires > Date.now()) return cached.seed;
        var res = await request(API + '/seed?mediaId=' + encodeURIComponent(mediaId), apiHeaders(), ctx, 'seed');
        var seed = res.ok && res.json && res.json.seed ? String(res.json.seed) : '';
        if (!seed) {
          var limited = res.status === 429 || /rate_limited/.test(res.text || '');
          if (limited) seedRetryAt = Math.max(seedRetryAt, hostRetryAt['api.wecollege.net'] || Date.now() + SEED_COOLDOWN_MS);
          ctx.failure = limited ? failure('rate_limited', 'seed', res.status || 429) :
            (res.ok ? failure('empty_seed', 'seed', res.status) : res);
          return '';
        }
        var ttl = Number(res.json.ttlMs) || 30000;
        var keys = Object.keys(seedCache);
        if (keys.length >= 16) delete seedCache[keys[0]];
        seedCache[mediaId] = { seed: seed, expires: Date.now() + Math.max(5000, ttl - 5000) };
        return seed;
      }
    
      // ---- Streams ----------------------------------------------------------
    
      function attributes(line) {
        var out = {};
        var pattern = /([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))/g;
        var match;
        while ((match = pattern.exec(line))) out[match[1]] = match[2] == null ? match[3] : match[2];
        return out;
      }
    
      function joinUrl(base, rel) {
        rel = String(rel || '').trim();
        if (!rel || /[\s\\]/.test(rel)) return '';
        if (/^[a-z][a-z0-9+.-]*:/i.test(rel)) return safeUrl(rel) ? rel : '';
        var match = String(base).match(/^(https:\/\/[^/]+)(\/[^?#]*)?(?:\?[^#]*)?/i);
        if (!match) return '';
        if (rel.indexOf('//') === 0) return safeUrl('https:' + rel) ? 'https:' + rel : '';
        var path = match[2] || '/';
        if (rel.charAt(0) === '?') return match[1] + path + rel;
        if (rel.charAt(0) !== '/') rel = path.slice(0, path.lastIndexOf('/') + 1) + rel;
        var suffix = rel.match(/[?#].*$/);
        var parts = rel.replace(/[?#].*$/, '').split('/');
        var normalized = [];
        parts.forEach(function (part) {
          if (part === '..') normalized.pop();
          else if (part !== '.' && part !== '') normalized.push(part);
        });
        var result = match[1] + '/' + normalized.join('/') + (suffix ? suffix[0] : '');
        return safeUrl(result) ? result : '';
      }
    
      function firstVariant(text, base) {
        var lines = String(text || '').split(/\r?\n/);
        var best = '', bestHeight = -1;
        for (var i = 0; i < lines.length; i += 1) {
          if (lines[i].indexOf('#EXT-X-STREAM-INF') !== 0) continue;
          var size = String(attributes(lines[i]).RESOLUTION || '').split('x');
          var h = Number(size[1]) || 0;
          for (var j = i + 1; j < lines.length; j += 1) {
            var next = lines[j].trim();
            if (!next || next.charAt(0) === '#') continue;
            // Probe a 1080p-or-lower rendition: cheaper than 4K, same token.
            var score = h > 1080 ? 0 : h;
            if (score > bestHeight) { bestHeight = score; best = joinUrl(base, next); }
            break;
          }
        }
        return best;
      }
    
      function firstSegment(text, base) {
        var lines = String(text || '').split(/\r?\n/);
        for (var i = 0; i < lines.length; i += 1) {
          var line = lines[i].trim();
          if (!line || line.charAt(0) === '#') continue;
          return joinUrl(base, line);
        }
        return '';
      }
    
      function looksLikeMedia(segment) {
        var sample = segment.text || '';
        if (!sample || sample.length < 16) return 'seg_empty';
        if (/^\s*(?:#EXTM3U|\{|\[)/.test(sample)) return 'seg_not_media';
        if (/^\s*<(?:!doctype|html|\?xml)/i.test(sample)) return 'seg_html';
        var ts = sample.charCodeAt(0) === 0x47;
        var mp4 = /^(?:ftyp|styp|moof|sidx)$/.test(sample.slice(4, 8));
        if (/PNG|JFIF|GIF8|WEBP/.test(sample.slice(0, 64)) && !ts && !mp4) return 'seg_image';
        if (/^(?:text\/|application\/(?:json|vnd.apple.mpegurl|x-mpegurl))/i.test(segment.contentType || '') &&
            !ts && !mp4) return 'seg_wrong_type';
        return '';
      }
    
      /** Checks the link answers like video: playlist, media playlist and a first segment. */
      async function probe(url, streamType, hdrs, ctx) {
        if (!url || FAKE.test(url)) return { ok: false, reason: 'fake_url' };
        if (streamType === 'mp4') {
          var head = await request(url, Object.assign({}, hdrs, { Range: 'bytes=0-4095' }), ctx, 'segment');
          if (!head.ok) return { ok: false, reason: 'mp4_' + (head.status || head.code) };
          var bad = looksLikeMedia(head);
          return bad ? { ok: false, reason: bad } : { ok: true };
        }
        var playlist = await request(url, hdrs, ctx, 'playlist');
        if (!playlist.ok || playlist.text.indexOf('#EXTM3U') < 0) {
          return { ok: false, reason: 'not_hls', status: playlist.status };
        }
        var body = playlist.text, mediaUrl = url;
        if (body.indexOf('#EXT-X-STREAM-INF') >= 0) {
          mediaUrl = firstVariant(body, url);
          if (!mediaUrl) return { ok: false, reason: 'no_variant' };
          var variant = await request(mediaUrl, hdrs, ctx, 'variant');
          if (!variant.ok || variant.text.indexOf('#EXTM3U') < 0) return { ok: false, reason: 'variant_fail' };
          body = variant.text;
        }
        var seg = firstSegment(body, mediaUrl);
        if (!seg || FAKE.test(seg)) return { ok: false, reason: 'no_segment' };
        var segment = await request(seg, Object.assign({}, hdrs, { Range: 'bytes=0-4095' }), ctx, 'segment');
        if (!segment.ok) return { ok: false, reason: 'seg_' + (segment.status || segment.code) };
        var reason = looksLikeMedia(segment);
        return reason ? { ok: false, reason: reason } : { ok: true };
      }
    
      function heightOf(value) {
        var text = String(value || '');
        if (/4k|2160|uhd/i.test(text)) return 2160;
        var m = text.match(/(\d{3,4})p/i);
        return m ? Number(m[1]) : 0;
      }
    
      function streamTypeOf(url) {
        return /\/mp4\/|\.mp4(?:[?#]|$)/i.test(url) ? 'mp4' : 'hls';
      }
    
      var LANG_CODES = { english: 'en', spanish: 'es', french: 'fr', german: 'de', italian: 'it',
        portuguese: 'pt', arabic: 'ar', japanese: 'ja', korean: 'ko', chinese: 'zh', russian: 'ru',
        hindi: 'hi', turkish: 'tr', dutch: 'nl', polish: 'pl', swedish: 'sv', greek: 'el',
        thai: 'th', vietnamese: 'vi', indonesian: 'id', romanian: 'ro', ukrainian: 'uk',
        czech: 'cs', danish: 'da', finnish: 'fi', hebrew: 'he', hungarian: 'hu', norwegian: 'no',
        eng: 'en', spa: 'es', fre: 'fr', fra: 'fr', ger: 'de', deu: 'de', ita: 'it', por: 'pt',
        ara: 'ar', jpn: 'ja', kor: 'ko', chi: 'zh', zho: 'zh', rus: 'ru', hin: 'hi', tur: 'tr' };
      ['en','es','fr','de','it','pt','ar','ja','ko','zh','ru','hi','tr','nl','pl','sv','el','th','vi','id','ro','uk','cs','da','fi','he','hu','no'].forEach(function (code) { LANG_CODES[code] = code; });
    
      function subtitleLanguage(row, url) {
        var text = String(row.lang || row.language || row.label || '').toLowerCase();
        var words = text.split(/[^a-z]+/).filter(Boolean);
        for (var i = 0; i < words.length; i += 1) {
          if (LANG_CODES[words[i]]) return LANG_CODES[words[i]];
        }
        var ext = String(url).match(/\.([a-z]{2,3})\.(?:srt|vtt)(?:[?#]|$)/i);
        if (ext && LANG_CODES[ext[1].toLowerCase()]) return LANG_CODES[ext[1].toLowerCase()];
        if (LANG_CODES[words[0]]) return LANG_CODES[words[0]];
        return 'und';
      }
    
      var LANG_NAMES = {};
      Object.keys(LANG_CODES).forEach(function (name) {
        if (name.length > 3) LANG_NAMES[LANG_CODES[name]] = name.charAt(0).toUpperCase() + name.slice(1);
      });
    
      // "Original--English-United-Kingdom--SDH" -> "English (United Kingdom) SDH";
      // "eng (forced)" -> "English (forced)".
      function subtitleLabel(row, lang) {
        var raw = clean(row.label || row.lang || row.language || 'Subtitle');
        var label;
        if (/\s-\s/.test(raw)) {
          // "Arabic - Arabic" -> "Arabic"; "Chinese - Chinese Simplified" -> "Chinese Simplified"
          var halves = raw.split(/\s-\s/);
          label = halves[1].indexOf(halves[0]) === 0 ? halves[1] : halves.join(' - ');
        } else {
          var parts = raw.replace(/^Original--/i, '').split('--');
          var main = parts[0].split('-');
          label = main[0] + (main.length > 1 ? ' (' + main.slice(1).join(' ') + ')' : '');
          label = clean(label + (parts.length > 1 ? ' ' + parts.slice(1).join(' ') : '')) || 'Subtitle';
        }
        var code = label.match(/^([a-z]{2,3})\b(.*)$/i);
        if (code && LANG_CODES[code[1].toLowerCase()] && LANG_NAMES[lang]) label = LANG_NAMES[lang] + code[2];
        return label;
      }
    
      // Full English first, then SDH, then forced-only tracks, then other languages.
      function captionRank(track) {
        var forced = /forced/i.test(track.label) ? 2 : /sdh|cc\b/i.test(track.label) ? 1 : 0;
        return (track.lang === 'en' ? 0 : 10) + forced;
      }
    
      function mapCaptions(rawList, seen, out) {
        (Array.isArray(rawList) ? rawList : []).forEach(function (row) {
          if (!row || typeof row !== 'object') return;
          var file = String(row.url || row.file || row.src || '').trim();
          if (!safeUrl(file) || seen[file] || /thumb|sprite|\.m3u8(?:[?#]|$)/i.test(file)) return;
          var declared = String(row.format || '').toLowerCase();
          declared = { webvtt: 'vtt', 'text/vtt': 'vtt', subrip: 'srt', 'application/x-subrip': 'srt' }[declared] || declared;
          if ((declared && declared !== 'srt' && declared !== 'vtt') || /\.(?:ass|ssa|ttml|xml|json)(?:[?#]|$)/i.test(file)) return;
          var extension = file.match(/\.(srt|vtt)(?:[?#]|$)/i);
          seen[file] = true;
          var lang = subtitleLanguage(row, file);
          var captionHeaders = streamHeaders();
          Object.keys(row.headers || {}).forEach(function (name) {
            var value = row.headers[name];
            if (/^[A-Za-z0-9-]+$/.test(name) && typeof value === 'string' && !/[\r\n]/.test(value)) captionHeaders[name] = value;
          });
          out.push({
            id: file,
            url: file,
            file: file,
            label: subtitleLabel(row, lang),
            language: lang,
            lang: lang,
            kind: 'subtitles',
            format: extension ? extension[1].toLowerCase() : (declared || undefined),
            headers: captionHeaders,
          });
        });
        return out;
      }
    
      // Austin and Delhi label sources by audio language ("Hindi", "Tamil")
      // instead of resolution.
      function qualityLanguage(value) {
        var word = String(value || '').trim().toLowerCase();
        return /^[a-z]{4,}$/.test(word) && LANG_CODES[word] ? LANG_CODES[word] : '';
      }
    
      function audioLabel(code) {
        return LANG_NAMES[code] ? LANG_NAMES[code] + ' audio' : 'audio ' + code;
      }
    
      async function buildGroup(server, list, hdrs, master, audio, original, ctx) {
        var qualities = list.map(function (src) {
          var url = String(src.url);
          var height = heightOf(src.quality);
          return { label: height ? height + 'p' : 'Auto', height: height, url: url, headers: hdrs,
            streamType: streamTypeOf(url) };
        }).sort(function (a, b) { return b.height - a.height; });
        // Unlabelled links (no height) become "Source 2", "Source 3" in the menu.
        var unnamed = 0;
        qualities.forEach(function (q) {
          if (!q.height) { unnamed += 1; q.label = 'Source ' + unnamed; }
        });
        // The site's master playlist lets the player switch quality on its own.
        var primary = master ? { url: master, streamType: 'hls' } :
          (qualities.filter(function (q) { return q.height && q.height <= 1080; })[0] || qualities[0]);
        var check = await probe(primary.url, primary.streamType, hdrs, ctx);
        if (!check.ok && !master && qualities.length > 1 && active(ctx)) {
          var fallback = qualities.filter(function (q) { return q.url !== primary.url; })[0];
          var second = await probe(fallback.url, fallback.streamType, hdrs, ctx);
          if (second.ok) { primary = fallback; check = second; }
        }
        if (!check.ok) return { server: null, reason: check.reason || 'probe_failed' };
        return {
          server: {
            name: server.name + (original ? ' (original audio)' : ' (' + audioLabel(audio) + ')'),
            url: primary.url,
            headers: hdrs,
            streamType: primary.streamType,
            lang: 'sub',
            audioLanguage: audio,
            original: original,
            qualities: qualities,
          },
        };
      }
    
      /** One server's answer -> playable server entries, one per audio language. */
      async function buildServers(server, data, hdrs, originalLanguage, ctx) {
        var list = (Array.isArray(data.sources) ? data.sources : []).filter(function (src) {
          var url = String(src && src.url || '');
          return safeUrl(url) && !FAKE.test(url) && !/\.(?:json|mpd)(?:[?#]|$)/i.test(url);
        }).slice(0, 8);
        if (!list.length) return [{ server: null, reason: 'no_sources' }];
        var groups = {}, order = [];
        list.forEach(function (src) {
          var lang = qualityLanguage(src.quality) || server.audio || originalLanguage;
          var key = lang + ':' + streamTypeOf(String(src.url));
          if (!groups[key]) { groups[key] = []; order.push(key); }
          groups[key].push(src);
        });
        var master = safeUrl(data.playlist) && !FAKE.test(data.playlist) && order.length === 1 && /:hls$/.test(order[0])
          ? String(data.playlist) : '';
        // Original language first; at most two other languages per server.
        order.sort(function (a, b) { return (a.split(':')[0] === originalLanguage ? 0 : 1) - (b.split(':')[0] === originalLanguage ? 0 : 1); });
        return Promise.all(order.slice(0, 3).map(function (key) {
          var lang = key.split(':')[0];
          var labelled = order.length > 1 ? Object.assign({}, server, { name: server.name + ' ' + key.split(':')[1].toUpperCase() }) : server;
          return buildGroup(labelled, groups[key], hdrs, master, lang,
            lang === originalLanguage || originalLanguage === 'und', ctx);
        }));
      }
    
      async function askServer(server, ref, params, mediaId, hdrs, originalLanguage, ctx) {
        var stage = 'sources:' + server.name;
        for (var attempt = 0; attempt < 2 && active(ctx); attempt += 1) {
          var seed = await getSeed(mediaId, ctx, attempt > 0);
          if (!seed) return [];
          var query = Object.assign({}, params, server.extra || {}, { enc: '2', seed: seed });
          if (server.germanTitle && params.germanTitle) query.altTitle = params.germanTitle;
          delete query.germanTitle;
          var q = Object.keys(query).filter(function (k) {
            return query[k] != null && query[k] !== '';
          }).map(function (k) {
            return encodeURIComponent(k) + '=' + encodeURIComponent(String(query[k]));
          }).join('&');
          var res = await request(API + '/' + server.path + '/sources?' + q, apiHeaders(), ctx, stage);
          // An expired or reused seed: fetch a new one once, like the site.
          if (!res.ok && res.status === 401 && attempt === 0) { delete seedCache[mediaId]; continue; }
          if (!res.ok || !res.text) return [];
          var data;
          try {
            data = res.json && Array.isArray(res.json.sources) ? res.json : JSON.parse(decrypt(res.text, seed, mediaId));
          } catch (_) {
            ctx.diagnostics.push({ stage: stage, code: 'invalid_source_payload', status: res.status });
            return [];
          }
          if (!data || !Array.isArray(data.sources)) return [];
          if (data.tmdbId != null && String(data.tmdbId) !== ref.id) return [];
          if (data.mediaType != null && String(data.mediaType) !== ref.type) return [];
          if (ref.type === 'tv' && ((data.seasonId != null && Number(data.seasonId) !== ref.season) ||
              (data.episodeId != null && Number(data.episodeId) !== ref.episode))) return [];
          ctx.captionRows.push(data.subtitles || data.subs || []);
          var built = await buildServers(server, data, hdrs, originalLanguage, ctx);
          built.forEach(function (row) {
            if (!row.server) ctx.diagnostics.push({ stage: 'media:' + server.name, code: row.reason });
          });
          return built.map(function (row) { return row.server; }).filter(Boolean);
        }
        return [];
      }
    
      async function resolve(ref, ctx) {
        var meta = await tmdb('/' + ref.type + '/' + ref.id + '?append_to_response=external_ids,translations', ctx);
        if (!meta || String(meta.id) !== ref.id) throw new Error('metadata_identity_mismatch');
        var title = clean(meta.title || meta.name || meta.original_title || meta.original_name);
        var year = String(meta.release_date || meta.first_air_date || '').slice(0, 4);
        var imdbId = clean((meta.external_ids && meta.external_ids.imdb_id) || meta.imdb_id);
        var original = clean(meta.original_language).toLowerCase() || 'und';
        var params = { title: title, mediaType: ref.type, year: year, tmdbId: ref.id, imdbId: imdbId };
        var german = ((meta.translations && meta.translations.translations) || []).filter(function (t) {
          return t && t.iso_639_1 === 'de' && t.data && (t.data.title || t.data.name);
        })[0];
        if (german) params.germanTitle = clean(german.data.title || german.data.name);
        if (ref.type === 'tv') {
          params.totalSeasons = Number(meta.number_of_seasons) || '';
          params.seasonId = Number(ref.season || 1);
          params.episodeId = Number(ref.episode || 1);
        }
        var hdrs = streamHeaders();
        // Fetch the seed before the parallel wave so all servers share it.
        if (!(await getSeed(ref.id, ctx, false))) return [];
        var native = LANGUAGE_SERVERS.filter(function (s) { return s.serves.indexOf(original) >= 0; });
        var foreign = LANGUAGE_SERVERS.filter(function (s) { return native.indexOf(s) < 0; });
        var waves = [SERVER_WAVES[0].concat(native)].concat(SERVER_WAVES.slice(1));
        var servers = [];
        function originals() { return servers.filter(function (s) { return s.original; }).length; }
        async function run(list) {
          var rows = await Promise.all(list.map(function (server) {
            return askServer(server, ref, params, ref.id, hdrs, original, ctx);
          }));
          rows.forEach(function (group) {
            group.forEach(function (row) {
              if (!servers.some(function (s) { return s.url === row.url; })) servers.push(row);
            });
          });
        }
        function timeLeft() { return ctx.deadline - Date.now() > 7000; }
        for (var w = 0; w < waves.length && active(ctx) && timeLeft(); w += 1) {
          // After the first wave one working original route is enough.
          if (originals() >= (w === 0 ? ENOUGH_SERVERS : 1)) break;
          await run(waves[w]);
          if (Date.now() < seedRetryAt) break;
        }
        // No original audio anywhere: offer dubbed servers, labelled, rather than nothing.
        if (!originals() && active(ctx) && timeLeft() && Date.now() >= seedRetryAt) await run(foreign);
        servers.sort(function (a, b) { return (a.original ? 0 : 1) - (b.original ? 0 : 1); });
        var seen = {}, captions = [];
        ctx.captionRows.forEach(function (rows) { mapCaptions(rows, seen, captions); });
        captions = captions.map(function (track, i) { return { track: track, i: i }; })
          .sort(function (a, b) { return captionRank(a.track) - captionRank(b.track) || a.i - b.i; })
          .map(function (row) { return row.track; });
        servers.forEach(function (row) { row.subtitles = captions; });
        return servers;
      }
    
      function pack(servers, ctx) {
        var primary = servers && servers[0];
        if (!primary || !primary.url) {
          var limited = Date.now() < seedRetryAt || (ctx && ctx.failure && ctx.failure.code === 'rate_limited');
          return {
            streams: [],
            subtitles: [],
            lang: 'sub',
            error: {
              code: ctx && ctx.failure ? ctx.failure.code : 'no_verified_stream',
              stage: ctx && ctx.failure ? ctx.failure.stage : 'resolution',
              message: limited
                ? 'Movy is limiting requests right now. Wait a little before trying again.'
                : 'Movy found no working stream for this title. Try again later or choose another source.',
            },
            diagnostics: ctx ? ctx.diagnostics : [],
          };
        }
        // Older app builds race stream candidates and keep the fastest, which can
        // be 360p. Only offer 720p and up for automatic choice; every rendition
        // stays in `qualities` for manual selection.
        var others = primary.qualities.filter(function (q) { return q.url !== primary.url; });
        var sharp = others.filter(function (q) { return q.height >= 720; });
        return {
          url: primary.url,
          streams: [{ url: primary.url, label: 'Auto', headers: primary.headers, streamType: primary.streamType }]
            .concat(sharp.length || !others.length ? sharp : others.slice(0, 1)),
          headers: primary.headers,
          streamType: primary.streamType,
          lang: 'sub',
          audioLanguage: primary.audioLanguage,
          quality: 'Auto',
          defaultQuality: 'Auto',
          qualities: [{ label: 'Auto', url: primary.url, headers: primary.headers }].concat(others),
          subtitles: primary.subtitles || [],
          servers: servers.map(function (row) {
            return {
              name: row.name,
              label: row.name,
              url: row.url,
              headers: row.headers,
              streamType: row.streamType,
              lang: 'sub',
              audioLanguage: row.audioLanguage,
              subtitles: row.subtitles || [],
              qualities: row.qualities || [],
            };
          }),
          provider: 'movy',
          diagnostics: ctx ? ctx.diagnostics : [],
        };
      }
    
      // ---- Module API -------------------------------------------------------
    
      async function catalogueOperation(work, milliseconds) {
        var ctx = { catalogue: true, deadline: Date.now() + milliseconds, closed: false,
          requests: 0, diagnostics: [] };
        var timedOut = {};
        try {
          var result = await withTimeout(work(ctx), milliseconds, timedOut);
          if (result === timedOut) throw new Error('Movy catalogue is taking too long. Please retry.');
          return result;
        } finally { ctx.closed = true; }
      }
    
      async function catalogueMap(values, work, ctx) {
        var next = 0, results = [];
        async function worker() {
          while (next < values.length) {
            if (!active(ctx)) throw new Error('Movy catalogue request budget exhausted.');
            var at = next++;
            results[at] = await work(values[at]);
          }
        }
        var workers = [];
        for (var i = 0; i < Math.min(3, values.length); i += 1) workers.push(worker());
        await Promise.all(workers);
        return results;
      }
    
      async function searchResults(query, page) {
        var q = clean(query);
        var direct = parseHref(q);
        return catalogueOperation(async function (ctx) {
          if (direct) {
            var item = mapItem(await tmdb('/' + direct.type + '/' + direct.id, ctx), direct.type);
            return item ? [item] : [];
          }
          var p = Math.max(1, Number(page) || 1);
          var path = q
            ? '/search/multi?query=' + encodeURIComponent(q) + '&include_adult=false&page=' + p
            : '/trending/all/week?page=' + p;
          var data = await tmdb(path, ctx);
          if (!Array.isArray(data.results)) throw new Error('Movy returned an invalid catalogue response.');
          return ((data && data.results) || []).map(function (row) { return mapItem(row); }).filter(Boolean).slice(0, 40);
        }, 10000);
      }
    
      async function extractDetails(urlOrId) {
        var ref = parseHref(urlOrId);
        if (!ref) return { title: 'Unavailable', description: 'Select an exact catalogue entry.' };
        return catalogueOperation(async function (ctx) {
          var meta = await tmdb('/' + ref.type + '/' + ref.id, ctx);
          if (String(meta.id) !== ref.id) throw new Error('Movy catalogue identity mismatch.');
          var item = mapItem(meta, ref.type);
          if (!item) return { title: 'Unavailable', description: '', href: urlOrId };
          item.description = clean(meta.overview);
          item.synopsis = item.description;
          item.genres = (meta.genres || []).map(function (g) { return g && g.name; }).filter(Boolean);
          item.status = clean(meta.status);
          item.aliases = clean(meta.original_title || meta.original_name);
          item.airdate = clean(meta.release_date || meta.first_air_date);
          return item;
        }, 10000);
      }
    
      async function extractEpisodes(seriesId) {
        var ref = parseHref(seriesId);
        if (!ref) return [];
        if (ref.type === 'movie') {
          return [{ id: href('movie', ref.id), href: href('movie', ref.id), number: 1, episodeNumber: 1,
            title: 'Movie', subAvailable: true, dubAvailable: false }];
        }
        return catalogueOperation(async function (ctx) {
          var meta = await tmdb('/tv/' + ref.id, ctx);
          if (String(meta.id) !== ref.id || !Array.isArray(meta.seasons)) throw new Error('Movy returned an invalid series identity.');
          var seasons = meta.seasons.filter(function (row) {
            return row && Number.isSafeInteger(Number(row.season_number)) && Number(row.season_number) > 0;
          });
          var today = new Date().toISOString().slice(0, 10);
          var rows = await catalogueMap(seasons, async function (row) {
            var num = Number(row.season_number);
            var season = await tmdb('/tv/' + ref.id + '/season/' + num, ctx);
            if (!Array.isArray(season.episodes) || (season.season_number != null && Number(season.season_number) !== num)) {
              throw new Error('Movy returned an invalid season identity.');
            }
            var out = [], seen = {};
            var episodes = season.episodes;
            episodes.forEach(function (ep) {
              var n = Number(ep && ep.episode_number);
              if (!Number.isSafeInteger(n) || n < 1 || seen[n] ||
                  (ep.season_number != null && Number(ep.season_number) !== num) ||
                  (ep.show_id != null && String(ep.show_id) !== ref.id)) throw new Error('Movy returned an invalid episode identity.');
              seen[n] = true;
              // Unaired episodes have no stream yet.
              if (ep.air_date && ep.air_date > today) return;
              out.push({
                id: href('tv', ref.id, num, n),
                href: href('tv', ref.id, num, n),
                season: num,
                number: n,
                episodeNumber: n,
                title: clean(ep.name) || ('S' + num + 'E' + n),
                description: clean(ep.overview),
                image: image(ep.still_path, 'w300'),
                subAvailable: true,
                dubAvailable: false,
              });
            });
            return out.sort(function (a, b) { return a.number - b.number; });
          }, ctx);
          return [].concat.apply([], rows).slice(0, 600);
        }, 24000);
      }
    
      async function extractStreamUrl(episodeHref, lang) {
        var want = String(lang || 'sub').toLowerCase();
        if (want === 'dub' || want === 'vf') {
          return { streams: [], subtitles: [], lang: want,
            error: { code: 'dub_unavailable', message: 'Movy provides original audio only.' } };
        }
        var ref = parseHref(episodeHref);
        if (!ref) return { streams: [], subtitles: [], error: { message: 'Invalid Movy link.' } };
        if (ref.type === 'tv' && (!ref.season || !ref.episode)) {
          return { streams: [], subtitles: [], error: { message: 'Choose an episode to play.' } };
        }
        var key = ref.type + ':' + ref.id + ':' + ref.season + ':' + ref.episode;
        if (inflight[key]) return JSON.parse(JSON.stringify(await inflight[key]));
        if (Object.keys(inflight).length >= 2) {
          return { streams: [], subtitles: [],
            error: { code: 'busy', message: 'Another title is still loading. Try again in a moment.' } };
        }
        var ctx = { deadline: Date.now() + RESOLVE_MS, closed: false, requests: 0, diagnostics: [], captionRows: [] };
        var pending = (async function () {
          try {
            var servers = await withTimeout(resolve(ref, ctx), RESOLVE_MS, null);
            if (!servers) ctx.failure = failure('timeout', 'resolution');
            return pack(servers, ctx);
          } catch (error) {
            ctx.failure = error.result || failure('resolution_error', 'resolution');
            return pack(null, ctx);
          } finally { ctx.closed = true; }
        })();
        inflight[key] = pending;
        try { return JSON.parse(JSON.stringify(await pending)); }
        finally { delete inflight[key]; }
      }
    
      var FEEDS = {
        'movy-trending': { title: 'Trending this week', path: '/trending/all/week', style: 'hero' },
        'movy-movies': { title: 'Trending movies', path: '/trending/movie/week', type: 'movie' },
        'movy-tv': { title: 'Trending series', path: '/trending/tv/week', type: 'tv' },
        'movy-top-movies': { title: 'Top rated movies', path: '/movie/top_rated', type: 'movie' },
        'movy-top-tv': { title: 'Top rated series', path: '/tv/top_rated', type: 'tv' },
      };
    
      async function discoveryHome() {
        var ids = Object.keys(FEEDS);
        return catalogueOperation(async function (ctx) {
        var sections = await catalogueMap(ids, async function (id) {
          var feed = FEEDS[id];
          try {
            var data = await tmdb(feed.path + '?page=1', ctx);
            var items = (data.results || []).map(function (r) { return mapItem(r, feed.type); }).filter(Boolean);
            return { id: id, title: feed.title, style: feed.style || 'poster',
              items: feed.style === 'hero' ? items.slice(0, 8) : items };
          } catch (_) { return null; }
        }, ctx);
        return { sections: sections.filter(function (s) { return s && s.items.length; }) };
        }, 12000);
      }
    
      async function discoveryFeed(feedId, page) {
        var p = Math.max(1, Number(page) || 1);
        var feed = FEEDS[feedId] || FEEDS['movy-trending'];
        return catalogueOperation(async function (ctx) {
          var data = await tmdb(feed.path + '?page=' + p, ctx);
          var items = (data.results || []).map(function (r) { return mapItem(r, feed.type); }).filter(Boolean);
          return { feedId: feedId || 'movy-trending', page: p, items: items, hasMore: items.length >= 18 };
        }, 10000);
      }
    
      globalThis.searchResults = searchResults;
      globalThis.extractDetails = extractDetails;
      globalThis.extractEpisodes = extractEpisodes;
      globalThis.extractStreamUrl = extractStreamUrl;
      globalThis.discoveryHome = discoveryHome;
      globalThis.discoveryFeed = discoveryFeed;
    })();
    return globalThis;
  })(globalThis);

  function toRef(href) { var m = String(href || '').match(/mdb:(movie|tv):(\d+)(?::(\d+))?(?::(\d+))?/i); if (!m) return null; return { type: m[1].toLowerCase(), id: m[2], season: m[3] ? Number(m[3]) : null, episode: m[4] ? Number(m[4]) : null }; }
  function playable(r) {
    return !!(r && (r.url || (Array.isArray(r.streams) && r.streams.some(function (s) { return s && (typeof s === 'string' || s.url); }))));
  }

  globalThis.extractStreamUrl = async function (href, lang, bypassCache) {
    var first = null, failure = null;
    try { first = await hostResolve(href, lang, bypassCache); } catch (e) { failure = e; }
    if (typeof first === 'string') { try { first = JSON.parse(first); } catch (_) { first = { url: first }; } }
    if (playable(first)) return first;
    var want = String(lang || 'sub').toLowerCase();
    var ref = toRef(href);
    if (ref && want !== 'dub' && !(ref.type === 'tv' && (!ref.season || !ref.episode))) {
      var key = ref.type + ':' + ref.id + (ref.type === 'tv' ? ':' + ref.season + ':' + ref.episode : '');
      try {
        var alt = await backup.extractStreamUrl(key, 'sub');
        if (playable(alt)) {
          alt.source = 'MovieDB backup (movy.sx original audio)';
          (alt.streams || []).forEach(function (s) { if (s && typeof s === 'object') s.title = 'Backup · ' + (s.title || s.label || s.server || 'Original audio'); });
          return alt;
        }
      } catch (_) {}
    }
    if (failure) throw failure;
    return first || { streams: [], subtitles: [] };
  };
})();
