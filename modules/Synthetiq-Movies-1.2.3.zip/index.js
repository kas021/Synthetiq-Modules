(() => {
  'use strict';

  const TMDB = 'https://api.themoviedb.org/3';
  const TMDB_KEY = 'e1a8efff4415028c5c266b3fcd50db6e';
  const IMAGE = 'https://image.tmdb.org/t/p';
  const MOVIES_BACKENDS = [
    'https://198.244.149.250.sslip.io/movies/resolve',
  ];
  // Stream Unity / VixCloud 403s from every VPS kitchen. Resolve it on the
  // phone first, then fall through to the OVH VideoEasy/STCine brain.
  const STREAMINGUNITY_BASE = 'https://streamingunity.vip';
  const VIX_BASE = 'https://vixcloud.co';
  const SU_UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const SU_PAGE_ACCEPT =
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
  const SU_HLS_ACCEPT =
    'application/vnd.apple.mpegurl,application/x-mpegURL,application/octet-stream,text/plain,*/*;q=0.8';
  // Public subtitle proxy. Wyzie keys stay on the One server, never in this ZIP.
  const SUBS_API = 'https://one.synthetiq.uk/v1/subs';
  const USER_AGENT =
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15';
  const SUBTITLE_HEADERS = {
    'User-Agent': USER_AGENT,
    Accept: 'text/vtt,text/plain,application/x-subrip,*/*',
    Origin: 'https://www.opensubtitles.org',
    Referer: 'https://www.opensubtitles.org/',
  };
  // Movies exposes a small language menu, but resolves only the selected
  // subtitle language. This keeps stream startup and downloads cheap.
  const MAX_SUBS_TOTAL = 1;
  const MAX_SUBS_PER_LANG = 1;
  const MAX_HYDRATED_SUBS = 1;
  const MAX_MEDIA_STREAMS = 6;
  const MAX_SUBTITLE_TEXT_CACHE = 12;
  const SUBTITLE_LIST_TTL_MS = 10 * 60 * 1000;
  const SUBTITLE_TEXT_TTL_MS = 30 * 60 * 1000;
  const subtitleListCache = Object.create(null);
  const subtitleListInflight = Object.create(null);
  const subtitleTextCache = Object.create(null);
  const subtitleTextInflight = Object.create(null);
  const detailsCache = Object.create(null);
  const seasonCache = Object.create(null);
  const seasonInflight = Object.create(null);

  async function readBody(response) {
    if (!response) return '';
    if (typeof response.body === 'string' && response.body.length) return response.body;
    if (response.json && typeof response.json !== 'function') {
      try { return JSON.stringify(response.json); } catch (_) {}
    }
    if (typeof response.text === 'function') {
      try {
        const text = await response.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof response.json === 'function') {
      try { return JSON.stringify(await response.json()); } catch (_) {}
    }
    return '';
  }

  async function requestJson(path) {
    const url = TMDB + path + (path.indexOf('?') >= 0 ? '&' : '?') +
      'api_key=' + encodeURIComponent(TMDB_KEY) + '&language=en-US';
    const headers = {
      Accept: 'application/json,*/*',
      'User-Agent': USER_AGENT,
      Referer: 'https://www.themoviedb.org/',
    };
    let response;
    if (typeof fetchv2 === 'function') response = await fetchv2(url, headers, 'GET', null);
    else if (typeof fetch === 'function') response = await fetch(url, { headers });
    else throw new Error('No fetch available');
    const status = Number((response && response.status) || 0);
    if (status && (status < 200 || status >= 400)) throw new Error('tmdb_http_' + status);
    const body = await readBody(response);
    if (!body) return null;
    try { return JSON.parse(body); } catch (_) { return null; }
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function twoDigits(value) {
    const text = String(value);
    return text.length < 2 ? '0' + text : text;
  }

  function todayStamp() {
    const date = new Date();
    return date.getFullYear() + '-' + twoDigits(date.getMonth() + 1) + '-' + twoDigits(date.getDate());
  }

  function hasAired(airDate) {
    const stamp = String(airDate || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(stamp)) return true;
    return stamp <= todayStamp();
  }

  function withTimeout(promise, ms, fallback) {
    if (typeof setTimeout !== 'function') return promise;
    let timer = null;
    const timeout = new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallback), Math.max(1, Number(ms) || 0));
    });
    return Promise.race([promise, timeout]).then((value) => {
      if (timer && typeof clearTimeout === 'function') clearTimeout(timer);
      return value;
    }, (error) => {
      if (timer && typeof clearTimeout === 'function') clearTimeout(timer);
      throw error;
    });
  }

  function poster(path, size) {
    if (!path) return '';
    if (/^https?:\/\//i.test(String(path))) return String(path);
    return IMAGE + '/' + (size || 'w500') + (String(path).charAt(0) === '/' ? path : '/' + path);
  }

  function href(type, id, season, episode) {
    let out = 'https://www.themoviedb.org/' + type + '/' + id;
    if (type === 'tv' && season != null && episode != null) {
      out += '?season=' + Number(season) + '&episode=' + Number(episode);
    }
    return out;
  }

  function parseHref(value) {
    const raw = String(value || '').trim();
    let match = raw.match(/themoviedb\.org\/(movie|tv)\/(\d+)(?:\?[^#]*season=(\d+)&episode=(\d+))?/i);
    if (!match) match = raw.match(/^(movie|tv):(\d+)(?::(\d+):(\d+))?$/i);
    if (!match) return null;
    return {
      type: match[1].toLowerCase(),
      id: match[2],
      season: match[3] ? Number(match[3]) : null,
      episode: match[4] ? Number(match[4]) : null,
    };
  }

  function mapItem(row, forcedType) {
    if (!row) return null;
    const type = String(forcedType || row.media_type || '').toLowerCase();
    if (type !== 'movie' && type !== 'tv') return null;
    if (row.adult === true) return null;
    const id = Number(row.id);
    const title = clean(row.title || row.name || row.original_title || row.original_name);
    if (!id || !title) return null;
    const year = String(row.release_date || row.first_air_date || '').slice(0, 4);
    const image = poster(row.poster_path || row.backdrop_path);
    return {
      id: href(type, id),
      href: href(type, id),
      title: title + (year ? ' (' + year + ')' : ''),
      image,
      poster: image,
      type,
      mediaType: type,
      year: year || undefined,
    };
  }

  async function searchResults(query, page) {
    const q = clean(query);
    const pageNumber = Math.max(1, Number(page || 0) + 1);
    const path = q
      ? '/search/multi?query=' + encodeURIComponent(q) +
          '&include_adult=false&page=' + pageNumber
      : '/trending/all/week?page=' + pageNumber;
    const data = await withTimeout(requestJson(path), 8000, null).catch(() => null);
    return ((data && data.results) || []).map((row) => mapItem(row)).filter(Boolean).slice(0, 40);
  }

  async function catalogue(type, path, page) {
    const data = await withTimeout(
      requestJson('/' + type + '/' + path + '?page=' + Math.max(1, Number(page) || 1)),
      8000,
      null,
    ).catch(() => null);
    return {
      items: ((data && data.results) || []).map((row) => mapItem(row, type)).filter(Boolean),
      page: Math.max(1, Number(page) || 1),
      hasMore: Math.max(1, Number(page) || 1) < Number((data && data.total_pages) || 1),
    };
  }

  async function discoveryHome() {
    const [trending, movies, tv] = await Promise.all([
      withTimeout(requestJson('/trending/all/week?page=1'), 8000, null).catch(() => null),
      catalogue('movie', 'popular', 1),
      catalogue('tv', 'popular', 1),
    ]);
    const trendItems = ((trending && trending.results) || [])
      .map((row) => mapItem(row)).filter(Boolean);
    return {
      sections: [
        { id: 'trending', title: 'Trending', style: 'hero', items: trendItems.slice(0, 8), viewAll: { mode: 'feed', feedId: 'trending' } },
        { id: 'movies', title: 'Popular Movies', style: 'poster', items: movies.items.slice(0, 20), viewAll: { mode: 'feed', feedId: 'movies' } },
        { id: 'tv', title: 'Popular TV', style: 'poster', items: tv.items.slice(0, 20), viewAll: { mode: 'feed', feedId: 'tv' } },
      ],
    };
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    if (feedId === 'movies') return catalogue('movie', 'popular', pageNumber);
    if (feedId === 'tv') return catalogue('tv', 'popular', pageNumber);
    const data = await withTimeout(
      requestJson('/trending/all/week?page=' + pageNumber),
      8000,
      null,
    ).catch(() => null);
    return {
      items: ((data && data.results) || []).map((row) => mapItem(row)).filter(Boolean),
      page: pageNumber,
      hasMore: pageNumber < Number((data && data.total_pages) || 1),
    };
  }

  async function extractDetails(value) {
    const parsed = parseHref(value);
    if (!parsed) return { title: 'Unknown title', description: 'Unable to resolve this title.' };
    const key = parsed.type + ':' + parsed.id;
    if (detailsCache[key]) return detailsCache[key];
    const data = await requestJson('/' + parsed.type + '/' + parsed.id);
    if (!data) return { title: 'Unknown title', description: 'Metadata is unavailable.' };
    const title = clean(data.title || data.name) || 'Unknown title';
    const image = poster(data.poster_path || data.backdrop_path);
    const seasons = parsed.type === 'tv'
      ? (data.seasons || []).map((row) => {
          const number = Number(row && row.season_number);
          if (!number || number < 1) return 0;
          if (!hasAired(row && row.air_date) && Number(row.episode_count || 0) === 0) return 0;
          return number;
        }).filter((n) => n > 0)
      : [];
    const result = {
      id: href(parsed.type, parsed.id),
      href: href(parsed.type, parsed.id),
      url: href(parsed.type, parsed.id),
      title,
      description: clean(data.overview) || 'No description available.',
      image,
      poster: image,
      banner: poster(data.backdrop_path, 'w1280') || image,
      genres: (data.genres || []).map((row) => row && row.name).filter(Boolean),
      rating: data.vote_average == null ? '' : Number(data.vote_average).toFixed(1),
      year: String(data.release_date || data.first_air_date || '').slice(0, 4),
      type: parsed.type,
      mediaType: parsed.type,
      seasonNumbers: seasons,
      seasons: seasons.length,
      isMovie: parsed.type === 'movie',
    };
    detailsCache[key] = result;
    if (parsed.type === 'tv' && seasons.length) {
      loadSeasons(parsed.id, seasons, image).catch(() => {});
    }
    return result;
  }

  function mapSeasonEpisodes(tmdbId, season, data, fallbackImage) {
    return ((data && data.episodes) || []).map((row) => {
      const episode = Number(row && row.episode_number);
      if (!episode || !hasAired(row && row.air_date)) return null;
      return {
        number: episode,
        episodeNumber: episode,
        season,
        seasonNumber: season,
        title: 'S' + season + 'E' + episode + ' - ' + (clean(row.name) || 'Episode ' + episode),
        href: href('tv', tmdbId, season, episode),
        image: poster(row.still_path, 'w300') || fallbackImage || '',
        airDate: String((row && row.air_date) || '').slice(0, 10),
        subAvailable: true,
      };
    }).filter(Boolean);
  }

  function collectedEpisodes(tmdbId, seasonNumbers) {
    const episodes = [];
    seasonNumbers.forEach((season) => {
      const rows = seasonCache[tmdbId + ':' + season] || [];
      rows.forEach((row) => episodes.push(row));
    });
    return episodes;
  }

  async function loadSeasons(tmdbId, seasonNumbers, fallbackImage) {
    const missing = seasonNumbers.filter((season) => !seasonCache[tmdbId + ':' + season]);
    if (!missing.length) return collectedEpisodes(tmdbId, seasonNumbers);
    const inflightKey = tmdbId + ':' + missing.join(',');
    if (!seasonInflight[inflightKey]) {
      seasonInflight[inflightKey] = (async () => {
        for (let offset = 0; offset < missing.length; offset += 12) {
          const batch = missing.slice(offset, offset + 12);
          const append = batch.map((season) => 'season/' + season).join(',');
          const data = await requestJson('/tv/' + tmdbId + '?append_to_response=' + append);
          const needFallback = [];
          batch.forEach((season) => {
            const block = data && (data['season/' + season] || data['season_' + season]);
            if (block && Array.isArray(block.episodes)) {
              seasonCache[tmdbId + ':' + season] = mapSeasonEpisodes(
                tmdbId, season, block, fallbackImage,
              );
            } else {
              needFallback.push(season);
            }
          });
          if (needFallback.length) {
            const pages = await Promise.all(needFallback.map((season) =>
              requestJson('/tv/' + tmdbId + '/season/' + season).catch(() => null),
            ));
            needFallback.forEach((season, index) => {
              seasonCache[tmdbId + ':' + season] = mapSeasonEpisodes(
                tmdbId, season, pages[index], fallbackImage,
              );
            });
          }
        }
      })();
    }
    try {
      await seasonInflight[inflightKey];
    } finally {
      delete seasonInflight[inflightKey];
    }
    return collectedEpisodes(tmdbId, seasonNumbers);
  }

  async function extractEpisodes(value) {
    const parsed = parseHref(value);
    if (!parsed) return [];
    const details = await extractDetails(value);
    if (parsed.type === 'movie') {
      return [{
        number: 1,
        episodeNumber: 1,
        season: 1,
        seasonNumber: 1,
        title: details.title,
        href: href('movie', parsed.id),
        image: details.image || '',
        isMovie: true,
        mediaType: 'movie',
        subAvailable: true,
      }];
    }
    const seasons = details.seasonNumbers && details.seasonNumbers.length
      ? details.seasonNumbers : [1];
    const episodes = await loadSeasons(parsed.id, seasons, details.image || '');
    episodes.sort((a, b) => a.season - b.season || a.episodeNumber - b.episodeNumber);
    episodes.forEach((row, index) => { row.number = index + 1; });
    return episodes;
  }

  const LANG_NAMES = {
    en: 'English',
    hi: 'Hindi',
    es: 'Spanish',
    de: 'German',
    pt: 'Portuguese',
    fr: 'French',
    ar: 'Arabic',
    it: 'Italian',
    ja: 'Japanese',
    ko: 'Korean',
    ru: 'Russian',
    zh: 'Chinese',
  };

  function streamLanguage(row) {
    const code = String((row && (row.language || row.lang)) || '').toLowerCase();
    if (LANG_NAMES[code]) return code;
    const blob = [
      row && row.label,
      row && row.quality,
      row && row.audio,
    ].filter(Boolean).join(' ').toLowerCase();
    if (/\bhindi\b/.test(blob)) return 'hi';
    if (/\b(spanish|latino|castellano)\b/.test(blob)) return 'es';
    if (/\b(german|deutsch)\b/.test(blob)) return 'de';
    if (/\b(portuguese|portugues)\b/.test(blob)) return 'pt';
    if (/\b(french|francais)\b/.test(blob)) return 'fr';
    if (/\barabic\b/.test(blob)) return 'ar';
    if (/\bitalian\b/.test(blob)) return 'it';
    if (/\bjapanese\b/.test(blob)) return 'ja';
    if (/\bkorean\b/.test(blob)) return 'ko';
    if (/\benglish\b/.test(blob)) return 'en';
    return '';
  }

  function streamLabel(row) {
    const code = streamLanguage(row);
    const name = LANG_NAMES[code] || String((row && row.label) || '').trim();
    if (code === 'en') return ' English';
    return name || 'Stream';
  }

  function mapSubtitles(rawList) {
    const out = [];
    const seen = Object.create(null);
    const rows = Array.isArray(rawList) ? rawList : [];
    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i];
      if (!row || typeof row !== 'object') continue;
      const file = String(row.url || row.file || row.src || '').trim();
      if (!file || file.indexOf('http') !== 0) continue;
      if (/\/thumbs?\/|sprite|thumbnail/i.test(file)) continue;
      if (seen[file]) continue;
      const lang = String(row.language || row.lang || row.srclang || '').toLowerCase().trim() || 'und';
      const baseLang = String(lang).split('-')[0];
      seen[file] = true;
      const variant = baseLang !== lang ? ' (' + String(lang).toUpperCase() + ')' : '';
      const label = (LANG_NAMES[baseLang] || baseLang || 'Subtitles') + variant
        + (row.hearingImpaired === true ? ' (HI)' : '');
      out.push({
        id: file,
        label: label,
        language: lang,
        lang: lang,
        url: file,
        file: file,
        kind: 'captions',
        headers: SUBTITLE_HEADERS,
        hearingImpaired: row.hearingImpaired === true,
        downloadCount: Number(row.downloadCount) || 0,
      });
    }
    // Group by base language, keep the best N per language (by popularity),
    // sort English first then by language code, cap the total.
    const byLang = Object.create(null);
    for (let i = 0; i < out.length; i += 1) {
      const key = String(out[i].language).split('-')[0] || 'und';
      (byLang[key] = byLang[key] || []).push(out[i]);
    }
    const groups = Object.keys(byLang).map((key) => {
      byLang[key].sort((a, b) => (Number(b.downloadCount) || 0) - (Number(a.downloadCount) || 0));
      return { key: key, rows: byLang[key].slice(0, MAX_SUBS_PER_LANG) };
    });
    groups.sort((a, b) => {
      if (a.key === 'en') return -1;
      if (b.key === 'en') return 1;
      return a.key.localeCompare(b.key);
    });
    const flat = [];
    for (let i = 0; i < groups.length && flat.length < MAX_SUBS_TOTAL; i += 1) {
      for (let j = 0; j < groups[i].rows.length && flat.length < MAX_SUBS_TOTAL; j += 1) {
        flat.push(groups[i].rows[j]);
      }
    }
    return flat;
  }

  function srtToVtt(raw) {
    const text = String(raw || '').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    if (!text.trim()) return '';
    if (/^WEBVTT/i.test(text.trim())) return text;
    const lines = text.split('\n');
    const out = ['WEBVTT', ''];
    for (let i = 0; i < lines.length; i += 1) {
      let line = lines[i];
      if (line.indexOf('-->') >= 0 && /\d\d:\d\d:\d\d,\d+/.test(line)) {
        line = line.replace(/(\d\d:\d\d:\d\d),(\d+)/g, '$1.$2');
      }
      out.push(line);
    }
    return out.join('\n');
  }

  async function fetchSubtitleText(url) {
    const file = String(url || '').trim();
    if (!file || file.indexOf('http') !== 0) return '';
    const cached = subtitleTextCache[file];
    if (cached && cached.expiresAt > Date.now()) return cached.body;
    if (subtitleTextInflight[file]) return subtitleTextInflight[file];
    const job = (async function () {
      try {
        const request = typeof fetchv2 === 'function'
          ? fetchv2(file, SUBTITLE_HEADERS, 'GET', null)
          : typeof fetch === 'function'
            ? fetch(file, { headers: SUBTITLE_HEADERS })
            : null;
        if (!request) return '';
        const response = await withTimeout(request, 5000, null);
        if (!response) return '';
        const body = await readBody(response);
        if (!body || /<html|just a moment|captcha/i.test(body.slice(0, 400))) return '';
        return body.length > 400000 ? body.slice(0, 400000) : body;
      } catch (_) {
        return '';
      }
    })().then(function (body) {
      if (body) {
        const keys = Object.keys(subtitleTextCache);
        if (keys.length >= MAX_SUBTITLE_TEXT_CACHE) {
          let oldest = keys[0];
          for (let i = 1; i < keys.length; i += 1) {
            if (subtitleTextCache[keys[i]].expiresAt < subtitleTextCache[oldest].expiresAt) oldest = keys[i];
          }
          delete subtitleTextCache[oldest];
        }
        subtitleTextCache[file] = { body: body, expiresAt: Date.now() + SUBTITLE_TEXT_TTL_MS };
      }
      return body;
    });
    subtitleTextInflight[file] = job;
    return job.then(function (body) {
      delete subtitleTextInflight[file];
      return body;
    }, function () {
      delete subtitleTextInflight[file];
      return '';
    });
  }

  async function hydrateSubtitleContent(subs) {
    const rows = Array.isArray(subs) ? subs : [];
    if (!rows.length) return [];
    // Embed only the first English track. Other tracks keep their URL and are
    // fetched on demand by the player, preventing large response payloads and
    // several subtitle downloads from delaying stream startup.
    const preferredIndexes = [];
    for (let i = 0; i < rows.length; i += 1) {
      const language = String(rows[i] && (rows[i].language || rows[i].lang) || '')
        .toLowerCase().split('-')[0];
      if (language === 'en') preferredIndexes.push(i);
    }
    if (!preferredIndexes.length) preferredIndexes.push(0);
    const hydrateIndexes = preferredIndexes.slice(0, MAX_HYDRATED_SUBS);
    const bodies = await Promise.all(hydrateIndexes.map(function (index) {
      return fetchSubtitleText(rows[index] && rows[index].url);
    }));
    const bodyByIndex = Object.create(null);
    hydrateIndexes.forEach(function (index, bodyIndex) {
      bodyByIndex[index] = bodies[bodyIndex] || '';
    });
    return rows.map(function (row, index) {
      if (!Object.prototype.hasOwnProperty.call(bodyByIndex, index)) return row;
      const vtt = srtToVtt(bodyByIndex[index]);
      if (!vtt) return row;
      const copy = {};
      const keys = Object.keys(row);
      for (let i = 0; i < keys.length; i += 1) copy[keys[i]] = row[keys[i]];
      copy.content = vtt;
      copy.data = vtt;
      return copy;
    });
  }

  async function withEnglishSubs(stream, extra) {
    if (!stream) return stream;
    const incoming = Array.isArray(stream.subtitles) ? stream.subtitles : [];
    const mapped = mapSubtitles(incoming.concat(Array.isArray(extra) ? extra : []));
    stream.subtitles = await hydrateSubtitleContent(mapped);
    return stream;
  }

  async function fetchSubsForLanguage(tmdbId, season, episode, lang) {
    const id = String(tmdbId || '').trim();
    if (!id) return [];
    try {
      let path = SUBS_API + '?id=' + encodeURIComponent(id)
        + '&language=' + encodeURIComponent(String(lang || 'en'))
        + '&format=srt';
      if (season != null && Number(season) > 0) {
        path += '&season=' + encodeURIComponent(Number(season));
      }
      if (episode != null && Number(episode) > 0) {
        path += '&episode=' + encodeURIComponent(Number(episode));
      }
      const headers = {
        Accept: 'application/json,*/*',
        'User-Agent': USER_AGENT,
      };
      const request = typeof fetchv2 === 'function'
        ? fetchv2(path, headers, 'GET', null)
        : typeof fetch === 'function'
          ? fetch(path, { headers })
          : null;
      if (!request) return [];
      const response = await withTimeout(request, 5000, null);
      if (!response) return [];
      const body = await readBody(response);
      if (!body) return [];
      let data = null;
      try {
        data = JSON.parse(body);
      } catch (_) {
        return [];
      }
      if (!data || data.ok === false) return [];
      return data.subtitles || [];
    } catch (_) {
      return [];
    }
  }

  async function fetchEnglishSubs(tmdbId, season, episode) {
    const id = String(tmdbId || '').trim();
    if (!id) return [];
    const key = id + ':' + String(season || 0) + ':' + String(episode || 0) + ':en';
    const cached = subtitleListCache[key];
    if (cached && cached.expiresAt > Date.now()) return cached.rows.slice();
    if (subtitleListInflight[key]) return subtitleListInflight[key];
    const job = fetchSubsForLanguage(id, season, episode, 'en')
      .then(function (rows) {
        const mapped = mapSubtitles(rows);
        subtitleListCache[key] = { rows: mapped, expiresAt: Date.now() + SUBTITLE_LIST_TTL_MS };
        return mapped.slice();
      })
      .catch(function () { return []; });
    subtitleListInflight[key] = job;
    return job.then(function (rows) {
      delete subtitleListInflight[key];
      return rows;
    }, function () {
      delete subtitleListInflight[key];
      return [];
    });
  }

  async function fetchLazySubtitles(tmdbId, season, episode, language) {
    const code = String(language || 'en').toLowerCase().split('-')[0];
    const allowed = { en: true, es: true, ar: true, de: true };
    if (!allowed[code]) return [];
    const key = String(tmdbId || '') + ':' + String(season || 0) + ':' +
      String(episode || 0) + ':' + code;
    const cached = subtitleListCache[key];
    if (cached && cached.expiresAt > Date.now()) return cached.rows.slice();
    if (subtitleListInflight[key]) return subtitleListInflight[key];
    const job = fetchSubsForLanguage(tmdbId, season, episode, code)
      .then(function (rows) {
        const mapped = mapSubtitles(rows);
        subtitleListCache[key] = { rows: mapped, expiresAt: Date.now() + SUBTITLE_LIST_TTL_MS };
        return mapped.slice(0, MAX_SUBS_TOTAL);
      })
      .catch(function () { return []; });
    subtitleListInflight[key] = job;
    return job.then(function (rows) {
      delete subtitleListInflight[key];
      return rows;
    }, function () {
      delete subtitleListInflight[key];
      return [];
    });
  }

  function compactMediaStreams(rawList) {
    const rows = [];
    const seen = Object.create(null);
    const source = Array.isArray(rawList) ? rawList : [];
    for (let i = 0; i < source.length; i += 1) {
      const row = source[i];
      const url = String(row && row.url || '').trim();
      if (!row || !url || url.indexOf('http') !== 0 || seen[url]) continue;
      seen[url] = true;
      rows.push(row);
    }
    rows.sort(function (a, b) {
      const aEn = streamLanguage(a) === 'en' ? 0 : 1;
      const bEn = streamLanguage(b) === 'en' ? 0 : 1;
      return aEn - bEn || (Number(b.height) || 0) - (Number(a.height) || 0);
    });
    return rows.slice(0, MAX_MEDIA_STREAMS);
  }

  function packBackendStream(resolved) {
    const incoming = Array.isArray(resolved && resolved.streams) ? resolved.streams : [];
    const candidates = incoming.slice();
    if (resolved && resolved.url) candidates.unshift({
      url: resolved.url,
      headers: resolved.headers || {},
      type: resolved.type || 'hls',
      language: resolved.language || 'en',
    });
    const rows = compactMediaStreams(candidates);
    if (!rows.length) return null;
    const preferred = rows.find((row) => streamLanguage(row) === 'en') || rows[0];
    return {
      url: preferred.url,
      streams: rows.map((row) => ({
        url: row.url,
        headers: row.headers || resolved.headers || {},
        streamType: row.type || row.streamType || resolved.type || 'hls',
        label: streamLabel(row),
        language: streamLanguage(row),
      })),
      headers: preferred.headers || resolved.headers || {},
      streamType: preferred.type || preferred.streamType || resolved.type || 'hls',
      quality: '1080p',
      lang: 'sub',
      subtitles: mapSubtitles(resolved && resolved.subtitles),
    };
  }

  function decodePageEntities(value) {
    let text = String(value == null ? '' : value);
    for (let i = 0; i < 3; i += 1) {
      const next = text
        .replace(/&quot;/gi, '"')
        .replace(/&#039;|&#x27;/gi, "'")
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&amp;/gi, '&')
        .replace(/&nbsp;/gi, ' ');
      if (next === text) break;
      text = next;
    }
    return text;
  }

  function suSlug(value) {
    return clean(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'title';
  }

  async function requestPageText(url, extraHeaders) {
    const headers = {
      'User-Agent': SU_UA,
      Accept: SU_PAGE_ACCEPT,
      Referer: STREAMINGUNITY_BASE + '/',
    };
    const extras = extraHeaders || {};
    Object.keys(extras).forEach((key) => { headers[key] = extras[key]; });
    let response = null;
    if (typeof fetchv2 === 'function') response = await fetchv2(url, headers, 'GET', null);
    else if (typeof fetch === 'function') response = await fetch(url, { method: 'GET', headers });
    const status = Number(response && response.status) || 0;
    const text = await readBody(response);
    return { ok: status >= 200 && status < 400, status, text: text || '' };
  }

  function parseInertiaPage(html) {
    const source = String(html || '');
    const match = source.match(/\bdata-page\s*=\s*"([^"]*)"/i) ||
      source.match(/\bdata-page\s*=\s*'([^']*)'/i);
    if (!match || !match[1]) return null;
    try { return JSON.parse(decodePageEntities(match[1])); } catch (_) { return null; }
  }

  function suTitleRecords(page) {
    const props = page && page.props && typeof page.props === 'object' ? page.props : page || {};
    if (Array.isArray(props.titles)) return props.titles;
    if (Array.isArray(props.results)) return props.results;
    if (props.title && typeof props.title === 'object') return [props.title];
    return [];
  }

  function extractVixEmbedUrl(html) {
    const source = String(html || '').replace(/\\\//g, '/');
    const matches = source.match(/<iframe[^>]+src=["']([^"']+)["']/ig) || [];
    for (let i = 0; i < matches.length; i += 1) {
      const match = matches[i].match(/src=["']([^"']+)["']/i);
      const candidate = decodePageEntities(clean(match && match[1]));
      if (/vixcloud\.co\//i.test(candidate)) {
        if (/^https?:\/\//i.test(candidate)) return candidate;
        if (candidate.indexOf('//') === 0) return 'https:' + candidate;
      }
    }
    const direct = source.match(/https?:\/\/vixcloud\.co\/(?:embed|e)\/[^"'<>\s]+/i);
    return direct ? decodePageEntities(clean(direct[0])) : '';
  }

  function unescapeJs(value) {
    return String(value || '')
      .replace(/\\u0026/gi, '&')
      .replace(/\\\//g, '/')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'");
  }

  function vixConfig(html) {
    const source = String(html || '');
    let streams = [];
    const streamMatch = source.match(/window\.streams\s*=\s*(\[[\s\S]*?\])\s*;/i);
    if (streamMatch) {
      try {
        const parsed = JSON.parse(unescapeJs(streamMatch[1]));
        if (Array.isArray(parsed)) streams = parsed;
      } catch (_) {}
    }
    streams.sort((a, b) => {
      const activeA = a && (a.active === true || a.active === 1) ? 1 : 0;
      const activeB = b && (b.active === true || b.active === 1) ? 1 : 0;
      return activeB - activeA;
    });
    const tokenMatch = source.match(/["']token["']\s*:\s*["']([^"']+)["']/i);
    const expiresMatch = source.match(/["']expires["']\s*:\s*["']([^"']+)["']/i);
    const asnMatch = source.match(/["']asn["']\s*:\s*["']([^"']*)["']/i);
    const masterMatch = source.match(/window\.masterPlaylist\s*=\s*\{[\s\S]*?\burl\s*:\s*["']([^"']+)["']/i);
    const videoMatch = source.match(/window\.video\s*=\s*\{[\s\S]*?\bid\s*:\s*["']([^"']+)["']/i);
    const bases = [];
    streams.forEach((stream) => {
      const value = unescapeJs(stream && stream.url);
      if (value && value.indexOf('/playlist/') >= 0) bases.push(value);
    });
    if (masterMatch && masterMatch[1]) bases.push(unescapeJs(masterMatch[1]));
    return {
      streams: bases,
      token: tokenMatch ? tokenMatch[1] : '',
      expires: expiresMatch ? expiresMatch[1] : '',
      asn: asnMatch ? asnMatch[1] : '',
      mediaId: videoMatch ? videoMatch[1] : '',
      canPlayFhd: /window\.canPlayFHD\s*=\s*true/i.test(source),
    };
  }

  function appendQuery(url, key, value) {
    const result = String(url || '');
    if (!value || new RegExp('(?:[?&])' + key + '=', 'i').test(result)) return result;
    return result + (result.indexOf('?') >= 0 ? '&' : '?') + key + '=' + encodeURIComponent(String(value));
  }

  function buildVixPlaylistUrl(base, config) {
    let url = clean(base).replace(/&amp;/g, '&');
    url = appendQuery(url, 'token', config.token);
    url = appendQuery(url, 'expires', config.expires);
    url = appendQuery(url, 'asn', config.asn);
    if (config.canPlayFhd) url = appendQuery(url, 'h', '1');
    url = appendQuery(url, 'lang', 'en');
    return url;
  }

  function vixHeaders() {
    return {
      'User-Agent': SU_UA,
      Accept: SU_HLS_ACCEPT,
      Referer: VIX_BASE + '/',
      Origin: VIX_BASE,
    };
  }

  async function loadSuTitle(id, slug) {
    const candidates = [];
    if (id && slug) candidates.push(STREAMINGUNITY_BASE + '/en/titles/' + id + '-' + slug);
    if (id) candidates.push(STREAMINGUNITY_BASE + '/en/titles/' + id);
    for (let i = 0; i < candidates.length; i += 1) {
      const pageRes = await requestPageText(candidates[i]);
      if (!pageRes.ok) continue;
      const page = parseInertiaPage(pageRes.text);
      const title = page && page.props && page.props.title;
      if (title && title.id) return title;
    }
    return null;
  }

  async function findStreamingUnityTitle(parsed) {
    const path = parsed.type === 'tv' ? '/tv/' + parsed.id : '/movie/' + parsed.id;
    const meta = await withTimeout(requestJson(path), 8000, null).catch(() => null);
    const name = clean(meta && (meta.title || meta.name || meta.original_title || meta.original_name));
    if (!name) return null;
    const searchRes = await requestPageText(
      STREAMINGUNITY_BASE + '/en/search?q=' + encodeURIComponent(name),
    );
    if (!searchRes.ok) return null;
    const page = parseInertiaPage(searchRes.text);
    const records = suTitleRecords(page);
    const wantedType = parsed.type === 'tv' ? 'tv' : 'movie';
    const wantedName = name.toLowerCase();
    const ranked = records.slice().sort((a, b) => {
      const aName = clean(a && (a.name || a.title)).toLowerCase() === wantedName ? 0 : 1;
      const bName = clean(b && (b.name || b.title)).toLowerCase() === wantedName ? 0 : 1;
      const aType = String(a && a.type || '').toLowerCase() === wantedType ? 0 : 1;
      const bType = String(b && b.type || '').toLowerCase() === wantedType ? 0 : 1;
      return aName - bName || aType - bType;
    });
    let namedFallback = null;
    for (let i = 0; i < Math.min(ranked.length, 6); i += 1) {
      const row = ranked[i];
      const id = String(row && row.id || '');
      if (!id) continue;
      if (String(row.type || '').toLowerCase() !== wantedType &&
          clean(row.name || row.title).toLowerCase() !== wantedName) {
        continue;
      }
      const title = await loadSuTitle(id, suSlug(row.slug || row.name || row.title));
      if (!title) continue;
      if (String(title.tmdb_id || '') === String(parsed.id)) return title;
      if (!namedFallback &&
          !title.tmdb_id &&
          clean(title.name || title.title).toLowerCase() === wantedName &&
          String(title.type || '').toLowerCase() === wantedType) {
        namedFallback = title;
      }
    }
    return namedFallback;
  }

  async function streamingUnityEpisodeId(title, season, episode) {
    const slug = suSlug(title.slug || title.name);
    const href = STREAMINGUNITY_BASE + '/en/titles/' + title.id + '-' + slug + '/season-' + Number(season);
    const pageRes = await requestPageText(href);
    if (!pageRes.ok) return '';
    const page = parseInertiaPage(pageRes.text);
    const loaded = page && page.props && page.props.loadedSeason;
    const rows = loaded && Array.isArray(loaded.episodes) ? loaded.episodes : [];
    const hit = rows.find((row) => Number(row && row.number) === Number(episode));
    return hit && hit.id ? String(hit.id) : '';
  }

  async function resolveStreamingUnityPlaylist(embedUrl, iframeUrl) {
    const embedRes = await requestPageText(embedUrl, {
      Referer: iframeUrl || STREAMINGUNITY_BASE + '/',
    });
    if (!embedRes.ok || !embedRes.text) return null;
    const config = vixConfig(embedRes.text);
    const bases = config.streams.slice();
    if (config.mediaId && !bases.length) {
      bases.push(VIX_BASE + '/playlist/' + config.mediaId + '?b=1');
    }
    const headers = vixHeaders();
    const seen = Object.create(null);
    for (let i = 0; i < bases.length; i += 1) {
      const playlistUrl = buildVixPlaylistUrl(bases[i], config);
      if (!playlistUrl || seen[playlistUrl]) continue;
      seen[playlistUrl] = true;
      const playlistRes = await requestPageText(playlistUrl, headers);
      if (!playlistRes.ok || String(playlistRes.text || '').indexOf('#EXTM3U') < 0) continue;
      if (playlistRes.text.indexOf('#EXT-X-STREAM-INF') >= 0) {
        const lines = playlistRes.text.split(/\r?\n/);
        let bestVariantUrl = '';
        const variants = [];
        for (let j = 0; j < lines.length; j += 1) {
          if (lines[j].indexOf('#EXT-X-STREAM-INF') === 0) {
            const nextLine = lines[j + 1] ? lines[j + 1].trim() : '';
            if (nextLine && !nextLine.startsWith('#')) {
              const varUrl = nextLine.startsWith('http') ? nextLine : new URL(nextLine, playlistUrl).toString();
              const resMatch = lines[j].match(/RESOLUTION=(\d+x\d+)/i);
              const qLabel = resMatch ? resMatch[1].split('x')[1] + 'p' : 'Auto';
              variants.push({ quality: qLabel, url: varUrl, label: 'English · Stream Unity (' + qLabel + ')', headers, streamType: 'hls', language: 'en', provider: 'streamingunity' });
              if (!bestVariantUrl) bestVariantUrl = varUrl;
            }
          }
        }
        return {
          url: bestVariantUrl || playlistUrl,
          headers,
          streamType: 'hls',
          language: 'en',
          label: 'English · Stream Unity',
          provider: 'streamingunity',
          streams: variants.length ? variants : [{ url: playlistUrl, headers, streamType: 'hls', label: 'English · Stream Unity', language: 'en', provider: 'streamingunity' }],
        };
      }
      return {
        url: playlistUrl,
        headers,
        streamType: 'hls',
        language: 'en',
        label: 'English · Stream Unity',
        provider: 'streamingunity',
      };
    }
    return null;
  }

  async function resolveStreamingUnity(parsed) {
    const title = await findStreamingUnityTitle(parsed);
    if (!title || !title.id) return null;
    let iframeUrl = STREAMINGUNITY_BASE + '/en/iframe/' + encodeURIComponent(String(title.id));
    if (parsed.type === 'tv') {
      const episodeId = await streamingUnityEpisodeId(
        title,
        parsed.season || 1,
        parsed.episode || 1,
      );
      if (!episodeId) return null;
      iframeUrl += '?episode_id=' + encodeURIComponent(episodeId) + '&next_episode=1';
    }
    const iframeRes = await requestPageText(iframeUrl, {
      Referer: STREAMINGUNITY_BASE + '/en/watch/' + encodeURIComponent(String(title.id)),
    });
    if (!iframeRes.ok) return null;
    const embedUrl = extractVixEmbedUrl(iframeRes.text);
    if (!embedUrl) return null;
    const playlist = await resolveStreamingUnityPlaylist(embedUrl, iframeUrl);
    if (!playlist || !playlist.url) return null;
    return {
      url: playlist.url,
      streams: [{
        url: playlist.url,
        headers: playlist.headers,
        streamType: 'hls',
        label: playlist.label,
        language: 'en',
        provider: 'streamingunity',
      }],
      headers: playlist.headers,
      streamType: 'hls',
      quality: 'Auto',
      lang: 'sub',
      subtitles: [],
    };
  }

  async function postBackend(url, parsed, lang) {
    const response = await withTimeout(
      Promise.resolve().then(function () {
        return fetchv2(
          url,
          { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': USER_AGENT },
          'POST',
          JSON.stringify({
            type: parsed.type,
            tmdbId: parsed.id,
            season: parsed.season || 1,
            episode: parsed.episode || 1,
            lang: String(lang || 'sub'),
          }),
        );
      }),
      12000,
      null,
    );
    if (!response) return null;
    const body = await readBody(response);
    if (!body) return null;
    try { return JSON.parse(body); } catch (_) { return null; }
  }

  async function resolveFromLocalBackend(parsed, lang) {
    if (typeof fetchv2 !== 'function') return { reached: false };
    return await new Promise((done) => {
      let pending = MOVIES_BACKENDS.length;
      let finished = false;
      let lastError = '';
      MOVIES_BACKENDS.forEach((url) => {
        postBackend(url, parsed, lang).then((data) => {
          if (finished) return;
          if (data && data.ok && data.url) {
            const stream = packBackendStream(data);
            if (stream) {
              finished = true;
              done({ reached: true, stream: stream });
              return;
            }
          }
          if (data && data.error) lastError = String(data.error);
          pending -= 1;
          if (pending <= 0) done({ reached: false, error: lastError });
        }).catch(() => {
          if (finished) return;
          pending -= 1;
          if (pending <= 0) done({ reached: false, error: lastError });
        });
      });
    });
  }

  async function attachSubtitles(stream, tmdbId, season, episode, requestedLang) {
    if (!stream) return stream;
    // Dub playback does not need a subtitle catalogue request. For sub
    // playback, keep the lookup best-effort and short so a healthy video route
    // is never held hostage by a subtitle service.
    const isDub = String(requestedLang || 'sub').toLowerCase().indexOf('dub') === 0;
    const extra = isDub ? [] : await withTimeout(
      fetchEnglishSubs(tmdbId, season, episode),
      2500,
      [],
    );
    const result = await withEnglishSubs(stream, extra);
    result.subtitleLanguages = [
      { code: 'en', label: 'English' },
      { code: 'es', label: 'Spanish' },
      { code: 'ar', label: 'Arabic' },
      { code: 'de', label: 'German' },
    ];
    return result;
  }

  async function extractSubtitles(episodeId, language) {
    const parsed = parseHref(episodeId);
    if (!parsed) return { subtitles: [], error: { message: 'Invalid episode.' } };
    const rows = await fetchLazySubtitles(
      parsed.id,
      parsed.type === 'tv' ? (parsed.season || 1) : null,
      parsed.type === 'tv' ? (parsed.episode || 1) : null,
      language,
    );
    return { subtitles: await hydrateSubtitleContent(rows) };
  }

  async function extractStreamUrl(episodeId, lang) {
    const parsed = parseHref(episodeId);
    if (!parsed) return { streams: [], subtitles: [], error: { message: 'Invalid episode.' } };
    const tvSeason = parsed.type === 'tv' ? (parsed.season || 1) : null;
    const tvEpisode = parsed.type === 'tv' ? (parsed.episode || 1) : null;
    let backendError = '';
    try {
      const unity = await withTimeout(resolveStreamingUnity(parsed), 14000, null);
      if (unity && unity.url) {
        return await attachSubtitles(unity, parsed.id, tvSeason, tvEpisode, lang);
      }
    } catch (_) {}
    try {
      const local = await resolveFromLocalBackend(parsed, lang);
      if (local && local.stream) return await attachSubtitles(local.stream, parsed.id, tvSeason, tvEpisode, lang);
      if (local && local.error) backendError = local.error;
    } catch (_) {}
    if (typeof globalThis.__resolveViaBackend === 'function') {
      try {
        let resolved = await globalThis.__resolveViaBackend(
          'synthetiq-movies-v1',
          'stream',
          JSON.stringify({
            episodeId: String(episodeId),
            type: parsed.type,
            tmdbId: parsed.id,
            season: parsed.season || 1,
            episode: parsed.episode || 1,
            lang: String(lang || 'sub'),
          }),
        );
        if (typeof resolved === 'string') {
          try { resolved = JSON.parse(resolved); } catch (_) {}
        }
        if (resolved && resolved._resolverError === 'service_limit_exceeded') {
          return { streams: [], subtitles: [], error: { message: 'Hourly fallback limit reached. Try again later.' } };
        }
        if (resolved && resolved.url) {
          const packed = packBackendStream(resolved);
          if (packed) return await attachSubtitles(packed, parsed.id, tvSeason, tvEpisode, lang);
        }
        if (resolved && Array.isArray(resolved.streams) && resolved.streams.length) {
          const packed = packBackendStream(resolved);
          if (packed) return await attachSubtitles(packed, parsed.id, tvSeason, tvEpisode, lang);
        }
      } catch (_) {}
    }
    return {
      streams: [],
      subtitles: [],
      error: { message: backendError || 'No verified video source is available right now.' },
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.extractSubtitles = extractSubtitles;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
