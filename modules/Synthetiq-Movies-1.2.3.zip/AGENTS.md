# Synthetiq Movies — agent config and context

Read this before changing the movies module, the movies backend, picker ranking, or the official catalogue entry.

Live since 2026-08-18. Module **1.2.1** (source; Stream Unity first on the phone). Backend **0.2.1**. Official catalogue zip may still be **1.1.3** until published.

---

## What it is

TMDB-only catalogue in the app. On play, the JS module POSTs to the **OVH brain**. The brain returns every offered audio language that VideoEasy actually lists, English first, plus headers. Video files are never stored. Do not invent languages.

X-Stream, STCine, and EV01 stay separate phone modules. Movies does not scrape those sites from OVH.

Stream Unity is **phone-side first** in the Movies ZIP (`extractStreamUrl` → streamingunity.vip → vixcloud.co English HLS). If that misses, the module POSTs the OVH brain as before (VideoEasy then STCine). Do not scrape vixcloud from the kitchens: every VPS returns 403 HTML. See `STREAM_UNITY.md`.

---

## Live layout

```
Phone module  POST https://198.244.149.250.sslip.io/movies/resolve
                    │
                    ▼
OVH brain     127.0.0.1:8791   (nginx /movies/)
  cache + poke-before-reuse
  no scrape
         │                    │
         ▼                    ▼
Hub kitchen            Old DO kitchen
167.172.60.98:8792     178.62.35.193:8792
VideoEasy only         STCine only
ufw: OVH IP only       ufw: OVH IP only
```

| Role | Host | SSH | Process |
|---|---|---|---|
| Brain | `198.244.149.250` | `synthetiq-ovh` | `synthetiq-movies.service` |
| VideoEasy kitchen | `167.172.60.98` | `synthetiq-cert-primary` | `synthetiq-movies.service` |
| STCine kitchen | `178.62.35.193` | `synthetiq-cert-secondary` | `synthetiq-movies.service` |
| Overnight TTL watch | OVH | `synthetiq-ovh` | `synthetiq-movies-ttl-watch.service` |

Public HTTPS (phone):

- Health: `https://198.244.149.250.sslip.io/movies/health`
- Resolve: `POST https://198.244.149.250.sslip.io/movies/resolve`
- Watching: `POST https://198.244.149.250.sslip.io/movies/watching`

Body:

```json
{ "type": "movie"|"tv", "tmdbId": "27205", "season": 1, "episode": 1, "lang": "sub" }
```

Do not scrape from OVH. Do not open kitchen port 8792 to the world.

---

## Paths

### App repo (this tree)

| Path | What |
|---|---|
| `backend/synthetiq-movies/` | Brain + kitchen source |
| `backend/synthetiq-movies/src/server.js` | HTTP: brain `/resolve` or kitchen `/scrape` |
| `backend/synthetiq-movies/src/engine.js` | Cache, inflight lock, scrape order |
| `backend/synthetiq-movies/src/store.js` | TTLs |
| `backend/synthetiq-movies/src/kitchens.js` | Remote kitchens (brain) / local adapters (kitchen) |
| `backend/synthetiq-movies/src/ttl_watch.js` | Overnight poke watch |
| `dev_assets/modules/_development/synthetiq-movies-v1/` | Module source |
| `dev_assets/modules/Synthetiq-Movies-1.1.3.zip` | Release zip |
| `lib/widgets/module_source_selector.dart` | Picker order + Reliable label |

### OVH (where the backend lives)

| Path | What |
|---|---|
| `/opt/synthetiq-movies/` | Deployed tree |
| `/opt/synthetiq-movies/AGENTS.md` | This file |
| `/etc/synthetiq-movies.env` | Role, kitchen URLs, kitchen key (do not print) |
| `/var/lib/synthetiq-movies/cache.json` | Brain URL cache |
| `/var/lib/synthetiq-movies/ttl-watch-status.json` | Overnight poke snapshot |
| `/var/lib/synthetiq-movies/ttl-watch.jsonl` | Per-poke log |
| `/etc/nginx/sites-enabled/karimi-ovh-sslip.conf` | `location ^~ /movies/` → `127.0.0.1:8791/` |
| TLS | `198.244.149.250.sslip.io` Let's Encrypt |

Hub/DO env: `MOVIES_ROLE=kitchen`, `MOVIES_KITCHEN=videasy|stcine`, listen `0.0.0.0:8792`.

---

## Module (phone)

| Field | Value |
|---|---|
| id | `synthetiq-movies-v1` |
| name | Synthetiq Movies |
| version | `1.1.3` |
| identity | `SP-VID-059-SYNTHETIQ-MOVIES` / **59** |
| category | `Movies & TV` |
| purpose | `Most Reliable Movies` |
| recommended | `true` |
| language | English |
| icon | `https://raw.githubusercontent.com/kas021/Synthetiq-Modules/main/assets/module-icons/synthetiq-movies.png?v=20260818-1` |
| backend | `https://198.244.149.250.sslip.io/movies/resolve` |
| official zip | [release 1.1.3](https://github.com/kas021/Synthetiq-Modules/releases/tag/module-synthetiq-movies-v1-v1.1.3) |
| bundle | Official **bundle 91** |

Catalogue only. TMDB search/details/episodes. `extractStreamUrl` POSTs the OVH URL. If OVH answers `ok: false`, do **not** fall through to a 30s signed-in resolver hang.

Hide TMDB episodes whose `air_date` is after today.

---

## Picker (already in app code)

`lib/widgets/module_source_selector.dart`

- **Movies & TV** (existing filter): Movies is **#1**, then X-Stream, STCine, EV01, DramaFun
- **Recommended**: Anikoto → One → **Movies (#3)**
- Label: `Synthetiq Movies (Most Reliable Movies)`; word **Reliable** is green

Do not add a new category. Do not change default video module (Anikoto).

---

## Cache / TTL

Rule: cache = half the proven link life. Poke the saved URL before reuse.

| Kitchen | Proven | Cache |
|---|---|---|
| VideoEasy | still alive at **217 min** (Mac watch died of disk full, not the link) | **110 min** |
| STCine | dead at **61 min** | **30 min** |
| Missing title | empty after both kitchens | **12 min** (do not re-scrape every tap) |

`no_stream_cached` means “already checked, no stream,” not “forgot to cache.”

Inflight lock: two users on the same title share one scrape.

Prefetch: after `/watching` on TV, warm next 3 episodes, 60s apart.

---

## Overnight TTL watch (OVH, separate process)

Not play. Resolves 5 links once, pokes them every 60s.

Slots: Inception, Dark Knight, Fight Club, Mentalist S1E1 (VideoEasy), Breaking Bad S1E1 (STCine).

```bash
ssh synthetiq-ovh 'cat /var/lib/synthetiq-movies/ttl-watch-status.json'
journalctl -u synthetiq-movies-ttl-watch -n 40 --no-pager
```

Do not restart this unit unless asked — restarting resolves **new** URLs and resets the clock. Disk-full must never be recorded as a dead link.

---

## Agent rules

1. Do not scrape on OVH. Scrapes only from the two kitchens.
2. Do not change Flutter play/account code for movies unless the user asks. Picker ranking is already shipped in this branch.
3. Do not put movies in store-bundled assets.
4. Do not change `defaultModules.video` away from `anikoto-v4`.
5. Official catalogue is `kas021/Synthetiq-Modules`. Push zip + `catalogue.json`; CI signs `repository.json`. Never edit an already-published zip.
6. Kitchen key lives only in `/etc/synthetiq-movies.env`. Never print or commit it.
7. Do not report play success from HTTP 200 alone. Brain already verifies playlist + media bytes.
8. Do not invent titles, languages, or streams. Unaired TMDB rows stay hidden.
9. X-Stream / STCine / EV01 phone modules stay independent.
10. After backend edits, deploy with rsync + `systemctl restart synthetiq-movies` on the box you changed. Confirm `https://198.244.149.250.sslip.io/movies/health`.

---

## Health / deploy

```bash
curl -sS https://198.244.149.250.sslip.io/movies/health
ssh synthetiq-ovh 'systemctl is-active synthetiq-movies synthetiq-movies-ttl-watch'
ssh synthetiq-cert-primary 'curl -sS http://127.0.0.1:8792/health'
ssh synthetiq-cert-secondary 'curl -sS http://127.0.0.1:8792/health'

# brain only
rsync -az backend/synthetiq-movies/src/ synthetiq-ovh:/opt/synthetiq-movies/src/
ssh synthetiq-ovh 'systemctl restart synthetiq-movies'
```

Kitchen `/health` must stay on localhost/OVH. Public 8792 is firewalled.

---

## Proven live results (2026-08-18)

- 40 users / 3 min, playable titles only: **558/558**, cache 100%, p50 86ms, p95 181ms
- OVH movies process: idle 0.40% CPU / 139 MB → load +0.15% CPU / +3.6 MB
- Kitchens barely moved (everything cached)

---

*Keep this file identical in the app repo, the module folder, the backend folder, and `/opt/synthetiq-movies/AGENTS.md` on OVH.*
