# Stream Unity in Synthetiq Movies

Added 2026-09-01 in module **1.2.1**.

Movies kitchens are still **VideoEasy** (Hub) and **STCine** (London). They are not X-Stream. X-Stream stays a separate phone module.

Stream Unity (`streamingunity.vip` → `vixcloud.co`) is tried **first on the phone**, then the OVH brain.

Why not a kitchen: the 2026-09-01 poke showed vixcloud playlists **alive on Mac for 125+ min** and **403 HTML from OVH, Hub, and London**. Kitchen scrape of that CDN would fail verification. Phone IPs can fetch the playlist.

English audio (`lang=en`) only. Same Wyzie subtitle attach as before. Playlist must contain `#EXTM3U` before it is returned. That is not a playback claim.
