const TEST_STREAM = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';

const testCard = {
  id: 'repository-update-test-2',
  href: 'repository-update-test-2',
  title: 'TEST 2',
  image: '',
};

async function searchResults() {
  return [testCard];
}

async function extractDetails() {
  return {
    id: testCard.id,
    href: testCard.href,
    title: testCard.title,
    description: 'Repository updater test item, version 1.0.1.',
    image: testCard.image,
    status: 'Test',
  };
}

async function extractEpisodes() {
  return [{
    href: 'repository-update-test-2-episode-1',
    number: 1,
    title: 'TEST 2',
  }];
}

async function extractStreamUrl() {
  return {
    streams: ['Test stream', TEST_STREAM],
  };
}

async function discoveryHome() {
  return {
    sections: [{
      id: 'test',
      title: 'TEST',
      style: 'poster',
      items: [testCard],
    }],
  };
}

async function discoveryFeed(feedId, page) {
  const pageNumber = Math.max(1, Number(page) || 1);
  if (String(feedId || 'all') !== 'all' || pageNumber > 1) {
    return { items: [], page: pageNumber, hasMore: false };
  }
  return { items: [testCard], page: pageNumber, hasMore: false };
}

globalThis.searchResults = searchResults;
globalThis.extractDetails = extractDetails;
globalThis.extractEpisodes = extractEpisodes;
globalThis.extractStreamUrl = extractStreamUrl;
globalThis.discoveryHome = discoveryHome;
globalThis.discoveryFeed = discoveryFeed;

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    searchResults,
    extractDetails,
    extractEpisodes,
    extractStreamUrl,
    discoveryHome,
    discoveryFeed,
  };
}
