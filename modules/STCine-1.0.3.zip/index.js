(() => {
  'use strict';

  const MODULE_NAME = 'STCine';
  const SITE = 'https://stcine.com';
  const API = SITE + '/api';
  const TMDB_IMG = 'https://image.tmdb.org/t/p/w500';
  const VIDEASY_ORIGIN = 'https://player.videasy.to';
  const LOOKMOVIE = 'https://www.lookmovie2.to';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  // Public TMDB key used by many free frontends (including STCine SPA). Catalogue fallback only.
  const TMDB_KEY = '9801b6b0548ad57581d111ea690c85c8';
  const lookmovieHitCache = Object.create(null);

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function encodeQuery(params) {
    const parts = [];
    Object.keys(params || {}).forEach((k) => {
      const v = params[k];
      if (v === undefined || v === null || v === '') return;
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
    });
    return parts.join('&');
  }


  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        return JSON.stringify(await res.json());
      } catch (_) {}
    }
    return '';
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        let resHeaders = {};
        try {
          if (res && res.headers) {
            if (typeof res.headers.get === 'function') {
              resHeaders = {
                'content-type': res.headers.get('content-type') || '',
                'Content-Type': res.headers.get('content-type') || '',
              };
            } else if (typeof res.headers === 'object') {
              resHeaders = res.headers;
            }
          }
        } catch (_) {}
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          body: textBody,
          json: safeJsonParse(textBody),
          headers: resHeaders,
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        let resHeaders = {};
        try {
          resHeaders = {
            'content-type': (res.headers && res.headers.get && res.headers.get('content-type')) || '',
            'Content-Type': (res.headers && res.headers.get && res.headers.get('content-type')) || '',
          };
        } catch (_) {}
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
          headers: resHeaders,
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null };
  }

  function posterUrl(path) {
    const p = cleanText(path || '');
    if (!p) return '';
    if (/^https?:\/\//i.test(p)) return p;
    return TMDB_IMG + (p.startsWith('/') ? p : '/' + p);
  }

  function cardFromStcine(item) {
    if (!item) return null;
    const tmdbId = item.tmdbId || item.id;
    if (!tmdbId) return null;
    const type = String(item.type || 'movie').toLowerCase() === 'tv' ? 'tv' : 'movie';
    const href = type === 'tv' ? ('tv:' + tmdbId) : ('movie:' + tmdbId);
    return {
      href: href,
      id: href,
      title: cleanText(item.title || item.name || ('TMDB ' + tmdbId)),
      image: posterUrl(item.poster_path || item.backdrop_path),
      poster: posterUrl(item.poster_path || item.backdrop_path),
      type: type,
      mediaType: type,
      isMovie: type === 'movie',
    };
  }

  function cardFromTmdb(item, typeHint) {
    if (!item) return null;
    const isTv = typeHint === 'tv' || item.media_type === 'tv' || (!!item.name && !item.title);
    const tmdbId = item.id;
    if (!tmdbId) return null;
    const type = isTv ? 'tv' : 'movie';
    const href = isTv ? ('tv:' + tmdbId) : ('movie:' + tmdbId);
    return {
      href: href,
      id: href,
      title: cleanText(item.title || item.name || ('TMDB ' + tmdbId)),
      image: posterUrl(item.poster_path),
      poster: posterUrl(item.poster_path),
      type: type,
      mediaType: type,
      isMovie: type === 'movie',
    };
  }

  function parseHref(raw) {
    const s = String(raw || '').trim();
    // movie:123 | tv:456 | tv:456:1:3 | legacy stcine player urls
    let m = s.match(/^(movie|tv):(\d+)(?::(\d+):(\d+))?$/i);
    if (m) {
      return {
        type: m[1].toLowerCase(),
        tmdbId: m[2],
        season: m[3] ? Number(m[3]) : 1,
        episode: m[4] ? Number(m[4]) : 1,
      };
    }
    m = s.match(/[?&]id=(\d+)/i);
    if (m) {
      const type = /type=tv/i.test(s) ? 'tv' : 'movie';
      return { type: type, tmdbId: m[1], season: 1, episode: 1 };
    }
    m = s.match(/\/(movie|tv)\/(\d+)/i);
    if (m) return { type: m[1].toLowerCase(), tmdbId: m[2], season: 1, episode: 1 };
    if (/^\d+$/.test(s)) return { type: 'movie', tmdbId: s, season: 1, episode: 1 };
    return null;
  }

  async function stcineList(type, page, search) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const qs = encodeQuery({
      status: 'published',
      type: type === 'tv' ? 'tv' : 'movie',
      limit: '24',
      page: String(pageNumber),
      search: search || undefined,
    });
    const res = await settleWithin(
      request(API + '/movies?' + qs, {
        headers: { Accept: 'application/json', Referer: SITE + '/' },
      }),
      15000,
      null,
    );
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : Array.isArray(data) ? data : [];
    return results.map(cardFromStcine).filter(Boolean);
  }

  async function tmdbSearch(query) {
    const q = encodeURIComponent(query);
    const url =
      'https://api.themoviedb.org/3/search/multi?api_key=' +
      TMDB_KEY +
      '&query=' +
      q +
      '&include_adult=false&language=en-US&page=1';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results
      .filter((r) => r && (r.media_type === 'movie' || r.media_type === 'tv'))
      .map((r) => cardFromTmdb(r))
      .filter(Boolean)
      .slice(0, 30);
  }

  async function tmdbPopular(kind) {
    const type = kind === 'tv' ? 'tv' : 'movie';
    const url =
      'https://api.themoviedb.org/3/' +
      type +
      '/popular?api_key=' +
      TMDB_KEY +
      '&language=en-US&page=1';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results.map((r) => cardFromTmdb(r, type)).filter(Boolean).slice(0, 20);
  }

  async function searchResults(query, page) {
    const q = cleanText(query || '');
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      if (!q) {
        const movies = await stcineList('movie', pageNumber, '');
        if (movies.length) return movies;
        return await tmdbPopular('movie');
      }
      // STCine search first, then TMDB if thin
      let cards = await stcineList('movie', pageNumber, q);
      const tv = await stcineList('tv', pageNumber, q);
      cards = cards.concat(tv);
      // Prefer exact-ish matches
      const lower = q.toLowerCase();
      cards.sort((a, b) => {
        const as = a.title.toLowerCase() === lower ? 0 : a.title.toLowerCase().includes(lower) ? 1 : 2;
        const bs = b.title.toLowerCase() === lower ? 0 : b.title.toLowerCase().includes(lower) ? 1 : 2;
        return as - bs;
      });
      if (cards.length < 5) {
        const tmdb = await tmdbSearch(q);
        const seen = new Set(cards.map((c) => c.href));
        for (const c of tmdb) {
          if (!seen.has(c.href)) {
            cards.push(c);
            seen.add(c.href);
          }
        }
      }
      return cards.slice(0, 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    const ref = parseHref(urlOrId);
    if (!ref) return { title: 'Unknown', description: '' };
    try {
      // Prefer TMDB for reliable metadata
      const path = ref.type === 'tv' ? 'tv' : 'movie';
      const url =
        'https://api.themoviedb.org/3/' +
        path +
        '/' +
        ref.tmdbId +
        '?api_key=' +
        TMDB_KEY +
        '&language=en-US';
      const res = await settleWithin(request(url), 12000, null);
      const d = (res && (res.json || safeJsonParse(res.body))) || {};
      const title = cleanText(d.title || d.name || ('TMDB ' + ref.tmdbId));
      const originalTitle = cleanText(d.original_title || d.original_name || '');
      const isMovie = ref.type === 'movie';
      const seasons = [];
      if (!isMovie && Array.isArray(d.seasons)) {
        d.seasons.forEach(function (s) {
          const n = Number(s && s.season_number);
          if (n > 0) seasons.push(n);
        });
      }
      return {
        title: title,
        originalTitle: originalTitle,
        description: cleanText(d.overview || ''),
        image: posterUrl(d.poster_path || d.backdrop_path),
        poster: posterUrl(d.poster_path || d.backdrop_path),
        banner: posterUrl(d.backdrop_path || d.poster_path),
        href: isMovie ? ('movie:' + ref.tmdbId) : ('tv:' + ref.tmdbId),
        id: isMovie ? ('movie:' + ref.tmdbId) : ('tv:' + ref.tmdbId),
        year: cleanText((d.release_date || d.first_air_date || '').slice(0, 4)),
        type: isMovie ? 'movie' : 'tv',
        mediaType: isMovie ? 'movie' : 'tv',
        isMovie: isMovie,
        seasons: isMovie ? 0 : seasons.length || Number(d.number_of_seasons || 0) || 0,
        seasonNumbers: isMovie ? [] : seasons,
      };
    } catch (e) {
      log('details error: ' + (e && e.message ? e.message : String(e)));
      return {
        title: ref.type + ' ' + ref.tmdbId,
        description: '',
        href: ref.type + ':' + ref.tmdbId,
        type: ref.type,
        mediaType: ref.type,
        isMovie: ref.type === 'movie',
      };
    }
  }

  async function extractEpisodes(seriesId) {
    const ref = parseHref(seriesId);
    if (!ref) return [];
    if (ref.type === 'movie') {
      // Movies are a single playable title — not "Episode 1".
      const details = await extractDetails('movie:' + ref.tmdbId);
      return [{
        number: 1,
        href: 'movie:' + ref.tmdbId,
        title: details.title || 'Full Movie',
        image: details.image || details.poster || '',
        isMovie: true,
        mediaType: 'movie',
        type: 'movie',
        subAvailable: true,
        dubAvailable: false,
      }];
    }
    // TV: expand seasons from TMDB
    try {
      const infoUrl =
        'https://api.themoviedb.org/3/tv/' +
        ref.tmdbId +
        '?api_key=' +
        TMDB_KEY +
        '&language=en-US';
      const infoRes = await settleWithin(request(infoUrl), 12000, null);
      const info = (infoRes && (infoRes.json || safeJsonParse(infoRes.body))) || {};
      const seasons = Array.isArray(info.seasons) ? info.seasons : [];
      const eps = [];
      // Cap seasons to keep payload reasonable
      const usable = seasons
        .filter((s) => s && Number(s.season_number) > 0)
        .slice(0, 8);
      for (const season of usable) {
        const sn = Number(season.season_number) || 1;
        const sUrl =
          'https://api.themoviedb.org/3/tv/' +
          ref.tmdbId +
          '/season/' +
          sn +
          '?api_key=' +
          TMDB_KEY +
          '&language=en-US';
        const sRes = await settleWithin(request(sUrl), 12000, null);
        const sData = (sRes && (sRes.json || safeJsonParse(sRes.body))) || {};
        const list = Array.isArray(sData.episodes) ? sData.episodes : [];
        for (const ep of list) {
          const en = Number(ep.episode_number) || eps.length + 1;
          eps.push({
            number: eps.length + 1,
            seasonNumber: sn,
            episodeNumber: en,
            href: 'tv:' + ref.tmdbId + ':' + sn + ':' + en,
            title: 'S' + sn + 'E' + en + (ep.name ? ' · ' + cleanText(ep.name) : ''),
            subAvailable: true,
            dubAvailable: false,
          });
          if (eps.length >= 500) break;
        }
        if (eps.length >= 500) break;
      }
      if (!eps.length) {
        return [{
          number: 1,
          href: 'tv:' + ref.tmdbId + ':1:1',
          title: 'S1E1',
          subAvailable: true,
          dubAvailable: false,
        }];
      }
      return eps;
    } catch (e) {
      log('episodes error: ' + (e && e.message ? e.message : String(e)));
      return [{
        number: 1,
        href: 'tv:' + ref.tmdbId + ':1:1',
        title: 'S1E1',
        subAvailable: true,
        dubAvailable: false,
      }];
    }
  }

  function qualityHeight(q) {
    const s = String(q || '');
    const m = s.match(/(\d{3,4})/);
    return m ? Number(m[1]) : 0;
  }

  async function resolveVideasy(ref) {
    const headers = {
      'User-Agent': USER_AGENT,
      Referer: VIDEASY_ORIGIN + '/',
      Origin: VIDEASY_ORIGIN,
    };
    const tmdbId = ref.tmdbId;
    const mediaType = ref.type === 'tv' ? 'tv' : 'movie';
    const seasonId = ref.season || 1;
    const episodeId = ref.episode || 1;

    const seedRes = await settleWithin(
      request('https://api.speedracelight.com/seed?mediaId=' + encodeURIComponent(tmdbId), {
        headers: headers,
      }),
      15000,
      null,
    );
    if (!seedRes || !seedRes.ok) return [];
    const seedJson = seedRes.json || safeJsonParse(seedRes.body) || {};
    const seed = seedJson.seed;
    if (!seed) return [];

    const servers = [
      { name: 'cdn', endpoint: 'cdn' },
      { name: 'm4uhd', endpoint: 'm4uhd' },
      { name: 'lamovie', endpoint: 'lamovie' },
    ];
    const streams = [];
    const seen = new Set();

    for (let si = 0; si < servers.length; si++) {
      const server = servers[si];
      try {
        const fullUrl =
          'https://api.speedracelight.com/' +
          server.endpoint +
          '/sources-with-title?title=&mediaType=' +
          mediaType +
          '&year=&episodeId=' +
          episodeId +
          '&seasonId=' +
          seasonId +
          '&tmdbId=' +
          tmdbId +
          '&imdbId=&enc=2&seed=' +
          encodeURIComponent(seed);
        const encRes = await settleWithin(
          request(fullUrl, { headers: headers }),
          20000,
          null,
        );
        if (!encRes || !encRes.ok || !encRes.body) continue;
        if (/Attention Required|Just a moment/i.test(encRes.body)) continue;

        const postData = JSON.stringify({
          text: String(encRes.body).trim(),
          id: String(tmdbId),
          seed: seed,
        });
        const decRes = await settleWithin(
          request('https://enc-dec.app/api/dec-videasy', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Accept: 'application/json',
              'User-Agent': USER_AGENT,
            },
            body: postData,
          }),
          25000,
          null,
        );
        if (!decRes || !decRes.ok) continue;
        const dec = decRes.json || safeJsonParse(decRes.body) || {};
        if (dec.status !== 200 || !dec.result) continue;
        const sources = Array.isArray(dec.result.sources) ? dec.result.sources : [];
        for (let i = 0; i < sources.length; i++) {
          const src = sources[i];
          if (!src || !src.url) continue;
          if (String(src.quality || '').includes('HDR')) continue;
          if (seen.has(src.url)) continue;
          seen.add(src.url);
          const h = qualityHeight(src.quality);
          streams.push({
            label: 'STCine · Videasy ' + server.name + ' · ' + (src.quality || 'auto'),
            url: src.url,
            quality: h || src.quality || 'auto',
            streamType: /\.m3u8/i.test(src.url) ? 'hls' : 'mp4',
            kind: /\.m3u8/i.test(src.url) ? 'hls' : 'mp4',
            provider: 'stcine-videasy-' + server.name,
            headers: {
              'User-Agent': USER_AGENT,
              Referer: VIDEASY_ORIGIN + '/',
              Origin: VIDEASY_ORIGIN,
            },
          });
        }
        if (streams.length >= 4) break;
      } catch (e) {
        log('videasy server fail ' + server.name + ': ' + (e && e.message ? e.message : e));
      }
    }

    // Prefer seek-friendly ladders: 1080 first, then 720, then lower, then 4K last.
    // Free 4K HLS often seeks poorly (long GOPs / weak CDN range).
    streams.sort((a, b) => streamSeekScore(b) - streamSeekScore(a));
    return streams;
  }

  function streamSeekScore(s) {
    if (!s || !s.url) return -1;
    const h = Number(s.height) || qualityHeight(s.quality) || qualityHeight(s.label) || 0;
    let score = 0;
    if (s.segmentDead || s.playlistDead) return -100000;
    if (s.segmentMimeRisky) score -= 40000;
    if (s.segmentProbeOk && !s.segmentMimeRisky) score += 15000;
    if (h === 1080) score += 10000;
    else if (h === 720) score += 8000;
    else if (h > 0 && h < 720) score += 4000 + h;
    else if (h >= 2160) score += 2500;
    else if (h > 1080) score += 3000;
    else score += 1000;
    if (s.kind === 'hls' || s.streamType === 'hls' || /\.m3u8/i.test(s.url || '')) score += 200;
    // Prefer real LookMovie TS when Videasy is jpeg-disguised junk.
    if (s.provider === 'lookmovie' && s.segmentProbeOk) score += 12000;
    else if (s.provider === 'lookmovie') score += 4000;
    if (/videasy-cdn/i.test(s.provider || '') && s.segmentProbeOk && !s.segmentMimeRisky) score += 1500;
    return score;
  }

  function absoluteFromPlaylist(baseUrl, line) {
    const t = String(line || '').trim();
    if (!t) return '';
    if (/^https?:\/\//i.test(t)) return t;
    if (t.charAt(0) === '/') {
      const origin = String(baseUrl).match(/^(https?:\/\/[^/]+)/i);
      return origin ? origin[1] + t : t;
    }
    const cut = String(baseUrl).lastIndexOf('/');
    return cut >= 0 ? String(baseUrl).slice(0, cut + 1) + t : t;
  }

  function firstMediaUri(body) {
    const lines = String(body || '').split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = String(lines[i] || '').trim();
      if (!line || line.charAt(0) === '#') continue;
      return line;
    }
    return '';
  }

  async function softProbeStream(stream) {
    if (!stream || !stream.url) return stream;
    if (stream.kind !== 'hls' && stream.streamType !== 'hls' && !/\.m3u8/i.test(stream.url)) {
      stream.segmentProbeOk = true;
      return stream;
    }
    try {
      const headers = Object.assign(
        { 'User-Agent': USER_AGENT, Accept: 'application/vnd.apple.mpegurl,*/*' },
        stream.headers || {},
      );
      const pl = await settleWithin(
        request(stream.url, { headers: headers }),
        8000,
        null,
      );
      if (!pl || !pl.body || String(pl.body).indexOf('#EXTM3U') < 0) {
        stream.playlistDead = true;
        stream.segmentDead = true;
        return stream;
      }
      const body = String(pl.body);
      // Fake Videasy playlists point at .jpg/.png/.css/.html "segments".
      if (/\.(jpg|jpeg|png|css|txt|html)(\?|$)/i.test(body) && !/\.ts(\?|$)/i.test(body)) {
        stream.segmentMimeRisky = true;
        stream.segmentDead = true;
        log('softProbe fake segment extensions for ' + (stream.label || ''));
        return stream;
      }
      let segUrl = absoluteFromPlaylist(stream.url, firstMediaUri(body));
      if (segUrl && /\.m3u8(\?|$)/i.test(segUrl)) {
        const nested = await settleWithin(request(segUrl, { headers: headers }), 7000, null);
        if (nested && nested.body && String(nested.body).indexOf('#EXTM3U') >= 0) {
          const nestedBody = String(nested.body);
          if (/\.(jpg|jpeg|png|css|txt|html)(\?|$)/i.test(nestedBody) && !/\.ts(\?|$)/i.test(nestedBody)) {
            stream.segmentMimeRisky = true;
            stream.segmentDead = true;
            return stream;
          }
          const nestedUri = firstMediaUri(nestedBody);
          if (nestedUri) segUrl = absoluteFromPlaylist(segUrl, nestedUri);
        }
      }
      if (!segUrl) {
        stream.segmentProbeFailed = true;
        return stream;
      }
      if (/\.(jpg|jpeg|png|css|html|txt)(\?|$)/i.test(segUrl)) {
        stream.segmentMimeRisky = true;
        stream.segmentDead = true;
        return stream;
      }
      const seg = await settleWithin(
        request(segUrl, {
          headers: Object.assign({}, headers, {
            Range: 'bytes=0-512',
            Accept: 'video/mp2t,video/*,*/*',
          }),
        }),
        8000,
        null,
      );
      if (!seg) {
        stream.segmentProbeFailed = true;
        stream.segmentDead = true;
        return stream;
      }
      const status = Number(seg.status || 0);
      const ctype = String(
        (seg.headers && (seg.headers['content-type'] || seg.headers['Content-Type'])) || '',
      ).toLowerCase();
      const raw = String(seg.body || '');
      const b0 = raw.length ? raw.charCodeAt(0) : 0;
      if (status === 401 || status === 403 || status === 404 || status >= 500) {
        stream.segmentDead = true;
        return stream;
      }
      if (ctype.indexOf('text/html') === 0 || /<!DOCTYPE|<html|Just a moment/i.test(raw)) {
        stream.segmentDead = true;
        stream.segmentMimeRisky = true;
        return stream;
      }
      if (ctype.indexOf('image/') === 0) {
        // jpeg-TS: often 0x47 but freezes / fails in player — treat as dead for STCine.
        stream.segmentMimeRisky = true;
        stream.segmentDead = true;
        log('softProbe image/* segment dead for ' + (stream.label || ''));
        return stream;
      }
      if (b0 === 0x47 || ctype.indexOf('video/') === 0 || ctype.indexOf('mp2t') >= 0 || ctype.indexOf('octet') >= 0) {
        stream.segmentProbeOk = true;
        stream.segmentDead = false;
        stream.segmentMimeRisky = false;
      } else if (status >= 200 && status < 300 && /lookmovie|refligns|tracclime|dancric/i.test(stream.url)) {
        stream.segmentProbeOk = true;
      } else if (status >= 200 && status < 300 && !raw.length) {
        stream.segmentProbeFailed = true;
      }
    } catch (e) {
      stream.segmentProbeFailed = true;
      stream.segmentDead = true;
    }
    return stream;
  }

  async function softProbeStreams(streams) {
    const list = Array.isArray(streams) ? streams.slice() : [];
    const out = [];
    let n = 0;
    for (let i = 0; i < list.length; i++) {
      if (n < 10) {
        n += 1;
        out.push(await softProbeStream(list[i]));
      } else {
        out.push(list[i]);
      }
    }
    return out;
  }

  function lookmovieHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Referer: LOOKMOVIE + '/',
      Origin: LOOKMOVIE,
      Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
    };
  }

  async function lookmovieRequest(url, options) {
    const opts = options || {};
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: opts.accept || 'application/json,text/html,*/*',
        Referer: LOOKMOVIE + '/',
        Origin: LOOKMOVIE,
      },
      opts.headers || {},
    );
    if (opts.xhr) headers['X-Requested-With'] = 'XMLHttpRequest';
    return settleWithin(request(url, { headers: headers }), opts.timeout || 12000, null);
  }

  function expandHlsUrls(url) {
    const u = String(url || '');
    if (!u || u.indexOf('http') !== 0) return [];
    const out = [u];
    if (/\/index\.m3u8(\?|$)/i.test(u)) {
      const master = u.replace(/\/index\.m3u8/i, '/master.m3u8');
      if (master !== u) out.push(master);
    } else if (/\/master\.m3u8(\?|$)/i.test(u)) {
      const index = u.replace(/\/master\.m3u8/i, '/index.m3u8');
      if (index !== u) out.unshift(index);
    }
    return out;
  }

  function streamsFromLookmovieAccess(json) {
    const streams = (json && json.streams) || {};
    const out = [];
    const keys = Object.keys(streams).sort(function (a, b) {
      return (qualityHeight(b) || 0) - (qualityHeight(a) || 0);
    });
    for (let i = 0; i < keys.length; i++) {
      const rawUrl = streams[keys[i]];
      if (!rawUrl || typeof rawUrl !== 'string' || rawUrl.indexOf('http') !== 0) continue;
      const height = qualityHeight(keys[i]) || qualityHeight(rawUrl) || 480;
      const urls = expandHlsUrls(rawUrl);
      for (let u = 0; u < urls.length; u++) {
        out.push({
          label: 'STCine · LookMovie ' + (height >= 360 ? height + 'p' : keys[i]),
          url: urls[u],
          quality: height,
          height: height,
          streamType: 'hls',
          kind: 'hls',
          provider: 'lookmovie',
          headers: lookmovieHeaders(),
        });
      }
    }
    return out;
  }

  async function findLookmovieMovie(title, year) {
    const queries = [];
    const push = function (v) {
      const s = cleanText(v);
      if (s && queries.indexOf(s) < 0) queries.push(s);
    };
    push(title);
    push(String(title || '').replace(/[:\-–—].*$/, ''));
    push(String(title || '').replace(/\s*\(\d{4}\)\s*$/, ''));
    if (year) push(cleanText(title) + ' ' + year);
    let best = null;
    let bestScore = -1;
    for (let i = 0; i < queries.length; i++) {
      const res = await lookmovieRequest(
        LOOKMOVIE + '/api/v1/movies/do-search/?q=' + encodeURIComponent(queries[i]),
        { xhr: true, timeout: 10000 },
      );
      if (!res || !res.body) continue;
      let rows = [];
      try {
        rows = ((JSON.parse(res.body) || {}).result) || [];
      } catch (_) {
        rows = [];
      }
      for (let j = 0; j < rows.length; j++) {
        const row = rows[j];
        const t = cleanText(row && row.title).toLowerCase();
        const q = cleanText(title).toLowerCase();
        let score = 0;
        if (t === q) score += 1000;
        else if (t.indexOf(q) === 0) score += 500;
        else if (q.indexOf(t) === 0 && t.length >= 4) score += 400;
        else if (t.indexOf(q) >= 0 || q.indexOf(t) >= 0) score += 200;
        if (year && Number(row && row.year) === Number(year)) score += 350;
        if (score > bestScore) {
          bestScore = score;
          best = row;
        }
      }
      if (bestScore >= 1300) break;
    }
    return bestScore >= 150 ? best : null;
  }

  async function findLookmovieShow(title, year) {
    const queries = [];
    const push = function (v) {
      const s = cleanText(v);
      if (s && queries.indexOf(s) < 0) queries.push(s);
    };
    push(title);
    push(String(title || '').replace(/[:\-–—].*$/, ''));
    if (year) push(cleanText(title) + ' ' + year);
    let best = null;
    let bestScore = -1;
    for (let i = 0; i < queries.length; i++) {
      const res = await lookmovieRequest(
        LOOKMOVIE + '/api/v1/shows/do-search/?q=' + encodeURIComponent(queries[i]),
        { xhr: true, timeout: 10000 },
      );
      if (!res || !res.body) continue;
      let rows = [];
      try {
        rows = ((JSON.parse(res.body) || {}).result) || [];
      } catch (_) {
        rows = [];
      }
      for (let j = 0; j < rows.length; j++) {
        const row = rows[j];
        const t = cleanText(row && row.title).toLowerCase();
        const q = cleanText(title).toLowerCase();
        let score = 0;
        if (t === q) score += 1000;
        else if (t.indexOf(q) === 0) score += 500;
        else if (q.indexOf(t) === 0 && t.length >= 4) score += 400;
        else if (t.indexOf(q) >= 0 || q.indexOf(t) >= 0) score += 200;
        if (year && Number(row && row.year) === Number(year)) score += 350;
        if (score > bestScore) {
          bestScore = score;
          best = row;
        }
      }
      if (bestScore >= 1300) break;
    }
    return bestScore >= 150 ? best : null;
  }

  function pickLookmovieEpisodeId(listPayload, season, episode) {
    const lst = listPayload;
    const s = String(season);
    const e = String(episode);
    if (lst && typeof lst === 'object' && !Array.isArray(lst)) {
      const seasonMap = lst[s] || lst[season];
      if (seasonMap && typeof seasonMap === 'object') {
        const cell = seasonMap[e] || seasonMap[episode];
        if (cell && cell.id_episode) return cell.id_episode;
      }
    }
    if (Array.isArray(lst)) {
      const tryMaps = [];
      if (lst[season] && typeof lst[season] === 'object') tryMaps.push(lst[season]);
      if (season > 0 && lst[season - 1] && typeof lst[season - 1] === 'object') {
        tryMaps.push(lst[season - 1]);
      }
      for (let i = 0; i < lst.length; i++) {
        if (lst[i] && typeof lst[i] === 'object') tryMaps.push(lst[i]);
      }
      for (let m = 0; m < tryMaps.length; m++) {
        const map = tryMaps[m];
        const cell = map[e] || map[episode];
        if (cell && cell.id_episode) return cell.id_episode;
      }
    }
    return null;
  }

  async function resolveLookmovie(ref) {
    try {
      const details = await extractDetails(
        ref.type === 'tv' ? 'tv:' + ref.tmdbId : 'movie:' + ref.tmdbId,
      );
      const title = details.title || '';
      const originalTitle = details.originalTitle || '';
      const year = details.year || '';

      if (ref.type === 'movie') {
        const cacheKey = 'movie:' + ref.tmdbId;
        let hit = lookmovieHitCache[cacheKey] || null;
        if (!hit) {
          hit = await findLookmovieMovie(title, year);
          if (!hit && originalTitle && originalTitle !== title) {
            hit = await findLookmovieMovie(originalTitle, year);
          }
          if (hit) lookmovieHitCache[cacheKey] = hit;
        }
        if (!hit) {
          log('lookmovie no match for ' + title);
          return [];
        }
        const view = await lookmovieRequest(
          LOOKMOVIE + '/movies/view/' + encodeURIComponent(hit.slug),
          { accept: 'text/html,*/*', timeout: 12000 },
        );
        if (!view || !view.body) return [];
        const playPath = (String(view.body).match(/href="(\/movies\/play\/[^"]+)"/i) || [])[1];
        if (!playPath) return [];
        const play = await lookmovieRequest(LOOKMOVIE + playPath, {
          accept: 'text/html,*/*',
          timeout: 12000,
        });
        if (!play || !play.body) return [];
        const text = String(play.body);
        const idMovie = (text.match(/id_movie:\s*(\d+)/) || [])[1];
        const hash = (text.match(/hash:\s*['"]([^'"]+)['"]/) || [])[1];
        const expires = (text.match(/expires:\s*(\d+)/) || [])[1];
        if (!idMovie || !hash || !expires) return [];
        const acc = await lookmovieRequest(
          LOOKMOVIE +
            '/api/v1/security/movie-access?id_movie=' +
            idMovie +
            '&hash=' +
            encodeURIComponent(hash) +
            '&expires=' +
            encodeURIComponent(expires),
          { xhr: true, timeout: 12000 },
        );
        if (!acc || !acc.body) return [];
        const json = safeJsonParse(acc.body);
        if (!json || !json.success) return [];
        return streamsFromLookmovieAccess(json);
      }

      // TV episode via LookMovie
      const season = ref.season || 1;
      const episode = ref.episode || 1;
      const cacheKey = 'tv:' + ref.tmdbId;
      let hit = lookmovieHitCache[cacheKey] || null;
      if (!hit) {
        hit = await findLookmovieShow(title, year);
        if (!hit && originalTitle && originalTitle !== title) {
          hit = await findLookmovieShow(originalTitle, year);
        }
        if (hit) lookmovieHitCache[cacheKey] = hit;
      }
      if (!hit || !hit.id_show) {
        log('lookmovie no TV match for ' + title);
        return [];
      }
      const listRes = await lookmovieRequest(
        LOOKMOVIE + '/api/v2/download/episode/list?id=' + encodeURIComponent(String(hit.id_show)),
        { xhr: true, timeout: 12000 },
      );
      if (!listRes || !listRes.body) return [];
      let list = {};
      try {
        list = (JSON.parse(listRes.body) || {}).list || {};
      } catch (_) {
        list = {};
      }
      const eid = pickLookmovieEpisodeId(list, season, episode);
      if (!eid) {
        log('lookmovie missing episode ' + season + 'x' + episode);
        return [];
      }
      const view = await lookmovieRequest(
        LOOKMOVIE + '/shows/view/' + encodeURIComponent(hit.slug),
        { accept: 'text/html,*/*', timeout: 12000 },
      );
      if (!view || !view.body) return [];
      const playPath = (String(view.body).match(/href="(\/shows\/play\/[^"]+)"/i) || [])[1];
      if (!playPath) return [];
      const play = await lookmovieRequest(LOOKMOVIE + playPath, {
        accept: 'text/html,*/*',
        timeout: 12000,
      });
      if (!play || !play.body) return [];
      const text = String(play.body);
      const hash = (text.match(/hash:\s*['"]([^'"]+)['"]/) || [])[1];
      const expires = (text.match(/expires:\s*(\d+)/) || [])[1];
      if (!hash || !expires) return [];
      const acc = await lookmovieRequest(
        LOOKMOVIE +
          '/api/v1/security/episode-access?id_episode=' +
          encodeURIComponent(String(eid)) +
          '&hash=' +
          encodeURIComponent(hash) +
          '&expires=' +
          encodeURIComponent(expires),
        { xhr: true, timeout: 12000 },
      );
      if (!acc || !acc.body) return [];
      const json = safeJsonParse(acc.body);
      if (!json || !json.success) return [];
      const raw = json.streams || {};
      const norm = {};
      Object.keys(raw).forEach(function (k) {
        norm[/p$/i.test(k) ? k : k + 'p'] = raw[k];
      });
      json.streams = norm;
      return streamsFromLookmovieAccess(json);
    } catch (e) {
      log('lookmovie fail: ' + (e && e.message ? e.message : e));
      return [];
    }
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseHref(episodeHref);
    if (!ref) return { streams: [] };
    log('extractStreamUrl ' + ref.type + ' ' + ref.tmdbId + ' s' + (ref.season || 1) + 'e' + (ref.episode || 1));

    let streams = [];
    const videasy = await resolveVideasy(ref);
    for (let i = 0; i < videasy.length; i++) {
      if (videasy[i] && videasy[i].url) {
        videasy[i].height = qualityHeight(videasy[i].quality) || videasy[i].height || 0;
        streams.push(videasy[i]);
      }
    }
    // LookMovie for movies + TV — real .ts when Videasy is jpeg-junk.
    {
      const lm = await resolveLookmovie(ref);
      for (let i = 0; i < lm.length; i++) {
        if (lm[i] && lm[i].url) streams.push(lm[i]);
      }
    }

    if (!streams.length) return { streams: [] };

    const probed = await softProbeStreams(streams);
    let good = probed.filter(function (s) {
      return s && s.url && !s.segmentDead && !s.playlistDead && !s.segmentMimeRisky;
    });
    if (!good.length) {
      // Last resort: unprobed non-dead only (never fake jpeg lists).
      good = probed.filter(function (s) {
        return s && s.url && !s.segmentDead && !s.playlistDead;
      });
    }
    good.sort(function (a, b) {
      return streamSeekScore(b) - streamSeekScore(a);
    });
    // Prefer 720–1080 first.
    const hd = good.filter(function (s) {
      const h = Number(s.height) || qualityHeight(s.quality) || 0;
      return h >= 720 && h <= 1080;
    });
    const rest = good.filter(function (s) {
      return hd.indexOf(s) < 0;
    });
    let ordered = hd.concat(rest).slice(0, 8);
    if (!ordered.length) {
      log('extractStreamUrl no playable streams after probe');
      return { streams: [] };
    }

    const top = ordered[0];
    return {
      streams: ordered.map(function (s, idx) {
        const h = Number(s.height) || qualityHeight(s.quality) || qualityHeight(s.label) || 0;
        return {
          label: s.label,
          url: s.url,
          height: h || undefined,
          quality: h >= 360 ? h + 'p' : s.quality,
          streamType: s.streamType || 'hls',
          kind: s.kind || 'hls',
          provider: s.provider,
          headers: s.headers,
          preferred: idx === 0,
          segmentProbeOk: !!s.segmentProbeOk,
        };
      }),
      subtitles: [],
      headers: top.headers,
      streamType: top.streamType || 'hls',
      quality: (Number(top.height) || qualityHeight(top.quality) || 0) >= 360
        ? (Number(top.height) || qualityHeight(top.quality)) + 'p'
        : top.quality,
      lang: String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub',
    };
  }

  function sectionFrom(id, title, items, feedId, style, limit) {
    if (!items || !items.length) return null;
    const max = Math.max(1, Number(limit) || 24);
    const section = {
      id: id,
      title: title,
      style: style || 'poster',
      items: items.slice(0, max).map((c, i) => ({
        href: c.href,
        title: c.title,
        image: c.image || c.poster || c.backdrop || '',
        poster: c.poster || c.image || '',
        rank: i + 1,
        type: c.type || c.mediaType || (c.isMovie ? 'movie' : undefined),
        mediaType: c.mediaType || c.type || (c.isMovie ? 'movie' : undefined),
        isMovie: !!c.isMovie || c.type === 'movie' || c.mediaType === 'movie',
      })),
    };
    if (feedId) section.viewAll = { mode: 'feed', feedId: feedId };
    return section;
  }

  async function tmdbTrending() {
    const url =
      'https://api.themoviedb.org/3/trending/all/week?api_key=' +
      TMDB_KEY +
      '&language=en-US';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results
      .filter((r) => r && (r.media_type === 'movie' || r.media_type === 'tv'))
      .map((r) => {
        const card = cardFromTmdb(r);
        if (!card) return null;
        // Hero prefers wide art when available
        const backdrop = posterUrl(r.backdrop_path);
        if (backdrop) {
          card.image = backdrop.replace('/w500/', '/w780/');
          card.backdrop = card.image;
        }
        return card;
      })
      .filter(Boolean)
      .slice(0, 12);
  }

  async function discoveryHome() {
    try {
      let movies = await stcineList('movie', 1, '');
      let tv = await stcineList('tv', 1, '');
      const popMovies = await tmdbPopular('movie');
      const popTv = await tmdbPopular('tv');
      const trending = await tmdbTrending();
      if (popMovies.length) movies = popMovies.concat(movies).slice(0, 24);
      if (popTv.length) tv = popTv.concat(tv).slice(0, 24);

      const sections = [];
      // Featured big cards (hero) — same pattern as X-Stream / Elisworld
      const featured = trending.length ? trending : movies.slice(0, 8);
      const sHero = sectionFrom('featured', 'Featured', featured, 'movies', 'hero', 8);
      const sTop = sectionFrom('top10', 'Top 10', (trending.length ? trending : movies).slice(0, 10), 'movies', 'top10', 10);
      const s1 = sectionFrom('popular-movies', 'Popular movies', movies, 'movies', 'poster', 24);
      const s2 = sectionFrom('popular-tv', 'Popular TV', tv, 'tv', 'poster', 24);
      if (sHero) sections.push(sHero);
      if (sTop) sections.push(sTop);
      if (s1) sections.push(s1);
      if (s2) sections.push(s2);
      return { sections };
    } catch (e) {
      log('home error: ' + (e && e.message ? e.message : String(e)));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const key = String(feedId || 'movies').toLowerCase();
    try {
      const type = key.includes('tv') ? 'tv' : 'movie';
      let items = await stcineList(type, pageNumber, '');
      if (!items.length && pageNumber === 1) {
        items = await tmdbPopular(type);
      }
      return {
        items: items.map((c) => ({
          href: c.href,
          title: c.title,
          image: c.image,
          poster: c.image,
        })),
        page: pageNumber,
        hasMore: items.length >= 12,
      };
    } catch (e) {
      log('feed error: ' + (e && e.message ? e.message : String(e)));
      return { items: [], page: pageNumber, hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
