(() => {
  'use strict';

  const MODULE_NAME = 'AnimeSama';
  const SITE = 'https://anime-sama.to';
  const ANILIST_URL = 'https://graphql.anilist.co';
  const SIBNET_HOST = 'https://video.sibnet.ru';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  const TIMEOUT_MS = 15000;

  // Curated popular French anime with official vertical portrait title covers and horizontal background banners
  const POPULAR_CATALOGUE = [
    {
      title: 'Attack on Titan',
      slug: 'shingeki-no-kyojin',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-buvcRTBx4NSm.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/16498-8jpFCOcDmneX.jpg'
    },
    {
      title: 'Demon Slayer',
      slug: 'demon-slayer',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-WBsBl0ClmgYL.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/101922-33MtJGsUSxga.jpg'
    },
    {
      title: 'Death Note',
      slug: 'death-note',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx1535-kUgkcrfOrkUM.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/1535.jpg'
    },
    {
      title: 'One Piece',
      slug: 'one-piece',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21-ELSYx3yMPcKM.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/21-wf37VakJmZqs.jpg'
    },
    {
      title: 'Solo Leveling',
      slug: 'solo-leveling',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx151807-it355ZgzquUd.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/151807-37yfQA3ym8PA.jpg'
    },
    {
      title: 'Jujutsu Kaisen',
      slug: 'jujutsu-kaisen',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx113415-LHBAeoZDIsnF.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/113415-jQBSkxWAAk83.jpg'
    },
    {
      title: 'My Hero Academia',
      slug: 'my-hero-academia',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21459-nYh85uj2Fuwr.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/21459-yeVkolGKdGUV.jpg'
    },
    {
      title: 'Chainsaw Man',
      slug: 'chainsaw-man',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx127230-DdP4vAdssLoz.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/127230-o8IRwCGVr9KW.jpg'
    },
    {
      title: 'Bleach',
      slug: 'bleach',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx269-d2GmRkJbMopq.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/269-08ar2HJOUAuL.jpg'
    },
    {
      title: 'Naruto',
      slug: 'naruto',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx20-dE6UHbFFg1A5.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/20-HHxhPj5JD13a.jpg'
    },
    {
      title: 'Naruto Shippuden',
      slug: 'naruto-shippuden',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx1735-kGfVm0YqCPcu.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/1735.jpg'
    },
    {
      title: 'Hunter x Hunter',
      slug: 'hunter-x-hunter-2011',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx11061-y5gsT1hoHuHw.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/11061-8WkkTZ6duKpq.jpg'
    },
    {
      title: 'Frieren',
      slug: 'frieren',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx154587-qQTzQnEJJ3oB.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/154587-ivXNJ23SM1xB.jpg'
    },
    {
      title: 'Fullmetal Alchemist: Brotherhood',
      slug: 'fullmetal-alchemist-brotherhood',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx5114-nSWCgQlmOMtj.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/5114-q0V5URebphSG.jpg'
    },
    {
      title: 'Spy x Family',
      slug: 'spy-x-family',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx140960-Kb6R5nYQfjmP.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/140960-Z7xSvkRxHKfj.jpg'
    },
    {
      title: 'Mushoku Tensei',
      slug: 'mushoku-tensei',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx108465-1ANspF1EWyFx.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/108465-RgsRpTMhP9Sv.jpg'
    },
    {
      title: 'Tokyo Revengers',
      slug: 'tokyo-revengers',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx120120-cWDmnmeEntSe.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/120120-UDYgoHA69peT.jpg'
    },
    {
      title: 'Black Clover',
      slug: 'black-clover',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx97940-fyh8o7gNbha0.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/97940-1URQdQ4U1a0b.jpg'
    },
    {
      title: 'Vinland Saga',
      slug: 'vinland-saga',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101348-2fhDFPCuMNiz.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/101348-pivKKffCAwAY.jpg'
    },
    {
      title: '86 Eighty Six',
      slug: '86-eighty-six',
      image: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx116589-KawXHB6sApFt.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/116589-SqwYWzaZCdD5.jpg'
    }
  ];

  // In-memory caches
  const detailsCache = Object.create(null);
  const episodesCache = Object.create(null);
  const streamCache = Object.create(null);
  let homeCardsCache = null;
  let homeCardsCacheTime = 0;

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function slugify(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function normForMatch(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .replace(/[’'`´:;.!?&,+()\[\]{}<>/\\|–—"]/g, ' ')
      .replace(/\bs\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  function slugFromAnimeUrl(url) {
    const raw = String(url || '').split('?')[0].replace(/\/+$/, '');
    const match = raw.match(/\/catalogue\/([^/?#]+)/i);
    return match ? match[1] : raw.replace(/^https?:\/\/[^/]+\//, '');
  }

  /* ────────────────────────── HTTP Request Layer ────────────────────────── */

  async function requestText(url, extraHeaders = {}, timeoutMs = TIMEOUT_MS) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/xhtml+xml,application/json,*/*',
        'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
      },
      extraHeaders
    );

    const doFetch = async () => {
      try {
        let res = null;
        if (typeof fetchv2 === 'function') {
          res = await fetchv2(url, headers, 'GET', null);
        } else if (typeof fetch === 'function') {
          res = await fetch(url, { headers });
        }
        const status = Number((res && res.status) || 0);
        if (!res || (status && status >= 400)) {
          return { status, text: '', headers: (res && res.headers) || {} };
        }
        let text = '';
        if (res && typeof res.text === 'function') text = await res.text();
        if (!text && res && typeof res.body === 'string') text = res.body;
        return { status, text: String(text || ''), headers: (res && res.headers) || {} };
      } catch (err) {
        log('requestText error for ' + url + ': ' + (err && err.message ? err.message : String(err)));
        return { status: 0, text: '', headers: {} };
      }
    };

    return settleWithin(doFetch(), timeoutMs, { status: 0, text: '', headers: {} });
  }

  /* ────────────────────────── Home & Catalog Card Parser ────────────────────────── */

  function parseCardsFromHtml(html) {
    const out = [];
    const seen = new Set();
    const cardRe =
      /<a[^>]*href="([^"*]*catalogue\/[^"*]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;

    while ((match = cardRe.exec(String(html || '')))) {
      const rawHref = match[1];
      const inner = match[2] || '';
      const cleanHref = rawHref.split('?')[0].replace(/\/+$/, '') + '/';
      const seriesHref = cleanHref.replace(
        /(\/catalogue\/[^/?#]+)\/(?:saison\d+|film|films|ova|specials?|scan)\/.*$/i,
        '$1/'
      );

      const slug = slugFromAnimeUrl(seriesHref);
      if (!slug || seen.has(slug)) continue;

      const imgMatch =
        inner.match(/src="([^"*]+contenu[^"*]+)"/i) || inner.match(/src="([^"*]+)"/i);
      let banner = imgMatch ? imgMatch[1].trim() : '';
      if (banner.includes('flag_') || banner.includes('logo_icon')) banner = '';

      const altMatch =
        inner.match(/<h2[^>]*class="card-title"[^>]*>([\s\S]*?)<\/h2>/i) ||
        inner.match(/alt="([^"*]+)"/i);
      let title = cleanText((altMatch && altMatch[1]) || '');

      if (!title || /^(vostfr|vf|va|var|vkr|vcn|vqc|vf1|vf2)$/i.test(title)) {
        title = slug
          .replace(/-/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase());
      }

      const pop = POPULAR_CATALOGUE.find((p) => p.slug === slug);
      const image = pop ? pop.image : (banner || `https://cdn.jsdelivr.net/gh/Anime-Sama/IMG@img/contenu/thumb/${slug}.webp`);
      const bannerImage = pop ? pop.bannerImage : (banner || image);

      seen.add(slug);
      out.push({
        title,
        slug,
        href: toAbsoluteUrl(seriesHref),
        image: toAbsoluteUrl(image),
        bannerImage: toAbsoluteUrl(bannerImage),
      });
    }

    return out;
  }

  async function getSiteCards() {
    const now = Date.now();
    if (homeCardsCache && now - homeCardsCacheTime < 300000) {
      return homeCardsCache;
    }

    const res = await requestText(SITE + '/', { Referer: SITE + '/' }, 12000);
    const parsed = parseCardsFromHtml(res.text);

    if (parsed.length > 0) {
      homeCardsCache = parsed;
      homeCardsCacheTime = now;
      return parsed;
    }

    return POPULAR_CATALOGUE.map((item) => ({
      title: item.title,
      slug: item.slug,
      href: `${SITE}/catalogue/${item.slug}/`,
      image: item.image,
      bannerImage: item.bannerImage,
    }));
  }

  /* ────────────────────────── AniList Title & Artwork Resolver ────────────────────────── */

  async function queryAniListAliases(query) {
    try {
      const gqlQuery =
        'query($q:String){Media(search:$q,type:ANIME){id title{english romaji native}coverImage{extraLarge large}bannerImage}}';
      let res;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(
          ANILIST_URL,
          { 'Content-Type': 'application/json', Accept: 'application/json' },
          'POST',
          JSON.stringify({ query: gqlQuery, variables: { q: query } })
        );
      } else if (typeof fetch === 'function') {
        res = await fetch(ANILIST_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: gqlQuery, variables: { q: query } }),
        });
      }

      const body = res && typeof res.text === 'function' ? await res.text() : (res && res.body) || '';
      const data = JSON.parse(body);
      const media = data && data.data && data.data.Media;
      if (!media) return null;

      const romaji = media.title && media.title.romaji;
      const english = media.title && media.title.english;
      const cover = media.coverImage && (media.coverImage.extraLarge || media.coverImage.large);
      const banner = media.bannerImage || '';

      return {
        romaji: romaji || '',
        english: english || '',
        cover: cover || '',
        banner: banner || '',
        slugs: [
          slugify(query),
          romaji ? slugify(romaji) : '',
          english ? slugify(english) : '',
        ].filter(Boolean),
      };
    } catch (_) {
      return null;
    }
  }

  /* ────────────────────────── Search & Details ────────────────────────── */

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    if (!term) {
      const cards = await getSiteCards();
      return cards.slice(0, 30).map((c) => ({
        id: c.href,
        href: c.href,
        title: c.title,
        image: c.image,
        poster: c.image,
        bannerImage: c.bannerImage,
        type: 'video',
      }));
    }

    const normQ = normForMatch(term);
    const siteCards = await getSiteCards();
    const matches = [];
    const seenHrefs = new Set();

    // 1. Direct match against loaded catalog
    for (const card of siteCards) {
      const normT = normForMatch(card.title);
      const normS = normForMatch(card.slug.replace(/-/g, ' '));
      if (normT.includes(normQ) || normS.includes(normQ) || normQ.includes(normS)) {
        if (!seenHrefs.has(card.href)) {
          seenHrefs.add(card.href);
          matches.push({
            id: card.href,
            href: card.href,
            title: card.title,
            image: card.image,
            poster: card.image,
            bannerImage: card.bannerImage,
            type: 'video',
          });
        }
      }
    }

    if (matches.length > 0) return matches;

    // 2. Query AniList for aliases, vertical Title Covers and Background Covers
    const anilistInfo = await queryAniListAliases(term);
    const candidateSlugs = anilistInfo
      ? anilistInfo.slugs
      : [slugify(term)];

    for (const slug of candidateSlugs) {
      const candidateUrl = `${SITE}/catalogue/${slug}/`;
      if (seenHrefs.has(candidateUrl)) continue;

      const pageRes = await requestText(candidateUrl, { Referer: SITE + '/' }, 6000);
      if (pageRes.status === 200 && pageRes.text.length > 500) {
        const titleMatch = pageRes.text.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
        const imgMatch =
          pageRes.text.match(
            /https:\/\/cdn\.jsdelivr\.net\/gh\/Anime-Sama\/IMG@img\/contenu\/[^"' \s)]+/gi
          ) || [];

        const title = cleanText((titleMatch && titleMatch[1]) || slug.replace(/-/g, ' '));
        const bannerImage = (anilistInfo && anilistInfo.banner) || imgMatch[0] || `https://cdn.jsdelivr.net/gh/Anime-Sama/IMG@img/contenu/thumb/${slug}.webp`;
        const image = (anilistInfo && anilistInfo.cover) || bannerImage;

        seenHrefs.add(candidateUrl);
        matches.push({
          id: candidateUrl,
          href: candidateUrl,
          title,
          image,
          poster: image,
          bannerImage,
          type: 'video',
        });
        break;
      }
    }

    if (matches.length > 0) return matches;

    // 3. Fallback matching against popular catalogue
    for (const item of POPULAR_CATALOGUE) {
      const normT = normForMatch(item.title);
      const normS = normForMatch(item.slug.replace(/-/g, ' '));
      if (normT.includes(normQ) || normS.includes(normQ)) {
        const href = `${SITE}/catalogue/${item.slug}/`;
        if (!seenHrefs.has(href)) {
          seenHrefs.add(href);
          matches.push({
            id: href,
            href,
            title: item.title,
            image: item.image,
            poster: item.image,
            bannerImage: item.bannerImage,
            type: 'video',
          });
        }
      }
    }

    return matches;
  }

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId).split('?')[0].replace(/\/+$/, '') + '/';
    const slug = slugFromAnimeUrl(url);
    if (!slug) throw new Error('Anime-Sama details missing valid URL');
    if (detailsCache[slug]) return detailsCache[slug];

    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    const html = res.text;

    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText((titleMatch && titleMatch[1]) || slug.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()));

    const synopsisMatch =
      html.match(/id="synopsisText"[^>]*>([\s\S]*?)<\/(?:p|div)>/i) ||
      html.match(/class="synopsis-text"[^>]*>([\s\S]*?)<\/(?:p|div)>/i) ||
      html.match(/<div class="synopsis-content"[^>]*>([\s\S]*?)<\/div>/i);
    let description = cleanText((synopsisMatch && synopsisMatch[1]) || '');

    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }

    const imgMatch = html.match(
      /https:\/\/cdn\.jsdelivr\.net\/gh\/Anime-Sama\/IMG@img\/contenu\/[^"' \s)]+/gi
    ) || [];

    const siteBanner = imgMatch[0] || `https://cdn.jsdelivr.net/gh/Anime-Sama/IMG@img/contenu/thumb/${slug}.webp`;

    // Check popular catalogue for pristine artwork
    const popularMatch = POPULAR_CATALOGUE.find((p) => p.slug === slug);
    let image = popularMatch ? popularMatch.image : '';
    let bannerImage = popularMatch ? popularMatch.bannerImage : siteBanner;

    // If not in popular list, query AniList for portrait cover & banner
    if (!image) {
      const anilistInfo = await queryAniListAliases(title || slug.replace(/-/g, ' '));
      if (anilistInfo && anilistInfo.cover) {
        image = anilistInfo.cover;
        if (anilistInfo.banner) bannerImage = anilistInfo.banner;
      } else {
        image = siteBanner;
      }
    }

    const details = {
      title,
      description: description || `Regarder ${title} en streaming VOSTFR et VF sur Anime-Sama.`,
      image,
      bannerImage,
      url,
      status: 'FINISHED',
      genres: ['Anime', 'VOSTFR', 'VF'],
      rating: '85',
      aliases: '',
    };

    detailsCache[slug] = details;
    return details;
  }

  /* ────────────────────────── Episode Extraction ────────────────────────── */

  function parseSeasonPanels(html) {
    const panels = [];
    const seen = Object.create(null);
    const re = /panneauAnime\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)/gi;
    let match;

    while ((match = re.exec(String(html || '')))) {
      const label = cleanText(match[1]);
      const path = String(match[2] || '').replace(/^\/+|\/+$/g, '');
      if (!path || path === 'url' || seen[path]) continue;
      seen[path] = true;
      panels.push({ label, path });
    }

    return panels;
  }

  function parseEpsArrays(jsText) {
    const out = {};
    const re = /var\s+(eps[0-9]+)\s*=\s*\[([\s\S]*?)\];/gi;
    let match;

    while ((match = re.exec(String(jsText || '')))) {
      const name = match[1].toLowerCase();
      const urls = [];
      const urlRe = /['"](https?:\/\/[^'"]+)['"]/g;
      let urlMatch;
      while ((urlMatch = urlRe.exec(match[2]))) {
        urls.push(urlMatch[1]);
      }
      if (urls.length) out[name] = urls;
    }

    return out;
  }

  function episodeCountFromPanels(arrays) {
    let max = 0;
    for (const key of Object.keys(arrays)) {
      max = Math.max(max, arrays[key].length);
    }
    return max;
  }

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId).split('?')[0].replace(/\/+$/, '') + '/';
    const slug = slugFromAnimeUrl(url);
    if (!slug) return [];
    if (episodesCache[slug]) return episodesCache[slug];

    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    const panels = parseSeasonPanels(res.text);
    const episodes = [];

    const details = await extractDetails(url);

    for (const panel of panels) {
      const parts = panel.path.split('/').filter(Boolean);
      const isVF = parts.some((p) => /vf/i.test(p));
      const langLabel = isVF ? 'VF' : 'VOSTFR';

      let seasonNum = 1;
      const sMatch = panel.path.match(/saison(\d+)/i);
      if (sMatch) seasonNum = Number(sMatch[1]);

      const episodesJsUrl = `${url}${panel.path}/episodes.js`;
      let arrays = {};
      try {
        const epsRes = await requestText(episodesJsUrl, { Referer: url }, 10000);
        arrays = parseEpsArrays(epsRes.text);
      } catch (_) {
        continue;
      }

      const count = episodeCountFromPanels(arrays);
      for (let ep = 1; ep <= count; ep += 1) {
        const panelTitle = panel.label && panel.label !== 'nom' ? panel.label : `Saison ${seasonNum}`;
        const title = `${panelTitle} [${langLabel}] · Épisode ${ep}`;

        episodes.push({
          number: ep,
          season: seasonNum,
          href: `as:${slug}:${panel.path}:${ep}`,
          title,
          image: details.image,
          description: `Épisode ${ep} de ${details.title} (${langLabel})`,
          subAvailable: !isVF,
          dubAvailable: isVF,
        });
      }
    }

    // Default fallback if no panels were parsed
    if (!episodes.length) {
      for (let ep = 1; ep <= 12; ep++) {
        episodes.push({
          number: ep,
          season: 1,
          href: `as:${slug}:saison1/vostfr:${ep}`,
          title: `Saison 1 [VOSTFR] · Épisode ${ep}`,
          image: details.image,
          subAvailable: true,
          dubAvailable: false,
        });
      }
    }

    episodesCache[slug] = episodes;
    return episodes;
  }

  /* ────────────────────────── Stream URL Extraction ────────────────────────── */

  function pickLecteurs(arrays, episode) {
    const order = [];
    for (const key of Object.keys(arrays)) {
      const urls = arrays[key];
      const url = urls[episode - 1];
      if (!url) continue;
      const hostMatch = String(url).match(/^https?:\/\/([^/]+)/i);
      const host = hostMatch ? hostMatch[1].toLowerCase() : '';
      order.push({ key, url, host });
    }

    // Prioritize Sibnet direct MP4 streams first
    order.sort((a, b) => {
      const rank = (entry) =>
        entry.host.includes('sibnet.ru') ? 0 : entry.host.includes('sendvid') ? 1 : entry.host.includes('ansembed') ? 2 : 3;
      return rank(a) - rank(b);
    });

    return order;
  }

  function parseSibnetSource(html) {
    const raw = String(html || '');
    const match =
      raw.match(/player\.src\(\[\{src:\s*"([^"]+\.mp4[^"]*)"/i) ||
      raw.match(/"file"\s*:\s*"([^"]+\.mp4[^"]*)"/i);
    if (match) return toAbsoluteUrl(match[1], SIBNET_HOST);
    return null;
  }

  async function resolveSibnet(embedUrl) {
    const res = await requestText(embedUrl, { Referer: SITE + '/' }, 10000);
    const rawVideoUrl = parseSibnetSource(res.text);
    if (!rawVideoUrl) throw new Error('Sibnet direct MP4 video link not found');

    // Pre-resolve 302 redirect so that the direct storage URL is returned immediately,
    // preventing cross-domain redirect stripping of Referer and download stalls in Flutter/Dio.
    let finalVideoUrl = rawVideoUrl;
    try {
      let headRes = null;
      if (typeof fetchv2 === 'function') {
        headRes = await fetchv2(rawVideoUrl, {
          'User-Agent': USER_AGENT,
          Referer: embedUrl,
        }, 'HEAD', null);
      } else if (typeof fetch === 'function') {
        headRes = await fetch(rawVideoUrl, {
          method: 'HEAD',
          redirect: 'manual',
          headers: { 'User-Agent': USER_AGENT, Referer: embedUrl },
        });
      }
      const loc = (headRes && headRes.headers && (headRes.headers.location || headRes.headers.Location || (typeof headRes.headers.get === 'function' && headRes.headers.get('location')))) || '';
      if (loc) {
        finalVideoUrl = loc.startsWith('//') ? 'https:' + loc : new URL(loc, rawVideoUrl).href;
      }
    } catch (_) {}

    const headers = {
      'User-Agent': USER_AGENT,
      Referer: 'https://video.sibnet.ru/',
      Origin: 'https://video.sibnet.ru',
      Accept: 'video/mp4,video/*,*/*',
    };

    return { url: finalVideoUrl, headers };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const parts = String(episodeHref || '').split(':');
    if (parts.length < 4 || parts[0] !== 'as') {
      throw new Error('Anime-Sama episode href is invalid');
    }

    const slug = parts[1];
    const path = parts[2];
    const episodeNum = Number(parts[3] || 1);
    const isVF = /vf/i.test(path);

    const cacheKey = `${slug}:${path}:${episodeNum}`;
    if (streamCache[cacheKey]) return streamCache[cacheKey];

    const animeUrl = `${SITE}/catalogue/${slug}/`;
    const episodesJsUrl = `${animeUrl}${path}/episodes.js`;

    const epsRes = await requestText(episodesJsUrl, { Referer: animeUrl }, 10000);
    const arrays = parseEpsArrays(epsRes.text);
    const lecteurs = pickLecteurs(arrays, episodeNum);

    if (!lecteurs.length) {
      throw new Error(`Aucun lecteur disponible pour ${slug} (${path} ep ${episodeNum})`);
    }

    for (const lecteur of lecteurs) {
      if (lecteur.host.includes('sibnet.ru')) {
        try {
          const resolved = await resolveSibnet(lecteur.url);
          const result = {
            streams: [
              `Sibnet ${isVF ? 'VF (1080p MP4)' : 'VOSTFR (1080p MP4)'}`,
              resolved.url,
            ],
            headers: resolved.headers,
            streamType: 'mp4',
            subtitles: [],
          };
          streamCache[cacheKey] = result;
          return result;
        } catch (_) {}
      }
    }

    throw new Error(`Stream indisponible pour l'épisode ${episodeNum}`);
  }

  /* ────────────────────────── Discovery Feeds ────────────────────────── */

  async function discoveryHome() {
    const siteCards = await getSiteCards();

    const trending = siteCards.slice(0, 8).map((c) => ({
      id: c.href,
      href: c.href,
      title: c.title,
      image: c.image,
      poster: c.image,
      bannerImage: c.bannerImage,
      type: 'video',
      rating: '85',
      year: '2024',
    }));

    const popular = siteCards.slice(8, 32).map((c) => ({
      id: c.href,
      href: c.href,
      title: c.title,
      image: c.image,
      poster: c.image,
      bannerImage: c.bannerImage,
      type: 'video',
      rating: '85',
      year: '2024',
    }));

    const latest = POPULAR_CATALOGUE.map((c) => ({
      id: `${SITE}/catalogue/${c.slug}/`,
      href: `${SITE}/catalogue/${c.slug}/`,
      title: c.title,
      image: c.image,
      poster: c.image,
      bannerImage: c.bannerImage,
      type: 'video',
      rating: '85',
      year: '2024',
    }));

    return {
      sections: [
        {
          id: 'trending',
          title: 'Tendances Anime (VOSTFR & VF)',
          style: 'hero',
          items: trending,
          viewAll: { mode: 'feed', feedId: 'trending' },
        },
        {
          id: 'popular',
          title: 'Animes Populaires en Français',
          style: 'poster',
          items: popular,
          viewAll: { mode: 'feed', feedId: 'popular' },
        },
        {
          id: 'classics',
          title: 'Grands Classiques Anime-Sama',
          style: 'poster',
          items: latest,
          viewAll: { mode: 'feed', feedId: 'classics' },
        },
      ],
    };
  }

  async function discoveryFeed(feedId, page) {
    const pageNum = Math.max(1, Number(page) || 1);
    const siteCards = await getSiteCards();
    const start = (pageNum - 1) * 20;
    const items = siteCards.slice(start, start + 20).map((c) => ({
      id: c.href,
      href: c.href,
      title: c.title,
      image: c.image,
      poster: c.image,
      bannerImage: c.bannerImage,
      type: 'video',
      rating: '85',
    }));

    return {
      items,
      page: pageNum,
      hasMore: start + 20 < siteCards.length,
    };
  }

  /* ────────────────────────── Global Module Exports ────────────────────────── */

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
