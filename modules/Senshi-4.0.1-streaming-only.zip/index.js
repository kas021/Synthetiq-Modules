(() => {
  'use strict';

  const MODULE_NAME = 'SenshiV1';
  const BASE_URL = 'https://senshi.live';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const defaultHeaders = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json, text/plain, */*',
    Referer: BASE_URL + '/',
    Origin: BASE_URL,
  };

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  function toAbsoluteUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    if (raw.startsWith('/')) return BASE_URL + raw;
    return BASE_URL + '/' + raw;
  }

  function slugifyQuery(query) {
    return String(query || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function isResponseOk(res, status) {
    if (res && (res.ok === true || res.ok === 1)) return true;
    if (res && (res.ok === false || res.ok === 0)) return false;
    return status >= 200 && status < 300;
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try {
        return JSON.stringify(res.json);
      } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.json === 'function') {
      try {
        const parsed = await res.json();
        if (parsed !== undefined && parsed !== null) {
          return JSON.stringify(parsed);
        }
      } catch (_) {}
    }
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        return typeof text === 'string' ? text : '';
      } catch (_) {
        return '';
      }
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = { ...defaultHeaders, ...(cfg.headers || {}) };
    const body = cfg.body == null ? null : cfg.body;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        return { ok: isResponseOk(res, status), status, body: textBody };
      }

      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        return { ok: !!res.ok, status: Number(res.status || 0), body: await res.text() };
      }

      return { ok: false, status: 0, body: '' };
    } catch (error) {
      log('request error: ' + (error && error.message ? error.message : String(error)));
      return { ok: false, status: 0, body: '' };
    }
  }

  function parseJsonBody(body) {
    if (!body) return null;
    try {
      return JSON.parse(body);
    } catch (_) {
      return null;
    }
  }

  async function requestJson(url, options) {
    const res = await request(url, options);
    if (!res.ok || !res.body) return null;
    return parseJsonBody(res.body);
  }

  function parseAnimeId(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';

    const watchMatch = raw.match(/\/watch\/(\d+)(?:\/|$)/i);
    if (watchMatch) return watchMatch[1];

    const animeMatch = raw.match(/\/anime\/(\d+)(?:\/|$|\?)/i);
    if (animeMatch) return animeMatch[1];

    if (/^\d+$/.test(raw)) return raw;
    return '';
  }

  function parseEpisodeHref(value) {
    const raw = String(value || '').trim();
    const watchMatch = raw.match(/\/watch\/(\d+)\/(\d+)/i);
    if (watchMatch) {
      return { animeId: watchMatch[1], epId: Number(watchMatch[2]) };
    }

    const animeId = parseAnimeId(raw);
    const epMatch = raw.match(/(?:^|[?&#])ep=(\d+)/i);
    if (animeId && epMatch) {
      return { animeId, epId: Number(epMatch[1]) };
    }

    return { animeId: '', epId: 0 };
  }

  function posterFromAnime(item) {
    return toAbsoluteUrl(item && item.anime_picture ? item.anime_picture : '');
  }

  function rankSearchResult(item, query) {
    const querySlug = slugifyQuery(query);
    if (!querySlug) return 2;

    const titles = [
      item && item.title,
      item && item.title_english,
      item && item.synonyms,
    ]
      .map((value) => slugifyQuery(value || ''))
      .filter(Boolean);

    const typePenalty =
      String((item && item.type) || '').toLowerCase() === 'movie' ? 20 : 0;

    for (const candidate of titles) {
      if (candidate === querySlug) return 0 + typePenalty;
      if (candidate.startsWith(querySlug + '-')) return 1 + typePenalty;
      if (candidate.includes(querySlug) || querySlug.includes(candidate)) {
        return 2 + typePenalty;
      }
    }
    return 3 + typePenalty;
  }

  function mapAnimeItem(item) {
    const id = String((item && item.id) || '').trim();
    if (!id) return null;

    const poster = posterFromAnime(item);
    const title = String((item && (item.title_english || item.title)) || 'Unknown').trim();

    return {
      href: BASE_URL + '/anime/' + id,
      title,
      image: poster,
      poster,
      backdrop: poster,
      backdropUrl: poster,
    };
  }

  function mapAnimeList(items) {
    const out = [];
    const seen = new Set();
    for (const item of Array.isArray(items) ? items : []) {
      const mapped = mapAnimeItem(item);
      if (!mapped || seen.has(mapped.href)) continue;
      seen.add(mapped.href);
      out.push(mapped);
      if (out.length >= 30) break;
    }
    return out;
  }

  async function fetchHomeItems() {
    const endpoints = [
      BASE_URL + '/anime/trending/month',
      BASE_URL + '/anime/trending/week',
      BASE_URL + '/anime/trending/day',
    ];

    const merged = [];
    const seen = new Set();

    for (const url of endpoints) {
      const data = await requestJson(url);
      const items = Array.isArray(data) ? data : data && Array.isArray(data.data) ? data.data : [];
      for (const item of items) {
        const id = String((item && item.id) || '').trim();
        if (!id || seen.has(id)) continue;
        seen.add(id);
        merged.push(item);
      }
    }

    if (merged.length) return mapAnimeList(merged);

    const fallback = await requestJson(BASE_URL + '/anime/recently-added');
    const recent = Array.isArray(fallback)
      ? fallback
      : fallback && Array.isArray(fallback.data)
        ? fallback.data
        : [];
    return mapAnimeList(recent);
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    if (!term) return fetchHomeItems();

    const payload = JSON.stringify({
      searchTerm: term,
      page: 1,
      limit: 30,
    });

    const data = await requestJson(BASE_URL + '/anime/filter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
    });

    const rows = data && Array.isArray(data.data) ? data.data.slice() : [];
    rows.sort((a, b) => rankSearchResult(a, term) - rankSearchResult(b, term));
    return mapAnimeList(rows);
  }

  async function fetchCatalogPage(page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const data = await requestJson(BASE_URL + '/anime/filter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ searchTerm: '', page: pageNumber, limit: 30 }),
    });
    const rows = data && Array.isArray(data.data) ? data.data : [];
    return {
      items: mapAnimeList(rows),
      hasMore: rows.length === 30 && (pageNumber * 30) < Number(data && data.total || 0),
    };
  }

  async function extractDetails(urlOrId) {
    const animeId = parseAnimeId(urlOrId);
    if (!animeId) {
      return { title: 'Unknown', description: 'No description available.' };
    }

    const data = await requestJson(BASE_URL + '/anime/' + animeId);
    if (!data || !data.id) {
      return { title: 'Unknown', description: 'No description available.' };
    }

    const poster = posterFromAnime(data);
    const genres = String(data.genres || '')
      .split(',')
      .map((part) => part.trim())
      .filter(Boolean);

    return {
      title: String(data.title_english || data.title || 'Unknown').trim(),
      description: String(data.ani_description || 'No description available.').trim(),
      image: poster,
      poster,
      backdrop: poster,
      backdropUrl: poster,
      year: Number(data.ani_year) || 0,
      tags: genres,
      rating: Number(data.score) || 0,
    };
  }

  async function probeLanguageAvailability(animeId, episodes) {
    const sample =
      (episodes || []).find((ep) => !ep.ep_filler && !ep.ep_recap) || (episodes || [])[0];
    if (!sample || !animeId) {
      return { subAvailable: true, dubAvailable: false };
    }

    const embeds = await requestJson(
      BASE_URL + '/episode-embeds/' + animeId + '/' + sample.ep_id,
    );
    const rows = Array.isArray(embeds) ? embeds : [];
    const hasSub = rows.some((row) => /hardsub|sub/i.test(String(row.status || '')));
    const hasDub = rows.some((row) => /dub/i.test(String(row.status || '')));

    return {
      subAvailable: hasSub || rows.length > 0,
      dubAvailable: hasDub,
    };
  }

  async function extractEpisodes(seriesId) {
    const animeId = parseAnimeId(seriesId);
    if (!animeId) return [];

    const episodes = await requestJson(BASE_URL + '/episodes/' + animeId);
    if (!Array.isArray(episodes) || !episodes.length) return [];

    const lang = await probeLanguageAvailability(animeId, episodes);

    return episodes
      .map((ep) => {
        const number = Number(ep.ep_id);
        if (!Number.isFinite(number) || number <= 0) return null;
        return {
          href: BASE_URL + '/watch/' + animeId + '/' + number,
          number,
          title: String(ep.ep_title || '').trim(),
          subAvailable: lang.subAvailable,
          dubAvailable: lang.dubAvailable,
        };
      })
      .filter(Boolean)
      .sort((a, b) => a.number - b.number);
  }

  function pickEmbedRow(rows, lang) {
    const list = Array.isArray(rows) ? rows : [];
    const wantDub = String(lang || '').toLowerCase() === 'dub';

    const dubRow = list.find((row) => /dub/i.test(String(row.status || '')));
    const subRow = list.find((row) => /hardsub|sub/i.test(String(row.status || '')));
    const anyRow = list.find((row) => row && (row.url || row.server2 || row.serverFM));

    if (wantDub && dubRow) return { label: 'dub', row: dubRow };
    if (!wantDub && subRow) return { label: 'sub', row: subRow };
    if (subRow) return { label: 'sub', row: subRow };
    if (dubRow) return { label: 'dub', row: dubRow };
    if (anyRow) {
      const label = /dub/i.test(String(anyRow.status || '')) ? 'dub' : 'sub';
      return { label, row: anyRow };
    }
    return null;
  }

  function streamUrlFromEmbed(row) {
    if (!row) return '';
    return (
      String(row.url || '').trim() ||
      String(row.server2 || '').trim() ||
      String(row.serverFM || '').trim() ||
      String(row.masked_base_url || '').trim()
    );
  }

  async function extractStreamUrl(episodeHref, lang) {
    const parsed = parseEpisodeHref(episodeHref);
    if (!parsed.animeId || !parsed.epId) return { streams: [] };

    const embeds = await requestJson(
      BASE_URL + '/episode-embeds/' + parsed.animeId + '/' + parsed.epId,
    );
    const picked = pickEmbedRow(embeds, lang);
    const streamUrl = streamUrlFromEmbed(picked && picked.row);
    if (!streamUrl) return { streams: [] };

    const label = picked.label || 'sub';
    const isHls = /\.m3u8(?:\?|$)/i.test(streamUrl);

    return {
      streams: [label, streamUrl],
      headers: {
        Referer: BASE_URL + '/',
        Origin: BASE_URL,
        'User-Agent': USER_AGENT,
        Accept: '*/*',
      },
      quality: 'auto',
      lang: label,
      streamType: isHls ? 'hls' : 'mp4',
    };
  }

  const V4_DISCOVERY_QUERIES = ['one piece', 'naruto', 'bleach', 'demon slayer', 'attack on titan', 'death note', 'fullmetal alchemist'];

  function toDiscoveryCards(items, limit) {
    const out = [];
    const seen = new Set();
    for (const item of Array.isArray(items) ? items : []) {
      const href = String(item && (item.href || item.url || item.id) || '').trim();
      const title = String(item && (item.title || item.name) || '').trim();
      if (!href || !title || seen.has(href)) continue;
      seen.add(href);
      out.push({ href, id: href, title, image: String(item.image || item.poster || '').trim() });
      if (out.length >= limit) break;
    }
    return out;
  }

  async function discoverFor(query, limit) {
    try { return toDiscoveryCards(await searchResults(query), limit); } catch (_) { return []; }
  }

  async function discoveryHome() {
    const groups = await Promise.all([fetchHomeItems(), fetchCatalogPage(1), fetchCatalogPage(2)]);
    const sections = [];
    if (groups[0].length) sections.push({ id: 'trending', title: 'Trending', style: 'hero', items: toDiscoveryCards(groups[0], 8), viewAll: { mode: 'feed', feedId: 'anime' } });
    if (groups[1].items.length) sections.push({ id: 'recent', title: 'Recently Added', style: 'poster', items: toDiscoveryCards(groups[1].items, 20), viewAll: { mode: 'feed', feedId: 'anime' } });
    if (groups[2].items.length) sections.push({ id: 'explore', title: 'Explore', style: 'poster', items: toDiscoveryCards(groups[2].items, 20), viewAll: { mode: 'feed', feedId: 'anime' } });
    if (!sections.length) throw new Error('Senshi discovery returned no usable cards');
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    if (String(feedId || '').toLowerCase() !== 'anime') return { items: [], page: pageNumber, hasMore: false };
    const feed = await fetchCatalogPage(pageNumber);
    return { items: toDiscoveryCards(feed.items, 30), page: pageNumber, hasMore: feed.hasMore };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
