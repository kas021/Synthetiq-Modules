(() => {
  'use strict';

  const MODULE_NAME = 'Ev01';
  const SITE = 'https://ev01.ws';
  const DULO_API = 'https://dulo.tv/api';
  const SECONDARY_SITE = 'https://www.lookmovie2.to';
  // Embedded in dulo.tv's public player bundle; required by its API.
  const DULO_API_KEY = 'WDNUNBUB3HR983Y9ISBADK4O82';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const RESOLVER_DEADLINE_MS = 16000;
  const VERIFY_TIMEOUT_MS = 3500;
  const VERIFY_RECOVERY_TIMEOUT_MS = 6500;

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  function searchTerms(query) {
    const raw = cleanText(query);
    const normalized = cleanText(raw.replace(/[^a-zA-Z0-9\s]/g, ' '));
    const withoutArticle = cleanText(normalized.replace(/^(?:the|an|a)\s+/i, ''));
    const out = [];
    for (const term of [raw, normalized, withoutArticle]) {
      if (term && !out.some((item) => item.toLowerCase() === term.toLowerCase())) out.push(term);
    }
    return out;
  }

  async function requestText(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers });
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw new Error('Request failed ' + (status || '') + ' for ' + url);
      }
      let text = '';
      if (res && typeof res.text === 'function') text = await res.text();
      if (!text && res && typeof res.body === 'string') text = res.body;
      let json = null;
      if (text) {
        try {
          json = JSON.parse(text);
        } catch (_) {}
      }
      if (json == null && res && typeof res.json === 'function') {
        try {
          json = await res.json();
        } catch (_) {}
      }
      return { status, text, json };
    };
    if (timeoutMs) {
      return settleWithin(doFetch(), timeoutMs, { status: 0, text: '', json: null });
    }
    return doFetch();
  }

  /* ------------------------------ catalogue ------------------------------ */

  function looksBlockedPage(html) {
    return /domain has been seized|attention required|just a moment|parked domain|domain is for sale/i.test(
      String(html || ''),
    );
  }

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const cardRe =
      /<a class="bf-card"[^>]*href="(\/watch\/((?:movie|tv))-[^"]+)"[^>]*title="([^"]+)"[\s\S]*?<img[^>]*src="([^"]+)"/gi;
    let match;
    while ((match = cardRe.exec(String(html || '')))) {
      const href = toAbsoluteUrl(match[1]);
      const mediaType = match[2].toLowerCase() === 'tv' ? 'tv' : 'movie';
      const title = cleanText(match[3]);
      const image = String(match[4] || '').trim();
      if (!href || !title || seen[href]) continue;
      seen[href] = true;
      out.push({
        title,
        href,
        image: image || SITE + '/assets/brands/ev01/favicon.png',
        mediaType,
      });
    }
    return out;
  }

  function parseTmdbFromEmbed(html, mediaType) {
    const raw = String(html || '');
    let match = raw.match(/embed\/movie\/(\d+)/i);
    if (match) return { type: 'movie', tmdb: Number(match[1]) };
    match = raw.match(/embed\/tv\/(\d+)(?:\/(\d+)\/(\d+))?/i);
    if (match) {
      return {
        type: 'tv',
        tmdb: Number(match[1]),
        season: match[2] ? Number(match[2]) : 1,
        episode: match[3] ? Number(match[3]) : 1,
      };
    }
    return mediaType === 'tv' ? { type: 'tv', tmdb: 0 } : null;
  }

  function parseJsonLd(html) {
    const blocks = String(html || '').match(
      /<script type="application\/ld\+json"[^>]*>[\s\S]*?<\/script>/gi,
    );
    for (const block of blocks || []) {
      const body = block
        .replace(/^<script[^>]*>/i, '')
        .replace(/<\/script>$/i, '');
      try {
        const json = JSON.parse(body);
        if (json && (json['@type'] === 'Movie' || json['@type'] === 'TVSeries')) {
          return json;
        }
      } catch (_) {}
    }
    return null;
  }

  function parseSeasonPills(html) {
    const seasons = [];
    const re = /class="season-pill[^"]*"[^>]*href="[^"]*[?&]s=(\d+)[^"]*"/gi;
    let match;
    const seen = Object.create(null);
    while ((match = re.exec(String(html || '')))) {
      const season = Number(match[1]);
      if (season > 0 && !seen[season]) {
        seen[season] = true;
        seasons.push(season);
      }
    }
    return seasons.sort((a, b) => a - b);
  }

  function parseEpisodeTiles(html, season) {
    const out = [];
    const re =
      /<a href="[^"]*[?&]s=(\d+)&(?:amp;)?e=(\d+)"[^>]*class="ep-tile([^"]*)"[^>]*title="([^"]*)"/gi;
    let match;
    while ((match = re.exec(String(html || '')))) {
      const s = Number(match[1]);
      const e = Number(match[2]);
      if (s !== season || e <= 0) continue;
      const flags = String(match[3] || '');
      const title = cleanText(String(match[4] || '').replace(/\s*\((?:trailer only|coming soon)\)\s*$/i, ''));
      out.push({
        season: s,
        number: e,
        title: title || 'Episode ' + e,
        trailerOnly: /coming|trailer/i.test(flags),
      });
    }
    return out;
  }

  function parseWatchRef(input) {
    const raw = String(input || '').trim();
    if (!raw) return null;
    let match = raw.match(/^ev01:(movie|tv):(\d+)(?::(\d+):(\d+))?(?::(.+))?$/i);
    if (match) {
      let hint = '';
      try {
        hint = match[5] ? decodeURIComponent(match[5]) : '';
      } catch (_) {
        hint = match[5] || '';
      }
      return {
        type: match[1].toLowerCase(),
        tmdb: Number(match[2]),
        season: match[3] ? Number(match[3]) : null,
        episode: match[4] ? Number(match[4]) : null,
        hint,
      };
    }
    match = raw.match(/\/watch\/(movie|tv)-([^/?#]+)/i);
    if (match) {
      return { type: match[1].toLowerCase(), slug: match[2], url: toAbsoluteUrl(raw, SITE) };
    }
    return null;
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    // Empty query powers the legacy home: the curated Top IMDB browse page.
    const terms = term ? searchTerms(term) : [''];
    const out = [];
    const seen = Object.create(null);
    for (const candidate of terms) {
      const url = candidate
        ? SITE + '/browser?keyword=' + encodeURIComponent(candidate)
        : SITE + '/top-imdb';
      const res = await requestText(url, { Referer: SITE + '/' }, 15000);
      if (looksBlockedPage(res.text)) {
        log('catalogue page blocked (seizure/park/challenge notice)');
        return [];
      }
      for (const card of parseCards(res.text)) {
        if (seen[card.href]) continue;
        seen[card.href] = true;
        out.push({ title: card.title, href: card.href, image: card.image });
      }
      if (out.length) break;
    }
    return out;
  }

  async function loadWatchPage(ref) {
    const res = await requestText(ref.url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('Ev01 page is blocked.');
    return res.text;
  }

  async function resolveSeriesRef(input) {
    const parsed = parseWatchRef(input);
    if (!parsed) throw new Error('Ev01 reference is invalid.');
    if (parsed.tmdb) return parsed;

    const html = await loadWatchPage({ url: parsed.url });
    const embed = parseTmdbFromEmbed(html, parsed.type);
    if (!embed || !embed.tmdb) throw new Error('No playable id found on the Ev01 page.');
    const ld = parseJsonLd(html) || {};
    return {
      type: parsed.type,
      tmdb: embed.tmdb,
      season: embed.season || 1,
      episode: embed.episode || 1,
      title: cleanText(ld.name || ''),
      description: cleanText(ld.description || ''),
      image:
        String(ld.image || '').trim() ||
        (String(html).match(/image\.tmdb\.org\/t\/p\/w\d+[^'" )]+/i)
          ? 'https://image.tmdb.org/t/p/w342' +
            String(html).match(/image\.tmdb\.org\/t\/p\/w\d+([^'" )]+)/i)[1]
          : ''),
    };
  }

  async function extractDetails(urlOrId) {
    const series = await resolveSeriesRef(urlOrId);
    return {
      title: series.title || (series.type === 'tv' ? 'TV Series' : 'Movie'),
      description:
        series.description ||
        (series.type === 'tv'
          ? 'TV series on Ev01.'
          : 'Movie on Ev01.'),
      image: series.image || SITE + '/assets/brands/ev01/favicon.png',
    };
  }

  async function extractEpisodes(seriesId) {
    const parsed = parseWatchRef(seriesId);
    if (!parsed) return [];
    if (parsed.tmdb && parsed.type === 'movie') {
      return [
        {
          number: 1,
          href: 'ev01:movie:' + parsed.tmdb + (parsed.hint ? ':' + encodeURIComponent(parsed.hint) : ''),
          title: 'Movie',
          isMovie: true,
          mediaType: 'movie',
          subAvailable: true,
          dubAvailable: false,
        },
      ];
    }
    if (parsed.tmdb && parsed.type === 'tv' && parsed.season && parsed.episode) {
      return [
        {
          number: parsed.episode,
          season: parsed.season,
          href:
            'ev01:tv:' + parsed.tmdb + ':' + parsed.season + ':' + parsed.episode +
            (parsed.hint ? ':' + encodeURIComponent(parsed.hint) : ''),
          title: 'Episode ' + parsed.episode,
          subAvailable: true,
          dubAvailable: false,
        },
      ];
    }

    // Full listing: fetch each season page and enumerate episode tiles.
    const html = await loadWatchPage({ url: parsed.url });
    const embed = parseTmdbFromEmbed(html, parsed.type);
    if (!embed || !embed.tmdb) return [];
    const ld = parseJsonLd(html) || {};
    const hint = cleanText(ld.name || parsed.slug || '');
    const encodedHint = hint ? ':' + encodeURIComponent(hint) : '';
    if (parsed.type === 'movie') {
      return [
        {
          number: 1,
          href: 'ev01:movie:' + embed.tmdb + encodedHint,
          title: 'Movie',
          isMovie: true,
          mediaType: 'movie',
          subAvailable: true,
          dubAvailable: false,
        },
      ];
    }
    let seasons = parseSeasonPills(html);
    if (!seasons.length) seasons = [embed.season || 1];

    const episodes = [];
    for (const season of seasons) {
      let seasonHtml = html;
      if (season !== (embed.season || 1)) {
        try {
          const url = parsed.url +
            (parsed.url.indexOf('?') >= 0 ? '&' : '?') + 's=' + season + '&e=1';
          const res = await requestText(url, { Referer: parsed.url }, 15000);
          if (res.text) seasonHtml = res.text;
        } catch (error) {
          log('season ' + season + ' page failed: ' + (error && error.message ? error.message : error));
          continue;
        }
      }
      for (const tile of parseEpisodeTiles(seasonHtml, season)) {
        episodes.push({
          number: tile.number,
          season: tile.season,
          href: 'ev01:tv:' + embed.tmdb + ':' + tile.season + ':' + tile.number + encodedHint,
          title: tile.title,
          trailerOnly: tile.trailerOnly === true,
          subAvailable: true,
          dubAvailable: false,
        });
      }
    }
    episodes.sort((a, b) => a.season - b.season || a.number - b.number);
    return episodes;
  }

  /* --------------------- authorized secondary adapter -------------------- */

  const secondaryHeaders = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json,text/html,*/*',
    Origin: SECONDARY_SITE,
    Referer: SECONDARY_SITE + '/',
  };

  async function secondaryRequest(path, xhr) {
    const headers = Object.assign({}, secondaryHeaders);
    if (xhr) headers['X-Requested-With'] = 'XMLHttpRequest';
    return requestText(toAbsoluteUrl(path, SECONDARY_SITE), headers, 12000);
  }

  function secondaryRows(payload) {
    return Array.isArray(payload && payload.result) ? payload.result : [];
  }

  function secondaryTitle(value) {
    return cleanText(String(value || '').replace(/\s+-\s+Season\s+\d+\s*$/i, ''));
  }

  function titleScore(query, title) {
    const q = secondaryTitle(query).toLowerCase();
    const t = secondaryTitle(title).toLowerCase();
    if (!q || !t) return 0;
    if (q === t) return 1000;
    if (t.indexOf(q) === 0 || q.indexOf(t) === 0) return 500;
    if (t.indexOf(q) >= 0 || q.indexOf(t) >= 0) return 250;
    const words = q.split(/\s+/).filter(Boolean);
    let matches = 0;
    for (const word of words) if (t.indexOf(word) >= 0) matches += 1;
    return matches * 25;
  }

  async function findSecondaryTitle(ref) {
    const query = secondaryTitle(ref.hint || '');
    if (!query) return null;
    const path = ref.type === 'tv'
      ? '/api/v1/shows/do-search/?q='
      : '/api/v1/movies/do-search/?q=';
    let rows = [];
    for (const term of searchTerms(query)) {
      const res = await secondaryRequest(path + encodeURIComponent(term), true);
      rows = rows.concat(secondaryRows(res.json));
      if (rows.length) break;
    }
    rows.sort((a, b) => titleScore(query, b.title) - titleScore(query, a.title));
    const hit = rows[0];
    if (!hit || titleScore(query, hit.title) < 250) return null;
    if (ref.type === 'tv') {
      return {
        id: Number(hit.id_show || 0),
        slug: String(hit.slug || ''),
        title: cleanText(hit.title || ''),
      };
    }
    return {
      id: Number(hit.id_movie || 0),
      slug: String(hit.slug || ''),
      title: cleanText(hit.title || ''),
    };
  }

  function secondaryPlayPath(html, type) {
    const pattern = type === 'tv'
      ? /href="(\/shows\/play\/[^"]+)"/i
      : /href="(\/movies\/play\/[^"]+)"/i;
    const match = String(html || '').match(pattern);
    return match ? match[1] : '';
  }

  function secondaryAccessFields(html) {
    const text = String(html || '');
    const idMovie = text.match(/id_movie:\s*(\d+)/);
    const idShow = text.match(/id_show:\s*(\d+)/);
    const hash = text.match(/hash:\s*['"]([^'"]+)['"]/);
    const expires = text.match(/expires:\s*(\d+)/);
    return {
      movieId: idMovie ? Number(idMovie[1]) : 0,
      showId: idShow ? Number(idShow[1]) : 0,
      hash: hash ? hash[1] : '',
      expires: expires ? expires[1] : '',
    };
  }

  async function secondaryPlayFields(ref, hit) {
    const viewPath = ref.type === 'tv'
      ? '/shows/view/' + encodeURIComponent(hit.slug || hit.id)
      : '/movies/view/' + encodeURIComponent(hit.slug || hit.id);
    const view = await secondaryRequest(viewPath, false);
    const playPath = secondaryPlayPath(view.text, ref.type);
    if (!playPath) return null;
    const play = await secondaryRequest(playPath, false);
    const fields = secondaryAccessFields(play.text);
    if (!fields.hash || !fields.expires) return null;
    return fields;
  }

  async function secondaryEpisodeId(showId, season, episode) {
    const res = await secondaryRequest(
      '/api/v2/download/episode/list?id=' + encodeURIComponent(String(showId)),
      true,
    );
    const list = (res.json && res.json.list) || {};
    const row = list[String(season)] && list[String(season)][String(episode)];
    return Number((row && (row.id_episode || row.id)) || 0);
  }

  function secondarySources(payload) {
    const streams = (payload && payload.streams) || {};
    const out = [];
    for (const key of Object.keys(streams)) {
      const url = String(streams[key] || '').trim();
      if (!/^https?:\/\//i.test(url)) continue;
      out.push({
        title: 'Secondary',
        quality: /p$/i.test(key) ? key : key + 'p',
        type: 'hls',
        url,
        headers: Object.assign({}, secondaryHeaders, {
          Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
        }),
      });
    }
    out.sort((a, b) => {
      const aq = Number((String(a.quality).match(/\d+/) || [0])[0]);
      const bq = Number((String(b.quality).match(/\d+/) || [0])[0]);
      return bq - aq;
    });
    return out;
  }

  async function resolveSecondaryStream(ref) {
    const hit = await findSecondaryTitle(ref);
    if (!hit || !hit.id) return [];
    const fields = await secondaryPlayFields(ref, hit);
    if (!fields) return [];
    let path = '';
    if (ref.type === 'tv') {
      const episodeId = await secondaryEpisodeId(
        hit.id,
        ref.season || 1,
        ref.episode || 1,
      );
      if (!episodeId) return [];
      path =
        '/api/v1/security/episode-access?id_episode=' + encodeURIComponent(String(episodeId)) +
        '&hash=' + encodeURIComponent(fields.hash) +
        '&expires=' + encodeURIComponent(fields.expires);
    } else {
      path =
        '/api/v1/security/movie-access?id_movie=' +
        encodeURIComponent(String(fields.movieId || hit.id)) +
        '&hash=' + encodeURIComponent(fields.hash) +
        '&expires=' + encodeURIComponent(fields.expires);
    }
    const access = await secondaryRequest(path, true);
    if (!access.json || access.json.success !== true) return [];
    const candidates = secondarySources(access.json);
    for (const source of candidates.slice(0, 3)) {
      const check = await settleWithin(
        softVerifySource(source),
        VERIFY_RECOVERY_TIMEOUT_MS,
        { ok: false, source, reason: 'verify_timeout' },
      );
      if (check.ok && check.source.deepVerified) {
        log('secondary route verified for ' + hit.title);
        return [check.source];
      }
    }
    return [];
  }

  function firstNonEmpty(promises) {
    return new Promise((resolve) => {
      let remaining = promises.length;
      let settled = false;
      if (!remaining) return resolve([]);
      for (const promise of promises) {
        Promise.resolve(promise)
          .then((value) => {
            if (settled) return;
            if (Array.isArray(value) && value.length) {
              settled = true;
              resolve(value);
              return;
            }
            remaining -= 1;
            if (!remaining) resolve([]);
          })
          .catch(() => {
            remaining -= 1;
            if (!settled && !remaining) resolve([]);
          });
      }
    });
  }

  /* ------------------------- dulo.tv stream resolver ------------------------ */
  // ev01's own player chain (vidsrc.mov -> vsembed.ru -> cloudnestra.com) is
  // currently DNS-dead, so playback resolves through the dulo.tv public
  // resolver using the same TMDB ids. Header policy, one-shot token
  // protection, and worker deep-verification mirror the proven Dulo rules.

  const duloHeaders = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json,text/plain,*/*',
    Origin: 'https://dulo.tv',
    Referer: 'https://dulo.tv/',
    'X-API-Key': DULO_API_KEY,
    Authorization: 'Bearer ' + DULO_API_KEY,
  };

  let sessionReady = false;
  const cookieJar = {};

  function storeCookies(res) {
    const headers = (res && res.headers) || {};
    let raw = headers['set-cookie'] || headers['Set-Cookie'];
    if (!raw && typeof headers.get === 'function') {
      // node-fetch Headers instance (test harnesses): plain reads miss it.
      raw = headers.get('set-cookie');
      if (!raw && typeof headers.raw === 'function') {
        const rawHeaders = headers.raw();
        if (rawHeaders && rawHeaders['set-cookie']) raw = rawHeaders['set-cookie'];
      }
    }
    if (!raw) return;
    const lines = Array.isArray(raw) ? raw : [raw];
    for (const line of lines) {
      const part = String(line || '').split(';')[0];
      const idx = part.indexOf('=');
      if (idx <= 0) continue;
      cookieJar[part.slice(0, idx).trim()] = part.slice(idx + 1).trim();
    }
  }

  function cookieHeader() {
    return Object.keys(cookieJar)
      .map((key) => key + '=' + cookieJar[key])
      .join('; ');
  }

  function sourceHost(url) {
    const match = String(url || '').match(/^https?:\/\/([^/]+)/i);
    return match ? String(match[1]).toLowerCase() : '';
  }

  function isDuloOwnedHost(url) {
    const host = sourceHost(url);
    return (
      host === 'dulo.tv' ||
      host.endsWith('.dulo.tv') ||
      host === 'dulo.cc' ||
      host.endsWith('.dulo.cc')
    );
  }

  async function duloRequest(url, options) {
    const cfg = options || {};
    const duloOwned = isDuloOwnedHost(url);
    const headers = duloOwned
      ? Object.assign({}, duloHeaders, cfg.headers || {})
      : Object.assign(
          {
            'User-Agent': USER_AGENT,
            Accept: 'video/mp4,video/*;q=0.9,application/vnd.apple.mpegurl,*/*;q=0.8',
          },
          cfg.headers || {},
        );
    if (duloOwned) {
      const cookie = cookieHeader();
      if (cookie) headers.Cookie = cookie;
    }
    let res = null;
    try {
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, cfg.method || 'GET', cfg.body == null ? null : cfg.body, cfg.fetchOptions || undefined);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { method: cfg.method || 'GET', headers, body: cfg.body == null ? undefined : cfg.body });
      }
    } catch (error) {
      log('dulo request error: ' + (error && error.message ? error.message : error));
      return { ok: false, status: 0, body: '', json: null };
    }
    if (duloOwned) storeCookies(res);
    const status = Number((res && res.status) || 0);
    let text = '';
    if (res && typeof res.text === 'function') text = await res.text();
    if (!text && res && typeof res.body === 'string') text = res.body;
    let json = null;
    if (res && typeof res.json === 'function') {
      try {
        json = await res.json();
      } catch (_) {}
    }
    if (!json && text) {
      try {
        json = JSON.parse(text);
      } catch (_) {}
    }
    return {
      ok: status >= 200 && status < 300,
      status,
      body: text,
      json,
      bodyDropped: !!(res && (res.bodyDropped === true || res.bodyDropped === 1)),
      bodyBytes: Number((res && res.bodyBytes) || 0),
    };
  }

  async function ensureSession() {
    if (sessionReady) return true;
    const res = await duloRequest(DULO_API + '/session');
    if (res.ok) {
      sessionReady = true;
      return true;
    }
    log('session failed status=' + res.status);
    return false;
  }

  function parseSourceEvents(body) {
    const sources = [];
    const seen = {};
    const blocks = String(body || '').replace(/\r\n/g, '\n').split(/\n\n+/);
    for (const block of blocks) {
      const eventMatch = block.match(/^event:\s*([^\n]+)/m);
      if (!eventMatch || String(eventMatch[1]).trim() !== 'sources') continue;
      const dataMatch = block.match(/^data:\s*(.+)$/m);
      if (!dataMatch) continue;
      let payload = null;
      try {
        payload = JSON.parse(dataMatch[1]);
      } catch (_) {
        continue;
      }
      const rows = Array.isArray(payload && payload.sources) ? payload.sources : [];
      for (const source of rows) {
        const url = String(source && source.url || '').trim();
        if (!url || seen[url]) continue;
        seen[url] = true;
        sources.push(source);
      }
    }
    return sources;
  }

  function isOneShotSignedUrl(url) {
    const value = String(url || '').toLowerCase();
    return (
      /[?&]t=[^&]{8,}/.test(value) &&
      /[?&]s=\d{9,}/.test(value) &&
      /[?&]e=\d{3,}/.test(value)
    );
  }

  function bodyLooksBlocked(body) {
    const text = String(body || '');
    if (!text) return false;
    const lower = text.toLowerCase();
    if (text.indexOf('BOUND_IP_ORB') >= 0) return true;
    if (lower.indexOf('not allowed to use this worker') >= 0) return true;
    if (lower.indexOf('organization is not allowed') >= 0) return true;
    if (lower.indexOf('bound_ip_orb_failed') >= 0) return true;
    if (lower.indexOf('<!doctype html') >= 0) return true;
    if (lower.indexOf('<html') >= 0 && lower.indexOf('worker') >= 0) return true;
    return false;
  }

  function bodyLooksLikeImageError(body) {
    const raw = String(body || '');
    if (!raw) return false;
    const b0 = raw.charCodeAt(0);
    const b1 = raw.length > 1 ? raw.charCodeAt(1) : 0;
    const b2 = raw.length > 2 ? raw.charCodeAt(2) : 0;
    if (b0 === 0xff && b1 === 0xd8 && b2 === 0xff) return true;
    if (b0 === 0x89 && b1 === 0x50 && b2 === 0x4e) return true;
    if (raw.indexOf('GIF8') === 0) return true;
    if (raw.slice(0, 4) === 'RIFF' && raw.indexOf('WEBP') > 0) return true;
    return false;
  }

  function bodyLooksLikeMedia(body) {
    const raw = String(body || '');
    if (!raw) return false;
    if (raw.indexOf('#EXTM3U') >= 0) return true;
    if (raw.charCodeAt(0) === 0x47) return true;
    if (raw.length >= 8 && raw.indexOf('ftyp') >= 4 && raw.indexOf('ftyp') < 12) return true;
    return false;
  }

  function firstPlaylistUri(m3u8Body, baseUrl) {
    const lines = String(m3u8Body || '').split(/\r?\n/);
    for (const line of lines) {
      const trimmed = String(line || '').trim();
      if (!trimmed || trimmed.charAt(0) === '#') continue;
      if (/^https?:\/\//i.test(trimmed)) return trimmed;
      if (trimmed.charAt(0) === '/') {
        const origin = String(baseUrl || '').match(/^(https?:\/\/[^/]+)/i);
        return origin ? origin[1] + trimmed : trimmed;
      }
      const cut = String(baseUrl || '').lastIndexOf('/');
      return cut >= 0 ? String(baseUrl).slice(0, cut + 1) + trimmed : trimmed;
    }
    return '';
  }

  function isHlsSource(source) {
    const type = String((source && source.type) || '').toLowerCase();
    const url = String((source && source.url) || '').toLowerCase();
    return type === 'hls' || url.includes('.m3u8') || url.includes('mpegurl');
  }

  function mergeSourceHeaders(source) {
    const fromSource =
      source && source.headers && typeof source.headers === 'object' ? source.headers : {};
    const headers = {
      'User-Agent': USER_AGENT,
      Accept: 'video/mp4,video/*;q=0.9,application/vnd.apple.mpegurl,*/*;q=0.8',
      Connection: 'keep-alive',
    };
    const declares = !!(
      fromSource.Referer ||
      fromSource.referer ||
      fromSource.Origin ||
      fromSource.origin
    );
    if (declares || isDuloOwnedHost(source && source.url)) {
      headers.Referer = fromSource.Referer || fromSource.referer || 'https://dulo.tv/';
      headers.Origin = fromSource.Origin || fromSource.origin || 'https://dulo.tv';
    }
    return Object.assign(headers, fromSource);
  }

  function scoreSource(source) {
    const url = String(source.url || '').toLowerCase();
    const title = String(source.title || '').toLowerCase();
    const height = Number((String(source.quality || title).match(/(\d{3,4})\s*p/i) || [])[1]) || 0;
    let score = height;
    if (isHlsSource(source) && !url.includes('jay.dulo.tv') && source.deepVerified) score += 320;
    else if (isHlsSource(source) && !url.includes('jay.dulo.tv')) score += 140;
    if (url.includes('workers.dev') || url.includes('proxy.dulo')) {
      score += source.deepVerified ? 30 : -20;
    }
    if (url.includes('jay.dulo.tv')) score += source.playableVerified ? 60 : 20;
    if (source.playableVerified) score += 120;
    if (url.includes('storrrrrrm.site')) score -= 200;
    return score;
  }

  function rankSources(sources) {
    return (Array.isArray(sources) ? sources : [])
      .filter((source) => source && source.url)
      .map((source) => ({ source, score: scoreSource(source) }))
      .sort((a, b) => b.score - a.score)
      .map((row) => row.source);
  }

  async function softVerifySource(source) {
    const url = String((source && source.url) || '').trim();
    if (!url) return { ok: false, source, reason: 'empty' };
    const headers = mergeSourceHeaders(source);

    if (!isHlsSource(source)) {
      if (isOneShotSignedUrl(url)) {
        source.playableVerified = true;
        return { ok: true, source, soft: true };
      }
      const res = await duloRequest(url, {
        headers: Object.assign({}, headers, { Range: 'bytes=0-1023' }),
      });
      const body = String(res.body || '');
      if (!res.ok || bodyLooksBlocked(body) || bodyLooksLikeImageError(body)) {
        return { ok: false, source, reason: 'mp4_blocked' };
      }
      source.playableVerified = bodyLooksLikeMedia(body) || body.length > 0;
      return { ok: true, source, soft: !source.playableVerified };
    }

    let playlistUrl = url;
    let res = await duloRequest(playlistUrl, {
      headers,
      fetchOptions: { maxBytesHint: 4 * 1024 * 1024 },
    });
    for (let depth = 0; depth < 4; depth += 1) {
      const playlistBody = String(res.body || '');
      if (!res.ok || bodyLooksBlocked(playlistBody) || bodyLooksLikeImageError(playlistBody)) {
        return { ok: false, source, reason: 'hls_blocked_or_error' };
      }
      if (playlistBody.indexOf('#EXTM3U') < 0) {
        return { ok: false, source, reason: 'hls_probe_fail' };
      }
      const nextUrl = firstPlaylistUri(playlistBody, playlistUrl);
      if (!nextUrl) return { ok: false, source, reason: 'hls_empty_playlist' };

      if (playlistBody.indexOf('#EXTINF') >= 0) {
        if (isOneShotSignedUrl(nextUrl)) {
          // savefiles-style one-shot tokens: probing would burn the player's
          // only fetch. Playlist structure verified; trust the fresh chain.
          source.resolvedPlaylistUrl = playlistUrl;
          source.playableVerified = true;
          source.oneShotSigned = true;
          return { ok: true, source, soft: true };
        }
        const segment = await duloRequest(nextUrl, {
          headers: Object.assign({}, headers, {
            Range: 'bytes=0-4096',
            Accept: 'video/mp2t,video/*,application/octet-stream,*/*',
          }),
          fetchOptions: { maxBytesHint: 1024 * 1024 },
        });
        const segmentBody = String(segment.body || '');
        if (!segment.ok || bodyLooksBlocked(segmentBody) || bodyLooksLikeImageError(segmentBody)) {
          return { ok: false, source, reason: 'hls_segment_blocked' };
        }
        if (segment.bodyDropped) {
          if (Number(segment.bodyBytes || 0) < 64 * 1024) {
            return { ok: false, source, reason: 'hls_segment_unusable' };
          }
        } else if (!bodyLooksLikeMedia(segmentBody) && segmentBody.length <= 32) {
          return { ok: false, source, reason: 'hls_segment_unusable' };
        }
        source.resolvedPlaylistUrl = playlistUrl;
        source.playableVerified = true;
        source.deepVerified = true;
        return { ok: true, source };
      }

      playlistUrl = nextUrl;
      res = await duloRequest(playlistUrl, {
        headers,
        fetchOptions: { maxBytesHint: 4 * 1024 * 1024 },
      });
    }
    return { ok: false, source, reason: 'playlist chain never reached media' };
  }

  async function resolveStream(ref) {
    await ensureSession();
    const startedAt = Date.now();
    const remainingMs = () => Math.max(0, RESOLVER_DEADLINE_MS - (Date.now() - startedAt));
    const payload =
      ref.type === 'tv'
        ? { type: 'tv', tmdbId: ref.tmdb, season: ref.season || 1, episode: ref.episode || 1 }
        : { type: 'movie', tmdbId: ref.tmdb };

    const live = await settleWithin(
      duloRequest(DULO_API + '/source', {
        method: 'POST',
        headers: {
          Accept: 'text/event-stream',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      }),
      Math.min(13000, remainingMs()),
      { ok: false, status: 0, body: '' },
    );
    let sources = parseSourceEvents(live.body);
    if (!sources.length && remainingMs() > 3000) {
      // One bounded retry after a fresh session; repeat emits are usually fast.
      sessionReady = false;
      await ensureSession();
      const retry = await settleWithin(
        duloRequest(DULO_API + '/source', {
          method: 'POST',
          headers: {
            Accept: 'text/event-stream',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        }),
        Math.min(8000, remainingMs()),
        { ok: false, status: 0, body: '' },
      );
      sources = parseSourceEvents(retry.body);
    }
    if (!sources.length) {
      log('no upstream sources for ' + JSON.stringify(payload));
      return [];
    }

    const ranked = rankSources(sources);
    const verified = [];
    const softOk = [];
    let checked = 0;
    for (const source of ranked.slice(0, 6)) {
      if (remainingMs() < 500) break;
      if (!isHlsSource(source)) {
        softOk.push(source);
        continue;
      }
      checked += 1;
      const check = await settleWithin(
        softVerifySource(source),
        Math.min(checked <= 2 ? VERIFY_TIMEOUT_MS : VERIFY_RECOVERY_TIMEOUT_MS, remainingMs()),
        { ok: false, source, reason: 'verify_timeout' },
      );
      if (check.ok && check.source.deepVerified) {
        verified.push(check.source);
        break;
      }
      if (check.ok && check.source.playableVerified) {
        softOk.push(check.source);
      } else if (!check.ok && /blocked|error|unusable/i.test(String(check.reason || ''))) {
        log('drop source: ' + check.reason);
      } else {
        softOk.push(source);
      }
    }

    const out = verified
      .concat(softOk)
      .concat(ranked.filter((s) => verified.indexOf(s) < 0 && softOk.indexOf(s) < 0))
      .filter(
        (source, index, list) =>
          list.findIndex((other) => other.url === source.url) === index &&
          (source.deepVerified || source.playableVerified),
      );
    log('resolver finished in ' + String(Date.now() - startedAt) + 'ms routes=' + out.length);
    return out.slice(0, 4);
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseWatchRef(episodeHref);
    if (!ref || !ref.tmdb) return { streams: [] };
    const playbackRef = {
      type: ref.type,
      tmdb: ref.tmdb,
      season: ref.type === 'tv' ? ref.season || 1 : null,
      episode: ref.type === 'tv' ? ref.episode || 1 : null,
    };

    const sources = await settleWithin(
      firstNonEmpty([
        resolveStream(playbackRef),
        resolveSecondaryStream(Object.assign({}, playbackRef, { hint: ref.hint || '' })),
      ]),
      RESOLVER_DEADLINE_MS + 2000,
      [],
    );
    if (!sources.length) {
      log('extractStreamUrl no routes for ' + episodeHref);
      return { streams: [] };
    }

    const entries = [];
    let primaryHeaders = null;
    for (const source of sources) {
      const streamUrl = String(source.resolvedPlaylistUrl || source.url || '').trim();
      if (!streamUrl) continue;
      const headers = mergeSourceHeaders(source);
      if (!primaryHeaders) primaryHeaders = headers;
      const quality = String(source.quality || '').trim();
      entries.push({
        label: (source.title || 'Stream') + (quality ? ' ' + quality : ''),
        url: streamUrl,
        headers,
      });
    }
    if (!entries.length) return { streams: [] };

    return {
      streams: entries,
      headers: primaryHeaders || { 'User-Agent': USER_AGENT },
      quality: 'auto',
      lang: String(lang || '').toLowerCase() === 'dub' ? 'dub' : 'sub',
      streamType: 'hls',
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
})();
