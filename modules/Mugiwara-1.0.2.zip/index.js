(() => {
  'use strict';

  const MODULE_NAME = 'Mugiwara';
  const SITE = 'https://www.mugiwara-no-streaming.com';
  const SIBNET = 'https://video.sibnet.ru';
  const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const MAX_EPISODES_CAP = 3000;

  function log(message) {
    try {
      if (typeof debugPrint === 'function') debugPrint('[' + MODULE_NAME + '] ' + String(message || ''));
      else console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function decodeHtml(text) {
    return String(text || '')
      .replace(/&#0?39;|&#x27;|&apos;/g, "'")
      .replace(/&#8217;/g, "'")
      .replace(/&#8211;|&ndash;/g, '-')
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ')
      .trim();
  }

  // ---------- HTTP bridge ----------

  async function requestJson(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'application/json',
      Referer: SITE + '/',
    }, extraHeaders || {});
    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }
    const status = Number((res && res.status) || 0);
    if (status < 200 || status >= 400) {
      throw new Error('Mugiwara: request failed (HTTP ' + status + ') for ' + url);
    }
    if (res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j) return j;
      } catch (_) {}
    }
    if (res && res.json && typeof res.json === 'object') {
      return res.json;
    }
    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;
    if (text) {
      try { return JSON.parse(text); } catch (_) {}
    }
    throw new Error('Mugiwara: response from ' + url + ' was not valid JSON');
  }

  async function requestText(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      Referer: SITE + '/',
    }, extraHeaders || {});
    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }
    const status = Number((res && res.status) || 0);
    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;
    if (!text && res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j) text = JSON.stringify(j);
      } catch (_) {}
    } else if (!text && res && res.json && typeof res.json === 'object') {
      text = JSON.stringify(res.json);
    }
    return { status: status, ok: status >= 200 && status < 400, text: text || '' };
  }

  // ---------- image scoring ----------

  function scoreImage(url) {
    if (!url) return -100;
    const lower = url.toLowerCase();
    if (lower.includes('heroines') || lower.includes('elbaf') || lower.includes('scan') || lower.includes('kai')) return -50;
    if (lower.includes('affiche')) return 100;
    if (lower.includes('saison1.') || lower.includes('saison1/') || lower.includes('saison1.jpg') || lower.includes('saison1.webp') || lower.includes('saison1.jpeg')) return 90;
    if (lower.includes('films/1.') || lower.includes('film1.')) return 85;
    if (lower.includes('saison')) return 70;
    return 10;
  }

  // ---------- catalogue ----------

  const catalogueCache = { at: 0, items: [] };

  async function fetchCatalogue() {
    if (catalogueCache.items.length && Date.now() - catalogueCache.at < 10 * 60 * 1000) {
      return catalogueCache.items;
    }
    const data = await requestJson(SITE + '/api/get-catalogues');
    const bySlug = {};

    for (const cat of ((data && data.catalogues) || [])) {
      for (const entry of (cat.names || [])) {
        const slug = String(entry.slug || '').trim();
        if (!slug) continue;
        const img = String((entry.data && entry.data.image) || '');
        const title = String(entry.animeName || entry.title || slug).trim();
        const category = String(cat.category || '');
        const disponibles = (entry.data && entry.data.disponibles) || [];

        if (!bySlug[slug]) {
          let canonicalImg = img;
          if (slug === 'one-piece') {
            canonicalImg = 'https://raw.githubusercontent.com/NOUSSS/mugiwara-no-streaming-images/main/Animes/one-piece/affiche.webp';
          }
          bySlug[slug] = {
            slug: slug,
            title: title,
            image: canonicalImg,
            category: category,
            disponibles: disponibles,
            images: [img].filter(Boolean),
          };
        } else {
          if (img) bySlug[slug].images.push(img);
          if (slug !== 'one-piece' && scoreImage(img) > scoreImage(bySlug[slug].image)) {
            bySlug[slug].image = img;
          }
          if (category && (!bySlug[slug].category || bySlug[slug].category === 'Nouveautés')) {
            bySlug[slug].category = category;
          }
          if (disponibles.length && !bySlug[slug].disponibles.length) {
            bySlug[slug].disponibles = disponibles;
          }
        }
      }
    }

    const items = Object.values(bySlug);
    if (!items.length) throw new Error('Mugiwara: catalogue returned no titles');
    catalogueCache.at = Date.now();
    catalogueCache.items = items;
    return items;
  }

  // ---------- search ----------

  async function searchResults(query) {
    const q = String(query || '').trim().toLowerCase();
    const items = await fetchCatalogue();
    if (!q) {
      return items.slice(0, 50).map((i) => ({
        href: SITE + '/catalogue/' + i.slug,
        id: i.slug,
        title: i.title,
        image: i.image,
      }));
    }
    const qNorm = q.replace(/[^a-z0-9]+/g, ' ').trim();
    const qTokens = qNorm.split(/\s+/).filter(Boolean);

    const scored = [];
    for (const item of items) {
      const tNorm = (item.title + ' ' + item.slug).toLowerCase().replace(/[^a-z0-9]+/g, ' ');
      let matches = true;
      let score = 0;
      for (const tok of qTokens) {
        if (tNorm.includes(tok)) {
          score += 10;
          if (item.title.toLowerCase().startsWith(tok)) score += 20;
        } else {
          matches = false;
          break;
        }
      }
      if (matches) {
        scored.push({ item: item, score: score });
      }
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.map((s) => ({
      href: SITE + '/catalogue/' + s.item.slug,
      id: s.item.slug,
      title: s.item.title,
      image: s.item.image,
    }));
  }

  // ---------- JSON parsing helpers ----------

  function matchObjectEnd(str, open) {
    let depth = 0, inStr = false, strCh = '', esc = false;
    for (let j = open; j < str.length; j++) {
      const ch = str.charAt(j);
      if (esc) { esc = false; continue; }
      if (inStr) {
        if (ch === '\\') { esc = true; continue; }
        if (ch === strCh) inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { inStr = true; strCh = ch; continue; }
      if (ch === '{') depth += 1;
      else if (ch === '}') { depth -= 1; if (depth === 0) return j + 1; }
    }
    return -1;
  }

  function matchArrayEnd(str, open) {
    let depth = 0, inStr = false, strCh = '', esc = false;
    for (let j = open; j < str.length; j++) {
      const ch = str.charAt(j);
      if (esc) { esc = false; continue; }
      if (inStr) {
        if (ch === '\\') { esc = true; continue; }
        if (ch === strCh) inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { inStr = true; strCh = ch; continue; }
      if (ch === '[') depth += 1;
      else if (ch === ']') { depth -= 1; if (depth === 0) return j + 1; }
    }
    return -1;
  }

  function extractJsonObjects(html, key) {
    const normalized = String(html || '').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    const idx = normalized.indexOf('"' + key + '":');
    if (idx < 0) return null;
    const start = normalized.indexOf('{', idx);
    if (start < 0) return null;
    const end = matchObjectEnd(normalized, start);
    if (end < 0) return null;
    try {
      return JSON.parse(normalized.slice(start, end));
    } catch (_) {
      return null;
    }
  }

  function extractJsonStrings(html, key) {
    const normalized = String(html || '').replace(/\\"/g, '"');
    const idx = normalized.indexOf(key);
    if (idx < 0) return '';
    return normalized.slice(Math.max(0, idx - 50), Math.min(normalized.length, idx + 100000));
  }

  // ---------- details ----------

  async function extractDetails(urlOrId) {
    let slug = String(urlOrId || '').trim();
    if (/^https?:\/\//i.test(slug)) {
      const m = slug.match(/\/catalogue\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?catalogue\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error('Mugiwara: extractDetails received an empty or foreign URL');

    const items = await fetchCatalogue();
    const known = items.find((i) => i.slug === slug);

    let res = await requestText(SITE + '/catalogue/' + slug + '/episodes');
    if (!res.ok) {
      res = await requestText(SITE + '/catalogue/' + slug + '/films');
    }
    if (!res.ok) {
      res = await requestText(SITE + '/catalogue/' + slug);
    }

    const og = (prop) => {
      const needle = 'og:' + prop;
      const tagRe = /<meta\b[^>]*>/gi;
      let tag;
      while ((tag = tagRe.exec(res.text)) !== null) {
        const t = tag[0];
        if (t.indexOf(needle) < 0) continue;
        const c = t.match(/content\s*=\s*"([^"]*)"/i) || t.match(/content\s*=\s*'([^']*)'/i);
        if (c) return decodeHtml(c[1]);
      }
      return '';
    };

    const window2 = extractJsonStrings(res.text, 'EPISODES_OPTIONS') || extractJsonStrings(res.text, 'FILM_OPTIONS') || extractJsonStrings(res.text, '"saisons"');
    const genresM = window2.match(/"genres":\[([^\]]*)\]/);
    const genres = genresM
      ? genresM[1].split(',').map((g) => decodeHtml(String(g).replace(/"/g, ''))).filter(Boolean)
      : [];

    return {
      href: SITE + '/catalogue/' + slug,
      id: slug,
      title: (og('title') || (known && known.title) || slug).replace(/\s*[-–|]\s*Mugiwara.*$/i, '').trim(),
      description: og('description') || 'Anime disponible sur Mugiwara No Streaming.',
      image: (known && known.image) || og('image') || '',
      genres: genres,
    };
  }

  // ---------- episodes & player parsing ----------

  function parseEpisodesJs(jsText) {
    const players = [];
    const re = /var\s+(?:eps\d+)\s*=\s*\[([\s\S]*?)\];/g;
    let m;
    while ((m = re.exec(String(jsText || ''))) !== null) {
      const urls = [];
      const urlRe = /['"]([^'"]+)['"]/g;
      let u;
      while ((u = urlRe.exec(m[1])) !== null) {
        const url = decodeHtml(u[1]).trim();
        if (/^https?:\/\//i.test(url) || /^\/\//i.test(url)) {
          urls.push(url.startsWith('//') ? 'https:' + url : url);
        }
      }
      if (urls.length) players.push(urls);
    }
    return players;
  }

  function sibnetVideoId(playerUrl) {
    const m = String(playerUrl || '').match(/[?&]videoid=(\d+)/i) || String(playerUrl || '').match(/sibnet\.ru\/shell\.php\?videoid=(\d+)/i);
    return m ? m[1] : '';
  }

  function sortMirrorsSibnetFirst(urls) {
    const arr = (urls || []).slice();
    arr.sort((a, b) => {
      const aSib = /sibnet\.ru/i.test(a) ? 1 : 0;
      const bSib = /sibnet\.ru/i.test(b) ? 1 : 0;
      return bSib - aSib;
    });
    return arr;
  }

  function parseInlineSeasons(html) {
    const normalized = String(html || '').replace(/\\"/g, '"');
    const marker = normalized.indexOf('"saisons":[');
    if (marker < 0) return [];
    const arrOpen = normalized.indexOf('[', marker);
    const arrClose = matchArrayEnd(normalized, arrOpen);
    if (arrClose < 0) return [];
    const region = normalized.slice(arrOpen + 1, arrClose);

    const seasons = [];
    let i = 0;
    while (i < region.length && seasons.length < 30) {
      while (i < region.length && /[\s,]/.test(region.charAt(i))) i += 1;
      if (region.charAt(i) !== '{') break;
      const objEnd = matchObjectEnd(region, i);
      if (objEnd < 0) break;
      const objStr = region.slice(i, objEnd);

      try {
        const parsed = JSON.parse(objStr);
        if (parsed && parsed.id && parsed.lang) {
          const vfMirrors = Array.isArray(parsed.lang.vf) ? parsed.lang.vf : [];
          const vostMirrors = Array.isArray(parsed.lang.vostfr) ? parsed.lang.vostfr : [];
          seasons.push({
            id: String(parsed.id),
            vfMirrors: vfMirrors,
            vostMirrors: vostMirrors,
          });
        }
      } catch (_) {}
      i = objEnd;
    }

    seasons.sort((a, b) => {
      const na = Number(a.id), nb = Number(b.id);
      const aIsNum = !isNaN(na) && /^[0-9]+$/.test(a.id);
      const bIsNum = !isNaN(nb) && /^[0-9]+$/.test(b.id);
      if (aIsNum && bIsNum) return na - nb;
      if (aIsNum) return -1;
      if (bIsNum) return 1;
      return a.id.localeCompare(b.id);
    });

    return seasons;
  }

  async function extractEpisodes(seriesId) {
    let slug = String(seriesId || '').trim();
    if (/^https?:\/\//i.test(slug)) {
      const m = slug.match(/\/catalogue\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?catalogue\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error('Mugiwara: extractEpisodes received an empty or foreign URL');

    let html = '';
    let isFilmPage = false;
    let res = await requestText(SITE + '/catalogue/' + slug + '/episodes');
    if (res.ok) html = res.text;

    const norm = html.replace(/\\"/g, '"');
    const hasInline = norm.includes('"saisons":[') && !norm.includes('"saisons":[]');
    const hasScriptOptions = norm.includes('EPISODES_OPTIONS');

    // --- CASE 1: Inline Seasons (One Piece, Titans, etc.) ---
    if (hasInline) {
      const inlineSeasons = parseInlineSeasons(html);
      if (inlineSeasons.length) {
        const episodes = [];
        let globalNumber = 0;

        for (const season of inlineSeasons) {
          const vostCount = season.vostMirrors ? season.vostMirrors.reduce((max, arr) => Math.max(max, (arr || []).length), 0) : 0;
          const vfCount = season.vfMirrors ? season.vfMirrors.reduce((max, arr) => Math.max(max, (arr || []).length), 0) : 0;
          const maxLen = Math.max(vostCount, vfCount);
          if (!maxLen) continue;

          for (let i = 0; i < maxLen; i++) {
            globalNumber += 1;
            const subCandidates = [];
            for (const mirrorArr of (season.vostMirrors || [])) {
              if (mirrorArr && mirrorArr[i]) subCandidates.push(mirrorArr[i]);
            }
            const dubCandidates = [];
            for (const mirrorArr of (season.vfMirrors || [])) {
              if (mirrorArr && mirrorArr[i]) dubCandidates.push(mirrorArr[i]);
            }

            episodes.push({
              number: globalNumber,
              title: '\u00c9pisode ' + globalNumber + (Number(season.id) > 1 || !/^[0-9]+$/.test(season.id) ? ' (S' + season.id + ')' : ''),
              href: 'mugi-dual:' + JSON.stringify({
                sub: sortMirrorsSibnetFirst(subCandidates),
                dub: sortMirrorsSibnetFirst(dubCandidates),
              }),
              subAvailable: subCandidates.length > 0,
              dubAvailable: dubCandidates.length > 0,
              image: '',
            });
            if (episodes.length >= MAX_EPISODES_CAP) break;
          }
          if (episodes.length >= MAX_EPISODES_CAP) break;
        }

        if (episodes.length) {
          log('inline canonical seasons parsed: ' + episodes.length + ' episodes for ' + slug);
          return episodes;
        }
      }
    }

    // --- CASE 2: External Script Seasons via EPISODES_OPTIONS (Naruto, Bleach, Solo Leveling, etc.) ---
    if (hasScriptOptions) {
      const window2 = extractJsonStrings(html, 'EPISODES_OPTIONS') || extractJsonStrings(html, 'saisons');
      const scriptM = window2.match(/"SCRIPT_URL":"([^"]+)"/) || html.match(/"SCRIPT_URL":"([^"]+)"/);
      const scriptBase = scriptM ? decodeHtml(scriptM[1]).replace(/\/?$/, '/') : (slug + '/');

      const seasons = [];
      const saisonRe = /\{"id":"([0-9.]+)","name":"([^"]*)"[^}]*?"langToShow":\[([^\]]*)\]\}/g;
      let sm;
      while ((sm = saisonRe.exec(window2)) !== null) {
        const langs = sm[3].split(',').map((l) => l.replace(/["\s]/g, '')).filter(Boolean);
        seasons.push({ id: sm[1], name: decodeHtml(sm[2]), langs: langs.length ? langs : ['vostfr'] });
      }
      if (!seasons.length) {
        seasons.push({ id: '1', name: 'Saison 1', langs: ['vostfr', 'vf'] });
      }

      const episodes = [];
      let globalNumber = 0;

      for (const season of seasons.slice(0, 25)) {
        let vostPlayers = [];
        let vfPlayers = [];

        try {
          const jsVost = await requestText(SITE + '/api/episodes-script?url=' + encodeURIComponent(scriptBase + 'saison' + season.id + '/vostfr/episodes.js'));
          if (jsVost.ok) vostPlayers = parseEpisodesJs(jsVost.text);
        } catch (_) {}

        try {
          const jsVf = await requestText(SITE + '/api/episodes-script?url=' + encodeURIComponent(scriptBase + 'saison' + season.id + '/vf/episodes.js'));
          if (jsVf.ok) vfPlayers = parseEpisodesJs(jsVf.text);
        } catch (_) {}

        const vostCount = vostPlayers.reduce((max, arr) => Math.max(max, arr.length), 0);
        const vfCount = vfPlayers.reduce((max, arr) => Math.max(max, arr.length), 0);
        const maxLen = Math.max(vostCount, vfCount);
        if (!maxLen) continue;

        for (let i = 0; i < maxLen; i++) {
          globalNumber += 1;
          const subCandidates = [];
          for (const playerArr of vostPlayers) {
            if (playerArr[i]) subCandidates.push(playerArr[i]);
          }
          const dubCandidates = [];
          for (const playerArr of vfPlayers) {
            if (playerArr[i]) dubCandidates.push(playerArr[i]);
          }

          episodes.push({
            number: globalNumber,
            title: '\u00c9pisode ' + globalNumber + (seasons.length > 1 ? ' (S' + season.id + ')' : ''),
            href: 'mugi-dual:' + JSON.stringify({
              sub: sortMirrorsSibnetFirst(subCandidates),
              dub: sortMirrorsSibnetFirst(dubCandidates),
            }),
            subAvailable: subCandidates.length > 0,
            dubAvailable: dubCandidates.length > 0,
            image: '',
          });
          if (episodes.length >= MAX_EPISODES_CAP) break;
        }
        if (episodes.length >= MAX_EPISODES_CAP) break;
      }

      if (episodes.length) {
        log('script seasons parsed: ' + episodes.length + ' episodes for ' + slug);
        return episodes;
      }
    }

    // --- CASE 3: Films & Anime Movies (Her Blue Sky, Your Name, Look Back, etc.) ---
    if (!html.includes('FILM_OPTIONS')) {
      const filmRes = await requestText(SITE + '/catalogue/' + slug + '/films');
      if (filmRes.ok) html = filmRes.text;
    }

    const filmOpts = extractJsonObjects(html, 'FILM_OPTIONS');
    if (filmOpts && filmOpts.lang) {
      const vfMirrors = Array.isArray(filmOpts.lang.vf) ? filmOpts.lang.vf : [];
      const vostMirrors = Array.isArray(filmOpts.lang.vostfr) ? filmOpts.lang.vostfr : [];
      const vostCount = vostMirrors.reduce((max, arr) => Math.max(max, (arr || []).length), 0);
      const vfCount = vfMirrors.reduce((max, arr) => Math.max(max, (arr || []).length), 0);
      const maxFilms = Math.max(1, Math.max(vostCount, vfCount));
      const episodes = [];

      for (let i = 0; i < maxFilms; i++) {
        const subCandidates = [];
        for (const mirrorArr of vostMirrors) {
          if (mirrorArr && mirrorArr[i]) subCandidates.push(mirrorArr[i]);
        }
        const dubCandidates = [];
        for (const mirrorArr of vfMirrors) {
          if (mirrorArr && mirrorArr[i]) dubCandidates.push(mirrorArr[i]);
        }
        const filmName = filmOpts.names && filmOpts.names[i] && filmOpts.names[i].name ? filmOpts.names[i].name : '';

        episodes.push({
          number: i + 1,
          title: 'Film ' + (i + 1) + (filmName ? ' - ' + filmName : ''),
          href: 'mugi-dual:' + JSON.stringify({
            sub: sortMirrorsSibnetFirst(subCandidates),
            dub: sortMirrorsSibnetFirst(dubCandidates),
          }),
          subAvailable: subCandidates.length > 0,
          dubAvailable: dubCandidates.length > 0,
          image: '',
        });
      }
      if (episodes.length) {
        log('films parsed: ' + episodes.length + ' films for ' + slug);
        return episodes;
      }
    }

    throw new Error('Mugiwara: no episodes or films found for ' + slug);
  }

  // ---------- stream resolution ----------

  async function resolveSibnetMp4(videoId) {
    const shellUrl = SIBNET + '/shell.php?videoid=' + videoId;
    const page = await requestText(shellUrl, { Referer: SITE + '/' });
    if (!page.ok) throw new Error('Mugiwara: Sibnet shell request failed (HTTP ' + page.status + ')');

    const m = page.text.match(/"(\/v\/[a-zA-Z0-9_\/-]+\.mp4)"/)
      || page.text.match(/'(\/v\/[a-zA-Z0-9_\/-]+\.mp4)'/)
      || page.text.match(/src:\s*"(\/v\/[^"]+\.mp4)"/);
    if (!m) throw new Error('Mugiwara: Sibnet stream unavailable or removed for video ' + videoId);

    const relativePath = m[1];
    const frontRouterUrl = SIBNET + relativePath;

    let directCdnUrl = frontRouterUrl;
    let probeHeaders = {
      'User-Agent': USER_AGENT,
      Referer: shellUrl,
      Origin: SIBNET,
      Range: 'bytes=0-1',
    };

    if (typeof fetchv2 === 'function') {
      try {
        const probeRes = await fetchv2(frontRouterUrl, probeHeaders, 'GET', null, { followRedirects: false });
        const location = probeRes && probeRes.headers && (probeRes.headers.location || probeRes.headers.Location);
        if (location && /^https?:\/\//i.test(location)) {
          directCdnUrl = location;
        }
      } catch (_) {}
    } else if (typeof fetch === 'function') {
      try {
        const probeRes = await fetch(frontRouterUrl, {
          method: 'GET',
          headers: probeHeaders,
          redirect: 'manual',
        });
        const location = probeRes.headers.get('location');
        if (location && /^https?:\/\//i.test(location)) {
          directCdnUrl = location;
        }
      } catch (_) {}
    }

    const authorizedHeaders = {
      'User-Agent': USER_AGENT,
      Referer: shellUrl,
      Origin: SIBNET,
    };

    return {
      url: directCdnUrl,
      headers: authorizedHeaders,
      streamType: 'mp4',
      quality: '1080p',
      streams: [
        { label: 'Direct HD (Sibnet)', url: directCdnUrl, headers: authorizedHeaders },
      ],
      qualities: [
        { label: '1080p', url: directCdnUrl, headers: authorizedHeaders },
      ],
    };
  }

  async function resolveSingleCandidate(targetUrl) {
    if (!targetUrl) throw new Error('Empty candidate URL');
    if (targetUrl.startsWith('mugi-sibnet:')) {
      const vid = targetUrl.slice('mugi-sibnet:'.length);
      return await resolveSibnetMp4(vid);
    }
    if (targetUrl.includes('sibnet.ru')) {
      const vid = sibnetVideoId(targetUrl);
      if (vid) return await resolveSibnetMp4(vid);
    }
    if (targetUrl.startsWith('mugi-embed:')) {
      targetUrl = targetUrl.slice('mugi-embed:'.length);
    }
    if (/^https?:\/\//i.test(targetUrl)) {
      return {
        url: targetUrl,
        headers: { 'User-Agent': USER_AGENT, Referer: SITE + '/' },
        streamType: 'mp4',
        quality: 'Auto',
        streams: [{ label: 'Web Stream', url: targetUrl, headers: { 'User-Agent': USER_AGENT, Referer: SITE + '/' } }],
        qualities: [{ label: 'Auto', url: targetUrl, headers: { 'User-Agent': USER_AGENT, Referer: SITE + '/' } }],
      };
    }
    throw new Error('Unsupported URL format ' + targetUrl);
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw) throw new Error('Mugiwara: extractStreamUrl received empty href');

    let candidates = [];
    if (raw.startsWith('mugi-dual:')) {
      const jsonBlob = raw.slice('mugi-dual:'.length);
      let parsed = null;
      try { parsed = JSON.parse(jsonBlob); } catch (_) {}
      if (parsed) {
        const isDub = String(lang || '').toLowerCase() === 'dub';
        const primary = isDub ? (parsed.dub || []) : (parsed.sub || []);
        const fallback = isDub ? (parsed.sub || []) : (parsed.dub || []);

        const toList = (x) => Array.isArray(x) ? x : (x ? [x] : []);
        candidates = toList(primary);
        if (!candidates.length) candidates = toList(fallback);
      }
    } else {
      candidates = [raw];
    }

    if (!candidates.length) {
      throw new Error('Mugiwara: requested ' + String(lang || 'sub').toUpperCase() + ' stream is not available for this episode');
    }

    let lastError = null;
    for (const cand of candidates) {
      try {
        const res = await resolveSingleCandidate(cand);
        if (res && res.url) return res;
      } catch (err) {
        lastError = err;
        log('Candidate ' + cand + ' failed (' + (err && err.message) + '), trying fallback mirror...');
      }
    }

    throw new Error('Mugiwara: all stream mirrors failed. Last error: ' + (lastError ? lastError.message : 'unknown'));
  }

  // ---------- discovery ----------

  async function discoveryHome() {
    const items = await fetchCatalogue();
    const byCat = {};
    for (const item of items) {
      const cat = item.category || 'Catalogue';
      (byCat[cat] = byCat[cat] || []).push(item);
    }

    const popularTitles = ['one-piece', 'solo-leveling', 'bleach', 'lattaque-des-titans', 'naruto-shippuden', 'chainsaw-man', 'dan-da-dan', 'jujutsu-kaisen'];
    const heroItems = [];
    for (const slug of popularTitles) {
      const found = items.find((i) => i.slug === slug);
      if (found) heroItems.push(found);
    }
    if (heroItems.length < 5) {
      for (const item of items.slice(0, 8)) {
        if (!heroItems.includes(item)) heroItems.push(item);
      }
    }

    const filmItems = items.filter((i) => (i.disponibles || []).includes('Films') || (i.category || '').toLowerCase().includes('film'));

    const sections = [];

    // 1. Hero Featured Carousel
    sections.push({
      id: 'featured_trending',
      title: '\u00c0 l\x27affiche (Tendances VOSTFR & VF)',
      style: 'hero',
      viewAll: { mode: 'feed', feedId: 'featured' },
      items: heroItems.slice(0, 8).map((i) => ({
        href: SITE + '/catalogue/' + i.slug,
        id: i.slug,
        title: i.title,
        image: i.image,
        poster: i.image,
      })),
    });

    // 2. Top 10 Popular
    const top10 = items.slice(0, 10);
    sections.push({
      id: 'top10_populaires',
      title: 'Top 10 Animes Populaires',
      style: 'top10',
      viewAll: { mode: 'feed', feedId: 'top10' },
      items: top10.map((i) => ({
        href: SITE + '/catalogue/' + i.slug,
        id: i.slug,
        title: i.title,
        image: i.image,
        poster: i.image,
      })),
    });

    // 3. Films d'Animation
    if (filmItems.length) {
      sections.push({
        id: 'films_animation',
        title: 'Films d\x27Animation & Longs-m\u00e9trages',
        style: 'poster',
        viewAll: { mode: 'feed', feedId: 'films' },
        items: filmItems.slice(0, 24).map((i) => ({
          href: SITE + '/catalogue/' + i.slug,
          id: i.slug,
          title: i.title,
          image: i.image,
          poster: i.image,
        })),
      });
    }

    // 4. Categorized Discovery Sections
    const cats = Object.keys(byCat).sort((a, b) => b.length - a.length);
    for (const cat of cats.slice(0, 5)) {
      if (cat === 'Catalogue') continue;
      const cleanId = 'cat_' + cat.toLowerCase().replace(/[^a-z0-9_-]+/g, '_').slice(0, 40);
      sections.push({
        id: cleanId,
        title: cat,
        style: 'poster',
        viewAll: { mode: 'feed', feedId: cat },
        items: byCat[cat].slice(0, 24).map((i) => ({
          href: SITE + '/catalogue/' + i.slug,
          id: i.slug,
          title: i.title,
          image: i.image,
          poster: i.image,
        })),
      });
    }

    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const items = await fetchCatalogue();
    const target = String(feedId || '').toLowerCase();

    let filtered = items;
    if (target === 'films') {
      filtered = items.filter((i) => (i.disponibles || []).includes('Films') || (i.category || '').toLowerCase().includes('film'));
    } else if (target === 'top10' || target === 'featured') {
      filtered = items;
    } else if (target) {
      const match = items.filter((i) => (i.category || '').toLowerCase() === target);
      if (match.length) filtered = match;
    }

    const pageSize = 24;
    const offset = (pageNumber - 1) * pageSize;
    const slice = filtered.slice(offset, offset + pageSize);

    return {
      items: slice.map((i) => ({
        href: SITE + '/catalogue/' + i.slug,
        id: i.slug,
        title: i.title,
        image: i.image,
        poster: i.image,
      })),
      page: pageNumber,
      hasMore: offset + slice.length < filtered.length,
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
