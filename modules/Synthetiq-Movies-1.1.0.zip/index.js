(() => {
  'use strict';

  const TMDB = 'https://api.themoviedb.org/3';
  const TMDB_KEY = 'e1a8efff4415028c5c266b3fcd50db6e';
  const IMAGE = 'https://image.tmdb.org/t/p';
  const MOVIES_BACKENDS = [
    'https://198.244.149.250.sslip.io/movies/resolve',
  ];
  const USER_AGENT =
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15';
  const detailsCache = Object.create(null);
  const seasonCache = Object.create(null);
  const seasonInflight = Object.create(null);

  async function readBody(response) {
    if (!response) return '';
    if (typeof response.body === 'string' && response.body.length) return response.body;
    if (response.json && typeof response.json !== 'function') {
      try { return JSON.stringify(response.json); } catch (_) {}
    }
    if (typeof response.text === 'function') {
      try {
        const text = await response.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof response.json === 'function') {
      try { return JSON.stringify(await response.json()); } catch (_) {}
    }
    return '';
  }

  async function requestJson(path) {
    const url = TMDB + path + (path.indexOf('?') >= 0 ? '&' : '?') +
      'api_key=' + encodeURIComponent(TMDB_KEY) + '&language=en-US';
    const headers = {
      Accept: 'application/json,*/*',
      'User-Agent': USER_AGENT,
      Referer: 'https://www.themoviedb.org/',
    };
    let response;
    if (typeof fetchv2 === 'function') response = await fetchv2(url, headers, 'GET', null);
    else if (typeof fetch === 'function') response = await fetch(url, { headers });
    else throw new Error('No fetch available');
    const status = Number((response && response.status) || 0);
    if (status && (status < 200 || status >= 400)) throw new Error('tmdb_http_' + status);
    const body = await readBody(response);
    if (!body) return null;
    try { return JSON.parse(body); } catch (_) { return null; }
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function twoDigits(value) {
    const text = String(value);
    return text.length < 2 ? '0' + text : text;
  }

  function todayStamp() {
    const date = new Date();
    return date.getFullYear() + '-' + twoDigits(date.getMonth() + 1) + '-' + twoDigits(date.getDate());
  }

  function hasAired(airDate) {
    const stamp = String(airDate || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(stamp)) return true;
    return stamp <= todayStamp();
  }

  function withTimeout(promise, ms, fallback) {
    if (typeof setTimeout !== 'function') return promise;
    let timer = null;
    const timeout = new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallback), Math.max(1, Number(ms) || 0));
    });
    return Promise.race([promise, timeout]).then((value) => {
      if (timer && typeof clearTimeout === 'function') clearTimeout(timer);
      return value;
    }, (error) => {
      if (timer && typeof clearTimeout === 'function') clearTimeout(timer);
      throw error;
    });
  }

  function poster(path, size) {
    if (!path) return '';
    if (/^https?:\/\//i.test(String(path))) return String(path);
    return IMAGE + '/' + (size || 'w500') + (String(path).charAt(0) === '/' ? path : '/' + path);
  }

  function href(type, id, season, episode) {
    let out = 'https://www.themoviedb.org/' + type + '/' + id;
    if (type === 'tv' && season != null && episode != null) {
      out += '?season=' + Number(season) + '&episode=' + Number(episode);
    }
    return out;
  }

  function parseHref(value) {
    const raw = String(value || '').trim();
    let match = raw.match(/themoviedb\.org\/(movie|tv)\/(\d+)(?:\?[^#]*season=(\d+)&episode=(\d+))?/i);
    if (!match) match = raw.match(/^(movie|tv):(\d+)(?::(\d+):(\d+))?$/i);
    if (!match) return null;
    return {
      type: match[1].toLowerCase(),
      id: match[2],
      season: match[3] ? Number(match[3]) : null,
      episode: match[4] ? Number(match[4]) : null,
    };
  }

  function mapItem(row, forcedType) {
    if (!row) return null;
    const type = String(forcedType || row.media_type || '').toLowerCase();
    if (type !== 'movie' && type !== 'tv') return null;
    if (row.adult === true) return null;
    const id = Number(row.id);
    const title = clean(row.title || row.name || row.original_title || row.original_name);
    if (!id || !title) return null;
    const year = String(row.release_date || row.first_air_date || '').slice(0, 4);
    const image = poster(row.poster_path || row.backdrop_path);
    return {
      id: href(type, id),
      href: href(type, id),
      title: title + (year ? ' (' + year + ')' : ''),
      image,
      poster: image,
      type,
      mediaType: type,
      year: year || undefined,
    };
  }

  async function searchResults(query, page) {
    const q = clean(query);
    const pageNumber = Math.max(1, Number(page || 0) + 1);
    const path = q
      ? '/search/multi?query=' + encodeURIComponent(q) +
          '&include_adult=false&page=' + pageNumber
      : '/trending/all/week?page=' + pageNumber;
    const data = await withTimeout(requestJson(path), 8000, null).catch(() => null);
    return ((data && data.results) || []).map((row) => mapItem(row)).filter(Boolean).slice(0, 40);
  }

  async function catalogue(type, path, page) {
    const data = await withTimeout(
      requestJson('/' + type + '/' + path + '?page=' + Math.max(1, Number(page) || 1)),
      8000,
      null,
    ).catch(() => null);
    return {
      items: ((data && data.results) || []).map((row) => mapItem(row, type)).filter(Boolean),
      page: Math.max(1, Number(page) || 1),
      hasMore: Math.max(1, Number(page) || 1) < Number((data && data.total_pages) || 1),
    };
  }

  async function discoveryHome() {
    const [trending, movies, tv] = await Promise.all([
      withTimeout(requestJson('/trending/all/week?page=1'), 8000, null).catch(() => null),
      catalogue('movie', 'popular', 1),
      catalogue('tv', 'popular', 1),
    ]);
    const trendItems = ((trending && trending.results) || [])
      .map((row) => mapItem(row)).filter(Boolean);
    return {
      sections: [
        { id: 'trending', title: 'Trending', style: 'hero', items: trendItems.slice(0, 10), viewAll: { mode: 'feed', feedId: 'trending' } },
        { id: 'movies', title: 'Popular Movies', style: 'poster', items: movies.items.slice(0, 20), viewAll: { mode: 'feed', feedId: 'movies' } },
        { id: 'tv', title: 'Popular TV', style: 'poster', items: tv.items.slice(0, 20), viewAll: { mode: 'feed', feedId: 'tv' } },
      ],
    };
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    if (feedId === 'movies') return catalogue('movie', 'popular', pageNumber);
    if (feedId === 'tv') return catalogue('tv', 'popular', pageNumber);
    const data = await withTimeout(
      requestJson('/trending/all/week?page=' + pageNumber),
      8000,
      null,
    ).catch(() => null);
    return {
      items: ((data && data.results) || []).map((row) => mapItem(row)).filter(Boolean),
      page: pageNumber,
      hasMore: pageNumber < Number((data && data.total_pages) || 1),
    };
  }

  async function extractDetails(value) {
    const parsed = parseHref(value);
    if (!parsed) return { title: 'Unknown title', description: 'Unable to resolve this title.' };
    const key = parsed.type + ':' + parsed.id;
    if (detailsCache[key]) return detailsCache[key];
    const data = await requestJson('/' + parsed.type + '/' + parsed.id);
    if (!data) return { title: 'Unknown title', description: 'Metadata is unavailable.' };
    const title = clean(data.title || data.name) || 'Unknown title';
    const image = poster(data.poster_path || data.backdrop_path);
    const seasons = parsed.type === 'tv'
      ? (data.seasons || []).map((row) => {
          const number = Number(row && row.season_number);
          if (!number || number < 1) return 0;
          if (!hasAired(row && row.air_date) && Number(row.episode_count || 0) === 0) return 0;
          return number;
        }).filter((n) => n > 0)
      : [];
    const result = {
      id: href(parsed.type, parsed.id),
      href: href(parsed.type, parsed.id),
      url: href(parsed.type, parsed.id),
      title,
      description: clean(data.overview) || 'No description available.',
      image,
      poster: image,
      banner: poster(data.backdrop_path, 'w1280') || image,
      genres: (data.genres || []).map((row) => row && row.name).filter(Boolean),
      rating: data.vote_average == null ? '' : Number(data.vote_average).toFixed(1),
      year: String(data.release_date || data.first_air_date || '').slice(0, 4),
      type: parsed.type,
      mediaType: parsed.type,
      seasonNumbers: seasons,
      seasons: seasons.length,
      isMovie: parsed.type === 'movie',
    };
    detailsCache[key] = result;
    if (parsed.type === 'tv' && seasons.length) {
      loadSeasons(parsed.id, seasons, image).catch(() => {});
    }
    return result;
  }

  function mapSeasonEpisodes(tmdbId, season, data, fallbackImage) {
    return ((data && data.episodes) || []).map((row) => {
      const episode = Number(row && row.episode_number);
      if (!episode || !hasAired(row && row.air_date)) return null;
      return {
        number: episode,
        episodeNumber: episode,
        season,
        seasonNumber: season,
        title: 'S' + season + 'E' + episode + ' - ' + (clean(row.name) || 'Episode ' + episode),
        href: href('tv', tmdbId, season, episode),
        image: poster(row.still_path, 'w300') || fallbackImage || '',
        airDate: String((row && row.air_date) || '').slice(0, 10),
        subAvailable: true,
      };
    }).filter(Boolean);
  }

  function collectedEpisodes(tmdbId, seasonNumbers) {
    const episodes = [];
    seasonNumbers.forEach((season) => {
      const rows = seasonCache[tmdbId + ':' + season] || [];
      rows.forEach((row) => episodes.push(row));
    });
    return episodes;
  }

  async function loadSeasons(tmdbId, seasonNumbers, fallbackImage) {
    const missing = seasonNumbers.filter((season) => !seasonCache[tmdbId + ':' + season]);
    if (!missing.length) return collectedEpisodes(tmdbId, seasonNumbers);
    const inflightKey = tmdbId + ':' + missing.join(',');
    if (!seasonInflight[inflightKey]) {
      seasonInflight[inflightKey] = (async () => {
        for (let offset = 0; offset < missing.length; offset += 12) {
          const batch = missing.slice(offset, offset + 12);
          const append = batch.map((season) => 'season/' + season).join(',');
          const data = await requestJson('/tv/' + tmdbId + '?append_to_response=' + append);
          const needFallback = [];
          batch.forEach((season) => {
            const block = data && (data['season/' + season] || data['season_' + season]);
            if (block && Array.isArray(block.episodes)) {
              seasonCache[tmdbId + ':' + season] = mapSeasonEpisodes(
                tmdbId, season, block, fallbackImage,
              );
            } else {
              needFallback.push(season);
            }
          });
          if (needFallback.length) {
            const pages = await Promise.all(needFallback.map((season) =>
              requestJson('/tv/' + tmdbId + '/season/' + season).catch(() => null),
            ));
            needFallback.forEach((season, index) => {
              seasonCache[tmdbId + ':' + season] = mapSeasonEpisodes(
                tmdbId, season, pages[index], fallbackImage,
              );
            });
          }
        }
      })();
    }
    try {
      await seasonInflight[inflightKey];
    } finally {
      delete seasonInflight[inflightKey];
    }
    return collectedEpisodes(tmdbId, seasonNumbers);
  }

  async function extractEpisodes(value) {
    const parsed = parseHref(value);
    if (!parsed) return [];
    const details = await extractDetails(value);
    if (parsed.type === 'movie') {
      return [{
        number: 1,
        episodeNumber: 1,
        season: 1,
        seasonNumber: 1,
        title: details.title,
        href: href('movie', parsed.id),
        image: details.image || '',
        isMovie: true,
        mediaType: 'movie',
        subAvailable: true,
      }];
    }
    const seasons = details.seasonNumbers && details.seasonNumbers.length
      ? details.seasonNumbers : [1];
    const episodes = await loadSeasons(parsed.id, seasons, details.image || '');
    episodes.sort((a, b) => a.season - b.season || a.episodeNumber - b.episodeNumber);
    episodes.forEach((row, index) => { row.number = index + 1; });
    return episodes;
  }

  function packBackendStream(resolved) {
    if (!resolved || !resolved.url) return null;
    return {
      url: resolved.url,
      streams: [{
        url: resolved.url,
        headers: resolved.headers || {},
        streamType: resolved.type || 'hls',
        label: resolved.provider || 'Synthetiq Movies',
      }],
      headers: resolved.headers || {},
      streamType: resolved.type || 'hls',
      quality: '1080p',
      lang: 'sub',
      subtitles: [],
    };
  }

  async function postBackend(url, parsed, lang) {
    const response = await fetchv2(
      url,
      { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': USER_AGENT },
      'POST',
      JSON.stringify({
        type: parsed.type,
        tmdbId: parsed.id,
        season: parsed.season || 1,
        episode: parsed.episode || 1,
        lang: String(lang || 'sub'),
      }),
    );
    const body = await readBody(response);
    if (!body) return null;
    try { return JSON.parse(body); } catch (_) { return null; }
  }

  async function resolveFromLocalBackend(parsed, lang) {
    if (typeof fetchv2 !== 'function') return { reached: false };
    return await new Promise((done) => {
      let pending = MOVIES_BACKENDS.length;
      let finished = false;
      MOVIES_BACKENDS.forEach((url) => {
        postBackend(url, parsed, lang).then((data) => {
          if (finished) return;
          if (data && data.ok && data.url) {
            finished = true;
            done({ reached: true, stream: packBackendStream(data) });
            return;
          }
          if (data && Object.prototype.hasOwnProperty.call(data, 'ok')) {
            finished = true;
            done({ reached: true, error: data.error || 'no_verified_video_stream' });
            return;
          }
          pending -= 1;
          if (pending <= 0) done({ reached: false });
        }).catch(() => {
          if (finished) return;
          pending -= 1;
          if (pending <= 0) done({ reached: false });
        });
      });
    });
  }

  async function extractStreamUrl(episodeId, lang) {
    const parsed = parseHref(episodeId);
    if (!parsed) return { streams: [], subtitles: [], error: { message: 'Invalid episode.' } };
    try {
      const local = await resolveFromLocalBackend(parsed, lang);
      if (local && local.stream) return local.stream;
      if (local && local.reached) {
        return {
          streams: [],
          subtitles: [],
          error: { message: 'This episode is not available from the movies backend yet.' },
        };
      }
    } catch (_) {}
    if (typeof globalThis.__resolveViaBackend === 'function') {
      try {
        let resolved = await globalThis.__resolveViaBackend(
          'synthetiq-movies-v1',
          'stream',
          JSON.stringify({
            episodeId: String(episodeId),
            type: parsed.type,
            tmdbId: parsed.id,
            season: parsed.season || 1,
            episode: parsed.episode || 1,
            lang: String(lang || 'sub'),
          }),
        );
        if (typeof resolved === 'string') {
          try { resolved = JSON.parse(resolved); } catch (_) {}
        }
        if (resolved && resolved._resolverError === 'service_limit_exceeded') {
          return { streams: [], subtitles: [], error: { message: 'Hourly fallback limit reached. Try again later.' } };
        }
        if (resolved && resolved.url) return packBackendStream(resolved);
        if (resolved && Array.isArray(resolved.streams) && resolved.streams.length) return resolved;
      } catch (_) {}
    }
    return { streams: [], subtitles: [], error: { message: 'No verified video source is available right now.' } };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
