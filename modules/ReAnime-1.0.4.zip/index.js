(() => {
  'use strict';

  const MODULE_NAME = 'Re:ANIME';
  const BASE_URL = 'https://reanime.to';
  const FLIX_URL = 'https://flixcloud.cc';
  const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(message) {
    try {
      if (typeof debugPrint === 'function') debugPrint('[' + MODULE_NAME + '] ' + String(message || ''));
      else console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function decodeHtml(text) {
    return String(text || '')
      .replace(/&#0?39;|&#x27;|&apos;/g, "'")
      .replace(/&#8217;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .trim();
  }

  function encodeUtf8(str) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
    const utf8 = unescape(encodeURIComponent(str));
    const arr = new Uint8Array(utf8.length);
    for (let i = 0; i < utf8.length; i++) arr[i] = utf8.charCodeAt(i);
    return arr;
  }

  function decodeUtf8(bytes) {
    if (typeof TextDecoder !== 'undefined') return new TextDecoder().decode(bytes);
    let str = '';
    for (let i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(str)); } catch (_) { return str; }
  }

  // ---------- HTTP bridge ----------

  async function requestJson(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'application/json',
      Referer: BASE_URL + '/',
    }, extraHeaders || {});

    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }

    const status = Number((res && res.status) || 0);
    if (status < 200 || status >= 400) {
      throw new Error('ReAnime: request failed (HTTP ' + status + ') for ' + url);
    }

    if (res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j !== null && j !== undefined) return j;
      } catch (_) {}
    }
    if (res && res.json && typeof res.json === 'object') return res.json;

    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;

    if (text) {
      try { return JSON.parse(text); } catch (_) {}
    }
    throw new Error('ReAnime: response from ' + url + ' was not valid JSON');
  }

  async function requestText(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      Referer: BASE_URL + '/',
    }, extraHeaders || {});

    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }

    const status = Number((res && res.status) || 0);
    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;
    if (!text && res && typeof res.json === 'function') {
      try { const j = await res.json(); if (j) text = JSON.stringify(j); } catch (_) {}
    } else if (!text && res && res.json && typeof res.json === 'object') {
      text = JSON.stringify(res.json);
    }
    return { status, ok: status >= 200 && status < 400, text: text || '' };
  }

  // ---------- search ----------

  async function searchResults(query) {
    const q = String(query || '').trim();
    const url = BASE_URL + '/api/v1/search?' + (q ? 'q=' + encodeURIComponent(q) : 'q=*');
    const data = await requestJson(url);
    const results = (data && data.results) || [];

    return results.map((item) => {
      const title = (item.title && (item.title.english || item.title.user_preferred || item.title.romaji)) || item.anime_id || 'Anime';
      const poster = (item.cover_image && (item.cover_image.extra_large || item.cover_image.large || item.cover_image.medium)) || '';
      return {
        id: item.anime_id,
        href: BASE_URL + '/watch/' + item.anime_id,
        title: title,
        image: poster,
      };
    });
  }

  // ---------- helper to resolve slug ----------

  async function resolveAnimeId(rawSlug) {
    let slug = String(rawSlug || '').trim();
    if (/^https?:\/\//i.test(slug)) {
      const m = slug.match(/\/watch\/([^/?#]+)/i) || slug.match(/\/anime\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?watch\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error('ReAnime: empty anime slug');

    // Try direct fetch
    try {
      const direct = await requestJson(BASE_URL + '/api/v1/anime/' + slug);
      if (direct && (direct.anime_id || direct.anilist_id)) return { slug: direct.anime_id || slug, data: direct };
    } catch (_) {}

    // Fallback: search for slug
    const searchRes = await searchResults(slug.replace(/[-_]+/g, ' '));
    if (searchRes.length) {
      const foundSlug = searchRes[0].id;
      const data = await requestJson(BASE_URL + '/api/v1/anime/' + foundSlug);
      return { slug: foundSlug, data: data };
    }

    throw new Error('ReAnime: unable to resolve anime for ' + rawSlug);
  }

  // ---------- details ----------

  async function extractDetails(urlOrId) {
    const { slug, data } = await resolveAnimeId(urlOrId);
    const title = (data.title && (data.title.english || data.title.user_preferred || data.title.romaji)) || data.anime_id || slug;
    const poster = (data.cover_image && (data.cover_image.extra_large || data.cover_image.large || data.cover_image.medium)) || '';
    const banner = (data.artworks && data.artworks.find((a) => a.image_type === 'background') && data.artworks.find((a) => a.image_type === 'background').url) || data.banner_image || poster;

    return {
      id: data.anime_id || slug,
      href: BASE_URL + '/watch/' + (data.anime_id || slug),
      title: title,
      description: data.description ? decodeHtml(data.description.replace(/<[^>]*>/g, '')) : 'Watch on Re:ANIME',
      image: poster,
      poster: poster,
      banner: banner,
      genres: Array.isArray(data.genres) ? data.genres : [],
      anilistId: data.anilist_id || 0,
      totalEpisodes: data.episodes_total || 0,
    };
  }

  // ---------- episodes ----------

  async function extractEpisodes(seriesId) {
    const { slug, data: animeData } = await resolveAnimeId(seriesId);
    const anilistId = animeData.anilist_id || 0;

    // Fetch episodes list
    const epData = await requestJson(BASE_URL + '/api/v1/anime/' + slug + '/episodes');
    const rawEpisodes = (epData && epData.data) || [];

    const episodes = [];
    for (let i = 0; i < rawEpisodes.length; i++) {
      const ep = rawEpisodes[i];
      const epNum = ep.episode_number || (i + 1);
      const title = ep.title ? `Episode ${epNum}: ${ep.title}` : `Episode ${epNum}`;

      episodes.push({
        number: epNum,
        title: title,
        href: `reanime-stream:${JSON.stringify({ anilist: anilistId, slug: slug, ep: epNum })}`,
        subAvailable: ep.subbed !== false,
        dubAvailable: ep.dubbed === true,
        image: ep.thumbnail || '',
      });
    }

    return episodes;
  }

  // ---------- flixcloud stream decryption ----------

  function base64ToUint8(base64Str) {
    if (typeof Buffer !== 'undefined') {
      return new Uint8Array(Buffer.from(base64Str, 'base64'));
    }
    const binary = atob(base64Str);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function getCryptoSubtle() {
    if (typeof crypto !== 'undefined' && crypto) {
      if (crypto.subtle) return crypto.subtle;
      if (crypto.webcrypto && crypto.webcrypto.subtle) return crypto.webcrypto.subtle;
    }
    if (typeof globalThis !== 'undefined' && globalThis.crypto) {
      if (globalThis.crypto.subtle) return globalThis.crypto.subtle;
      if (globalThis.crypto.webcrypto && globalThis.crypto.webcrypto.subtle) return globalThis.crypto.webcrypto.subtle;
    }
    try {
      if (typeof require === 'function') {
        const nodeCrypto = require('crypto');
        if (nodeCrypto.webcrypto && nodeCrypto.webcrypto.subtle) return nodeCrypto.webcrypto.subtle;
      }
    } catch (_) {}
    throw new Error('WebCrypto subtle is required for stream decryption');
  }

  async function computeSha256Hex(str) {
    const enc = encodeUtf8(str);
    const subtle = await getCryptoSubtle();
    const digest = await subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async function deriveFields(seed) {
    let e = seed;
    for (let i = 0; i < 3; i++) e = await computeSha256Hex(e + i.toString());
    let a = e;
    for (let i = 0; i < 3; i++) a = await computeSha256Hex(a + i.toString());
    return {
      videoField: `vf_${e.substring(0, 8)}`,
      keyField: `kf_${e.substring(8, 16)}`,
      ivField: `ivf_${e.substring(16, 24)}`,
      containerName: `cd_${e.substring(24, 32)}`,
      arrayName: `ad_${e.substring(32, 40)}`,
      objectName: `od_${e.substring(40, 48)}`,
      tokenField: `${e.substring(48, 64)}_${e.substring(56, 64)}`,
      keyFrag2Field: `${a.substring(0, 16)}_${a.substring(16, 24)}`,
    };
  }

  async function executeWasmPayload(t, e, a, o, wasmPayloadB64) {
    const wasmBytes = base64ToUint8(wasmPayloadB64);
    const wasmInst = await WebAssembly.instantiate(wasmBytes, {});
    const exports = wasmInst.instance ? wasmInst.instance.exports : wasmInst.exports;
    const mem = exports.memory;
    if (mem.buffer.byteLength === 0) mem.grow(1);
    const memView = new Uint8Array(mem.buffer);

    const k = t.length;
    const I = 1000;
    const P = I + k;
    const U = P + k;
    const nt = U + k;

    memView.set(t, I);
    memView.set(e, P);
    memView.set(a, U);
    exports._s(o);
    exports._r(I, P, U, nt, k);

    const out = new Uint8Array(k);
    out.set(memView.subarray(nt, nt + k));
    return out;
  }

  async function resolveFlixCloudEmbed(embedUrl) {
    const res = await requestText(embedUrl, { Referer: BASE_URL + '/' });
    const html = res.text;

    const marker = 'data: [null,null,{type:"data",data:';
    const startIdx = html.indexOf(marker);
    if (startIdx < 0) throw new Error('ReAnime: FlixCloud embed payload marker not found');

    const jsonStart = startIdx + marker.length;
    let depth = 0, inStr = false, strCh = '', esc = false, jsonEnd = -1;
    for (let j = jsonStart; j < html.length; j++) {
      const ch = html.charAt(j);
      if (esc) { esc = false; continue; }
      if (inStr) {
        if (ch === '\\') { esc = true; continue; }
        if (ch === strCh) inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { inStr = true; strCh = ch; continue; }
      if (ch === '{') depth += 1;
      else if (ch === '}') {
        depth -= 1;
        if (depth === 0) { jsonEnd = j + 1; break; }
      }
    }

    const rawJson = html.slice(jsonStart, jsonEnd);
    let pageData = null;
    try { pageData = JSON.parse(rawJson); } catch (_) { pageData = (new Function('return ' + rawJson))(); }

    const fields = await deriveFields(pageData.obfuscation_seed);
    const container = pageData.obfuscated_crypto_data && pageData.obfuscated_crypto_data[fields.containerName];
    const arr = container && container[fields.arrayName];
    const obj = arr && arr[0] && arr[0][fields.objectName];
    const frag1B64 = obj && obj[fields.keyField];
    const ivB64 = obj && obj[fields.ivField];
    const frag2B64 = pageData[fields.keyFrag2Field];

    let tokenRef = null;
    for (const [k, v] of Object.entries(pageData)) {
      if (k === fields.tokenField && typeof v === 'string' && v.length > 0) {
        tokenRef = v;
        break;
      }
    }
    if (!tokenRef) throw new Error('ReAnime: token reference not found in FlixCloud embed');

    // Request stream tokens
    const tokenData = await requestJson(FLIX_URL + '/api/m3u8/' + tokenRef, { Referer: embedUrl });
    const vidKey = (await computeSha256Hex(tokenRef + 'vid')).substring(0, 10);
    const encKey = (await computeSha256Hex(tokenRef + 'key')).substring(0, 10);
    const pVal = tokenData[vidKey];
    const uVal = tokenData[encKey];

    const tBytes = base64ToUint8(frag1B64);
    const eBytes = base64ToUint8(frag2B64);
    const aBytes = base64ToUint8(uVal);
    const seedInt = parseInt(pageData.obfuscation_seed.substring(0, 8), 16);

    const wasmOut = await executeWasmPayload(tBytes, eBytes, aBytes, seedInt, pageData.w_payload);

    const subtle = await getCryptoSubtle();
    const pbkdf2Key = await subtle.importKey('raw', wasmOut, { name: 'PBKDF2' }, false, ['deriveBits']);
    const derivedBits = await subtle.deriveBits(
      { name: 'PBKDF2', salt: encodeUtf8(pageData.obfuscation_seed), iterations: 1000, hash: 'SHA-256' },
      pbkdf2Key,
      256
    );

    const xorBytes = new Uint8Array(derivedBits);
    for (let b = 0; b < 32; b++) {
      xorBytes[b] ^= pageData.obfuscation_seed.charCodeAt(b % pageData.obfuscation_seed.length);
    }

    const finalKeyDigest = await subtle.digest('SHA-256', xorBytes);
    const aesKey = await subtle.importKey('raw', new Uint8Array(finalKeyDigest), { name: 'AES-CBC' }, false, ['decrypt']);
    const decrypted = await subtle.decrypt(
      { name: 'AES-CBC', iv: base64ToUint8(ivB64) },
      aesKey,
      base64ToUint8(pVal)
    );

    const streamUrl = decodeUtf8(new Uint8Array(decrypted));

    const headers = {
      'User-Agent': USER_AGENT,
      Referer: FLIX_URL + '/',
      Origin: FLIX_URL,
    };

    return {
      url: streamUrl,
      headers: headers,
      streamType: 'hls',
      quality: 'Auto',
      streams: [
        { label: 'Auto (HLS Master)', url: streamUrl, headers: headers },
      ],
      subtitles: (pageData.subtitles || []).map((sub) => ({
        url: sub.url,
        language: sub.language,
        format: sub.format,
        default: sub.default,
      })),
      chapters: pageData.chapters || [],
    };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw.startsWith('reanime-stream:')) {
      throw new Error('ReAnime: invalid stream href format');
    }

    const payload = JSON.parse(raw.slice('reanime-stream:'.length));
    const targetLang = String(lang || 'sub').toLowerCase();

    // 1. Query Flix server list for the anilist ID & episode number
    const flixRes = await requestJson(BASE_URL + '/api/flix/' + payload.anilist + '/' + payload.ep);
    const servers = (flixRes && flixRes.servers) || [];
    if (!servers.length) throw new Error('ReAnime: no streaming servers found for this episode');

    // Filter by target language, with fallback
    const primary = servers.filter((s) => s.dataType === targetLang);
    const pool = primary.length ? primary : servers;

    let lastError = null;
    for (const server of pool) {
      if (server.dataLink && server.dataLink.includes('flixcloud')) {
        try {
          return await resolveFlixCloudEmbed(server.dataLink);
        } catch (err) {
          lastError = err;
          log('Server ' + server.serverName + ' failed (' + (err && err.message) + '), trying next server...');
        }
      }
    }

    throw new Error('ReAnime: all streaming servers failed. Last error: ' + (lastError ? lastError.message : 'unknown'));
  }

  // ---------- discovery ----------

  async function discoveryHome() {
    const trendingData = await requestJson(BASE_URL + '/api/v1/search?q=*&limit=24');
    const results = (trendingData && trendingData.results) || [];

    const sections = [];

    // 1. Hero Featured Carousel
    sections.push({
      id: 'featured_trending',
      title: 'Featured Anime',
      style: 'hero',
      viewAll: { mode: 'feed', feedId: 'trending' },
      items: results.slice(0, 8).map((item) => ({
        id: item.anime_id,
        href: BASE_URL + '/watch/' + item.anime_id,
        title: (item.title && (item.title.english || item.title.user_preferred || item.title.romaji)) || item.anime_id,
        image: (item.cover_image && (item.cover_image.extra_large || item.cover_image.large)) || '',
      })),
    });

    // 2. Top 10 Popular
    sections.push({
      id: 'top10_popular',
      title: 'Top 10 Popular',
      style: 'top10',
      viewAll: { mode: 'feed', feedId: 'popular' },
      items: results.slice(0, 10).map((item) => ({
        id: item.anime_id,
        href: BASE_URL + '/watch/' + item.anime_id,
        title: (item.title && (item.title.english || item.title.user_preferred || item.title.romaji)) || item.anime_id,
        image: (item.cover_image && (item.cover_image.extra_large || item.cover_image.large)) || '',
      })),
    });

    // 3. Trending Now Grid
    sections.push({
      id: 'trending_now',
      title: 'Trending on Re:ANIME',
      style: 'poster',
      viewAll: { mode: 'feed', feedId: 'trending' },
      items: results.slice(0, 24).map((item) => ({
        id: item.anime_id,
        href: BASE_URL + '/watch/' + item.anime_id,
        title: (item.title && (item.title.english || item.title.user_preferred || item.title.romaji)) || item.anime_id,
        image: (item.cover_image && (item.cover_image.extra_large || item.cover_image.large)) || '',
      })),
    });

    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    const pageNum = Math.max(1, Number(page) || 1);
    const pageSize = 24;
    const offset = (pageNum - 1) * pageSize;
    const data = await requestJson(BASE_URL + '/api/v1/search?q=*&offset=' + offset + '&limit=' + pageSize);
    const results = (data && data.results) || [];

    return {
      items: results.map((item) => ({
        id: item.anime_id,
        href: BASE_URL + '/watch/' + item.anime_id,
        title: (item.title && (item.title.english || item.title.user_preferred || item.title.romaji)) || item.anime_id,
        image: (item.cover_image && (item.cover_image.extra_large || item.cover_image.large)) || '',
      })),
      page: pageNum,
      hasMore: results.length >= pageSize,
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
