(() => {
  'use strict';

  const MODULE_NAME = 'Mugiwara';
  const SITE = 'https://www.mugiwara-no-streaming.com';
  const SIBNET = 'https://video.sibnet.ru';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(message) {
    try { console.log('[' + MODULE_NAME + '] ' + String(message || '')); } catch (_) {}
  }

  function decodeHtml(text) {
    return String(text || '')
      .replace(/&#0?39;|&#x27;|&apos;/g, "'")
      .replace(/&#8217;/g, "'")
      .replace(/&#8211;|&ndash;/g, '-')
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ')
      .trim();
  }

  async function requestJson(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'application/json',
      Referer: SITE + '/',
    }, extraHeaders || {});
    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }
    const status = Number((res && res.status) || 0);
    if (status < 200 || status >= 400) {
      throw new Error('Mugiwara: request failed (HTTP ' + status + ') for ' + url);
    }
    if (res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j) return j;
      } catch (_) {}
    }
    if (res && res.json && typeof res.json === 'object') {
      return res.json;
    }
    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;
    if (text) {
      try { return JSON.parse(text); } catch (_) {}
    }
    throw new Error('Mugiwara: response from ' + url + ' was not valid JSON');
  }

  async function requestText(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      Referer: SITE + '/',
    }, extraHeaders || {});
    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }
    const status = Number((res && res.status) || 0);
    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;
    if (!text && res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j) text = JSON.stringify(j);
      } catch (_) {}
    } else if (!text && res && res.json && typeof res.json === 'object') {
      text = JSON.stringify(res.json);
    }
    return { status: status, ok: status >= 200 && status < 400, text: text || '' };
  }

  // ---------- catalogue ----------

  const catalogueCache = { at: 0, items: [] };

  async function fetchCatalogue() {
    if (catalogueCache.items.length && Date.now() - catalogueCache.at < 10 * 60 * 1000) {
      return catalogueCache.items;
    }
    const data = await requestJson(SITE + '/api/get-catalogues');
    const items = [];
    const seen = new Set();
    for (const cat of ((data && data.catalogues) || [])) {
      for (const entry of (cat.names || [])) {
        const slug = String(entry.slug || '').trim();
        if (!slug || seen.has(slug)) continue;
        seen.add(slug);
        items.push({
          slug: slug,
          title: String(entry.animeName || slug).trim(),
          image: String((entry.data && entry.data.image) || ''),
          category: String(cat.category || ''),
          disponibles: (entry.data && entry.data.disponibles) || [],
        });
      }
    }
    if (!items.length) throw new Error('Mugiwara: catalogue returned no titles (site may have changed)');
    catalogueCache.at = Date.now();
    catalogueCache.items = items;
    return items;
  }

  async function searchResults(query) {
    const term = String(query || '').trim().toLowerCase();
    const items = await fetchCatalogue();
    const mapped = items.map((i) => ({
      href: SITE + '/catalogue/' + i.slug,
      id: i.slug,
      title: i.title,
      image: i.image,
    }));
    if (!term) return mapped.slice(0, 50);
    const norm = (v) => String(v || '').toLowerCase().replace(/[^a-z0-9\u00c0-\u024f]+/g, '');
    const termNorm = norm(term);
    const idNorm = norm(term).replace(/-/g, '');
    return mapped.filter((i) => {
      const t = norm(i.title);
      return t.indexOf(termNorm) >= 0 || norm(i.id).indexOf(idNorm) >= 0;
    });
  }

  // ---------- details ----------

  function extractJsonStrings(html, needle) {
    // Pull the Next.js flight payload region around the needle. The payload is
    // embedded JSON-in-JSON, so quotes arrive backslash-escaped; normalize.
    const idx = html.indexOf(needle);
    if (idx < 0) return '';
    const start = Math.max(0, idx - 4000);
    const raw = html.slice(start, idx + 4000);
    return raw.indexOf('\\"') >= 0 ? raw.replace(/\\"/g, '"') : raw;
  }

  async function extractDetails(urlOrId) {
    let slug = String(urlOrId || '').trim();
    if (/^https?:\/\//i.test(slug)) {
      const m = slug.match(/\/catalogue\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?catalogue\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error('Mugiwara: extractDetails received an empty or foreign URL');

    const items = await fetchCatalogue();
    const known = items.find((i) => i.slug === slug);

    const res = await requestText(SITE + '/catalogue/' + slug + '/episodes');
    if (!res.ok) throw new Error('Mugiwara: details request failed (HTTP ' + res.status + ')');

    const og = (prop) => {
      const needle = 'og:' + prop;
      const tagRe = /<meta\b[^>]*>/gi;
      let tag;
      while ((tag = tagRe.exec(res.text)) !== null) {
        const t = tag[0];
        if (t.indexOf(needle) < 0) continue;
        const c = t.match(/content\s*=\s*"([^"]*)"/i) || t.match(/content\s*=\s*'([^']*)'/i);
        if (c) return decodeHtml(c[1]);
      }
      return '';
    };

    const window2 = extractJsonStrings(res.text, 'EPISODES_OPTIONS') || extractJsonStrings(res.text, '"saisons"');
    const genresM = window2.match(/"genres":\[([^\]]*)\]/);
    const genres = genresM
      ? genresM[1].split(',').map((g) => decodeHtml(String(g).replace(/"/g, ''))).filter(Boolean)
      : [];

    return {
      href: SITE + '/catalogue/' + slug,
      id: slug,
      title: (og('title') || (known && known.title) || slug).replace(/\s*[-–|]\s*Mugiwara.*$/i, '').trim(),
      description: og('description') || 'Anime disponible sur Mugiwara No Streaming.',
      image: og('image') || (known && known.image) || '',
      genres: genres,
    };
  }

  // ---------- episodes ----------

  function parseEpisodesJs(jsText) {
    const players = [];
    const re = /var\s+(?:eps\d+)\s*=\s*\[([\s\S]*?)\];/g;
    let m;
    while ((m = re.exec(String(jsText || ''))) !== null) {
      const urls = [];
      const urlRe = /['"]([^'"]+)['"]/g;
      let u;
      while ((u = urlRe.exec(m[1])) !== null) {
        const url = decodeHtml(u[1]).trim();
        if (/^https?:\/\//i.test(url)) urls.push(url);
      }
      if (urls.length) players.push(urls);
    }
    return players;
  }

  function sibnetVideoId(playerUrl) {
    const m = String(playerUrl || '').match(/[?&]videoid=(\d+)/i) || String(playerUrl || '').match(/sibnet\.ru\/shell\.php\?videoid=(\d+)/i);
    return m ? m[1] : '';
  }

  function pickBestPlayerArray(players) {
    // Only the Sibnet lecteur resolves to a direct MP4 with plain HTTP.
    for (const arr of players) {
      if (arr.some((u) => /sibnet\.ru/i.test(u))) return arr;
    }
    return null;
  }

  // Inline seasons shape: "saisons":[{"id":"1", ...,"lang":{"vf":[shell urls],
  // "vostfr":[...]}}, ...]. Some titles (e.g. One Piece) embed player lists
  // directly instead of using episodes.js.
  // Reads a JSON-ish value starting at str[startIdx]. Returns a tree:
  // { t:'s', v:string } or { t:'a', kids:[tree...] }, plus the index after.
  function readValueTree(str, startIdx, depth) {
    let i = startIdx;
    while (i < str.length && /\s/.test(str.charAt(i))) i += 1;
    if (str.charAt(i) === '"') {
      let j = i + 1;
      let out = '';
      while (j < str.length) {
        const ch = str.charAt(j);
        if (ch === '\\') { out += str.charAt(j + 1) || ''; j += 2; continue; }
        if (ch === '"') { j += 1; break; }
        out += ch;
        j += 1;
      }
      return { node: { t: 's', v: out }, end: j };
    }
    if (str.charAt(i) !== '[') return null;
    if ((depth || 0) > 6) return null;
    const kids = [];
    i += 1;
    for (;;) {
      while (i < str.length && /[\s,]/.test(str.charAt(i))) i += 1;
      if (i >= str.length) return null;
      if (str.charAt(i) === ']') return { node: { t: 'a', kids: kids }, end: i + 1 };
      const parsed = readValueTree(str, i, (depth || 0) + 1);
      if (!parsed) return null;
      kids.push(parsed.node);
      i = parsed.end;
    }
  }

  // Convert a player-list tree into an ordered episode URL list.
  //   flat:   ["u","u"]            -> those urls
  //   nested: [["u","m"],["u"]]    -> first mirror of each episode
  //   deeper: [[[..],[..]],[[..]]] -> recursed and concatenated
  function firstHttpUrl(node) {
    if (!node) return '';
    if (node.t === 's') return /^https?:\/\//i.test(node.v) ? node.v : '';
    for (const k of (node.kids || [])) {
      const r = firstHttpUrl(k);
      if (r) return r;
    }
    return '';
  }

  function collectUrlsFlat(node) {
    return (node.kids || [])
      .map((k) => (k.t === 's' && /^https?:\/\//i.test(k.v)) ? k.v : '')
      .filter(Boolean);
  }

  // A lang value is one or more HOST LISTS (each sibling array = every
  // episode of one lecteur). Pick the best list: Sibnet first, else longest.
  function treeToEpisodes(node) {
    if (!node) return [];
    if (node.t === 'a' && !node.kids.some((k) => k.t === 'a')) {
      return collectUrlsFlat(node);
    }
    let best = null;
    for (const kid of (node.kids || [])) {
      if (kid.t !== 'a') continue;
      const urls = treeToEpisodes(kid);
      if (!urls.length) continue;
      const score = (urls.some((u) => /sibnet\.ru/i.test(u)) ? 100000 : 0) + urls.length;
      if (!best || score > best.score) best = { score: score, urls: urls };
    }
    return best ? best.urls : [];
  }

  // String-aware scan: returns index just after the '}' matching str[open].
  function matchObjectEnd(str, open) {
    let depth = 0, inStr = false, strCh = '', esc = false;
    for (let j = open; j < str.length; j++) {
      const ch = str.charAt(j);
      if (esc) { esc = false; continue; }
      if (inStr) {
        if (ch === '\\') { esc = true; continue; }
        if (ch === strCh) inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { inStr = true; strCh = ch; continue; }
      if (ch === '{') depth += 1;
      else if (ch === '}') { depth -= 1; if (depth === 0) return j + 1; }
    }
    return -1;
  }

  // String-aware scan for the ']' matching str[open] ('[').
  function matchArrayEnd(str, open) {
    let depth = 0, inStr = false, strCh = '', esc = false;
    for (let j = open; j < str.length; j++) {
      const ch = str.charAt(j);
      if (esc) { esc = false; continue; }
      if (inStr) {
        if (ch === '\\') { esc = true; continue; }
        if (ch === strCh) inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { inStr = true; strCh = ch; continue; }
      if (ch === '[') depth += 1;
      else if (ch === ']') { depth -= 1; if (depth === 0) return j + 1; }
    }
    return -1;
  }

  function parseInlineSeasons(html) {
    const normalized = String(html || '').replace(/\\"/g, '"');
    let marker = normalized.indexOf('"saisons":[');
    if (marker < 0) marker = normalized.indexOf('"films":[');
    if (marker < 0) {
      return [];
    }
    const arrOpen = normalized.indexOf('[', marker);
    const arrClose = matchArrayEnd(normalized, arrOpen);
    if (arrClose < 0) return [];
    const region = normalized.slice(arrOpen + 1, arrClose);

    const seasons = [];

    let i = 0;
    while (i < region.length && seasons.length < 40) {
      while (i < region.length && /[\s,]/.test(region.charAt(i))) i += 1;
      if (region.charAt(i) !== '{') break;
      const objEnd = matchObjectEnd(region, i);
      if (objEnd < 0) break;
      const obj = region.slice(i, objEnd);

      const idM = obj.match(/"id"\s*:\s*"([^"]+)"/);
      const seasonId = idM ? idM[1] : String(seasons.length + 1);

      const langIdx = obj.indexOf('"lang"');
      if (langIdx >= 0) {
        const langsMap = {};
        const tail = obj.slice(langIdx);
        const langKeyRe = /"(vostfr|vf[0-9]*|vo)"\s*:\s*\[/gi;
        let km;
        while ((km = langKeyRe.exec(tail)) !== null) {
          const arrStart2 = km.index + km[0].length - 1;
          const parsed = readValueTree(tail, arrStart2, 0);
          if (!parsed) break;
          const urls = treeToEpisodes(parsed.node);
          if (urls.length) {
            langsMap[String(km[1]).toLowerCase()] = urls;
            langKeyRe.lastIndex = parsed.end;
          }
        }
        if (Object.keys(langsMap).length) {
          seasons.push({ id: seasonId, langsMap: langsMap });
        }
      }
      i = objEnd;
    }
    return seasons;
  }

  function makeEpisodeFromUrl(url, number, seasonId, langName) {
    const sibnetId = sibnetVideoId(url);
    const isSub = /vost/.test(langName);
    return {
      number: number,
      href: sibnetId ? 'mugi-sibnet:' + sibnetId : 'mugi-embed:' + url,
      title: '\u00c9pisode ' + number
        + (Number(seasonId) > 1 || !/^[0-9]+$/.test(String(seasonId)) ? ' (' + seasonId + ')' : '')
        + ' ' + langName.toUpperCase(),
      subAvailable: isSub,
      dubAvailable: /^vf[0-9]*$/.test(langName),
      image: '',
    };
  }

  async function extractEpisodes(seriesId) {
    let slug = String(seriesId || '').trim();
    if (/^https?:\/\//i.test(slug)) {
      const m = slug.match(/\/catalogue\/([^/?#]+)/i);
      slug = m ? m[1] : '';
    } else {
      slug = slug.replace(/^\/?catalogue\//i, '').replace(/^\/+|\/+$/g, '').split('/')[0];
    }
    if (!slug) throw new Error('Mugiwara: extractEpisodes received an empty or foreign URL');

    const res = await requestText(SITE + '/catalogue/' + slug + '/episodes');
    if (!res.ok) throw new Error('Mugiwara: episodes request failed (HTTP ' + res.status + ')');
    const html = res.text;

    // Shape 1 — inline seasons with embedded player lists (One Piece style).
    const inline = parseInlineSeasons(html);
    if (inline.length) {
      const episodesInline = [];
      let counter = 0;
      for (const season of inline.slice(0, 20)) {
        const availableLangs = ['vostfr', 'vf', 'vo'].filter((l) => season.langsMap[l]);
        availableLangs.sort((a, b) => {
          const aCount = (season.langsMap[a] || []).filter((u) => /sibnet/i.test(u)).length;
          const bCount = (season.langsMap[b] || []).filter((u) => /sibnet/i.test(u)).length;
          return bCount - aCount;
        });
        const langName = availableLangs[0];
        if (!langName) continue;
        for (const url of season.langsMap[langName]) {
          counter += 1;
          episodesInline.push(makeEpisodeFromUrl(url, counter, season.id, langName));
          if (counter >= MAX_EPISODES_CAP) break;
        }
        if (counter >= MAX_EPISODES_CAP) break;
      }
      if (episodesInline.length) {
        log('inline seasons parsed: ' + episodesInline.length + ' episodes');
        episodesInline.sort((a, b) => a.number - b.number);
        const hrefSeen = new Set();
        const ordered = [];
        let n2 = 1;
        for (const ep of episodesInline) {
          if (hrefSeen.has(ep.href)) continue;
          hrefSeen.add(ep.href);
          ordered.push(Object.assign({}, ep, { number: n2 }));
          n2 += 1;
          if (ordered.length >= MAX_EPISODES_CAP) break;
        }
        return ordered;
      }
    }

    // Shape 2 — episodes.js lecteur lists via EPISODES_OPTIONS.
    const window2 = extractJsonStrings(html, 'EPISODES_OPTIONS')
      || extractJsonStrings(html, 'saisons');
    if (!window2) {
      throw new Error('Mugiwara: episode options missing on page — site markup may have changed for ' + slug);
    }

    const scriptM = window2.match(/"SCRIPT_URL":"([^"]+)"/)
      || html.match(/"SCRIPT_URL":"([^"]+)"/);
    if (!scriptM) throw new Error('Mugiwara: SCRIPT_URL not found for ' + slug);
    const scriptBase = decodeHtml(scriptM[1]).replace(/\/?$/, '/');

    // saisons: [{id:"1", name:"Saison 1", langToShow:["vostfr", ...]}, ...]
    const seasons = [];
    const saisonRe = /\{"id":"([0-9.]+)","name":"([^"]*)"[^}]*?"langToShow":\[([^\]]*)\]\}/g;
    let sm;
    while ((sm = saisonRe.exec(window2)) !== null) {
      const langs = sm[3].split(',').map((l) => l.replace(/["\s]/g, '')).filter(Boolean);
      seasons.push({ id: sm[1], name: decodeHtml(sm[2]), langs: langs.length ? langs : ['vostfr'] });
    }
    if (!seasons.length) {
      // single-season animes may inline only EPISODES_OPTIONS; default to saison1/vostfr
      seasons.push({ id: '1', name: 'Saison 1', langs: ['vostfr'] });
      log('no explicit seasons found, defaulting to saison1/vostfr');
    }

    const episodes = [];
    const seenKeys = new Set();
    for (const season of seasons.slice(0, 20)) {
      for (const lang of season.langs.slice(0, 3)) {
        const scriptPath = scriptBase + 'saison' + season.id + '/' + lang + '/episodes.js';
        const jsRes = await requestText(SITE + '/api/episodes-script?url=' + encodeURIComponent(scriptPath));
        if (!jsRes.ok) continue;
        const players = parseEpisodesJs(jsRes.text);
        const chosen = pickBestPlayerArray(players);
        if (!chosen) continue;
        for (let i = 0; i < chosen.length; i++) {
          const number = Number(season.id) > 1 && /^[0-9.]+$/.test(chosen[i].match(/[?#]([a-z0-9]+)\s*$/i) ? '' : '')
            ? i + 1 : i + 1;
          const key = season.id + '/' + lang + '/' + (i + 1);
          if (seenKeys.has(key)) continue;
          seenKeys.add(key);
          const playerUrl = chosen[i];
          const sibnetId = sibnetVideoId(playerUrl);
          episodes.push({
            number: number,
            href: sibnetId ? 'mugi-sibnet:' + sibnetId : 'mugi-embed:' + playerUrl,
            title: '\u00c9pisode ' + (i + 1) + (seasons.length > 1 ? ' (S' + season.id + ' ' + lang.toUpperCase() + ')' : (lang !== 'vostfr' ? ' ' + lang.toUpperCase() : '')),
            season: Number(season.id) || 1,
            subAvailable: lang.toLowerCase().indexOf('vost') >= 0,
            dubAvailable: /^vf/.test(lang.toLowerCase()),
            image: '',
          });
        }
        if (episodes.length) break; // first working season/lang is enough per season loop
      }
      if (episodes.length >= MAX_EPISODES_CAP) break;
    }

    if (!episodes.length) {
      throw new Error('Mugiwara: no playable episode sources found for ' + slug
        + ' — upstream may be empty or its player list changed');
    }

    return finalizeEpisodes(episodes);
  }

  function finalizeEpisodes(episodes) {
    episodes.sort((a, b) => a.number - b.number);
    const outSeen = new Set();
    const out = [];
    for (const ep of episodes) {
      if (outSeen.has(ep.number)) continue;
      outSeen.add(ep.number);
      out.push(ep);
      if (out.length >= MAX_EPISODES_CAP) break;
    }
    return out;
  }

  const MAX_EPISODES_CAP = 1500;

  // ---------- streams ----------

  async function resolveSibnet(videoId) {
    const shellUrl = SIBNET + '/shell.php?videoid=' + encodeURIComponent(videoId);
    const page = await requestText(shellUrl, { Referer: SITE + '/' });
    if (!page.ok) throw new Error('Mugiwara: sibnet player request failed (HTTP ' + page.status + ')');
    const srcM = page.text.match(/player\.src\(\[\{src:\s*"([^"]+\.mp4[^"]*)"/i)
      || page.text.match(/"(\/v\/[^"]+\.mp4[^"]*)"/i);
    if (!srcM) throw new Error('Mugiwara: sibnet MP4 source not found on player page');
    let videoUrl = srcM[1];
    if (!/^https?:\/\//i.test(videoUrl)) videoUrl = SIBNET + videoUrl;

    // Pre-resolve the 302 to the physical CDN so downloads start instantly.
    let finalUrl = videoUrl;
    try {
      const probe = await fetchv2(
        videoUrl,
        { 'User-Agent': USER_AGENT, Referer: SIBNET + '/', Range: 'bytes=0-1' },
        'GET',
        null,
        { followRedirects: false },
      );
      const loc = probe && probe.headers
        ? (probe.headers.location || probe.headers.Location || '')
        : '';
      if (loc) finalUrl = loc.startsWith('//') ? 'https:' + loc
        : (/^https?:\/\//i.test(loc) ? loc : 'https://video.sibnet.ru' + loc);
    } catch (_) {}

    return {
      label: 'SibNet',
      url: finalUrl,
      streamType: 'mp4',
      headers: {
        'User-Agent': USER_AGENT,
        Referer: SIBNET + '/',
        Origin: 'https://video.sibnet.ru',
      },
    };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw) throw new Error('Mugiwara: extractStreamUrl received an empty href');

    let streams = [];
    if (raw.indexOf('mugi-sibnet:') === 0) {
      const videoId = raw.slice('mugi-sibnet:'.length).replace(/[^0-9]/g, '');
      if (!videoId) throw new Error('Mugiwara: malformed sibnet episode reference');
      streams.push(await resolveSibnet(videoId));
    } else if (raw.indexOf('mugi-embed:') === 0) {
      const embed = raw.slice('mugi-embed:'.length);
      const sibnetId = embed.match(/videoid=(\d+)/i);
      if (sibnetId) {
        streams.push(await resolveSibnet(sibnetId[1]));
      } else {
        throw new Error('Mugiwara: non-Sibnet lecteur (' + embed.replace(/^https?:\/\/([^/]+).*$/, '$1')
          + ') is not directly playable — switch lecteur on the site or use another episode source');
      }
    } else {
      // direct sibnet link passthrough
      const id = sibnetVideoId(raw);
      if (id) streams.push(await resolveSibnet(id));
      else throw new Error('Mugiwara: unrecognised episode reference: ' + raw.slice(0, 80));
    }

    if (!streams.length) {
      throw new Error('Mugiwara: no playable stream resolved for this episode');
    }

    const flatStreams = [];
    for (const s of streams) flatStreams.push(s.label, s.url);
    return {
      url: streams[0].url,
      streams: flatStreams,
      qualities: streams.map((s) => ({ label: s.label, url: s.url, headers: s.headers })),
      headers: streams[0].headers,
      lang: String(lang || '').toLowerCase() === 'dub' ? 'dub' : 'sub',
      streamType: streams[0].streamType,
      subtitles: [],
    };
  }

  // ---------- discovery ----------

  async function discoveryHome() {
    const items = await fetchCatalogue();
    const byCat = {};
    for (const item of items) {
      const cat = item.category || 'Catalogue';
      (byCat[cat] = byCat[cat] || []).push(item);
    }
    const sections = [];
    const order = ['Nouveaut\u00e9s', 'Populaires'];
    const cats = Object.keys(byCat).sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      if (ia >= 0 || ib >= 0) return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      return a.localeCompare(b);
    });
    for (const cat of cats.slice(0, 6)) {
      sections.push({
        id: 'cat_' + cat.toLowerCase().replace(/[^a-z0-9]+/g, '_'),
        title: cat,
        style: 'poster',
        viewAll: { mode: 'feed', feedId: cat },
        items: byCat[cat].slice(0, 30).map((i) => ({
          href: SITE + '/catalogue/' + i.slug,
          id: i.slug,
          title: i.title,
          image: i.image,
        })),
      });
    }
    if (!sections.length) throw new Error('Mugiwara: discovery found no categories');
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const items = await fetchCatalogue();
    const cat = String(feedId || '');
    const filtered = cat
      ? items.filter((i) => (i.category || '').toLowerCase() === cat.toLowerCase())
      : items;
    const pageSize = 30;
    const offset = (pageNumber - 1) * pageSize;
    const slice = filtered.slice(offset, offset + pageSize);
    return {
      items: slice.map((i) => ({
        href: SITE + '/catalogue/' + i.slug,
        id: i.slug,
        title: i.title,
        image: i.image,
      })),
      page: pageNumber,
      hasMore: offset + slice.length < filtered.length,
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
