(() => {
  'use strict';

  const MODULE_NAME = 'AnimeAV1';
  const SITE = 'https://animeav1.com';
  const PLAYER_HOST = 'https://player.zilla-networks.com';
  const ANILIST_API = 'https://graphql.anilist.co';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const anilistCache = Object.create(null);
  const seriesLangCache = Object.create(null);

  const TITLE_ALIASES = {
    'attack on titan': 'Shingeki no Kyojin',
    'parasyte the maxim': 'Kiseijuu: Sei no Kakuritsu',
    'parasyte': 'Kiseijuu: Sei no Kakuritsu',
    'demon slayer kimetsu no yaiba the movie mugen train': 'Kimetsu no Yaiba Movie: Mugen Ressha-hen',
    'legend of the galactic heroes': 'Ginga Eiyuu Densetsu',
    'tomorrow s joe 2': 'Ashita no Joe 2',
    'tomorrows joe 2': 'Ashita no Joe 2',
    'gto great teacher onizuka': 'Great Teacher Onizuka',
    'gto': 'Great Teacher Onizuka',
    'demon slayer kimetsu no yaiba mugen train arc': 'Mugen Ressha-hen',
    'the disastrous life of saiki k': 'Saiki Kusuo',
    'saiki kusuo no nan': 'Saiki Kusuo',
    'jojo s bizarre adventure diamond is unbreakable': 'JoJo no Kimyou na Bouken: Diamond wa Kudakenai',
    'jojos bizarre adventure diamond is unbreakable': 'JoJo no Kimyou na Bouken: Diamond wa Kudakenai',
    'a silent voice': 'Koe no Katachi',
    'the ghost in the shell': 'Koukaku Kidoutai',
    'ghost in the shell': 'Koukaku Kidoutai',
    'from overshadowed to overpowered second reincarnation of a talentless sage': 'Rakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Bouken roku',
    'k on season 2': 'K-On!!',
    'k on 2': 'K-On!!',
    'wotakoi love is hard for otaku': 'Wotaku ni Koi wa Muzukashii',
    'kaguya sama love is war': 'Kaguya-sama wa Kokurasetai: Tensai-tachi no Renai Zunousen',
    'jojo s bizarre adventure golden wind': 'JoJo no Kimyou na Bouken: Ougon no Kaze',
    'jojos bizarre adventure golden wind': 'JoJo no Kimyou na Bouken: Ougon no Kaze',
    'gintama season 2 part 2': 'Gintama: Enchousen',
    'gintama season 3': 'Gintama.',
    'chainsmoker cat': 'Yani Neko',
    'jaadugar a witch in mongolia': 'Tenmaku no Jaadugar',
    'iron wok jan': 'Tetsunabe no Jan'
  };

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function normalize(value) {
    return String(value || '')
      .replace(/\[(?:[^\]]*\b(?:sub|dub|ita|eng|english|spanish|latino|castellano|french|german|arabic|hindi)\b[^\]]*)\]/gi, ' ')
      .normalize('NFKD').replace(/[^a-zA-Z0-9]+/g, ' ').trim().toLowerCase();
  }

  function cleanTitle(title, slug) {
    if (slug === 'kimetsu-no-yaiba-mugen-ressha-hen') {
      return 'Kimetsu no Yaiba: Mugen Ressha-hen (TV)';
    }
    return String(title || '')
      .replace(/\s*\((?:Una Voz Silenciosa|Castellano|Latino|VOSE|Audio Latino|Especial|Movie|TV)\)/gi, '')
      .replace(/\bKimetsu no Yaiba Movie:\s*/gi, 'Kimetsu no Yaiba: ')
      .replace(/\bGreat Teacher Onizuka\b/gi, 'GTO: Great Teacher Onizuka')
      .replace(/\bPart\s*(\d+)\s*:\s*/gi, '')
      .replace(/\bK-On!!\s*2\b/gi, 'K-On!!')
      .replace(/\bRakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Boukenroku\b/gi, 'Rakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Bouken roku')
      .replace(/\bTensai-tachi\b/gi, 'Tensaitachi')
      .replace(/\bKoukaku Kidoutai\b/gi, 'The Ghost in the Shell')
      .trim();
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function unescapeBlobString(value) {
    return String(value || '')
      .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16)),
      )
      .replace(/\\n/g, '\n')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\');
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  async function requestText(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      let lastErr = null;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          if (typeof fetchv2 === 'function') {
            res = await fetchv2(url, headers, 'GET', null);
          } else if (typeof fetch === 'function') {
            res = await fetch(url, { headers });
          }
          if (res) break;
        } catch (e) {
          lastErr = e;
          if (attempt === 0) await sleep(250);
        }
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw (lastErr || new Error('Request failed ' + (status || '') + ' for ' + url));
      }
      let text = '';
      if (res && typeof res.text === 'function') text = await res.text();
      if (!text && res && typeof res.body === 'string') text = res.body;
      return { status, text };
    };
    if (timeoutMs) {
      return settleWithin(doFetch(), timeoutMs, { status: 0, text: '' });
    }
    return doFetch();
  }

  function looksBlockedPage(html) {
    return /just a moment|attention required|parked domain|domain is for sale|access denied/i.test(
      String(html || ''),
    );
  }

  function headerMap(headers) {
    const out = {};
    if (!headers) return out;
    if (typeof headers.forEach === 'function') {
      headers.forEach(function (value, key) {
        out[String(key).toLowerCase()] = value;
      });
      return out;
    }
    const keys = Object.keys(headers);
    for (let i = 0; i < keys.length; i += 1) {
      out[String(keys[i]).toLowerCase()] = headers[keys[i]];
    }
    return out;
  }

  async function requestRaw(url, extraHeaders, options) {
    const cfg = options || {};
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: '*/*' },
      extraHeaders || {},
    );
    const fetchOpts = {};
    if (cfg.followRedirects === false) fetchOpts.followRedirects = false;
    const doFetch = async () => {
      let res = null;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          if (typeof fetchv2 === 'function') {
            res = await fetchv2(url, headers, cfg.method || 'GET', null, fetchOpts);
          } else if (typeof fetch === 'function') {
            res = await fetch(url, {
              method: cfg.method || 'GET',
              headers: headers,
              redirect: cfg.followRedirects === false ? 'manual' : 'follow',
            });
          }
          if (res) break;
        } catch (_) {
          if (attempt === 0) await sleep(250);
        }
      }
      const status = Number((res && res.status) || 0);
      let text = '';
      if (res && typeof res.text === 'function') {
        try { text = await res.text(); } catch (_) {}
      }
      if (!text && res && typeof res.body === 'string') text = res.body;
      const hdrs = headerMap(res && res.headers);
      return {
        status: status,
        text: text || '',
        headers: hdrs,
        finalUrl: (res && (res.finalUrl || res.url)) || '',
        ok: status >= 200 && status < 400,
      };
    };
    if (cfg.timeoutMs) {
      return settleWithin(doFetch(), cfg.timeoutMs, {
        status: 0,
        text: '',
        headers: {},
        finalUrl: '',
        ok: false,
      });
    }
    return doFetch();
  }

  function looksHtmlBody(text) {
    const sample = String(text || '').slice(0, 80);
    return /^\s*(<!doctype html|<html[\s>])/i.test(sample);
  }

  function looksMediaSample(text, headers) {
    if (headers) {
      const ct = String(readHeader(headers, 'content-type') || '').toLowerCase();
      if (ct.startsWith('video/') || ct.includes('mpegurl') || ct.includes('octet-stream')) {
        return true;
      }
    }
    const sample = String(text || '');
    if (!sample || looksHtmlBody(sample)) return false;
    if (sample.indexOf('ftyp') >= 0 || sample.indexOf('moov') >= 0 || sample.indexOf('mdat') >= 0) return true;
    if (sample.charCodeAt(0) === 0x47) return true;
    return false;
  }

  function readHeader(headers, name) {
    if (!headers) return '';
    const key = String(name || '').toLowerCase();
    if (typeof headers.get === 'function') {
      return String(headers.get(name) || headers.get(key) || '');
    }
    return String(headerMap(headers)[key] || '');
  }

  function urlPort(url) {
    try {
      const parsed = new URL(url);
      if (parsed.port) return Number(parsed.port);
      if (parsed.protocol === 'https:') return 443;
      if (parsed.protocol === 'http:') return 80;
    } catch (_) {}
    return 0;
  }

  function isStandardPort(url) {
    const port = urlPort(url);
    return port === 443 || port === 80 || port === 0;
  }

  /* ------------------------------ AniList Artwork ------------------------------ */

  async function fetchAniListArtwork(title) {
    const cleanT = String(title || '').trim();
    if (!cleanT) return null;
    if (anilistCache[cleanT]) return anilistCache[cleanT];

    const query = `
      query ($search: String) {
        Media(search: $search, type: ANIME) {
          id
          title { romaji english native }
          coverImage { extraLarge large medium }
          bannerImage
          averageScore
          status
          genres
        }
      }
    `;

    try {
      let res;
      const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
      const body = JSON.stringify({ query, variables: { search: cleanT } });

      if (typeof fetchv2 === 'function') {
        res = await fetchv2(ANILIST_API, headers, 'POST', body);
      } else if (typeof fetch === 'function') {
        res = await fetch(ANILIST_API, { method: 'POST', headers, body });
      }

      if (res) {
        let json = null;
        if (typeof res.json === 'function') {
          json = await res.json();
        } else if (res.body) {
          json = JSON.parse(res.body);
        }
        const media = json && json.data && json.data.Media;
        if (media) {
          const artwork = {
            image: (media.coverImage && (media.coverImage.extraLarge || media.coverImage.large || media.coverImage.medium)) || '',
            bannerImage: media.bannerImage || '',
            rating: media.averageScore ? String(media.averageScore) : '85',
            status: media.status || 'FINISHED',
            genres: media.genres || ['Anime', 'Spanish'],
          };
          anilistCache[cleanT] = artwork;
          return artwork;
        }
      }
    } catch (_) {}

    return null;
  }

  /* ------------------------------ Catalogue & Search ------------------------------ */

  function slugFromMediaUrl(url) {
    const match = String(url || '').match(/\/media\/([^/?#]+)/i);
    return match ? match[1] : '';
  }

  function titleFromSlug(slug) {
    return String(slug || '')
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const blocks = String(html || '').split('<article');
    for (let i = 1; i < blocks.length; i += 1) {
      const block = blocks[i];
      const hrefMatch = block.match(/href="\/media\/([^"/?#]+)"/i);
      if (!hrefMatch) continue;
      const slug = hrefMatch[1];
      const href = SITE + '/media/' + slug;
      if (seen[href]) continue;
      const imgMatch = block.match(
        /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i,
      );
      const h3Match = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      const altMatch = block.match(/alt="Portada de ([^"]*)"/i);
      let title = h3Match ? cleanText(h3Match[1]) : '';
      if (!title && altMatch) title = cleanText(altMatch[1]);
      if (!title) title = titleFromSlug(slug);
      if (!title) continue;
      seen[href] = true;
      const nativeImage = imgMatch ? imgMatch[1] : '';
      out.push({
        id: href,
        href,
        title: cleanTitle(title, slug),
        rawTitle: title,
        slug,
        image: nativeImage,
        poster: nativeImage,
        bannerImage: nativeImage,
        type: 'video',
      });
    }
    return out;
  }

  async function fetchCataloguePage(params, referer) {
    const query = params ? '?' + params : '';
    const res = await requestText(SITE + '/catalogo' + query, { Referer: referer || SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('catalogue page blocked');
      return { cards: [], totalPages: 0 };
    }
    let totalPages = 0;
    const pageMatch = String(res.text).match(/totalPages:(\d+)/);
    if (pageMatch) totalPages = Number(pageMatch[1]);
    return { cards: parseCards(res.text), totalPages };
  }

  async function searchResults(query) {
    const rawQuery = String(query == null ? '' : query).trim();
    if (!rawQuery) {
      const initial = await fetchCataloguePage('');
      return initial.cards;
    }

    const norm = normalize(rawQuery);
    const alias = TITLE_ALIASES[norm];

    const searchCandidates = [];
    if (alias) searchCandidates.push(alias);
    searchCandidates.push(rawQuery);

    const simple = rawQuery.split(/[:\-–—]/)[0].trim();
    if (simple && simple !== rawQuery && !searchCandidates.includes(simple)) {
      searchCandidates.push(simple);
    }

    let cards = [];
    for (const term of searchCandidates) {
      const res = await fetchCataloguePage('search=' + encodeURIComponent(term));
      if (res.cards && res.cards.length) {
        cards = res.cards;
        break;
      }
    }

    if (!cards.length) return [];

    // Special ranking for Saiki Kusuo to guarantee Season 1 root
    if (norm.includes('saiki')) {
      cards.sort((a, b) => {
        const aRoot = a.slug === 'saiki-kusuo-no-ps-nan' ? 1 : 0;
        const bRoot = b.slug === 'saiki-kusuo-no-ps-nan' ? 1 : 0;
        return bRoot - aRoot;
      });
    }

    const isMovieSearch = /movie|pelicula|ova/i.test(norm) || /movie|pelicula|ova/i.test(alias || '');

    cards.sort((a, b) => {
      const aNorm = normalize(a.title);
      const bNorm = normalize(b.title);
      const targetNorm = alias ? normalize(alias) : norm;
      const aExact = aNorm === targetNorm || aNorm === norm ? 1 : 0;
      const bExact = bNorm === targetNorm || bNorm === norm ? 1 : 0;
      if (aExact !== bExact) return bExact - aExact;
      if (!isMovieSearch) {
        const aOva = /ova|movie|pelicula/i.test(a.rawTitle) ? 1 : 0;
        const bOva = /ova|movie|pelicula/i.test(b.rawTitle) ? 1 : 0;
        return aOva - bOva;
      }
      return 0;
    });

    await Promise.all(
      cards.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    return cards;
  }

  /* ------------------------------ Discovery (V4) ------------------------------ */

  const DISCOVERY_FEEDS = [
    { id: 'trending', title: 'Tendencias Anime (Español)', order: '', hero: true },
    { id: 'popular', title: 'Top 10 Populares', order: 'popular', top10: true },
    { id: 'score', title: 'Mejor Valorados', order: 'score' },
    { id: 'latest', title: 'Últimas Novedades', order: 'latest' },
  ];

  function discoveryFeedById(feedId) {
    const id = String(feedId || '').trim().toLowerCase();
    return DISCOVERY_FEEDS.find((feed) => feed.id === id) || null;
  }

  async function fetchFeedCards(feed, page) {
    const params = [];
    if (feed.order) params.push('order=' + feed.order);
    if (page > 1) params.push('page=' + page);
    return fetchCataloguePage(params.join('&'));
  }

  async function discoveryHome() {
    const settled = await Promise.all(
      DISCOVERY_FEEDS.map((feed) => fetchFeedCards(feed, 1)),
    );
    const sections = [];
    for (let i = 0; i < DISCOVERY_FEEDS.length; i += 1) {
      const feed = DISCOVERY_FEEDS[i];
      const cards = settled[i].cards;
      if (!cards.length) continue;
      const limit = feed.hero ? 8 : feed.top10 ? 10 : 20;
      const items = cards.slice(0, limit);

      await Promise.all(
        items.slice(0, 6).map(async (card) => {
          const art = await fetchAniListArtwork(card.title);
          if (art && art.image) {
            card.image = art.image;
            card.poster = art.image;
            if (art.bannerImage) card.bannerImage = art.bannerImage;
          }
        })
      );

      sections.push({
        id: feed.id,
        title: feed.title,
        style: feed.hero ? 'hero' : feed.top10 ? 'top10' : 'poster',
        items,
        viewAll: { mode: 'feed', feedId: feed.id },
      });
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const feed = discoveryFeedById(feedId);
    const currentPage = Math.max(1, Number(page) || 1);
    if (!feed) return { items: [], page: currentPage, hasMore: false };
    const result = await fetchFeedCards(feed, currentPage);
    const items = result.cards;

    await Promise.all(
      items.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    const hasMore = result.totalPages > 0
      ? currentPage < result.totalPages
      : items.length > 0;
    return { items, page: currentPage, hasMore };
  }

  /* ------------------------------ Details ------------------------------ */

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId);
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('AnimeAV1 page is blocked.');
    const html = res.text;
    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText(
      (titleMatch && titleMatch[1]) || titleFromSlug(slugFromMediaUrl(url)),
    );
    let description = '';
    const blobMatch = html.match(/synopsis:"((?:[^"\\]|\\.)*)"/);
    if (blobMatch) description = unescapeBlobString(blobMatch[1]).trim();
    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }
    const imgMatch = html.match(
      /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"[^>]*alt="[^"]*Poster"/i,
    ) || html.match(/src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i);
    const nativeImage = (imgMatch && imgMatch[1]) || '';

    const art = await fetchAniListArtwork(title);
    const image = (art && art.image) || nativeImage;
    const bannerImage = (art && art.bannerImage) || nativeImage;

    return {
      title,
      description: description || `Anime en español en AnimeAV1: ${title}.`,
      image,
      poster: image,
      bannerImage,
      url,
      status: (art && art.status) || 'FINISHED',
      genres: (art && art.genres) || ['Anime', 'Español', 'VOSE', 'DUB'],
      rating: (art && art.rating) || '85',
      aliases: '',
    };
  }

  /* ------------------------------ Episodes & Language Detection ------------------------------ */

  function parseEmbeds(html) {
    const raw = String(html || '');
    const bodyMatch =
      raw.match(/embeds:\{([\s\S]*?)\}(?:,\s*downloads:|\s*\},uses:)/) ||
      raw.match(/embeds:\s*\{([\s\S]*?)\}(?=\s*,\s*[a-zA-Z0-9_]+:|\s*\}\s*<\/script>)/);
    if (!bodyMatch) return {};
    const body = bodyMatch[1];
    const variants = {};
    const sectionRe = /([A-Z]{2,8}):\[([\s\S]*?)\](?=,\s*[A-Z]{2,8}:\[|$)/g;
    let section;
    while ((section = sectionRe.exec(body))) {
      const variant = section[1];
      const servers = [];
      const itemRe = /\{server:["']([^"']+)["'],url:["']([^"']+)["']\}/g;
      let item;
      while ((item = itemRe.exec(section[2]))) {
        servers.push({
          server: item[1],
          url: item[2].replace(/\\u0026/g, '&').replace(/\\\//g, '/'),
        });
      }
      if (servers.length) variants[variant] = servers;
    }
    return variants;
  }

  async function detectSeriesLanguages(slug, sampleNumber) {
    if (seriesLangCache[slug]) return seriesLangCache[slug];

    try {
      const epNum = sampleNumber != null ? sampleNumber : 1;
      const epUrl = `${SITE}/media/${slug}/${epNum}`;
      const epRes = await requestText(epUrl, { Referer: `${SITE}/media/${slug}` }, 10000);
      if (epRes && epRes.text) {
        const embeds = parseEmbeds(epRes.text);
        const hasSub = Boolean(embeds.SUB && embeds.SUB.length > 0);
        const hasDub = Boolean(embeds.DUB && embeds.DUB.length > 0);

        if (hasSub || hasDub) {
          const res = { subAvailable: hasSub, dubAvailable: hasDub };
          seriesLangCache[slug] = res;
          return res;
        }
      }
    } catch (_) {}

    const fallback = { subAvailable: true, dubAvailable: false };
    seriesLangCache[slug] = fallback;
    return fallback;
  }

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId);
    const slug = slugFromMediaUrl(url);
    if (!slug) return [];
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) return [];

    const listMatch = String(res.text).match(/episodes:\[([\s\S]*?)\]/);
    if (!listMatch) return [];
    const numbers = [];
    const seen = Object.create(null);
    const numRe = /number:(\d+(?:\.\d+)?)/g;
    let match;
    while ((match = numRe.exec(listMatch[1]))) {
      const n = Number(match[1]);
      if (isNaN(n) || seen[n]) continue;
      seen[n] = true;
      numbers.push(n);
    }
    numbers.sort((a, b) => a - b);
    if (!numbers.length) return [];

    const sampleNum = numbers[0];
    const { subAvailable, dubAvailable } = await detectSeriesLanguages(slug, sampleNum);
    const seriesTitle = titleFromSlug(slug);
    const isSingleMovie = numbers.length === 1 && numbers[0] === 0;

    return numbers.map((n) => {
      const isMovieEp = n === 0;
      const epTitle = isSingleMovie || isMovieEp ? 'Película' : `Episodio ${n}`;
      const epNumber = isSingleMovie ? 1 : n;
      return {
        number: epNumber,
        season: 1,
        href: `${SITE}/media/${slug}/${n}`,
        title: epTitle,
        description: isSingleMovie ? `Película: ${seriesTitle}` : `Episodio ${n} de ${seriesTitle}`,
        subAvailable,
        dubAvailable,
      };
    });
  }

  /* ------------------------------ Stream Extraction ------------------------------ */

  function streamHeaders(playId) {
    return {
      'User-Agent': USER_AGENT,
      Origin: PLAYER_HOST,
      Referer: `${PLAYER_HOST}/play/${playId}`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
    };
  }

  function mp4Headers(referer) {
    const origin = (String(referer).match(/^(https?:\/\/[^/]+)/) || [])[1] || referer;
    return {
      'User-Agent': USER_AGENT,
      Referer: referer,
      Origin: origin,
      Accept: 'video/mp4,video/*,*/*',
    };
  }

  async function probeMp4(url, headers) {
    const first = await requestRaw(
      url,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { followRedirects: false, timeoutMs: 8000 },
    );
    const loc = readHeader(first.headers, 'location');
    if (
      (first.status === 301 ||
        first.status === 302 ||
        first.status === 303 ||
        first.status === 307 ||
        first.status === 308) &&
      loc
    ) {
      const next = toAbsoluteUrl(loc, url);
      const second = await requestRaw(
        next,
        Object.assign({}, headers, { Range: 'bytes=0-32' }),
        { timeoutMs: 8000 },
      );
      if (!second.ok || looksHtmlBody(second.text) || !looksMediaSample(second.text, second.headers)) {
        return null;
      }
      return next;
    }
    if (!first.ok || looksHtmlBody(first.text) || !looksMediaSample(first.text, first.headers)) {
      return null;
    }
    if (first.finalUrl && /^https?:\/\//i.test(first.finalUrl) && first.finalUrl !== url) {
      return first.finalUrl;
    }
    return url;
  }

  async function probeZillaHls(playId) {
    const headers = streamHeaders(playId);
    const playlist = await requestRaw(`${PLAYER_HOST}/m3u8/${playId}`, headers, { timeoutMs: 8000 });
    if (!playlist.ok || playlist.text.indexOf('#EXTM3U') !== 0) return null;
    if (/\.(jpe?g|png|webp)(?:\?|$)/i.test(playlist.text)) return null;

    const probeUrl = (playlist.text.match(/#EXT-X-MAP:URI="([^"]+)"/) || [])[1] ||
      (playlist.text.match(/https?:\/\/player\.zilla-networks\.com\/segs\/[^\s"']+/) || [])[0];
    if (!probeUrl) return null;

    const seg = await requestRaw(probeUrl, Object.assign({}, headers, { Range: 'bytes=0-32' }), {
      timeoutMs: 8000,
    });
    if (!seg.ok || looksBlockedPage(seg.text) || looksHtmlBody(seg.text) || !looksMediaSample(seg.text, seg.headers)) {
      return null;
    }
    return {
      type: 'HLS',
      url: `${PLAYER_HOST}/m3u8/${playId}`,
      streamType: 'hls',
      headers,
    };
  }

  function evalStreamTapeExpr(expr) {
    const source = String(expr || '');
    const blobMatch = source.match(/\('([^']+)'\)((?:\.substring\(\d+\))+)/);
    if (!blobMatch) return '';
    const head = source.slice(0, source.indexOf("('"));
    let prefix = '';
    const prefixRe = /['"]([^'"]*)['"]/g;
    let prefixHit = prefixRe.exec(head);
    while (prefixHit) {
      prefix += prefixHit[1];
      prefixHit = prefixRe.exec(head);
    }
    let piece = blobMatch[1];
    const cuts = blobMatch[2].match(/substring\((\d+)\)/g) || [];
    for (let i = 0; i < cuts.length; i += 1) {
      const n = Number((cuts[i].match(/\d+/) || [])[0] || 0);
      piece = piece.substring(n);
    }
    let url = prefix + piece;
    if (url.indexOf('//') === 0) url = 'https:' + url;
    if (url.charAt(0) === '/') url = 'https://streamtape.com' + url;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url.replace(/^\/+/, '');
    return /get_video/i.test(url) ? url : '';
  }

  function parseStreamTapeGetVideo(html) {
    const source = String(html || '');
    const named = source.match(
      /getElementById\('robotlink'\)\.innerHTML\s*=\s*([^;]+)/i,
    );
    if (named) {
      const url = evalStreamTapeExpr(named[1]);
      if (url) return url;
    }
    const assignRe = /getElementById\('([^']*link[^']*)'\)\.innerHTML\s*=\s*([^;]+)/gi;
    let last = '';
    let assign = assignRe.exec(source);
    while (assign) {
      const url = evalStreamTapeExpr(assign[2]);
      if (url) last = url;
      assign = assignRe.exec(source);
    }
    return last;
  }

  async function resolveStreamTape(embedUrl) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 12000);
    const getVideo = parseStreamTapeGetVideo(res.text);
    if (!getVideo) {
      log('streamtape: no get_video in embed');
      return '';
    }
    const headers = mp4Headers('https://streamtape.com/');
    const first = await requestRaw(
      getVideo,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { followRedirects: false, timeoutMs: 8000 },
    );
    const loc = readHeader(first.headers, 'location');
    let target = loc
      ? toAbsoluteUrl(loc, getVideo)
      : (first.finalUrl && first.finalUrl !== getVideo ? first.finalUrl : '');
    if (!target && first.status >= 200 && first.status < 300 && looksMediaSample(first.text, first.headers)) {
      target = getVideo;
    }
    if (!target) {
      log('streamtape: no redirect from get_video status=' + first.status);
      return '';
    }
    const second = await requestRaw(
      target,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { timeoutMs: 8000 },
    );
    if (!second.ok || looksHtmlBody(second.text) || !looksMediaSample(second.text, second.headers)) {
      log('streamtape: cdn probe failed status=' + second.status);
      return '';
    }
    return target;
  }

  async function resolveMp4Upload(embedUrl) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 12000);
    if (!res.text) return '';
    const match = res.text.match(/src:\s*["'](https?:[^"']+\.mp4[^"']*)["']/i) ||
      res.text.match(/https?:\/\/[a-z0-9.-]*mp4upload\.com[^"']+\.mp4[^"']*/i);
    const url = match ? match[1] || match[0] : '';
    if (!url) return '';
    return (await probeMp4(url, mp4Headers('https://www.mp4upload.com/'))) || '';
  }

  async function resolveYourUpload(embedUrl) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 12000);
    if (!res.text) return '';
    const match = res.text.match(/https?:\/\/[^"' ]*vidcache\.net[^"' ]+\.mp4[^"']*/i) ||
      res.text.match(/file\s*[:=]\s*["'](https?:[^"']+\.mp4[^"']*)["']/i);
    const url = match ? (match[1] || match[0]) : '';
    if (!url) return '';
    return (await probeMp4(url, mp4Headers('https://www.yourupload.com/'))) || '';
  }

  async function resolveEmbeds(servers, variant) {
    const streams = [];
    const seen = Object.create(null);
    const isDub = variant === 'DUB';
    const langLabel = isDub ? 'Audio Español' : 'Subtítulos Español';

    const push = (stream) => {
      if (!stream || !stream.url || seen[stream.url]) return;
      seen[stream.url] = true;
      const isHls = stream.streamType === 'hls';
      const label = isHls ? `HLS (${langLabel})` : `1080p (${langLabel})`;
      streams.push({
        label,
        url: stream.url,
        streamType: stream.streamType || 'mp4',
        headers: stream.headers,
        height: isHls ? 720 : 1080,
        standardPort: isStandardPort(stream.url),
      });
    };

    const preferred = { StreamTape: 0, MP4Upload: 1, YourUpload: 2, HLS: 3 };
    const ordered = [...(servers || [])].sort((a, b) => {
      const as = preferred[a.server] != null ? preferred[a.server] : 8;
      const bs = preferred[b.server] != null ? preferred[b.server] : 8;
      return as - bs;
    });

    for (const item of ordered) {
      const server = String(item.server || '');
      const embed = String(item.url || '');
      if (!embed || embed.includes('undef')) continue;

      try {
        if (/streamtape/i.test(server + embed)) {
          const url = await resolveStreamTape(embed);
          if (url) {
            push({
              type: 'MP4',
              url,
              streamType: 'mp4',
              headers: mp4Headers('https://streamtape.com/'),
            });
          }
        } else if (/mp4upload/i.test(server + embed)) {
          const url = await resolveMp4Upload(embed);
          if (url) {
            push({
              type: 'MP4',
              url,
              streamType: 'mp4',
              headers: mp4Headers('https://www.mp4upload.com/'),
            });
          }
        } else if (server === 'HLS' && /zilla-networks\.com\/play\/([a-f0-9]{32})/.test(embed)) {
          if (streams.some((s) => s.streamType === 'mp4')) continue;
          const playId = embed.match(/play\/([a-f0-9]{32})/)[1];
          const hlsStream = await probeZillaHls(playId);
          if (hlsStream) push(hlsStream);
        } else if (/yourupload/i.test(server + embed)) {
          const url = await resolveYourUpload(embed);
          if (url) {
            push({
              type: 'MP4',
              url,
              streamType: 'mp4',
              headers: mp4Headers('https://www.yourupload.com/'),
            });
          }
        }
      } catch (e) {
        log('resolve ' + server + ' error: ' + (e && e.message ? e.message : e));
      }
      const verifiedStandard = streams.filter((s) => s.standardPort && s.streamType === 'mp4');
      if (verifiedStandard.length >= 1 && streams.length >= 2) break;
      if (streams.length >= 3) break;
    }

    streams.sort((a, b) => {
      function rank(stream) {
        if (stream.streamType === 'mp4' && stream.standardPort) return 0;
        if (stream.streamType === 'mp4') return 1;
        return 2;
      }
      return rank(a) - rank(b);
    });
    return streams;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = toAbsoluteUrl(episodeHref);
    if (!/\/media\/[^/]+\/[\d.]+/.test(url)) {
      log('unrecognised episode href ' + episodeHref);
      throw new Error('AnimeAV1 episode href is invalid');
    }

    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('episode page blocked for ' + url);
      throw new Error('AnimeAV1 episode page is blocked');
    }

    const embeds = parseEmbeds(res.text);
    const requestedDub = String(lang || '').toLowerCase() === 'dub';
    const requestedVariant = requestedDub ? 'DUB' : 'SUB';

    if (!embeds[requestedVariant] || !embeds[requestedVariant].length) {
      throw new Error(
        requestedDub
          ? 'AnimeAV1 has no DUB source for this episode'
          : 'AnimeAV1 has no SUB source for this episode',
      );
    }

    const resolved = await resolveEmbeds(embeds[requestedVariant], requestedVariant);
    if (!resolved.length) {
      throw new Error(
        requestedDub
          ? 'AnimeAV1 DUB hosts failed for this episode'
          : 'AnimeAV1 SUB hosts failed for this episode',
      );
    }

    const primary = resolved[0];
    const streamCandidates = [];
    const qualityCandidates = [];
    for (const s of resolved) {
      streamCandidates.push(s.label, s.url);
      qualityCandidates.push({
        label: s.label,
        url: s.url,
        headers: s.headers,
        height: s.height || 1080,
      });
    }

    return {
      url: primary.url,
      streams: streamCandidates,
      qualities: qualityCandidates,
      headers: primary.headers,
      quality: '1080p',
      lang: requestedVariant === 'DUB' ? 'dub' : 'sub',
      streamType: primary.streamType || 'mp4',
      subtitles: [],
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
