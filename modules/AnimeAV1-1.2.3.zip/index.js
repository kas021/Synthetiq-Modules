(() => {
  'use strict';

  const MODULE_NAME = 'AnimeAV1';
  const SITE = 'https://animeav1.com';
  const PLAYER_HOST = 'https://player.zilla-networks.com';
  const ANILIST_API = 'https://graphql.anilist.co';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const anilistCache = Object.create(null);
  const seriesLangCache = Object.create(null);

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function unescapeBlobString(value) {
    return String(value || '')
      .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16)),
      )
      .replace(/\\n/g, '\n')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\');
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  async function requestText(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers });
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw new Error('Request failed ' + (status || '') + ' for ' + url);
      }
      let text = '';
      if (res && typeof res.text === 'function') text = await res.text();
      if (!text && res && typeof res.body === 'string') text = res.body;
      return { status, text };
    };
    if (timeoutMs) {
      return settleWithin(doFetch(), timeoutMs, { status: 0, text: '' });
    }
    return doFetch();
  }

  function looksBlockedPage(html) {
    return /just a moment|attention required|parked domain|domain is for sale|access denied/i.test(
      String(html || ''),
    );
  }

  /* ------------------------------ AniList Artwork ------------------------------ */

  async function fetchAniListArtwork(title) {
    const cleanTitle = String(title || '').trim();
    if (!cleanTitle) return null;
    if (anilistCache[cleanTitle]) return anilistCache[cleanTitle];

    const query = `
      query ($search: String) {
        Media(search: $search, type: ANIME) {
          id
          title { romaji english native }
          coverImage { extraLarge large medium }
          bannerImage
          averageScore
          status
          genres
        }
      }
    `;

    try {
      let res;
      const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
      const body = JSON.stringify({ query, variables: { search: cleanTitle } });

      if (typeof fetchv2 === 'function') {
        res = await fetchv2(ANILIST_API, headers, 'POST', body);
      } else if (typeof fetch === 'function') {
        res = await fetch(ANILIST_API, { method: 'POST', headers, body });
      }

      if (res) {
        let json = null;
        if (typeof res.json === 'function') {
          json = await res.json();
        } else if (res.body) {
          json = JSON.parse(res.body);
        }
        const media = json && json.data && json.data.Media;
        if (media) {
          const artwork = {
            image: (media.coverImage && (media.coverImage.extraLarge || media.coverImage.large || media.coverImage.medium)) || '',
            bannerImage: media.bannerImage || '',
            rating: media.averageScore ? String(media.averageScore) : '85',
            status: media.status || 'FINISHED',
            genres: media.genres || ['Anime', 'Spanish'],
          };
          anilistCache[cleanTitle] = artwork;
          return artwork;
        }
      }
    } catch (_) {}

    return null;
  }

  /* ------------------------------ Catalogue & Search ------------------------------ */

  function slugFromMediaUrl(url) {
    const match = String(url || '').match(/\/media\/([^/?#]+)/i);
    return match ? match[1] : '';
  }

  function titleFromSlug(slug) {
    return String(slug || '')
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const blocks = String(html || '').split('<article');
    for (let i = 1; i < blocks.length; i += 1) {
      const block = blocks[i];
      const hrefMatch = block.match(/href="\/media\/([^"/?#]+)"/i);
      if (!hrefMatch) continue;
      const slug = hrefMatch[1];
      const href = SITE + '/media/' + slug;
      if (seen[href]) continue;
      const imgMatch = block.match(
        /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i,
      );
      const h3Match = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      const altMatch = block.match(/alt="Portada de ([^"]*)"/i);
      let title = h3Match ? cleanText(h3Match[1]) : '';
      if (!title && altMatch) title = cleanText(altMatch[1]);
      if (!title) title = titleFromSlug(slug);
      if (!title) continue;
      seen[href] = true;
      const nativeImage = imgMatch ? imgMatch[1] : '';
      out.push({
        id: href,
        href,
        title,
        image: nativeImage,
        poster: nativeImage,
        bannerImage: nativeImage,
        type: 'video',
      });
    }
    return out;
  }

  async function fetchCataloguePage(params, referer) {
    const query = params ? '?' + params : '';
    const res = await requestText(SITE + '/catalogo' + query, { Referer: referer || SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('catalogue page blocked');
      return { cards: [], totalPages: 0 };
    }
    let totalPages = 0;
    const pageMatch = String(res.text).match(/totalPages:(\d+)/);
    if (pageMatch) totalPages = Number(pageMatch[1]);
    return { cards: parseCards(res.text), totalPages };
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    const result = term
      ? await fetchCataloguePage('search=' + encodeURIComponent(term))
      : await fetchCataloguePage('');

    const cards = result.cards;
    await Promise.all(
      cards.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    return cards;
  }

  /* ------------------------------ Discovery (V4) ------------------------------ */

  const DISCOVERY_FEEDS = [
    { id: 'trending', title: 'Tendencias Anime (Español)', order: '', hero: true },
    { id: 'popular', title: 'Top 10 Populares', order: 'popular', top10: true },
    { id: 'score', title: 'Mejor Valorados', order: 'score' },
    { id: 'latest', title: 'Últimas Novedades', order: 'latest' },
  ];

  function discoveryFeedById(feedId) {
    const id = String(feedId || '').trim().toLowerCase();
    return DISCOVERY_FEEDS.find((feed) => feed.id === id) || null;
  }

  async function fetchFeedCards(feed, page) {
    const params = [];
    if (feed.order) params.push('order=' + feed.order);
    if (page > 1) params.push('page=' + page);
    return fetchCataloguePage(params.join('&'));
  }

  async function discoveryHome() {
    const settled = await Promise.all(
      DISCOVERY_FEEDS.map((feed) => fetchFeedCards(feed, 1)),
    );
    const sections = [];
    for (let i = 0; i < DISCOVERY_FEEDS.length; i += 1) {
      const feed = DISCOVERY_FEEDS[i];
      const cards = settled[i].cards;
      if (!cards.length) continue;
      const limit = feed.hero ? 8 : feed.top10 ? 10 : 20;
      const items = cards.slice(0, limit);

      await Promise.all(
        items.slice(0, 6).map(async (card) => {
          const art = await fetchAniListArtwork(card.title);
          if (art && art.image) {
            card.image = art.image;
            card.poster = art.image;
            if (art.bannerImage) card.bannerImage = art.bannerImage;
          }
        })
      );

      sections.push({
        id: feed.id,
        title: feed.title,
        style: feed.hero ? 'hero' : feed.top10 ? 'top10' : 'poster',
        items,
        viewAll: { mode: 'feed', feedId: feed.id },
      });
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const feed = discoveryFeedById(feedId);
    const currentPage = Math.max(1, Number(page) || 1);
    if (!feed) return { items: [], page: currentPage, hasMore: false };
    const result = await fetchFeedCards(feed, currentPage);
    const items = result.cards;

    await Promise.all(
      items.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    const hasMore = result.totalPages > 0
      ? currentPage < result.totalPages
      : items.length > 0;
    return { items, page: currentPage, hasMore };
  }

  /* ------------------------------ Details ------------------------------ */

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId);
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('AnimeAV1 page is blocked.');
    const html = res.text;
    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText(
      (titleMatch && titleMatch[1]) || titleFromSlug(slugFromMediaUrl(url)),
    );
    let description = '';
    const blobMatch = html.match(/synopsis:"((?:[^"\\]|\\.)*)"/);
    if (blobMatch) description = unescapeBlobString(blobMatch[1]).trim();
    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }
    const imgMatch = html.match(
      /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"[^>]*alt="[^"]*Poster"/i,
    ) || html.match(/src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i);
    const nativeImage = (imgMatch && imgMatch[1]) || '';

    const art = await fetchAniListArtwork(title);
    const image = (art && art.image) || nativeImage;
    const bannerImage = (art && art.bannerImage) || nativeImage;

    return {
      title,
      description: description || `Anime en español en AnimeAV1: ${title}.`,
      image,
      poster: image,
      bannerImage,
      url,
      status: (art && art.status) || 'FINISHED',
      genres: (art && art.genres) || ['Anime', 'Español', 'VOSE', 'DUB'],
      rating: (art && art.rating) || '85',
      aliases: '',
    };
  }

  /* ------------------------------ Episodes & Language Detection ------------------------------ */

  function parseEmbeds(html) {
    const raw = String(html || '');
    const bodyMatch =
      raw.match(/embeds:\{([\s\S]*?)\}(?:,\s*downloads:|\s*\},uses:)/);
    if (!bodyMatch) return {};
    const body = bodyMatch[1];
    const variants = {};
    const sectionRe = /([A-Z]{2,8}):\[([\s\S]*?)\](?=,\s*[A-Z]{2,8}:\[|$)/g;
    let section;
    while ((section = sectionRe.exec(body))) {
      const variant = section[1];
      const servers = [];
      const itemRe = /\{server:"([^"]+)",url:"([^"]+)"\}/g;
      let item;
      while ((item = itemRe.exec(section[2]))) {
        servers.push({ server: item[1], url: item[2].replace(/\\u0026/g, '&') });
      }
      if (servers.length) variants[variant] = servers;
    }
    return variants;
  }

  async function detectSeriesLanguages(slug, sampleNumber) {
    if (seriesLangCache[slug]) return seriesLangCache[slug];

    try {
      const epNum = sampleNumber != null ? sampleNumber : 1;
      const epUrl = `${SITE}/media/${slug}/${epNum}`;
      const epRes = await requestText(epUrl, { Referer: `${SITE}/media/${slug}` }, 10000);
      if (epRes && epRes.text) {
        const embeds = parseEmbeds(epRes.text);
        const hasSub = Boolean(embeds.SUB && embeds.SUB.length > 0);
        const hasDub = Boolean(embeds.DUB && embeds.DUB.length > 0);

        if (hasSub || hasDub) {
          const res = { subAvailable: hasSub, dubAvailable: hasDub };
          seriesLangCache[slug] = res;
          return res;
        }
      }
    } catch (_) {}

    // Default fallback
    const fallback = { subAvailable: true, dubAvailable: false };
    seriesLangCache[slug] = fallback;
    return fallback;
  }

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId);
    const slug = slugFromMediaUrl(url);
    if (!slug) return [];
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) return [];

    const listMatch = String(res.text).match(/episodes:\[([\s\S]*?)\]/);
    if (!listMatch) return [];
    const numbers = [];
    const seen = Object.create(null);
    const numRe = /number:(\d+)/g;
    let match;
    while ((match = numRe.exec(listMatch[1]))) {
      const n = Number(match[1]);
      // Explicitly allow episode 0 for movies/specials
      if (isNaN(n) || seen[n]) continue;
      seen[n] = true;
      numbers.push(n);
    }
    numbers.sort((a, b) => a - b);
    if (!numbers.length) return [];

    const sampleNum = numbers[0];
    const { subAvailable, dubAvailable } = await detectSeriesLanguages(slug, sampleNum);
    const seriesTitle = titleFromSlug(slug);
    const isSingleMovie = numbers.length === 1 && numbers[0] === 0;

    return numbers.map((n) => {
      const isMovieEp = n === 0;
      const epTitle = isSingleMovie || isMovieEp ? 'Película' : `Episodio ${n}`;
      const epNumber = isSingleMovie ? 1 : n;
      return {
        number: epNumber,
        season: 1,
        href: `${SITE}/media/${slug}/${n}`,
        title: epTitle,
        description: isSingleMovie ? `Película: ${seriesTitle}` : `Episodio ${n} de ${seriesTitle}`,
        subAvailable,
        dubAvailable,
      };
    });
  }

  /* ------------------------------ Stream Extraction ------------------------------ */

  function streamHeaders(playId) {
    return {
      'User-Agent': USER_AGENT,
      Origin: PLAYER_HOST,
      Referer: `${PLAYER_HOST}/play/${playId}`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
    };
  }

  function mp4Headers(referer) {
    const origin = (String(referer).match(/^(https?:\/\/[^/]+)/) || [])[1] || referer;
    return {
      'User-Agent': USER_AGENT,
      Referer: referer,
      Origin: origin,
      Accept: 'video/mp4,video/*,*/*',
    };
  }

  async function requestStatus(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: '*/*' },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers });
      }
      const status = Number((res && res.status) || 0);
      let text = '';
      if (res && typeof res.text === 'function') {
        try { text = await res.text(); } catch (_) {}
      }
      if (!text && res && typeof res.body === 'string') text = res.body;
      return { status: status, text: text || '', ok: status >= 200 && status < 400 };
    };
    if (timeoutMs) return settleWithin(doFetch(), timeoutMs, { status: 0, text: '', ok: false });
    return doFetch();
  }

  async function probeZillaHls(playId) {
    const headers = streamHeaders(playId);
    const playlist = await requestStatus(`${PLAYER_HOST}/m3u8/${playId}`, headers, 8000);
    if (!playlist.ok || playlist.text.indexOf('#EXTM3U') !== 0) return null;
    if (/\.(jpe?g|png|webp)(?:\?|$)/i.test(playlist.text)) return null;

    const probeUrl = (playlist.text.match(/#EXT-X-MAP:URI="([^"]+)"/) || [])[1] ||
      (playlist.text.match(/https?:\/\/player\.zilla-networks\.com\/segs\/[^\s"']+/) || [])[0];
    if (!probeUrl) return null;

    const seg = await requestStatus(probeUrl, headers, 8000);
    if (!seg.ok || looksBlockedPage(seg.text) || /<!DOCTYPE|<html|Attention Required/i.test(seg.text)) {
      return null;
    }
    return {
      type: 'HLS',
      url: `${PLAYER_HOST}/m3u8/${playId}`,
      streamType: 'hls',
      headers,
    };
  }

  async function resolveMp4Upload(embedUrl) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 12000);
    if (!res.text) return '';
    const match = res.text.match(/src:\s*["'](https?:[^"']+\.mp4[^"']*)["']/i) ||
      res.text.match(/https?:\/\/[a-z0-9.-]*mp4upload\.com[^"']+\.mp4[^"']*/i);
    return match ? match[1] || match[0] : '';
  }

  async function resolveYourUpload(embedUrl) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 12000);
    if (!res.text) return '';
    const match = res.text.match(/https?:\/\/[^"' ]*vidcache\.net[^"' ]+\.mp4[^"']*/i) ||
      res.text.match(/file\s*[:=]\s*["'](https?:[^"']+\.mp4[^"']*)["']/i);
    return match ? (match[1] || match[0]) : '';
  }

  async function resolveEmbeds(servers, variant) {
    const streams = [];
    const seen = Object.create(null);
    const isDub = variant === 'DUB';
    const langLabel = isDub ? 'Audio Español' : 'Subtítulos Español';

    const push = (stream) => {
      if (!stream || !stream.url || seen[stream.url]) return;
      seen[stream.url] = true;
      const isHls = stream.streamType === 'hls';
      const label = isHls ? `HLS (${langLabel})` : `1080p (${langLabel})`;
      streams.push({
        label,
        url: stream.url,
        streamType: stream.streamType || 'mp4',
        headers: stream.headers,
        height: isHls ? 720 : 1080,
      });
    };

    // Prioritize YourUpload (H.264 MP4 with Content-Length / 438MB), then MP4Upload, then HLS
    const preferred = { YourUpload: 0, MP4Upload: 1, HLS: 2 };
    const ordered = [...(servers || [])].sort((a, b) => {
      const as = preferred[a.server] != null ? preferred[a.server] : 8;
      const bs = preferred[b.server] != null ? preferred[b.server] : 8;
      return as - bs;
    });

    for (const item of ordered) {
      const server = String(item.server || '');
      const embed = String(item.url || '');
      if (!embed || embed.includes('undef')) continue;

      try {
        if (/yourupload/i.test(server + embed)) {
          const url = await resolveYourUpload(embed);
          if (url) {
            push({
              type: 'MP4',
              url,
              streamType: 'mp4',
              headers: mp4Headers('https://www.yourupload.com/'),
            });
          }
        } else if (/mp4upload/i.test(server + embed)) {
          const url = await resolveMp4Upload(embed);
          if (url) {
            push({
              type: 'MP4',
              url,
              streamType: 'mp4',
              headers: mp4Headers('https://www.mp4upload.com/'),
            });
          }
        } else if (server === 'HLS' && /zilla-networks\.com\/play\/([a-f0-9]{32})/.test(embed)) {
          const playId = embed.match(/play\/([a-f0-9]{32})/)[1];
          const hlsStream = await probeZillaHls(playId);
          if (hlsStream) push(hlsStream);
        }
      } catch (e) {
        log('resolve ' + server + ' error: ' + (e && e.message ? e.message : e));
      }
      if (streams.length >= 3) break;
    }
    return streams;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = toAbsoluteUrl(episodeHref);
    if (!/\/media\/[^/]+\/\d+/.test(url)) {
      log('unrecognised episode href ' + episodeHref);
      throw new Error('AnimeAV1 episode href is invalid');
    }

    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('episode page blocked for ' + url);
      throw new Error('AnimeAV1 episode page is blocked');
    }

    const embeds = parseEmbeds(res.text);
    const requestedDub = String(lang || '').toLowerCase() === 'dub';

    // Prioritize requested language variant with clean fallback if not available
    let primaryVariant = requestedDub ? 'DUB' : 'SUB';
    if (!embeds[primaryVariant]) {
      primaryVariant = requestedDub ? (embeds.SUB ? 'SUB' : null) : (embeds.DUB ? 'DUB' : null);
    }

    if (!primaryVariant || !embeds[primaryVariant]) {
      throw new Error('No video streams available for this episode');
    }

    const resolved = await resolveEmbeds(embeds[primaryVariant], primaryVariant);
    if (!resolved.length) {
      // Try secondary variant if primary failed to resolve
      const secondaryVariant = primaryVariant === 'DUB' ? 'SUB' : 'DUB';
      if (embeds[secondaryVariant]) {
        const secondary = await resolveEmbeds(embeds[secondaryVariant], secondaryVariant);
        for (const s of secondary) resolved.push(s);
      }
    }

    if (!resolved.length) {
      throw new Error('No playable video streams could be extracted');
    }

    const primary = resolved[0];
    const streamCandidates = [];
    const qualityCandidates = [];
    for (const s of resolved) {
      streamCandidates.push(s.label, s.url);
      qualityCandidates.push({
        label: s.label,
        url: s.url,
        headers: s.headers,
        height: s.height || 1080,
      });
    }

    return {
      url: primary.url,
      streams: streamCandidates,
      qualities: qualityCandidates,
      headers: primary.headers,
      quality: '1080p',
      lang: primaryVariant === 'DUB' ? 'dub' : 'sub',
      streamType: primary.streamType || 'mp4',
      subtitles: [],
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
