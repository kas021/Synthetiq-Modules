// FRAnime (franime.fr) — French anime with separate VOSTFR (sub) and VF (dub) routes.
// Catalogue and episode lists come from the site's public JSON API (api.franime.fr).
// Player links are resolved per episode, per language and per player index, then
// each candidate is checked (playlist + first segment, or a ranged MP4 read)
// before exactly one validated route is returned.
(function () {
  'use strict';

  var SITE = 'https://franime.fr';
  var API = 'https://api.franime.fr/api/';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';
  var API_HEADERS = { 'User-Agent': UA, Accept: 'application/json, text/plain, */*', Origin: SITE, Referer: SITE + '/' };
  var CATALOGUE_TTL_MS = 30 * 60 * 1000;
  var DETAILS_TTL_MS = 10 * 60 * 1000;
  // Hosts the module can turn into a playable stream, in preference order.
  // uqload: stream servers present an expired TLS certificate (Nov 2026), so it is not offered.
  // filemoon/byse: encrypted SPA player, adds <0.1% coverage; not offered.
  var HOST_ORDER = ['vidmoly', 'sendvid', 'sibnet'];

  var catalogueCache = null;
  var catalogueAt = 0;
  var cataloguePromise = null;
  var detailsCache = Object.create(null);

  function log(msg) {
    try { console.log('[FRAnime] ' + msg); } catch (_) {}
  }

  function cleanText(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]*>/g, ' ')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'")
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }

  function norm(value) {
    var s = String(value == null ? '' : value).toLowerCase();
    if (typeof s.normalize === 'function') s = s.normalize('NFD').replace(/[̀-ͯ]/g, '');
    return s.replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim();
  }

  function absolute(url, base) {
    var u = String(url || '').trim();
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'https:' + u;
    var origin = (String(base).match(/^https?:\/\/[^/]+/i) || [''])[0];
    if (u.charAt(0) === '/') return origin + u;
    return String(base).split('?')[0].replace(/[^/]*$/, '') + u;
  }

  function withTimeout(promise, ms) {
    var timer;
    return Promise.race([
      promise,
      new Promise(function (resolve) { timer = setTimeout(function () { resolve(null); }, Math.max(1, ms)); })
    ]).then(function (v) {
      try { clearTimeout(timer); } catch (_) {}
      return v;
    });
  }

  // Returns { status, text, headers, url } or null on transport failure/timeout.
  async function request(url, headers, opts) {
    var o = opts || {};
    var h = Object.assign({ 'User-Agent': UA }, headers || {});
    var timeoutMs = o.timeoutMs || 20000;
    try {
      if (typeof fetchv2 === 'function') {
        var fo = { followRedirects: o.followRedirects !== false, timeoutMs: timeoutMs };
        if (o.maxBytesHint) fo.maxBytesHint = o.maxBytesHint;
        var res = await withTimeout(fetchv2(url, h, 'GET', null, fo), timeoutMs + 2000);
        if (!res) return null;
        var text = '';
        var json;
        if (typeof res.body === 'string') text = res.body;
        if (!text && typeof res.text === 'function') { try { text = await res.text(); } catch (_) { text = ''; } }
        // The app bridge parses JSON natively and hands it over without a text body.
        if (!text && o.wantJson) {
          if (typeof res.json === 'function') { try { json = await res.json(); } catch (_) { json = undefined; } }
          else if (res.json && typeof res.json === 'object') json = res.json;
        }
        return {
          status: Number(res.status || 0),
          text: text || '',
          json: json,
          headers: res.headers || {},
          url: res.finalUrl || res.url || url
        };
      }
      if (typeof fetch === 'function') {
        var r = await withTimeout(fetch(url, { headers: h, redirect: o.followRedirects === false ? 'manual' : 'follow' }), timeoutMs);
        if (!r) return null;
        var hh = {};
        try { r.headers.forEach(function (v, k) { hh[k] = v; }); } catch (_) {}
        return { status: r.status, text: o.range ? '' : await r.text(), headers: hh, url: r.url || url };
      }
    } catch (e) {
      log('request failed ' + url.split('?')[0] + ': ' + (e && e.message ? e.message : e));
    }
    return null;
  }

  async function apiJson(path, opts) {
    var res = await request(API + path, API_HEADERS, Object.assign({ wantJson: true }, opts || {}));
    if (!res || res.status !== 200) throw new Error('API ' + path.split('/')[0] + ' HTTP ' + (res ? res.status : 0));
    if (res.json !== undefined && res.json !== null) return res.json;
    if (!res.text) throw new Error('API ' + path.split('/')[0] + ' empty body');
    return JSON.parse(res.text);
  }

  // ───────────────────────── Catalogue ─────────────────────────

  function slimAnime(a) {
    var titles = a.titles || {};
    var alt = [a.title, a.titleO, titles.en_jp, titles.en_us, titles.en, titles.ja_jp].filter(Boolean);
    return {
      id: a.id,
      title: cleanText(a.title || a.titleO),
      image: a.affiche || a.affiche_small || '',
      banner: a.banner || '',
      format: String(a.format || ''),
      year: /^\d{4}/.test(String(a.startDate || '')) ? Number(String(a.startDate).slice(0, 4)) : 0,
      nsfw: a.nsfw === true,
      updated: Number(a.updatedDate) || 0,
      updatedVF: Number(a.updatedDateVF) || 0,
      hasVF: hasLang(a, 'vf'),
      hasVO: hasLang(a, 'vo'),
      keys: alt.map(norm).filter(Boolean)
    };
  }

  function hasLang(a, lang) {
    var seasons = a.saisons || [];
    for (var i = 0; i < seasons.length; i++) {
      var eps = seasons[i].episodes || [];
      for (var j = 0; j < eps.length; j++) {
        var l = (eps[j].lang || {})[lang];
        if (l && Array.isArray(l.lecteurs) && l.lecteurs.length) return true;
      }
    }
    return false;
  }

  async function loadCatalogue() {
    if (catalogueCache && Date.now() - catalogueAt < CATALOGUE_TTL_MS) return catalogueCache;
    if (cataloguePromise) return cataloguePromise;
    cataloguePromise = (async function () {
      try {
        var data = await apiJson('animes', { timeoutMs: 25000, maxBytesHint: 16 * 1024 * 1024 });
        if (!Array.isArray(data) || !data.length) throw new Error('empty catalogue');
        var slim = [];
        for (var i = 0; i < data.length; i++) {
          if (data[i] && data[i].id != null) slim.push(slimAnime(data[i]));
        }
        catalogueCache = slim;
        catalogueAt = Date.now();
        log('catalogue loaded: ' + slim.length + ' titles');
        return slim;
      } catch (e) {
        log('catalogue unavailable: ' + (e && e.message ? e.message : e));
        return catalogueCache; // stale cache if any, else null
      } finally {
        cataloguePromise = null;
      }
    })();
    return cataloguePromise;
  }

  function hrefFor(id) {
    return 'franime:anime:' + id;
  }

  function parseAnimeRef(value) {
    var raw = decodeURIComponent(String(value || ''));
    var m = raw.match(/franime:(?:anime|ep):(\d+)/i) || raw.match(/[?&]fid=(\d+)/i);
    return m ? m[1] : null;
  }

  function card(item) {
    return { title: item.title, href: hrefFor(item.id), image: item.image };
  }

  // ───────────────────────── Search ─────────────────────────

  async function kitsuFallbackSearch(query) {
    // Used only if the FRAnime catalogue cannot be loaded. FRAnime ids are Kitsu ids
    // for ~91% of titles; each hit is confirmed against FRAnime before it is shown.
    var res = await request('https://kitsu.io/api/edge/anime?page[limit]=10&filter[text]=' + encodeURIComponent(query),
      { Accept: 'application/vnd.api+json' }, { timeoutMs: 12000 });
    if (!res || res.status !== 200) return [];
    var rows = [];
    try { rows = (JSON.parse(res.text).data || []); } catch (_) { return []; }
    var out = [];
    await Promise.all(rows.slice(0, 8).map(async function (row) {
      try {
        var a = await getAnime(row.id);
        if (a && !a.nsfw) out.push(card(slimAnime(a)));
      } catch (_) {}
    }));
    return out;
  }

  function scoreItem(item, q, tokens) {
    var best = 0;
    for (var i = 0; i < item.keys.length; i++) {
      var k = item.keys[i];
      var s = 0;
      if (k === q) s = 100;
      else if (k.indexOf(q) === 0) s = 80;
      else if (k.indexOf(q) >= 0) s = 60;
      else if (tokens.every(function (t) { return k.indexOf(t) >= 0; })) s = 40;
      if (s > best) best = s;
    }
    return best;
  }

  async function searchResults(query) {
    var q = norm(query);
    var cat = await loadCatalogue();
    if (!q) {
      var home = await discoveryFeed('top', 1);
      return home.items || [];
    }
    if (!cat) return kitsuFallbackSearch(query);
    var tokens = q.split(' ').filter(Boolean);
    var scored = [];
    for (var i = 0; i < cat.length; i++) {
      var it = cat[i];
      if (it.nsfw) continue;
      var s = scoreItem(it, q, tokens);
      if (s > 0) scored.push({ it: it, s: s });
    }
    scored.sort(function (a, b) {
      return b.s - a.s || (b.it.format === 'TV') - (a.it.format === 'TV') || a.it.title.length - b.it.title.length || b.it.year - a.it.year;
    });
    return scored.slice(0, 40).map(function (x) { return card(x.it); });
  }

  // ───────────────────────── Details & episodes ─────────────────────────

  async function getAnime(id) {
    var key = String(id);
    var hit = detailsCache[key];
    if (hit && Date.now() - hit.at < DETAILS_TTL_MS) return hit.data;
    var data = await apiJson('anime-by-id/' + encodeURIComponent(key), { timeoutMs: 20000 });
    if (!data || data.id == null) throw new Error('anime not found');
    var keys = Object.keys(detailsCache);
    if (keys.length > 40) delete detailsCache[keys[0]];
    detailsCache[key] = { at: Date.now(), data: data };
    return data;
  }

  async function extractDetails(urlOrId) {
    var id = parseAnimeRef(urlOrId);
    if (!id) return { title: '', description: '' };
    var a = await getAnime(id);
    var langs = [];
    if (hasLang(a, 'vo')) langs.push('VOSTFR');
    if (hasLang(a, 'vf')) langs.push('VF');
    var episodes = 0;
    (a.saisons || []).forEach(function (s) { episodes += (s.episodes || []).length; });
    var info = [String(a.format || ''), a.startDate ? String(a.startDate).slice(0, 4) : '', a.status || '', langs.join(' / ')]
      .filter(Boolean).join(' · ');
    var desc = cleanText(a.description);
    return {
      title: cleanText(a.title || a.titleO),
      description: desc || info,
      image: a.affiche || '',
      poster: a.affiche || '',
      banner: a.banner || '',
      backdrop: a.banner || '',
      aliases: cleanText(a.titleO || ''),
      airdate: a.startDate || '',
      status: a.status || '',
      genres: Array.isArray(a.themes) ? a.themes.slice(0, 8) : [],
      rating: Number(a.note) || undefined,
      isMovie: /^(film|movie)$/i.test(String(a.format || '')) && episodes <= 1,
      episodeCount: episodes,
      languages: langs
    };
  }

  function langPlayers(ep, lang) {
    var l = ((ep && ep.lang) || {})[lang];
    return l && Array.isArray(l.lecteurs) ? l.lecteurs : [];
  }

  function supportedIndexes(players) {
    var out = [];
    HOST_ORDER.forEach(function (host) {
      players.forEach(function (name, idx) {
        if (String(name).toLowerCase() === host) out.push({ host: host, index: idx });
      });
    });
    return out;
  }

  function titleNumber(title) {
    var m = String(title || '').match(/(\d+(?:[.,]\d+)?)(?!.*\d)/);
    return m ? Number(m[1].replace(',', '.')) : NaN;
  }

  // Splits a season into numbered main episodes and specials.
  // Main episodes keep the source's own numbering (One Piece arcs continue at 62,
  // 144, ...) when every whole-numbered title is >= 1 and strictly increasing;
  // otherwise they are numbered by position. Fractional titles such as
  // "Épisode 1004.5" are specials: the app needs whole, unique numbers, so they
  // are listed in a separate "Spéciaux" season instead of colliding with 1004.
  function planSeason(eps) {
    var nums = eps.map(function (e) { return titleNumber(e.title); });
    var main = [], specials = [];
    nums.forEach(function (n, i) {
      if (!isNaN(n) && Math.floor(n) !== n) specials.push(i); else main.push(i);
    });
    var mainNums = main.map(function (i) { return nums[i]; });
    var ok = mainNums.length > 0 && mainNums.every(function (n, k) { return n >= 1 && (k === 0 || n > mainNums[k - 1]); });
    if (!ok) return { main: eps.map(function (_, i) { return { index: i, number: i + 1 }; }), specials: [] };
    return {
      main: main.map(function (i, k) { return { index: i, number: mainNums[k] }; }),
      specials: specials
    };
  }

  async function extractEpisodes(seriesId) {
    var id = parseAnimeRef(seriesId);
    if (!id) return [];
    var a = await getAnime(id);
    var seasons = a.saisons || [];
    var multi = seasons.length > 1;
    var isFilm = /^(film|movie)$/i.test(String(a.format || ''));
    var single = isFilm && seasons.length === 1 && (seasons[0].episodes || []).length === 1;
    var out = [];
    var specials = [];

    function row(season, si, ei, number, seasonNo) {
      var ep = season.episodes[ei];
      var vo = supportedIndexes(langPlayers(ep, 'vo')).length > 0;
      var vf = supportedIndexes(langPlayers(ep, 'vf')).length > 0;
      if (!vo && !vf) return null; // nothing playable in either language
      var label = cleanText(ep.title) || ('Épisode ' + number);
      if (single) label = cleanText(a.title || a.titleO);
      else if (multi) label = cleanText(season.title) + ' – ' + label;
      return {
        number: number,
        season: seasonNo,
        title: label,
        href: 'franime:ep:' + id + ':' + si + ':' + ei,
        subAvailable: vo,
        dubAvailable: vf,
        isMovie: single
      };
    }

    seasons.forEach(function (season, si) {
      var plan = planSeason(season.episodes || []);
      plan.main.forEach(function (m) {
        var r = row(season, si, m.index, m.number, si + 1);
        if (r) out.push(r);
      });
      plan.specials.forEach(function (ei) { specials.push({ season: season, si: si, ei: ei }); });
    });
    var specialSeason = seasons.length + 1;
    specials.forEach(function (sp, k) {
      var r = row(sp.season, sp.si, sp.ei, k + 1, specialSeason);
      if (r) {
        r.title = 'Spéciaux – ' + (multi ? cleanText(sp.season.title) + ' – ' : '') + (cleanText(sp.season.episodes[sp.ei].title) || ('Spécial ' + (k + 1)));
        out.push(r);
      }
    });
    return out;
  }

  // ───────────────────────── Player link decoding ─────────────────────────

  function b64decode(input) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var str = String(input).replace(/[^A-Za-z0-9+/]/g, '');
    var out = '';
    var buffer = 0, bits = 0;
    for (var i = 0; i < str.length; i++) {
      buffer = (buffer << 6) | chars.indexOf(str.charAt(i));
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out += String.fromCharCode((buffer >> bits) & 0xff);
      }
    }
    return out;
  }

  // The API answers with franime.fr/watch2/?a=..&b=..; `b` is the embed URL as
  // base64(hex(bytes XOR k)) with a one-byte key. Every embed URL starts with "h".
  function decodeWatchLink(link) {
    var m = String(link || '').match(/[?&]b=([^&]+)/);
    if (!m) return null;
    var hex = b64decode(decodeURIComponent(m[1]));
    if (!/^[0-9a-f]+$/i.test(hex) || hex.length % 2) return null;
    var bytes = [];
    for (var i = 0; i < hex.length; i += 2) bytes.push(parseInt(hex.substr(i, 2), 16));
    var key = bytes[0] ^ 0x68;
    var url = bytes.map(function (b) { return String.fromCharCode(b ^ key); }).join('');
    return /^https:\/\/[a-z0-9.-]+\//i.test(url) ? url : null;
  }

  async function embedFor(id, si, ei, lang, index) {
    var res = await request(API + 'anime/' + id + '/' + si + '/' + ei + '/' + lang + '/' + index,
      Object.assign({}, API_HEADERS, { 'Content-Type': 'application/json' }), { timeoutMs: 12000 });
    if (!res || res.status !== 200) return null;
    return decodeWatchLink(res.text.trim());
  }

  // ───────────────────────── Host resolvers ─────────────────────────

  async function resolveVidmoly(embed) {
    var url = embed;
    var res = await request(url, { Referer: SITE + '/' }, { timeoutMs: 12000 });
    if (!res || res.status !== 200) return null;
    var m = res.text.match(/sources\s*:\s*\[\s*\{[^}]*?file\s*:\s*["']([^"']+\.m3u8[^"']*)["']/i) ||
      res.text.match(/["'](https?:\/\/[^"']+\/master\.m3u8\?[^"']+)["']/i);
    if (!m) return null;
    var origin = (url.match(/^https?:\/\/[^/]+/i) || [''])[0];
    return { url: m[1], streamType: 'hls', headers: { 'User-Agent': UA, Referer: origin + '/', Origin: origin } };
  }

  async function resolveSendvid(embed) {
    var url = embed.replace('/embed/embed/', '/embed/');
    var res = await request(url, { Referer: SITE + '/' }, { timeoutMs: 12000 });
    if (!res || res.status !== 200) return null;
    var m = res.text.match(/<source[^>]+src=["']([^"']+\.mp4[^"']*)["']/i) ||
      res.text.match(/og:video(?::secure_url)?["']\s+content=["']([^"']+\.mp4[^"']*)["']/i);
    if (!m) return null;
    return {
      url: absolute(m[1].replace(/&amp;/g, '&'), url),
      streamType: 'mp4',
      headers: { 'User-Agent': UA, Referer: 'https://sendvid.com/', Accept: 'video/mp4,video/*,*/*' }
    };
  }

  async function resolveSibnet(embed) {
    var res = await request(embed, { Referer: SITE + '/' }, { timeoutMs: 12000 });
    if (!res || res.status !== 200) return null;
    var m = res.text.match(/player\.src\(\[\{src:\s*"([^"]+\.mp4[^"]*)"/i);
    if (!m) return null;
    var raw = absolute(m[1], 'https://video.sibnet.ru/');
    var headers = { 'User-Agent': UA, Referer: embed, Accept: 'video/mp4,video/*,*/*' };
    // Sibnet answers the /v/ URL with a 302 to signed storage; follow it once.
    var probe = await request(raw, Object.assign({ Range: 'bytes=0-1' }, headers), { followRedirects: false, timeoutMs: 10000 });
    var loc = probe && probe.headers ? (probe.headers.location || probe.headers.Location) : '';
    return { url: loc ? absolute(loc, raw) : raw, streamType: 'mp4', headers: headers };
  }

  // ───────────────────────── Media validation ─────────────────────────

  async function rangeBytes(url, headers) {
    var res = await request(url, Object.assign({}, headers, { Range: 'bytes=0-4095' }), { timeoutMs: 12000, maxBytesHint: 65536 });
    if (!res) return null;
    return res;
  }

  function contentType(res) {
    var h = res.headers || {};
    return String(h['content-type'] || h['Content-Type'] || '');
  }

  async function validate(route) {
    if (route.streamType === 'mp4') {
      var r = await rangeBytes(route.url, route.headers);
      if (!r || (r.status !== 206 && r.status !== 200)) return null;
      var ct = contentType(r);
      if (/text\/html|image\//i.test(ct) || /^\s*</.test(r.text.slice(0, 20))) return null;
      if (!/video\/|octet-stream/i.test(ct) && r.text.slice(4, 8) !== 'ftyp') return null;
      route.qualities = [{ label: 'Auto', url: route.url, headers: route.headers }];
      return route;
    }
    var master = await request(route.url, route.headers, { timeoutMs: 12000 });
    if (!master || master.status !== 200 || !/^\s*#EXTM3U/.test(master.text)) return null;
    var variants = [];
    var re = /#EXT-X-STREAM-INF:([^\r\n]*)[\r\n]+([^#\r\n][^\r\n]*)/g;
    var m;
    while ((m = re.exec(master.text))) {
      var height = Number((m[1].match(/RESOLUTION=\d+x(\d+)/i) || [])[1]) || 0;
      variants.push({ label: height ? height + 'p' : 'Auto', height: height, url: absolute(m[2].trim(), master.url || route.url), headers: route.headers });
    }
    var media = variants.length ? variants[0] : { url: master.url || route.url };
    var playlist = variants.length ? await request(media.url, route.headers, { timeoutMs: 12000 }) : master;
    if (!playlist || playlist.status !== 200 || !/#EXTINF:/.test(playlist.text)) return null;
    var seg = playlist.text.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(function (x) { return x && x.charAt(0) !== '#'; })[0];
    if (!seg) return null;
    var segRes = await rangeBytes(absolute(seg, playlist.url || media.url), route.headers);
    if (!segRes || (segRes.status !== 200 && segRes.status !== 206)) return null;
    var sct = contentType(segRes);
    if (/text\/html|image\//i.test(sct) || /^\s*</.test(segRes.text.slice(0, 20))) return null;
    variants.sort(function (a, b) { return (b.height || 0) - (a.height || 0); });
    route.qualities = variants.length ? variants : [{ label: 'Auto', url: route.url, headers: route.headers }];
    return route;
  }

  // ───────────────────────── Streams ─────────────────────────

  function parseEpisodeRef(href) {
    var m = String(href || '').match(/franime:ep:(\d+):(\d+):(\d+)/i);
    return m ? { id: m[1], si: Number(m[2]), ei: Number(m[3]) } : null;
  }

  async function extractStreamUrl(episodeHref, lang) {
    var ref = parseEpisodeRef(episodeHref);
    var wanted = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';
    var empty = { streams: [], subtitles: [], lang: wanted };
    if (!ref) return empty;
    var sourceLang = wanted === 'dub' ? 'vf' : 'vo';
    var a = await getAnime(ref.id);
    var ep = (((a.saisons || [])[ref.si] || {}).episodes || [])[ref.ei];
    if (!ep) return empty;
    // Never substitute: a VF request only ever tries VF players, VOSTFR only VOSTFR.
    var candidates = supportedIndexes(langPlayers(ep, sourceLang));
    if (!candidates.length) {
      log('no ' + sourceLang.toUpperCase() + ' player for ' + ref.id + ' s' + ref.si + ' e' + ref.ei);
      return empty;
    }
    var deadline = Date.now() + 25000;
    for (var i = 0; i < candidates.length && Date.now() < deadline; i++) {
      var c = candidates[i];
      try {
        var embed = await embedFor(ref.id, ref.si, ref.ei, sourceLang, c.index);
        if (!embed) continue;
        var route = null;
        // Dispatch on the API's player name: vidmoly is also served from mirrors
        // such as ansembed.net, so the embed domain alone is not reliable.
        if (c.host === 'vidmoly') route = await resolveVidmoly(embed);
        else if (c.host === 'sendvid') route = await resolveSendvid(embed);
        else if (c.host === 'sibnet') route = await resolveSibnet(embed);
        if (!route) { log(c.host + ' unresolved'); continue; }
        var ok = await validate(route);
        if (!ok) { log(c.host + ' failed media check'); continue; }
        var name = c.host.charAt(0).toUpperCase() + c.host.slice(1) + ' ' + (sourceLang === 'vf' ? 'VF' : 'VOSTFR');
        var server = {
          id: 'server-1',
          name: name,
          lang: wanted,
          url: ok.qualities[0].url,
          headers: ok.headers,
          streamType: ok.streamType,
          qualities: ok.qualities,
          streams: ok.qualities.reduce(function (acc, q) { return acc.concat([q.label, q.url]); }, []),
          subtitles: []
        };
        // One validated route only: several concurrent routes caused double audio in the app.
        return {
          streams: server.streams,
          url: server.url,
          headers: server.headers,
          streamType: server.streamType,
          qualities: server.qualities,
          defaultQuality: server.qualities[0].label,
          servers: [server],
          subtitles: [],
          lang: wanted,
          audioLanguage: sourceLang === 'vf' ? 'fr' : 'ja',
          subtitleLanguage: sourceLang === 'vf' ? undefined : 'fr'
        };
      } catch (e) {
        log(c.host + ' error: ' + (e && e.message ? e.message : e));
      }
    }
    return empty;
  }

  // ───────────────────────── Discovery ─────────────────────────

  var FEEDS = {
    top: { title: 'Top de la semaine', style: 'hero' },
    'latest-vostfr': { title: 'Derniers ajouts VOSTFR', style: 'poster' },
    'latest-vf': { title: 'Derniers ajouts VF', style: 'poster' },
    films: { title: 'Films', style: 'poster' }
  };

  async function feedItems(feedId) {
    var cat = await loadCatalogue();
    if (!cat) return [];
    var safe = cat.filter(function (x) { return !x.nsfw; });
    if (feedId === 'top') {
      var top = [];
      try { top = await apiJson('top/animes/weekly', { timeoutMs: 12000 }); } catch (_) { top = []; }
      var byId = Object.create(null);
      safe.forEach(function (x) { byId[String(x.id)] = x; });
      var ranked = (Array.isArray(top) ? top : []).map(function (t) { return byId[String(t.id)]; }).filter(Boolean);
      if (ranked.length) return ranked;
      return safe.slice().sort(function (a, b) { return b.updated - a.updated; });
    }
    if (feedId === 'latest-vf') {
      return safe.filter(function (x) { return x.hasVF; }).sort(function (a, b) { return b.updatedVF - a.updatedVF; });
    }
    if (feedId === 'films') {
      return safe.filter(function (x) { return /^(film|movie)$/i.test(x.format); }).sort(function (a, b) { return b.year - a.year || b.updated - a.updated; });
    }
    return safe.filter(function (x) { return x.hasVO; }).sort(function (a, b) { return b.updated - a.updated; });
  }

  async function discoveryHome() {
    try {
      var keys = Object.keys(FEEDS);
      var lists = await Promise.all(keys.map(function (k) { return feedItems(k).catch(function () { return []; }); }));
      var sections = [];
      keys.forEach(function (k, i) {
        var items = lists[i].slice(0, 20).map(card);
        if (!items.length) return;
        sections.push({ id: k, title: FEEDS[k].title, style: FEEDS[k].style, items: items, viewAll: { mode: 'feed', feedId: k } });
      });
      return { sections: sections };
    } catch (e) {
      log('discoveryHome failed: ' + (e && e.message ? e.message : e));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    var id = FEEDS[String(feedId || '')] ? String(feedId) : 'top';
    var p = Math.max(1, Number(page) || 1);
    var size = 30;
    try {
      var all = await feedItems(id);
      var items = all.slice((p - 1) * size, p * size).map(card);
      return { feedId: id, page: p, items: items, hasMore: p * size < all.length };
    } catch (e) {
      return { feedId: id, page: p, items: [], hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
