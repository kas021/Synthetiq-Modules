/**
 * DramaCool Content Module for Synthetiq Player (Contract Version 4)
 * Target: https://dramacool9.com.ro
 */
(function () {
  'use strict';

  const SITE = 'https://dramacool9.com.ro';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(msg) {
    try {
      console.log('[DramaCool] ' + String(msg || ''));
    } catch (_) {}
  }

  function cleanText(v) {
    return String(v || '')
      .replace(/<script\b[\s\S]*?<\/script>/gi, '')
      .replace(/<style\b[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&#(x[\da-f]+|\d+);/gi, function (_, n) {
        const num = n[0].toLowerCase() === 'x' ? parseInt(n.slice(1), 16) : Number(n);
        return num > 0 && num <= 0x10ffff ? String.fromCodePoint(num) : '';
      })
      .replace(/&(amp|quot|apos|nbsp|lt|gt);/g, function (_, n) {
        return { amp: '&', quot: '"', apos: "'", nbsp: ' ', lt: '<', gt: '>' }[n] || '';
      })
      .replace(/\s+/g, ' ')
      .trim();
  }

  function attr(tag, name) {
    const m = String(tag || '').match(
      new RegExp('(?:^|\\s)' + name + '\\s*=\\s*(["\'])([\\s\\S]*?)\\1', 'i')
    );
    return m ? cleanText(m[2]) : '';
  }

  function absolute(url, base) {
    const v = String(url || '').trim().replace(/&amp;/g, '&');
    if (!v || /^(?:javascript|mailto|tel|data):/i.test(v)) return '';
    if (/^https?:\/\//i.test(v)) return v;
    if (/^\/\//.test(v)) return 'https:' + v;
    const root = (base || SITE).match(/^https?:\/\/[^/]+/i);
    if (!root) return '';
    if (v[0] === '/') return root[0] + v;
    return (base || SITE + '/').replace(/[?#].*$/, '').replace(/[^/]*$/, '') + v;
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      cfg.headers || {}
    );
    const body = cfg.body || null;

    if (typeof fetchv2 === 'function') {
      const res = await fetchv2(url, headers, method, body, {
        followRedirects: cfg.followRedirects !== false,
        timeoutMs: cfg.timeoutMs || 20000,
      });
      const textBody = typeof res.text === 'function' ? await res.text() : (res.body || '');
      const ok = !!(res && (res.ok || (res.status >= 200 && res.status < 300)));
      return {
        ok: ok,
        status: Number((res && res.status) || 0),
        text: textBody,
        headers: (res && res.headers) || {},
        finalUrl: (res && (res.finalUrl || res.url)) || url,
      };
    }

    if (typeof fetch === 'function') {
      const res = await fetch(url, {
        method: method,
        headers: headers,
        body: body,
        redirect: cfg.followRedirects === false ? 'manual' : 'follow',
      });
      const textBody = await res.text();
      return {
        ok: res.ok,
        status: Number(res.status || 0),
        text: textBody,
        headers: Object.fromEntries(res.headers.entries()),
        finalUrl: res.url || url,
      };
    }

    throw new Error('No HTTP transport available');
  }

  function parseCards(html) {
    const out = [];
    const seen = new Set();
    const re = /<a\b([^>]*\bclass=["'][^"']*\bmask\b[^"']*["'][^>]*)>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(html))) {
      const href = absolute(attr(m[1], 'href'));
      if (!href || seen.has(href)) continue;
      const title = attr(m[1], 'title') || cleanText((m[2].match(/<h[2-4][^>]*>([\s\S]*?)<\/h[2-4]>/i) || [])[1]);
      if (!title) continue;
      const imgTag = (m[2].match(/<img\b[^>]*>/i) || [''])[0];
      const image = absolute(attr(imgTag, 'data-original') || attr(imgTag, 'data-src') || attr(imgTag, 'src'));
      seen.add(href);
      out.push({ id: href, title: title, image: image, href: href });
    }
    return out;
  }

  async function discoveryHome() {
    const res = await request(SITE + '/');
    const cards = parseCards(res.text);

    // Filter into sections (Hero cap is 8 items)
    const used = new Set();
    const featured = cards.slice(0, 8);
    featured.forEach(function (x) { used.add(x.id); });

    const recentDramas = cards.filter(function (x) { return !used.has(x.id); }).slice(0, 20);
    recentDramas.forEach(function (x) { used.add(x.id); });

    const sections = [
      {
        id: 'featured',
        title: 'Popular & Latest Dramas',
        style: 'hero',
        items: featured,
      },
      {
        id: 'recent-updates',
        title: 'Recently Updated',
        style: 'poster',
        items: recentDramas,
        viewAll: { mode: 'feed', feedId: 'recent-updates' },
      }
    ];

    // Fetch Korean country section if available
    try {
      const krRes = await request(SITE + '/country/korean');
      const krCards = parseCards(krRes.text).filter(function (x) { return !used.has(x.id); }).slice(0, 20);
      if (krCards.length) {
        sections.push({
          id: 'korean-dramas',
          title: 'Korean Dramas',
          style: 'poster',
          items: krCards,
          viewAll: { mode: 'feed', feedId: 'korean-dramas' },
        });
      }
    } catch (_) {}

    return {
      sections: sections.filter(function (s) { return s.items.length > 0; })
    };
  }

  async function discoveryFeed(feedId, page) {
    const pageNum = Math.max(1, Number(page) || 1);
    const fid = String(feedId || '').toLowerCase();

    let targetUrl = SITE + '/';
    if (fid === 'korean-dramas' || fid === 'korean') {
      targetUrl = SITE + '/country/korean/' + (pageNum > 1 ? 'page/' + pageNum + '/' : '');
    } else if (fid === 'chinese-dramas' || fid === 'chinese') {
      targetUrl = SITE + '/country/chinese/' + (pageNum > 1 ? 'page/' + pageNum + '/' : '');
    } else if (fid === 'japanese-dramas' || fid === 'japanese') {
      targetUrl = SITE + '/country/japanese/' + (pageNum > 1 ? 'page/' + pageNum + '/' : '');
    } else {
      targetUrl = SITE + '/' + (pageNum > 1 ? 'page/' + pageNum + '/' : '');
    }

    const res = await request(targetUrl);
    const items = parseCards(res.text).slice(0, 40);

    return {
      items: items,
      page: pageNum,
      hasMore: items.length >= 10,
    };
  }

  async function searchResults(query) {
    const q = cleanText(query || '');
    if (!q) return [];
    const url = SITE + '/?s=' + encodeURIComponent(q);
    const res = await request(url);
    return parseCards(res.text);
  }

  async function extractDetails(urlOrId) {
    const url = absolute(urlOrId);
    if (!url) throw new Error('Invalid drama URL');
    const res = await request(url);
    const html = res.text;

    const title = cleanText((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1]) ||
                  cleanText((html.match(/<h2[^>]*class=["'][^"']*title[^"']*["'][^>]*>([\s\S]*?)<\/h2>/i) || [])[1]);

    const synopsis = cleanText(
      (html.match(/<div\b[^>]*class=["'][^"']*\bsynopsis\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i) || [])[1] ||
      (html.match(/<div\b[^>]*class=["'][^"']*\bdesc\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i) || [])[1]
    ).replace(/^Synopsis:\s*/i, '');

    const posterTag = (html.match(/<img\b[^>]*class=["'][^"']*\bwp-post-image\b[^"']*["'][^>]*>/i) || [''])[0];
    const image = absolute(attr(posterTag, 'data-original') || attr(posterTag, 'src'));

    const genres = [];
    const genreMatches = [...html.matchAll(/<a\b[^>]*href=["'][^"']*\/genre\/([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)];
    genreMatches.forEach(function (m) {
      const g = cleanText(m[2]);
      if (g && !genres.includes(g)) genres.push(g);
    });

    return {
      title: title || 'Drama Details',
      description: synopsis,
      image: image,
      genres: genres,
      rating: '',
      href: url,
    };
  }

        async function extractEpisodes(seriesId) {
    const url = absolute(seriesId);
    if (!url) return [];
    const res = await request(url);
    const html = res.text;

    const title = cleanText((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1]);
    const seasonMatch = title.match(/(?:Season|Staffel|S)\s*(\d+)/i);
    const season = seasonMatch ? Number(seasonMatch[1]) : 1;

    // Get drama slug from URL (e.g. 'vincenzo-2021' from 'vincenzo-2021-hd')
    const slugMatch = url.match(/\/([^/?#]+?)(?:-hd|-csdcd)?(?:\.html)?$/i);
    const dramaSlug = slugMatch ? slugMatch[1] : '';

    const episodes = [];
    const seenNumbers = new Set();
    const epRe = /<a\b([^>]*\bhref=['"]([^'"]*-episode-(\d+)\.html)['"][^>]*)>([\s\S]*?)<\/a>/gi;
    let m;

    while ((m = epRe.exec(html))) {
      const epHref = absolute(m[2]);
      const epNum = Number(m[3]);
      if (!epHref || isNaN(epNum) || seenNumbers.has(epNum)) continue;

      // Filter out unrelated sidebar dramas if dramaSlug is known
      if (dramaSlug && !epHref.includes(dramaSlug.slice(0, 12))) continue;

      seenNumbers.add(epNum);
      const epTitle = cleanText(m[4]) || ('Episode ' + epNum);
      const isDub = /\b(?:dub|raw)\b/i.test(epTitle);
      episodes.push({
        number: epNum,
        season: season,
        title: epTitle,
        href: epHref,
        subAvailable: true,
        dubAvailable: isDub,
      });
    }

    // Sort episodes in natural ascending order (Episode 1, 2, 3...)
    episodes.sort(function (a, b) { return a.number - b.number; });

    // Fallback if detail page only contains a movie player
    if (!episodes.length && /<iframe\b/i.test(html)) {
      episodes.push({
        number: 1,
        season: 1,
        title: title || 'Movie',
        href: url,
        subAvailable: true,
        dubAvailable: false,
      });
    }

    return episodes;
  }

  // --- Embed Stream Resolvers ---

  async function resolveVidmoly(embedUrl) {
    const res = await request(embedUrl, {
      headers: { Referer: SITE + '/' },
      timeoutMs: 12000,
    });
    const html = res.text;
    const fileMatch = html.match(/sources:\s*\[\s*\{\s*file:\s*['"]([^'"]+)['"]/i) ||
                      html.match(/file:\s*['"]([^'"]+\.m3u8[^'"]*)['"]/i) ||
                      html.match(/(https?:\/\/[^'"\s]+\.m3u8[^'"\s]*)/i);
    if (!fileMatch) return null;
    const m3u8Url = fileMatch[1];
    const streamHeaders = {
      'User-Agent': USER_AGENT,
      Referer: 'https://vidmoly.net/',
      Origin: 'https://vidmoly.net',
    };

    // Verify HLS master playlist
    const probe = await request(m3u8Url, { headers: streamHeaders, timeoutMs: 10000 });
    if (!probe.ok || probe.text.indexOf('#EXTM3U') !== 0) return null;

    return {
      url: m3u8Url,
      stream: m3u8Url,
      streams: [
        { label: 'Vidmoly HD (Sub)', url: m3u8Url, quality: 1080, streamType: 'hls', headers: streamHeaders }
      ],
      qualities: [
        { label: '1080p HD', url: m3u8Url, height: 1080, headers: streamHeaders }
      ],
      headers: streamHeaders,
      quality: '1080p',
      lang: 'sub',
      streamType: 'hls',
      subtitles: [],
    };
  }

  async function resolveMegaPlay(embedUrl) {
    const res = await request(embedUrl, {
      headers: { Referer: SITE + '/' },
      timeoutMs: 12000,
    });
    const fileMatch = res.text.match(/file:\s*["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/i);
    if (!fileMatch) return null;
    const m3u8Url = fileMatch[1];
    const streamHeaders = {
      'User-Agent': USER_AGENT,
      Referer: 'https://megaplay.su/',
      Origin: 'https://megaplay.su',
    };

    const probe = await request(m3u8Url, { headers: streamHeaders, timeoutMs: 10000 });
    if (!probe.ok || probe.text.indexOf('#EXTM3U') !== 0) return null;

    return {
      url: m3u8Url,
      stream: m3u8Url,
      streams: [
        { label: 'MegaPlay HD (Sub)', url: m3u8Url, quality: 720, streamType: 'hls', headers: streamHeaders }
      ],
      qualities: [
        { label: '720p', url: m3u8Url, height: 720, headers: streamHeaders }
      ],
      headers: streamHeaders,
      quality: '720p',
      lang: 'sub',
      streamType: 'hls',
      subtitles: [],
    };
  }

  async function resolveStreamTape(embedUrl) {
    const res = await request(embedUrl, {
      headers: { Referer: SITE + '/' },
      timeoutMs: 12000,
    });
    const html = res.text;
    const blobMatch = html.match(/\('([^']+)'\)((?:\.substring\(\d+\))+)/);
    if (!blobMatch) return null;
    const rawHead = html.slice(0, html.indexOf("('"));
    let prefix = '';
    const prefixRe = /['"]([^'"]*)['"]/g;
    let pm;
    while ((pm = prefixRe.exec(rawHead))) {
      if (pm[1].includes('tapecontent.net') || pm[1].includes('streamtape.com')) {
        prefix = pm[1];
      }
    }
    let body = blobMatch[1];
    const subs = [...blobMatch[2].matchAll(/\.substring\((\d+)\)/g)];
    for (const sm of subs) {
      body = body.substring(Number(sm[1]));
    }
    let directUrl = prefix + body;
    if (directUrl.startsWith('//')) directUrl = 'https:' + directUrl;
    if (!/^https:\/\//i.test(directUrl)) return null;

    const streamHeaders = {
      'User-Agent': USER_AGENT,
      Referer: 'https://streamtape.com/',
    };

    return {
      url: directUrl,
      stream: directUrl,
      streams: [
        { label: 'StreamTape (1080p MP4)', url: directUrl, quality: 1080, streamType: 'mp4', headers: streamHeaders }
      ],
      qualities: [
        { label: '1080p', url: directUrl, height: 1080, headers: streamHeaders }
      ],
      headers: streamHeaders,
      quality: '1080p',
      lang: 'sub',
      streamType: 'mp4',
      subtitles: [],
    };
  }

  function unpackDeanEdwards(p, a, c, k) {
    function e(c) {
      return (c < a ? '' : e(parseInt(c / a, 10))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
    }
    let count = c;
    let unpacked = p;
    while (count--) {
      if (k[count]) {
        unpacked = unpacked.replace(new RegExp('\\b' + e(count) + '\\b', 'g'), k[count]);
      }
    }
    return unpacked;
  }

  async function resolveVidHide(embedUrl) {
    const res = await request(embedUrl, {
      headers: { Referer: SITE + '/' },
      timeoutMs: 12000,
    });
    const html = res.text;
    let m3u8Url = '';
    const subtitles = [];

    const m = html.match(/eval\(function\(p,a,c,k,e,d\)[\s\S]*?\}\((['"][\s\S]*?['"]),\s*(\d+),\s*(\d+),\s*(['"][\s\S]*?['"])\.split\('\|'\)/);
    if (m) {
      try {
        const p = (new Function('return ' + m[1]))();
        const a = parseInt(m[2], 10);
        const c = parseInt(m[3], 10);
        const k = (new Function('return ' + m[4]))().split('|');
        const unpacked = unpackDeanEdwards(p, a, c, k);

        const m3u8Match = unpacked.match(/https?:\/\/[^'"\s]+\.m3u8[^'"\s]*/i) ||
                          unpacked.match(/sources:\s*\[\s*\{\s*file:\s*['"]([^'"]+)['"]/i) ||
                          unpacked.match(/file:\s*['"]([^'"]+)['"]/i);
        if (m3u8Match) {
          m3u8Url = m3u8Match[1] || m3u8Match[0];
        }

        const vttMatches = [...unpacked.matchAll(/https?:\/\/[^'"\s]+\.vtt/gi)];
        vttMatches.forEach(function (v) {
          if (!subtitles.some(function (s) { return s.file === v[0]; })) {
            subtitles.push({ label: 'English', file: v[0], kind: 'captions' });
          }
        });
      } catch (_) {}
    }

    if (!m3u8Url) {
      const direct = html.match(/https?:\/\/[^'"\s]+\.m3u8[^'"\s]*/i);
      if (direct) m3u8Url = direct[0];
    }

    if (!m3u8Url) return null;

    const origin = embedUrl.replace(/^(https?:\/\/[^/]+).*$/, '$1');
    const streamHeaders = {
      'User-Agent': USER_AGENT,
      Referer: embedUrl,
      Origin: origin,
    };

    const probe = await request(m3u8Url, { headers: streamHeaders, timeoutMs: 10000 });
    if (!probe.ok || probe.text.indexOf('#EXTM3U') !== 0) return null;

    return {
      url: m3u8Url,
      stream: m3u8Url,
      streams: [
        { label: 'VidHide HD (Sub)', url: m3u8Url, quality: 720, streamType: 'hls', headers: streamHeaders }
      ],
      qualities: [
        { label: '720p', url: m3u8Url, height: 720, headers: streamHeaders }
      ],
      headers: streamHeaders,
      quality: '720p',
      lang: 'sub',
      streamType: 'hls',
      subtitles: subtitles,
    };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = absolute(episodeHref);
    if (!url) throw new Error('Invalid episode URL');

    const res = await request(url);
    const html = res.text;

    // Collect all candidate server embed URLs
    const candidates = [];
    const iframeMatches = [...html.matchAll(/<iframe\b[^>]*\bsrc=["']([^"']+)["']/gi)];
    iframeMatches.forEach(function (f) {
      if (/^https?:\/\//i.test(f[1]) && !candidates.includes(f[1])) candidates.push(f[1]);
    });

    const btnMatches = [...html.matchAll(/<(?:button|li|a)\b[^>]*(?:data-src|data-video)=["']([^"']+)["']/gi)];
    btnMatches.forEach(function (b) {
      if (/^https?:\/\//i.test(b[1]) && !candidates.includes(b[1])) candidates.push(b[1]);
    });

    log('Found ' + candidates.length + ' server candidate(s)');

    // Prioritize Vidmoly, VidHide (minochinos etc.), MegaPlay, StreamTape
    candidates.sort(function (a, b) {
      function score(u) {
        if (/vidmoly/i.test(u)) return 4;
        if (/minochinos|vidhide|filelions|streamwish/i.test(u)) return 3;
        if (/megaplay/i.test(u)) return 2;
        if (/streamtape|watchadsontape/i.test(u)) return 1;
        return 0;
      }
      return score(b) - score(a);
    });

    for (const embedUrl of candidates) {
      try {
        log('Attempting resolver for embed: ' + embedUrl);
        if (/vidmoly/i.test(embedUrl)) {
          const resolved = await resolveVidmoly(embedUrl);
          if (resolved) return resolved;
        } else if (/minochinos|vidhide|filelions|streamwish/i.test(embedUrl)) {
          const resolved = await resolveVidHide(embedUrl);
          if (resolved) return resolved;
        } else if (/megaplay\.su/i.test(embedUrl)) {
          const resolved = await resolveMegaPlay(embedUrl);
          if (resolved) return resolved;
        } else if (/streamtape|watchadsontape/i.test(embedUrl)) {
          const resolved = await resolveStreamTape(embedUrl);
          if (resolved) return resolved;
        }
      } catch (err) {
        log('Resolver failed for ' + embedUrl + ': ' + err.message);
      }
    }

    throw new Error('No playable video stream found for this episode.');
  }

  // Export Contract V4 methods on globalThis
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
})();
