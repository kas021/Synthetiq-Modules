(() => {
  'use strict';

  const MODULE_NAME = 'AnimeAV1';
  const SITE = 'https://animeav1.com';
  const PLAYER_HOST = 'https://player.zilla-networks.com';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Unescape a JS string literal captured from the page state blob.
  function unescapeBlobString(value) {
    return String(value || '')
      .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16)),
      )
      .replace(/\\n/g, '\n')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\');
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  async function requestText(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers });
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw new Error('Request failed ' + (status || '') + ' for ' + url);
      }
      let text = '';
      if (res && typeof res.text === 'function') text = await res.text();
      if (!text && res && typeof res.body === 'string') text = res.body;
      return { status, text };
    };
    if (timeoutMs) {
      return settleWithin(doFetch(), timeoutMs, { status: 0, text: '' });
    }
    return doFetch();
  }

  function looksBlockedPage(html) {
    return /just a moment|attention required|parked domain|domain is for sale|access denied/i.test(
      String(html || ''),
    );
  }

  /* ------------------------------ catalogue ------------------------------ */

  function slugFromMediaUrl(url) {
    const match = String(url || '').match(/\/media\/([^/?#]+)/i);
    return match ? match[1] : '';
  }

  function titleFromSlug(slug) {
    return String(slug || '')
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const blocks = String(html || '').split('<article');
    for (let i = 1; i < blocks.length; i += 1) {
      const block = blocks[i];
      const hrefMatch = block.match(/href="\/media\/([^"/?#]+)"/i);
      if (!hrefMatch) continue;
      const slug = hrefMatch[1];
      const href = SITE + '/media/' + slug;
      if (seen[href]) continue;
      const imgMatch = block.match(
        /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i,
      );
      const h3Match = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      const altMatch = block.match(/alt="Portada de ([^"]*)"/i);
      let title = h3Match ? cleanText(h3Match[1]) : '';
      if (!title && altMatch) title = cleanText(altMatch[1]);
      if (!title) title = titleFromSlug(slug);
      if (!title) continue;
      seen[href] = true;
      out.push({ title, href, image: imgMatch ? imgMatch[1] : '' });
    }
    return out;
  }

  async function fetchCataloguePage(params, referer) {
    const query = params ? '?' + params : '';
    const res = await requestText(SITE + '/catalogo' + query, { Referer: referer || SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('catalogue page blocked');
      return { cards: [], totalPages: 0 };
    }
    // State blob carries honest pagination: pagination:{currentPage:1,
    // recordsPerPage:20,totalPages:50,totalRecords:1000}
    let totalPages = 0;
    const pageMatch = String(res.text).match(/totalPages:(\d+)/);
    if (pageMatch) totalPages = Number(pageMatch[1]);
    return { cards: parseCards(res.text), totalPages };
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    const result = term
      ? await fetchCataloguePage('search=' + encodeURIComponent(term))
      : await fetchCataloguePage('');
    return result.cards.map((card) => ({
      title: card.title,
      href: card.href,
      image: card.image,
    }));
  }

  /* ------------------------------ discovery (V4) ------------------------------ */

  // The site's genre URL parameter does not filter (returns the full 1000-title
  // catalogue regardless), so discovery rows are built from the catalogue's real
  // sort orders only — every row is a view the site itself provides.
  const DISCOVERY_FEEDS = [
    { id: 'trending', title: 'Tendencias', order: '', hero: true },
    { id: 'popular', title: 'Top 10 Populares', order: 'popular', top10: true },
    { id: 'score', title: 'Mejor Valorados', order: 'score' },
    { id: 'latest', title: 'Últimas Novedades', order: 'latest' },
  ];

  function discoveryFeedById(feedId) {
    const id = String(feedId || '').trim().toLowerCase();
    return DISCOVERY_FEEDS.find((feed) => feed.id === id) || null;
  }

  async function fetchFeedCards(feed, page) {
    const params = [];
    if (feed.order) params.push('order=' + feed.order);
    if (page > 1) params.push('page=' + page);
    return fetchCataloguePage(params.join('&'));
  }

  async function discoveryHome() {
    const settled = await Promise.all(
      DISCOVERY_FEEDS.map((feed) => fetchFeedCards(feed, 1)),
    );
    const sections = [];
    for (let i = 0; i < DISCOVERY_FEEDS.length; i += 1) {
      const feed = DISCOVERY_FEEDS[i];
      const cards = settled[i].cards;
      if (!cards.length) continue;
      const limit = feed.hero ? 8 : feed.top10 ? 10 : 20;
      sections.push({
        id: feed.id,
        title: feed.title,
        style: feed.hero ? 'hero' : feed.top10 ? 'top10' : 'poster',
        items: cards.slice(0, limit).map((card) => ({
          title: card.title,
          href: card.href,
          image: card.image,
        })),
        viewAll: { mode: 'feed', feedId: feed.id },
      });
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const feed = discoveryFeedById(feedId);
    const currentPage = Math.max(1, Number(page) || 1);
    if (!feed) return { items: [], page: currentPage, hasMore: false };
    const result = await fetchFeedCards(feed, currentPage);
    const items = result.cards.map((card) => ({
      title: card.title,
      href: card.href,
      image: card.image,
    }));
    // Honest hasMore from the site's own pagination block.
    const hasMore = result.totalPages > 0
      ? currentPage < result.totalPages
      : items.length > 0;
    return { items, page: currentPage, hasMore };
  }

  /* ------------------------------ details ------------------------------ */

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId);
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('AnimeAV1 page is blocked.');
    const html = res.text;
    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText(
      (titleMatch && titleMatch[1]) || titleFromSlug(slugFromMediaUrl(url)),
    );
    let description = '';
    const blobMatch = html.match(/synopsis:"((?:[^"\\]|\\.)*)"/);
    if (blobMatch) description = unescapeBlobString(blobMatch[1]).trim();
    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }
    const imgMatch = html.match(
      /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"[^>]*alt="[^"]*Poster"/i,
    ) || html.match(/src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i);
    return {
      title,
      description: description || 'Anime on AnimeAV1.',
      image: (imgMatch && imgMatch[1]) || '',
    };
  }

  /* ------------------------------ episodes ------------------------------ */

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId);
    const slug = slugFromMediaUrl(url);
    if (!slug) return [];
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) return [];
    // The title page state blob carries the full flat episode list:
    // episodes:[{id:3433,number:1},{id:3434,number:2},...]
    const listMatch = String(res.text).match(/episodes:\[([\s\S]*?)\]/);
    if (!listMatch) return [];
    const numbers = [];
    const seen = Object.create(null);
    const numRe = /number:(\d+)/g;
    let match;
    while ((match = numRe.exec(listMatch[1]))) {
      const n = Number(match[1]);
      if (!n || seen[n]) continue;
      seen[n] = true;
      numbers.push(n);
    }
    numbers.sort((a, b) => a - b);
    return numbers.map((n) => ({
      number: n,
      href: SITE + '/media/' + slug + '/' + n,
      title: 'Episode ' + n,
      subAvailable: true,
      dubAvailable: true,
    }));
  }

  /* ------------------------------ streams ------------------------------ */

  function streamHeaders(playId) {
    return {
      'User-Agent': USER_AGENT,
      Origin: PLAYER_HOST,
      Referer: PLAYER_HOST + '/play/' + playId,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
    };
  }

  // Episode pages embed a state blob:
  // embeds:{SUB:[{server:"HLS",url:"https://player.zilla-networks.com/play/<id>"},...],
  //         DUB:[...]},downloads:{...}
  function parseHlsEmbeds(html) {
    const raw = String(html || '');
    const bodyMatch =
      raw.match(/embeds:\{([\s\S]*?)\},downloads:/) ||
      raw.match(/embeds:\{([\s\S]*?)\}\s*\},uses:/);
    if (!bodyMatch) return {};
    const body = bodyMatch[1];
    const variants = {};
    const sectionRe = /([A-Z]{2,8}):\[([\s\S]*?)\](?=,\s*[A-Z]{2,8}:\[|$)/g;
    let section;
    while ((section = sectionRe.exec(body))) {
      const variant = section[1];
      const hls = section[2].match(
        /\{server:"HLS",url:"https:\/\/player\.zilla-networks\.com\/play\/([a-f0-9]{32})"\}/,
      );
      if (hls) variants[variant] = hls[1];
    }
    return variants;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = toAbsoluteUrl(episodeHref);
    if (!/\/media\/[^/]+\/\d+/.test(url)) {
      log('unrecognised episode href ' + episodeHref);
      return { streams: [] };
    }
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('episode page blocked for ' + url);
      return { streams: [] };
    }
    const variants = parseHlsEmbeds(res.text);
    const want = String(lang || '').toLowerCase() === 'dub' ? 'DUB' : 'SUB';
    const order = Object.keys(variants).sort((a, b) => {
      if (a === want) return -1;
      if (b === want) return 1;
      return a.localeCompare(b);
    });
    const streams = [];
    for (const variant of order) {
      const playId = variants[variant];
      streams.push({
        label: 'HLS · ' + variant,
        url: PLAYER_HOST + '/m3u8/' + playId,
        headers: streamHeaders(playId),
      });
    }
    if (!streams.length) {
      log('no HLS embeds for ' + url);
      return { streams: [] };
    }
    return {
      streams,
      headers: streams[0].headers,
      quality: 'auto',
      lang: want === 'DUB' && variants.DUB ? 'dub' : 'sub',
      streamType: 'hls',
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
