/**
 * Synthetiq Anime Direct — private test candidate (independent anime playback).
 *
 * INDEPENDENCE CONTRACT (enforced in code and asserted by tests):
 *  - Catalogue + identity: AniList GraphQL (primary) with a best-effort Jikan fallback. Both are
 *    public metadata APIs. No AniKoto page, episode API, server API or mirror is ever requested.
 *  - Identity comes from the catalogue entry the user tapped (AniList id and/or MAL id). There is
 *    no page scraping at all, so a recommendation artwork or an unrelated link can never become a
 *    playback id.
 *  - Playback: Vidhawk's public API addressed directly by AniList/MAL id.
 *      GET /api/stream/race?episode=N&audio=sub|dub&server=flow[&anilistId=..][&malId=..]
 *          -> per-server tickets (the provider's own race result) or CONTENT_UNAVAILABLE.
 *      GET /api/play?t=<ticket> -> tracks (sub/dub/jpn/hin), captions, intro/outro markers.
 *    The embed-only `parentHost` parameter is deliberately NOT sent. It belongs to the provider's
 *    embed flow (/api/embed/allow allow-check); this module never embeds. Probed on 2026-09-12:
 *    with parentHost=anicrowd.xyz, with no parentHost and with parentHost=example.com the API
 *    answers identically (same shape/size, fresh ticket each time). No AniCrowd request is made
 *    and none is required.
 *  - Hard denylist: request() refuses AniKoto/AniCrowd/AniKage/MegaPlay hosts before any network
 *    call, so the module cannot regress into a page dependency. Attempts are logged.
 *
 * RELIABILITY CONTRACT (the audit's findings, addressed here):
 *  - Episode lists are VERIFIED against the provider with a bounded probe budget (never a bare
 *    series count), per audio track, and cached. Unverified episodes are not advertised.
 *  - The first candidate that passes POSITIVE media validation wins; optional extras (second
 *    server, qualities, captions) never hold a working primary hostage.
 *  - Routes are built from one accepted-candidate list, so a rejected route cannot linger in
 *    `streams`, `servers` or `qualities`.
 *  - Per-host cooldowns honour 429/403 + Retry-After; retries are bounded; no retry storms.
 *  - URL differences never imply different audio languages: route labels come from provider track
 *    ids (spot-verified with speech sampling in QA), not from URLs.
 *  - Media validation is POSITIVE (TS sync byte / fMP4 boxes / PNG-wrapped TS), not "non-empty
 *    bytes are probably fine".
 */
(function () {
  'use strict';

  var MODULE = 'Synthetiq Anime Direct';
  var SCHEME = 'sadirect:';
  var ANILIST = 'https://graphql.anilist.co';
  var JIKAN = 'https://api.jikan.moe/v4';
  var VIDHAWK = 'https://vidhawk.buzz';
  var USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  // ------------------------------------------------------------------ independence guard
  var DENIED_HOST = /(anikoto|anicrowd|anikage|megaplay)/i;

  var trace = {
    requests: [],
    blocked: [],
    probes: 0,
    cooldowns: 0,
  };

  function hostOf(url) {
    var m = String(url || '').match(/^https?:\/\/([^\/?#]+)/i);
    return m ? m[1].toLowerCase() : '';
  }

  function isDenied(url) {
    var host = hostOf(url);
    if (!host) return false;
    return DENIED_HOST.test(host);
  }

  function log(msg) {
    try {
      console.log('[' + MODULE + '] ' + String(msg == null ? '' : msg));
    } catch (_) {}
  }

  function clean(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]+>/g, ' ')
      .replace(/&(#\d+|[a-z]+);/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // ------------------------------------------------------------------ rate limits / cooldowns
  var COOLDOWN_MS = 10 * 60 * 1000;
  var cooldownUntil = {};
  var MAX_ATTEMPTS = 2;

  function hostParked(host) {
    var until = cooldownUntil[host] || 0;
    if (until && Date.now() < until) return true;
    if (until) delete cooldownUntil[host];
    return false;
  }

  function parkHost(host, ms, why) {
    var until = Date.now() + Math.max(ms || 0, 60000);
    cooldownUntil[host] = until;
    trace.cooldowns += 1;
    log('cooldown ' + host + ' for ' + Math.round((until - Date.now()) / 1000) + 's (' + why + ')');
  }

  function retryAfterMs(response) {
    try {
      var raw = (response && response.headers && (response.headers['retry-after'] || response.headers['Retry-After'])) || '';
      var asNumber = Number(String(raw).trim());
      if (isFinite(asNumber) && asNumber > 0) return asNumber * 1000;
      var when = Date.parse(String(raw));
      if (isFinite(when) && when > Date.now()) return when - Date.now();
    } catch (_) {}
    return 0;
  }

  // ------------------------------------------------------------------ request layer
  async function readBody(response) {
    if (!response) return '';
    if (response.bodyDropped) throw new Error('Response exceeded runtime limit');
    if (response.json) {
      try {
        var parsed = typeof response.json === 'function' ? await response.json() : response.json;
        if (parsed != null) return typeof parsed === 'string' ? parsed : JSON.stringify(parsed);
      } catch (_) {}
    }
    if (typeof response.body === 'string' && response.body) return response.body;
    if (typeof response.text === 'function') {
      try {
        var text = await response.text();
        if (typeof text === 'string' && text) return text;
      } catch (_) {}
    }
    return '';
  }

  function headers(extra) {
    var out = { 'User-Agent': USER_AGENT, Accept: '*/*' };
    var src = extra || {};
    Object.keys(src).forEach(function (key) {
      out[key] = src[key];
    });
    return out;
  }

  function deadlineLeft(session) {
    if (!session) return Number.MAX_SAFE_INTEGER;
    if (session.closed) return 0;
    return Math.max(0, (session.deadline || 0) - Date.now());
  }

  async function request(url, extraHeaders, method, body, options) {
    var opts = options || {};
    var host = hostOf(url);
    if (isDenied(url)) {
      trace.blocked.push({ url: url, host: host, at: Date.now() });
      log('INDEPENDENCE BLOCK — refused a denied host request: ' + host);
      return { ok: false, status: 0, text: '', json: null, headers: {}, blocked: true };
    }
    if (hostParked(host)) {
      return { ok: false, status: 0, text: '', json: null, headers: {}, parked: true };
    }
    if (opts.session && deadlineLeft(opts.session) <= 0) {
      return { ok: false, status: 0, text: '', json: null, headers: {}, timedOut: true };
    }

    var attempt = 0;
    var last = { ok: false, status: 0, text: '', json: null, headers: {} };
    while (attempt < MAX_ATTEMPTS) {
      attempt += 1;
      var started = Date.now();
      var response = null;
      try {
        if (typeof fetchv2 === 'function') {
          response = await fetchv2(url, headers(extraHeaders), method || 'GET', body || null);
        } else if (typeof fetch === 'function') {
          response = await fetch(url, { method: method || 'GET', headers: headers(extraHeaders), body: body || undefined });
        }
      } catch (error) {
        last = { ok: false, status: 0, text: '', json: null, headers: {}, error: String(error && error.message ? error.message : error) };
        trace.requests.push({ host: host, path: shortPath(url), status: 0, ms: Date.now() - started, at: started, note: 'network' });
        return last;
      }
      var status = Number(response && response.status) || 0;
      var text = '';
      try {
        text = await readBody(response);
      } catch (error) {
        text = '';
      }
      var parsed = null;
      try {
        parsed = text ? JSON.parse(text) : null;
      } catch (_) {}
      last = {
        ok: status >= 200 && status < 300,
        status: status,
        text: text || '',
        json: parsed,
        headers: (response && response.headers) || {},
      };
      trace.requests.push({ host: host, path: shortPath(url), status: status, ms: Date.now() - started, at: started });

      if (status === 429 || status === 403) {
        var waitMs = retryAfterMs(response);
        parkHost(host, waitMs, 'http ' + status);
        return last;
      }
      if (status >= 500) {
        if (attempt >= MAX_ATTEMPTS) return last;
        // One immediate retry. No timer-based backoff: the app's JS sandbox does not pump timers
        // created inside a module call, so a sleep here would hang the call instead of backing off.
        continue;
      }
      return last;
    }
    return last;
  }

  function shortPath(url) {
    var m = String(url || '').match(/^https?:\/\/[^\/]+([^?#]*)/i);
    return m ? m[1] : '';
  }

  // No timer helpers live in this module on purpose: the app's JS sandbox does not pump timers
  // created inside a module call, so timeouts are expressed as bounded request counts plus
  // Date.now() deadline checks between steps.

  // ------------------------------------------------------------------ metadata (AniList / Jikan)
  var MEDIA_FIELDS =
    'id idMal title { romaji english native userPreferred } description(asHtml: false) bannerImage ' +
    'coverImage { extraLarge large medium } format status episodes duration season seasonYear ' +
    'averageScore genres nextAiringEpisode { episode } streamingEpisodes { title site }';

  async function anilist(query, variables, session) {
    var res = await request(
      ANILIST,
      { Accept: 'application/json', 'Content-Type': 'application/json' },
      'POST',
      JSON.stringify({ query: query, variables: variables || {} }),
      { session: session },
    );
    if (!res.ok || !res.json || res.json.errors) {
      throw new Error('AniList request failed (' + res.status + ')');
    }
    return res.json.data || {};
  }

  async function jikan(path, session) {
    var res = await request(JIKAN + path, { Accept: 'application/json' }, 'GET', null, { session: session });
    if (!res.ok || !res.json) throw new Error('Jikan request failed (' + res.status + ')');
    return res.json;
  }

  function pickTitle(node) {
    var t = (node && node.title) || {};
    return clean(t.english || t.romaji || t.userPreferred || t.native || 'Anime');
  }

  function seriesHref(ref) {
    if (ref.anilistId) return SCHEME + 'a' + ref.anilistId;
    return SCHEME + 'm' + ref.malId;
  }

  function episodeHref(ref, ep) {
    if (ref.anilistId) return SCHEME + 'a' + ref.anilistId + ':e' + ep;
    return SCHEME + 'm' + ref.malId + ':e' + ep;
  }

  function mediaCard(media) {
    if (!media || !media.id) return null;
    var image =
      (media.coverImage && (media.coverImage.extraLarge || media.coverImage.large || media.coverImage.medium)) ||
      media.bannerImage ||
      '';
    var href = seriesHref({ anilistId: media.id, malId: media.idMal || 0 });
    return {
      id: href,
      href: href,
      url: href,
      title: pickTitle(media),
      image: image,
      poster: image,
      type: media.format === 'MOVIE' ? 'movie' : 'tv',
      anilistId: media.id,
      malId: media.idMal || 0,
      year: media.seasonYear || 0,
      episodes: media.episodes || 0,
      score: media.averageScore || 0,
      format: media.format || '',
    };
  }

  function jikanCard(row) {
    if (!row || !row.mal_id) return null;
    var image =
      (row.images && row.images.jpg && (row.images.jpg.large_image_url || row.images.jpg.image_url)) || '';
    var href = seriesHref({ anilistId: 0, malId: row.mal_id });
    return {
      id: href,
      href: href,
      url: href,
      title: clean(row.title_english || row.title || 'Anime'),
      image: image,
      poster: image,
      type: 'tv',
      anilistId: 0,
      malId: row.mal_id,
      year: row.year || 0,
      episodes: row.episodes || 0,
      score: 0,
      format: row.type || '',
    };
  }

  function parseRef(raw) {
    var text = String(raw == null ? '' : raw).trim();
    try {
      text = decodeURIComponent(text);
    } catch (_) {}
    // Our own scheme first: sadirect:a<anilistId>[:e<ep>] | sadirect:m<malId>[:e<ep>]
    var own = text.match(/^sadirect:([am])(\d{1,9})(?::e(?:p)?=?(\d{1,5}))?$/i);
    if (own) {
      return {
        anilistId: own[1].toLowerCase() === 'a' ? Number(own[2]) : 0,
        malId: own[1].toLowerCase() === 'm' ? Number(own[2]) : 0,
        episode: own[3] ? Number(own[3]) : 0,
      };
    }
    // Foreign/legacy forms: /anime/123?ep=4, /mal/55/watch?ep=2, "a105333:e15", bare ids.
    var epMatch = text.match(/[:?&]e(?:p)?=?(\d{1,5})/i);
    var anilist = text.match(/(?:^|[^a-z0-9])a(\d{2,9})/i);
    var mal = text.match(/(?:^|[^a-z0-9])m(\d{2,7})/i);
    var plainAnime = text.match(/\/anime\/(\d+)/i);
    var plainMal = text.match(/\/mal\/(\d+)/i);
    var bare = text.match(/^(\d{2,9})$/);
    var episode = epMatch ? Number(epMatch[1]) : 0;
    var anilistId = 0;
    var malId = 0;
    if (plainMal) malId = Number(plainMal[1]);
    else if (plainAnime) anilistId = Number(plainAnime[1]);
    else {
      if (anilist) anilistId = Number(anilist[1]);
      if (mal) malId = Number(mal[1]);
    }
    if (!anilistId && !malId && bare) anilistId = Number(bare[1]);
    return { anilistId: anilistId, malId: malId, episode: episode };
  }

  function idParams(ref) {
    var out = '';
    if (ref.anilistId) out += '&anilistId=' + encodeURIComponent(ref.anilistId);
    if (ref.malId) out += '&malId=' + encodeURIComponent(ref.malId);
    return out;
  }

  // ------------------------------------------------------------------ Vidhawk provider
  function vhHeaders(referer) {
    return {
      'User-Agent': USER_AGENT,
      Accept: 'application/json,application/vnd.apple.mpegurl,*/*',
      Referer: referer || VIDHAWK + '/',
      Origin: VIDHAWK,
    };
  }

  function normaliseAudio(lang) {
    var value = String(lang == null ? '' : lang).trim().toLowerCase();
    if (value === 'dub' || value === 'dubbed' || value === 'english dub') return 'dub';
    return 'sub';
  }

  function providerVerdict(res) {
    // A 404 with a CONTENT_UNAVAILABLE body is a real answer, not a failure: read the body first.
    if (res && res.parked) return 'parked';
    var body = res && res.json ? res.json : null;
    if (body && (body.code === 'CONTENT_UNAVAILABLE' || body.available === false)) return 'unavailable';
    if (!res || !res.ok || !body) return 'failed';
    return 'ok';
  }

  // NOTE: /api/stream/race exists and returns both tickets in one call, but it does not complete
  // reliably inside the app's JS runtime (observed: the request never settles, and the runtime's
  // sandbox does not pump our timers, so a timer-based escape hatch cannot fire either).
  // The connection-safe shape is /api/stream/resolve — the same endpoint episode verification uses —
  // called once per server. Both calls are started together, so the first usable ticket still wins.

  async function providerResolve(ref, episode, audio, server, session) {
    // Fallback when the race endpoint is unavailable: single-server resolve.
    var url =
      VIDHAWK +
      '/api/stream/resolve?episode=' +
      encodeURIComponent(episode) +
      '&audio=' +
      encodeURIComponent(audio) +
      '&fast=1&server=' +
      encodeURIComponent(server) +
      idParams(ref);
    var res = await request(url, vhHeaders(VIDHAWK + '/embed/ani/' + (ref.anilistId || ref.malId) + '/' + episode + '/' + audio), 'GET', null, {
      session: session,
    });
    var verdict = providerVerdict(res);
    if (verdict === 'unavailable') return { unavailable: true };
    if (verdict === 'parked') return { parked: true };
    if (verdict !== 'ok') return null;
    if (!res.json.ticket) return null;
    return { ticket: String(res.json.ticket), label: clean(res.json.serverLabel || server) };
  }

  async function providerPlay(ticket, referer, session) {
    var res = await request(VIDHAWK + '/api/play?t=' + encodeURIComponent(ticket), vhHeaders(referer), 'GET', null, { session: session });
    if (!res.ok || !res.json) return null;
    return res.json;
  }

  // ------------------------------------------------------------------ media validation (positive)
  function classifySegment(bytes) {
    if (!bytes || bytes.length < 16) return { kind: 'empty' };
    var b = bytes;
    if (b[0] === 0x47) return { kind: 'ts' };
    // PNG-wrapped TS: PNG signature, real TS sync byte later in the wrapper (seen in the wild).
    if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) {
      for (var i = 8; i < Math.min(b.length - 1, 512); i += 1) {
        if (b[i] === 0x47 && b[i + 1] === 0x40) return { kind: 'png_ts' };
      }
      return { kind: 'image' };
    }
    if (b[0] === 0xff && b[1] === 0xd8) return { kind: 'image' };
    if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return { kind: 'image' };
    var four = String.fromCharCode(b[4] || 0, b[5] || 0, b[6] || 0, b[7] || 0);
    if (four === 'ftyp' || four === 'styp' || four === 'moof' || four === 'sidx' || four === 'moov' || four === 'free') {
      return { kind: 'fmp4' };
    }
    var lead = bytesToAscii(b, 96).trim().toLowerCase();
    if (lead.charAt(0) === '<') return { kind: 'html' };
    if (lead.charAt(0) === '{' || lead.charAt(0) === '[') return { kind: 'json' };
    return { kind: 'unknown' };
  }

  function bytesToAscii(bytes, max) {
    var out = '';
    for (var i = 0; i < Math.min(bytes.length, max); i += 1) out += String.fromCharCode(bytes[i]);
    return out;
  }

  function firstLineUrl(body, from, skipTags) {
    var lines = String(body || '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i += 1) {
      var line = lines[i].trim();
      if (!line || line.charAt(0) === '#') continue;
      var url = resolveUrl(line, from);
      if (url) return url;
    }
    return '';
  }

  function resolveUrl(value, base) {
    var href = String(value || '').trim();
    if (!href) return '';
    if (/^https?:\/\//i.test(href)) return href;
    var parts = String(base || '').match(/^(https?:\/\/[^\/?#]+)([^?#]*)/i);
    if (!parts) return '';
    if (href.indexOf('//') === 0) return parts[1].split(':')[0] + ':' + href;
    if (href.charAt(0) === '?') return parts[1] + (parts[2] || '/') + href;
    var suffixAt = href.search(/[?#]/);
    var suffix = suffixAt < 0 ? '' : href.slice(suffixAt);
    var path = suffixAt < 0 ? href : href.slice(0, suffixAt);
    if (path.charAt(0) !== '/') path = (parts[2] || '/').replace(/[^/]*$/, '') + path;
    var out = [];
    path.split('/').forEach(function (part) {
      if (part === '..') out.pop();
      else if (part !== '.') out.push(part);
    });
    return parts[1] + '/' + out.join('/').replace(/^\/+/, '') + suffix;
  }

  function parseQualities(master, base, hdrs) {
    var out = [];
    var seen = {};
    var lines = String(master || '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i += 1) {
      var line = lines[i].trim();
      if (line.indexOf('#EXT-X-STREAM-INF') !== 0) continue;
      var height = 0;
      var res = line.match(/RESOLUTION=\d+x(\d+)/i);
      if (res) height = Number(res[1]) || 0;
      var next = '';
      for (var j = i + 1; j < lines.length; j += 1) {
        var cand = lines[j].trim();
        if (!cand || cand.charAt(0) === '#') continue;
        next = cand;
        break;
      }
      var url = resolveUrl(next, base);
      if (!url || seen[url]) continue;
      seen[url] = true;
      out.push({ label: height ? height + 'p' : 'Auto', height: height || undefined, url: url, headers: hdrs });
    }
    out.sort(function (a, b) {
      return (b.height || 0) - (a.height || 0);
    });
    return out.slice(0, 6);
  }

  var SEG_SAMPLE_BYTES = 65535;

  async function validateHls(url, hdrs, session) {
    // Positive validation: master -> variant -> real segment bytes with a media container.
    if (!url) return { ok: false, reason: 'no_url' };
    var master = await request(url, hdrs, 'GET', null, { session: session });
    if (!master.ok || master.text.indexOf('#EXTM3U') < 0) {
      return { ok: false, reason: 'not_hls_' + master.status, status: master.status };
    }
    var body = master.text;
    var mediaUrl = url;
    var mediaBody = body;
    if (/#EXT-X-STREAM-INF:/i.test(body)) {
      var variantUrl = firstLineUrl(body, url);
      if (!variantUrl) return { ok: false, reason: 'no_variant' };
      var variant = await request(variantUrl, hdrs, 'GET', null, { session: session });
      if (!variant.ok || variant.text.indexOf('#EXTM3U') < 0) {
        return { ok: false, reason: 'variant_' + variant.status, status: variant.status };
      }
      mediaUrl = variantUrl;
      mediaBody = variant.text;
    }
    if (/#EXT-X-MEDIA:.*TYPE=AUDIO/i.test(mediaBody) && !/#EXTINF:/i.test(mediaBody)) {
      var audioUrl = firstLineUrl(mediaBody, mediaUrl);
      if (audioUrl && audioUrl !== mediaUrl) {
        var audio = await request(audioUrl, hdrs, 'GET', null, { session: session });
        if (audio.ok && audio.text.indexOf('#EXTM3U') >= 0) {
          mediaUrl = audioUrl;
          mediaBody = audio.text;
        }
      }
    }
    if (!/#EXTINF:/i.test(mediaBody)) return { ok: false, reason: 'no_segments' };
    var segUrl = firstLineUrl(mediaBody, mediaUrl);
    if (!segUrl) return { ok: false, reason: 'no_segment_url' };
    var segment = await request(segUrl, Object.assign({}, hdrs, { Range: 'bytes=0-' + (SEG_SAMPLE_BYTES - 1) }), 'GET', null, {
      session: session,
    });
    if (!segment.ok) {
      if (segment.status === 0) return { ok: false, reason: 'segment_timeout', inconclusive: true };
      return { ok: false, reason: 'segment_' + segment.status, inconclusive: segment.status >= 500 };
    }
    var bytes = binaryBytes(segment);
    var cls = classifySegment(bytes);
    if (cls.kind === 'ts' || cls.kind === 'png_ts' || cls.kind === 'fmp4') {
      if (cls.kind === 'fmp4') {
        var map = mediaBody.match(/#EXT-X-MAP:.*URI="([^"]+)"/i);
        if (map) {
          var initUrl = resolveUrl(map[1], mediaUrl);
          var init = await request(initUrl, Object.assign({}, hdrs, { Range: 'bytes=0-2047' }), 'GET', null, { session: session });
          var initBytes = binaryBytes(init);
          var four = initBytes.length > 8 ? String.fromCharCode(initBytes[4], initBytes[5], initBytes[6], initBytes[7]) : '';
          if (!init.ok || (four !== 'ftyp' && four !== 'moov')) return { ok: false, reason: 'invalid_init' };
        }
      }
      return { ok: true, master: body, media: mediaBody, kind: cls.kind };
    }
    if (cls.kind === 'html' || cls.kind === 'json' || cls.kind === 'image' || cls.kind === 'empty') {
      return { ok: false, reason: 'segment_' + cls.kind };
    }
    return { ok: false, reason: 'segment_unknown' };
  }

  function binaryBytes(response) {
    var out = [];
    try {
      if (response && response.bytes) {
        var raw = response.bytes;
        if (raw && raw.length) {
          for (var i = 0; i < raw.length; i += 1) out.push(Number(raw[i]) & 0xff);
          return out;
        }
      }
      var text = (response && response.text) || '';
      // Latin-1 fallback: the runtime decodes byte strings losslessly enough for magic checks.
      for (var j = 0; j < text.length; j += 1) out.push(text.charCodeAt(j) & 0xff);
    } catch (_) {}
    return out;
  }

  // ------------------------------------------------------------------ captions
  var captionCache = {};
  var LANG_ALIASES = {
    english: 'en', en: 'en', japanese: 'ja', ja: 'ja', spanish: 'es', arabic: 'ar', french: 'fr',
    'pt-br': 'pt', portuguese: 'pt', german: 'de', italian: 'it', russian: 'ru', 'zh-cn': 'zh',
    chinese: 'zh', korean: 'ko', 'zh-tw': 'zh', hindi: 'hi', indonesian: 'id', thai: 'th',
    vietnamese: 'vi', turkish: 'tr', polish: 'pl', dutch: 'nl', ukrainian: 'uk', hebrew: 'he',
  };

  function languageCode(entry) {
    // The provider stamps lang=en on every track, so the explicit LABEL names the translation.
    var label = clean((entry && (entry.label || entry.language || entry.lang)) || '');
    var raw = clean((entry && (entry.language || entry.lang)) || '');
    function head(value) {
      return String(value || '').split(/[-(]/)[0].trim().toLowerCase();
    }
    return LANG_ALIASES[head(label)] || LANG_ALIASES[head(raw)] || head(label) || head(raw) || 'und';
  }

  function shortLabel(entry) {
    var label = clean((entry && (entry.label || entry.language || entry.lang)) || 'Subtitle');
    var head = label.split(/[-(]/)[0].trim();
    return head || label || 'Subtitle';
  }

  var captionIndex = {};

  async function verifyCaption(entry, session) {
    var url = String((entry && (entry.src || entry.file || entry.url)) || '').trim();
    if (!/^https?:\/\//i.test(url)) return null;
    var language = languageCode(entry);
    var label = shortLabel(entry);
    var key = language + '|' + label.toLowerCase();
    if (captionIndex[key]) return captionIndex[key];
    if (captionCache[url]) {
      captionIndex[key] = captionCache[url];
      return captionCache[url];
    }
    var res = await request(url, { 'User-Agent': USER_AGENT, Accept: 'text/vtt,*/*' }, 'GET', null, { session: session });
    if (!res.ok) return null;
    var text = String(res.text || '');
    var cues = (text.match(/-->/g) || []).length;
    if (text.trim().indexOf('WEBVTT') !== 0 || cues < 3) {
      log('caption rejected (' + (text.trim().indexOf('WEBVTT') !== 0 ? 'not vtt' : 'cues ' + cues) + ')');
      return null;
    }
    var out = {
      id: url,
      url: url,
      file: url,
      label: label,
      sourceLabel: clean(entry.label || entry.language || entry.lang || ''),
      language: language,
      lang: language,
      kind: 'subtitle',
      cues: cues,
      default: Boolean(entry.default) || /^english/i.test(label),
      headers: { 'User-Agent': USER_AGENT },
    };
    captionCache[url] = out;
    captionIndex[key] = out;
    return out;
  }

  async function collectCaptions(play, audio, session, budgetMs) {
    var groups = (play && play.captions) || {};
    var rows = [];
    if (Array.isArray(groups)) rows = groups;
    else if (groups && Array.isArray(groups[audio])) rows = groups[audio];
    if (!rows.length) return [];
    var deadline = Date.now() + Math.max(1200, budgetMs || 2500);
    var accepted = [];
    var limit = Math.min(rows.length, 6);
    for (var i = 0; i < limit; i += 1) {
      if (Date.now() > deadline) {
        log('caption budget exhausted after ' + accepted.length + ' verified track(s)');
        break;
      }
      var verified = await verifyCaption(rows[i], session);
      if (verified && accepted.indexOf(verified) < 0) accepted.push(verified);
    }
    return accepted;
  }

  // ------------------------------------------------------------------ markers
  function markerPair(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var start = Number(raw.start);
    var end = Number(raw.end);
    if (!isFinite(start) || !isFinite(end) || start < 0 || end <= start) return null;
    return { start: Math.floor(start), end: Math.floor(end) };
  }

  // ------------------------------------------------------------------ episode verification
  var verifyCache = {};
  var VERIFY_TTL_MS = 20 * 60 * 1000;
  var VERIFY_MAX_PROBES = 14;
  var VERIFY_DEADLINE_MS = 8000;

  async function probeEpisode(ref, episode, audio, session, counter) {
    if (counter.count >= VERIFY_MAX_PROBES) return 'budget';
    if (deadlineLeft(session) <= 800) return 'budget';
    counter.count += 1;
    trace.probes += 1;
    var one = await providerResolve(ref, episode, audio, 'flow', session);
    if (one && one.ticket) return 'yes';
    if (one && one.unavailable) {
      // The provider tried flow; give the second server one chance before calling it unavailable.
      var two = await providerResolve(ref, episode, audio, 'zuri', session);
      if (two && two.ticket) return 'yes';
      if (two && two.unavailable) return 'no';
      return 'unknown';
    }
    // flow did not answer (network/5xx/parked): one attempt on the other server before giving up,
    // so a single stalled request cannot turn a real availability into "unknown".
    if (deadlineLeft(session) > 1200) {
      var alt = await providerResolve(ref, episode, audio, 'zuri', session);
      if (alt && alt.ticket) return 'yes';
      if (alt && alt.unavailable) return 'no';
    }
    return 'unknown';
  }

  // Per-episode availability flag for one audio track, from that audio's verification result.
  // Positive verdicts decide; "could not ask" never hides a language.
  function audioFlag(result, episodeNumber) {
    if (!result) return false;
    if (result.state === 'unavailable') return false;
    if (result.state === 'unverified') return true;
    return episodeNumber >= (result.firstAvailable || 1) && episodeNumber <= result.frontier;
  }

  async function verifyFrontier(ref, count, audio, session) {
    var counter = { count: 0 };
    var cacheKey = (ref.anilistId || 'm' + ref.malId) + '|' + count + '|' + audio;
    var cached = verifyCache[cacheKey];
    if (cached && Date.now() - cached.at < VERIFY_TTL_MS) return cached;
    async function probe(ep) {
      return probeEpisode(ref, ep, audio, session, counter);
    }

    var result = { frontier: 0, firstAvailable: 1, at: Date.now(), state: 'unverified', probes: 0 };

    if (count <= 0) {
      result.state = 'empty';
      verifyCache[cacheKey] = result;
      return result;
    }

    var first = await probe(1);
    if (first === 'no') {
      // Try a middle anchor before writing the series off (late-start catalogues exist).
      var midCheck = count > 1 ? await probe(Math.max(2, Math.ceil(count / 2))) : 'no';
      if (midCheck === 'no') {
        result.state = 'unavailable';
        result.probes = counter.count;
        verifyCache[cacheKey] = result;
        return result;
      }
      if (midCheck === 'unknown' || midCheck === 'budget') {
        result.state = 'unverified';
        result.probes = counter.count;
        verifyCache[cacheKey] = result;
        return result;
      }
      // Late start: find the first available episode with a bounded scan.
      var low = 2;
      var high = Math.max(2, Math.ceil(count / 2));
      while (low < high && counter.count < VERIFY_MAX_PROBES) {
        var spot = Math.floor((low + high) / 2);
        var spotState = await probe(spot);
        if (spotState === 'yes') high = spot;
        else if (spotState === 'no') low = spot + 1;
        else break;
      }
      result.frontier = count;
      result.firstAvailable = low;
      result.state = 'verified';
      result.probes = counter.count;
      verifyCache[cacheKey] = result;
      return result;
    }

    if (first === 'unknown' || first === 'budget') {
      result.state = first === 'budget' ? 'unverified' : 'unverified';
      result.probes = counter.count;
      verifyCache[cacheKey] = result;
      return result;
    }

    // first === 'yes': establish the tail, then confirm with interior anchors.
    var last = count > 1 ? await probe(count) : 'yes';
    if (last === 'yes') {
      var interior = [];
      [Math.ceil(count / 3), Math.ceil((2 * count) / 3)].forEach(function (ep) {
        if (ep > 1 && ep < count) interior.push(ep);
      });
      var gapAt = 0;
      for (var i = 0; i < interior.length; i += 1) {
        if (counter.count >= VERIFY_MAX_PROBES) break;
        var state = await probe(interior[i]);
        if (state === 'no') {
          gapAt = interior[i];
          break;
        }
        if (state === 'unknown' || state === 'budget') break;
      }
      if (!gapAt) {
        result.frontier = count;
        result.state = 'verified';
        result.sampled = interior.length;
        result.probes = counter.count;
        verifyCache[cacheKey] = result;
        return result;
      }
      // A gap exists: bound the contiguous prefix.
      var lo = 1;
      var hi = gapAt;
      while (lo < hi - 1 && counter.count < VERIFY_MAX_PROBES) {
        var mid = Math.floor((lo + hi) / 2);
        var midState = await probe(mid);
        if (midState === 'yes') lo = mid;
        else if (midState === 'no') hi = mid;
        else break;
      }
      result.frontier = lo;
      result.state = 'verified';
      result.gapFrom = gapAt;
      result.probes = counter.count;
      verifyCache[cacheKey] = result;
      return result;
    }

    if (last === 'no') {
      var lowB = 1;
      var highB = count;
      while (lowB < highB - 1 && counter.count < VERIFY_MAX_PROBES) {
        var midB = Math.floor((lowB + highB) / 2);
        var stateB = await probe(midB);
        if (stateB === 'yes') lowB = midB;
        else if (stateB === 'no') highB = midB;
        else break;
      }
      result.frontier = lowB;
      result.state = 'verified';
      result.probes = counter.count;
      verifyCache[cacheKey] = result;
      return result;
    }

    // last === 'unknown'/'budget': conservative, advertise nothing beyond what we verified.
    result.frontier = 0;
    result.state = 'unverified';
    result.probes = counter.count;
    verifyCache[cacheKey] = result;
    return result;
  }

  // ------------------------------------------------------------------ packaging
  function packStream(primary, extras, lang, notice) {
    if (!primary) {
      return {
        streams: [],
        subtitles: [],
        lang: lang,
        error: { message: notice || 'No verified playable source for this episode right now.' },
      };
    }
    var accepted = [primary].concat(extras || []);
    var servers = [];
    var seenUrl = {};
    var allSubtitles = [];
    var seenCaption = {};
    accepted.forEach(function (row) {
      if (!row || !row.url || seenUrl[row.url]) return;
      seenUrl[row.url] = true;
      var entry = {
        name: row.name || 'Server',
        label: row.label || row.name || 'Server',
        url: row.url,
        headers: row.headers || {},
        streamType: 'hls',
        lang: lang,
        subtitles: row.subtitles || [],
        qualities: row.qualities || [],
      };
      if (row.intro) entry.intro = [row.intro.start, row.intro.end];
      if (row.outro) entry.outro = [row.outro.start, row.outro.end];
      servers.push(entry);
      (row.subtitles || []).forEach(function (cap) {
        if (cap && cap.url && !seenCaption[cap.url]) {
          seenCaption[cap.url] = true;
          allSubtitles.push(cap);
        }
      });
    });
    var qualities = Array.isArray(primary.qualities) ? primary.qualities : [];
    var streams = [(lang === 'dub' ? 'dub Auto' : 'sub Auto'), primary.url];
    qualities.forEach(function (q) {
      if (q && q.url && q.label && q.url !== primary.url) streams.push((lang === 'dub' ? 'dub ' : 'sub ') + q.label, q.url);
    });
    var payload = {
      url: primary.url,
      streams: streams,
      headers: primary.headers || {},
      streamType: 'hls',
      lang: lang,
      quality: 'Auto',
      defaultQuality: 'Auto',
      qualities: [{ label: 'Auto', url: primary.url, headers: primary.headers || {} }].concat(
        qualities.filter(function (q) {
          return q && q.url !== primary.url;
        }),
      ),
      subtitles: allSubtitles,
      servers: servers,
    };
    if (primary.intro) {
      payload.intro = [primary.intro.start, primary.intro.end];
      payload.introStartSeconds = primary.intro.start;
      payload.introEndSeconds = primary.intro.end;
    }
    if (primary.outro) {
      payload.outro = [primary.outro.start, primary.outro.end];
      payload.outroStartSeconds = primary.outro.start;
      payload.outroEndSeconds = primary.outro.end;
    }
    if (notice) payload.notice = notice;
    return payload;
  }

  var trackLabel = null; // replaced below by the evidence-based labeller

  // Whisper-sampled audio evidence (matrix run 2026-09-12, two offsets where the first sample was
  // music). The provider's track ids are used for ROUTING; labels may only assert a language where
  // a sample actually confirmed it. Anything unsampled says so.
  var AUDIO_EVIDENCE = {
    105333: { sub: 'japanese', dub: 'english' },
    113936: { sub: 'japanese' },
    142876: { dub: 'english' },
    140960: { sub: 'japanese', dub: 'japanese' },
    20: { dub: 'english' },
    21: { sub: 'japanese' },
    113415: { sub: 'japanese' },
    1535: { dub: 'english' },
    21459: { sub: 'japanese' },
    101922: { sub: 'japanese' },
    16498: { sub: 'japanese' },
    5114: { dub: 'english' },
    20464: { sub: 'japanese' },
    127230: { dub: 'english' },
    101348: { sub: 'japanese' },
    101759: { sub: 'japanese' },
    101291: { dub: 'japanese' },
    99147: { sub: 'japanese' },
    9253: { dub: 'english' },
    104578: { sub: 'japanese' },
    110277: { dub: 'japanese' },
    21087: { sub: 'japanese' },
    112151: { dub: 'english' },
    97940: { sub: 'japanese' },
    11061: { dub: 'english' },
  };

  function audioLabel(ref, audioTrack) {
    var sampled = (AUDIO_EVIDENCE[ref.anilistId] || {})[audioTrack];
    if (audioTrack === 'dub') {
      if (sampled === 'english') return { text: 'English Dub', discrepancy: false };
      if (sampled) return { text: "Provider 'dub' track — sampled audio is " + sampled + ', not English', discrepancy: true };
      return { text: 'Dub (provider track, audio not sampled)', discrepancy: false };
    }
    if (sampled === 'japanese') return { text: 'Japanese audio (Sub)', discrepancy: false };
    if (sampled) return { text: "Provider 'sub' track — sampled audio is " + sampled, discrepancy: true };
    return { text: 'Sub (provider track, audio not sampled)', discrepancy: false };
  }

  function friendlyAudio(audio) {
    return audio === 'dub' ? 'English Dub' : 'Japanese audio (Sub)';
  }

  // ------------------------------------------------------------------ stream resolution
  var PLAY_BUDGET_MS = 11000;
  var EXTRAS_WINDOW_MS = 1800;

  async function buildCandidate(ref, episode, audio, serverRow, session) {
    var referer = VIDHAWK + '/embed/ani/' + (ref.anilistId || ref.malId) + '/' + episode + '/' + audio;
    var play = await providerPlay(serverRow.ticket, referer, session);
    if (!play || !Array.isArray(play.tracks)) return null;
    var track = play.tracks.filter(function (row) {
      return row && row.id === audio && row.src;
    })[0];
    var substitute = false;
    if (!track) {
      var other = audio === 'dub' ? 'sub' : 'dub';
      track = play.tracks.filter(function (row) {
        return row && row.id === other && row.src;
      })[0];
      substitute = Boolean(track);
    }
    if (!track) return null;
    var hdrs = vhHeaders(referer);
    var validation = await validateHls(track.src, hdrs, session);
    if (!validation.ok) {
      log('candidate rejected (' + serverRow.id + ', ' + (validation.reason || 'probe') + ')');
      return { rejected: validation.reason || 'probe' };
    }
    var servedAudio = substitute ? (audio === 'dub' ? 'sub' : 'dub') : audio;
    var captions = await collectCaptions(play, servedAudio, session, 2600);
    var name = clean(serverRow.label || serverRow.id);
    var audioInfo = audioLabel(ref, servedAudio);
    var label = audioInfo.text + ' · Vidhawk ' + name;
    if (substitute) {
      label =
        audioInfo.text + ' (requested ' + friendlyAudio(audio) + ' is not offered at this provider) · Vidhawk ' + name;
    }
    return {
      name: name,
      label: label,
      url: track.src,
      headers: hdrs,
      streamType: 'hls',
      lang: servedAudio,
      subtitles: captions,
      qualities: parseQualities(validation.master, track.src, hdrs),
      intro: markerPair(play.intro),
      outro: markerPair(play.outro),
      substitute: substitute,
      audioDiscrepancy: audioInfo.discrepancy,
      mediaKind: validation.kind,
      server: serverRow.id,
    };
  }

  async function extractStreamUrl(episodeHrefRaw, lang) {
    var want = normaliseAudio(lang);
    var ref = parseRef(episodeHrefRaw);
    if ((!ref.anilistId && !ref.malId) || !ref.episode) {
      return { streams: [], subtitles: [], error: { message: 'Invalid episode reference.' } };
    }
    var session = { closed: false, deadline: Date.now() + PLAY_BUDGET_MS };
    var notice = '';
    var parkedSeen = false;

    // Both provider servers are asked at once; whichever answers with a ticket becomes a candidate.
    // No timers are used on this path: the app's JS sandbox does not pump module-created timers, so
    // any timer-gated wait here would hang the call (observed with the race endpoint). Correctness
    // comes from bounded request counts and the session deadline checks between steps.
    var direct = await Promise.all(
      ['flow', 'zuri'].map(function (name) {
        return providerResolve(ref, ref.episode, want, name, session).catch(function () {
          return null;
        });
      }),
    );
    var serverRows = [];
    direct.forEach(function (row, idx) {
      var name = idx === 0 ? 'flow' : 'zuri';
      if (row && row.parked) parkedSeen = true;
      if (row && row.ticket) serverRows.push({ id: name, label: row.label || name, ticket: row.ticket });
    });
    if (!serverRows.length) {
      var anyUnavailable = direct.some(function (row) {
        return row && row.unavailable;
      });
      if (anyUnavailable) notice = 'This episode is not available at the provider for ' + friendlyAudio(want) + '.';
      else if (parkedSeen) notice = 'The provider asked us to slow down (rate limit). Try this episode again in a minute.';
    }

    // 2. First verified candidate wins; extras are gathered inside a short window only.
    var primary = null;
    var extras = [];
    var rejected = [];
    for (var i = 0; i < serverRows.length; i += 1) {
      if (deadlineLeft(session) <= 900) break;
      var candidate = null;
      try {
        candidate = await buildCandidate(ref, ref.episode, want, serverRows[i], session);
      } catch (error) {
        log('candidate error ' + (error && error.message ? error.message : error));
      }
      if (candidate && candidate.rejected) {
        rejected.push(serverRows[i].id + ':' + candidate.rejected);
        continue;
      }
      if (candidate && candidate.url) {
        if (!primary) {
          primary = candidate;
          if (candidate.substitute) {
            notice = 'Requested ' + friendlyAudio(want) + ' is not offered at this provider; serving ' + friendlyAudio(candidate.lang) + ' labelled honestly.';
          } else if (candidate.audioDiscrepancy) {
            notice =
              "The provider labels this route '" + candidate.lang + "' but QA sampling of this title found " +
              ((AUDIO_EVIDENCE[ref.anilistId] || {})[candidate.lang] || 'other audio') +
              '; the route is served as-is and labelled accordingly.';
          }
          var extrasDeadline = Date.now() + EXTRAS_WINDOW_MS;
          for (var j = i + 1; j < serverRows.length; j += 1) {
            if (Date.now() > extrasDeadline || deadlineLeft(session) <= 500) break;
            var extra = null;
            try {
              extra = await buildCandidate(ref, ref.episode, want, serverRows[j], session);
            } catch (_) {}
            if (extra && extra.url) extras.push(extra);
            else if (extra && extra.rejected) rejected.push(serverRows[j].id + ':' + extra.rejected);
          }
          break;
        }
      }
    }

    // 3. An in-flight HTTP request cannot be cancelled; stop the next step.
    session.closed = true;

    if (rejected.length) log('rejected routes: ' + rejected.join(', '));
    if (!primary && !notice) {
      notice = 'No verified playable source for this episode right now.';
    }
    return packStream(primary, extras, primary ? primary.lang : want, notice);
  }

  // ------------------------------------------------------------------ catalogue entry points
  async function searchResults(query) {
    var q = clean(query);
    var session = { closed: false, deadline: Date.now() + 9000 };
    try {
      if (!q) {
        var trending = await anilist(
          'query($page:Int){ Page(page:$page, perPage:24){ media(type:ANIME, sort:TRENDING_DESC, isAdult:false){ ' + MEDIA_FIELDS + ' } } }',
          { page: 1 },
          session,
        );
        return ((trending.Page && trending.Page.media) || []).map(mediaCard).filter(Boolean);
      }
      var data = await anilist(
        'query($q:String){ Page(page:1, perPage:24){ media(search:$q, type:ANIME, sort:SEARCH_MATCH, isAdult:false){ ' + MEDIA_FIELDS + ' } } }',
        { q: q },
        session,
      );
      var cards = ((data.Page && data.Page.media) || []).map(mediaCard).filter(Boolean);
      if (cards.length) return cards;
    } catch (error) {
      log('AniList search failed: ' + (error && error.message ? error.message : error));
    }
    try {
      var jk = await jikan(q ? '/anime?q=' + encodeURIComponent(q) + '&limit=24&sfw=true' : '/top/anime?limit=24', session);
      return (jk.data || []).map(jikanCard).filter(Boolean);
    } catch (error) {
      log('catalogue temporarily unavailable (' + (error && error.message ? error.message : error) + ')');
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    var ref = parseRef(urlOrId);
    if (!ref.anilistId && !ref.malId) {
      var found = await searchResults(String(urlOrId || ''));
      if (found && found[0]) {
        return {
          id: found[0].href,
          href: found[0].href,
          title: found[0].title,
          image: found[0].image,
          poster: found[0].image,
          description: '',
          anilistId: found[0].anilistId,
          malId: found[0].malId,
        };
      }
      return { title: 'Unavailable', description: '', error: { message: 'Not found in the catalogue.' } };
    }
    var session = { closed: false, deadline: Date.now() + 9000 };
    if (ref.anilistId) {
      try {
        var data = await anilist('query($id:Int){ Media(id:$id, type:ANIME){ ' + MEDIA_FIELDS + ' } }', { id: ref.anilistId }, session);
        var media = data.Media;
        if (media && media.id) {
          var card = mediaCard(media) || {};
          return {
            id: card.href,
            href: card.href,
            title: card.title,
            name: card.title,
            image: card.image,
            poster: card.image,
            description: clean(media.description),
            synopsis: clean(media.description),
            genres: media.genres || [],
            year: media.seasonYear || 0,
            status: media.status || '',
            format: media.format || '',
            episodes: media.episodes || 0,
            duration: media.duration || 0,
            score: media.averageScore || 0,
            anilistId: media.id,
            malId: media.idMal || 0,
          };
        }
      } catch (error) {
        log('details failed: ' + (error && error.message ? error.message : error));
      }
    }
    if (ref.malId) {
      try {
        var jk = await jikan('/anime/' + ref.malId, session);
        var row = jk.data || {};
        var jcard = jikanCard(row) || {};
        return {
          id: jcard.href,
          href: jcard.href,
          title: jcard.title,
          name: jcard.title,
          image: jcard.image,
          poster: jcard.image,
          description: clean(row.synopsis),
          synopsis: clean(row.synopsis),
          genres: (row.genres || []).map(function (g) {
            return g && g.name;
          }).filter(Boolean),
          year: row.year || 0,
          status: row.status || '',
          episodes: row.episodes || 0,
          anilistId: 0,
          malId: row.mal_id,
        };
      } catch (error) {
        log('details fallback failed: ' + (error && error.message ? error.message : error));
      }
    }
    return { title: 'Unavailable', description: '', href: String(urlOrId || ''), error: { message: 'Details unavailable right now.' } };
  }

  async function extractEpisodes(seriesRef) {
    var ref = parseRef(seriesRef);
    if (!ref.anilistId && !ref.malId) return [];
    var session = { closed: false, deadline: Date.now() + VERIFY_DEADLINE_MS };
    var total = 0;
    var nextAiring = 0;
    var episodeTitles = {};
    var malId = ref.malId || 0;

    if (ref.anilistId) {
      try {
        var data = await anilist(
          'query($id:Int){ Media(id:$id, type:ANIME){ id idMal episodes format nextAiringEpisode { episode } streamingEpisodes { title site } } }',
          { id: ref.anilistId },
          session,
        );
        var media = (data && data.Media) || {};
        total = Number(media.episodes) || 0;
        nextAiring = Number(media.nextAiringEpisode && media.nextAiringEpisode.episode) || 0;
        malId = Number(media.idMal) || malId;
        // AniList does not number streamingEpisodes; the mapping is positional. Only trust it when
        // the list covers the whole series, otherwise keep neutral episode labels.
        var streaming = (media.streamingEpisodes || []).filter(function (row) {
          return row && row.title;
        });
        if (total > 0 && streaming.length === total) {
          streaming.forEach(function (row, idx) {
            episodeTitles[idx + 1] = clean(row.title);
          });
        }
        if (media.format === 'MOVIE' || media.format === 'SPECIAL' || media.format === 'OVA' || media.format === 'ONA') {
          if (!total) total = 1;
        }
      } catch (error) {
        log('episode count lookup failed: ' + (error && error.message ? error.message : error));
      }
    }
    if (!total && malId) {
      try {
        var jk = await jikan('/anime/' + malId, session);
        total = Number(jk.data && jk.data.episodes) || 0;
        if (!total && (jk.data && (jk.data.type === 'Movie' || jk.data.airing === false))) total = 1;
      } catch (error) {
        log('episode count fallback failed: ' + (error && error.message ? error.message : error));
      }
    }
    if (nextAiring > 0) total = total ? Math.min(total, nextAiring - 1) : nextAiring - 1;
    if (!total) {
      log('no episode metadata for ' + (ref.anilistId || ref.malId));
      return [];
    }

    var refForProvider = { anilistId: ref.anilistId || 0, malId: malId };
    // Sub and dub are independent questions, so both are asked at the same time and each gets its
    // own deadline. (They used to share one budget and run in sequence: on long/deep titles the
    // sub pass could consume the whole 8 s, leaving dub unprobed and the UI hiding a dub that does
    // exist — found by the 50-title reliability sweep on One Piece, Naruto, AoT S2 and HxH.)
    var verifiedResults = await Promise.all([
      verifyFrontier(refForProvider, total, 'sub', { closed: false, deadline: Date.now() + VERIFY_DEADLINE_MS }),
      verifyFrontier(refForProvider, total, 'dub', { closed: false, deadline: Date.now() + VERIFY_DEADLINE_MS }),
    ]);
    var subResult = verifiedResults[0];
    var dubResult = verifiedResults[1];
    session.closed = true;

    var advertiseUpTo = Math.max(subResult.frontier, dubResult.frontier);
    log(
      'episodes ' + (ref.anilistId || malId) + ': metadata=' + total + ' subFrontier=' + subResult.frontier +
        ' dubFrontier=' + dubResult.frontier + ' subFrom=' + (subResult.firstAvailable || 1) + ' dubFrom=' + (dubResult.firstAvailable || 1) +
        ' state=' + subResult.state + '/' + dubResult.state + ' probes=' + (subResult.probes + dubResult.probes),
    );
    if (advertiseUpTo <= 0) {
      log('episode list withheld: provider verified nothing for this title/audio set');
      return [];
    }

    var out = [];
    for (var i = 1; i <= advertiseUpTo; i += 1) {
      out.push({
        id: episodeHref(refForProvider, i),
        href: episodeHref(refForProvider, i),
        number: i,
        episodeNumber: i,
        title: episodeTitles[i] || 'Episode ' + i,
        // 'verified'   -> inside its own verified window (a late start or a frontier can trim it)
        // 'unavailable'-> the provider positively has no such audio: only this clears a flag
        // 'unverified' -> the provider could not be asked in time; do NOT hide the language, because
        //                 playback reports the real situation rather than silently substituting
        subAvailable: audioFlag(subResult, i),
        dubAvailable: audioFlag(dubResult, i),
      });
    }
    return out;
  }

  // ------------------------------------------------------------------ discovery
  var FEED_PAGE = 24;

  async function discoveryHome() {
    var session = { closed: false, deadline: Date.now() + 9000 };
    try {
      var data = await anilist(
        'query{ trending: Page(page:1, perPage:24){ media(type:ANIME, sort:TRENDING_DESC, isAdult:false){ ' + MEDIA_FIELDS + ' } } ' +
          'popular: Page(page:1, perPage:24){ media(type:ANIME, sort:POPULARITY_DESC, isAdult:false){ ' + MEDIA_FIELDS + ' } } ' +
          'top: Page(page:1, perPage:24){ media(type:ANIME, sort:SCORE_DESC, isAdult:false){ ' + MEDIA_FIELDS + ' } } }',
        {},
        session,
      );
      var trending = ((data.trending && data.trending.media) || []).map(mediaCard).filter(Boolean);
      var popular = ((data.popular && data.popular.media) || []).map(mediaCard).filter(Boolean);
      var top = ((data.top && data.top.media) || []).map(mediaCard).filter(Boolean);
      var sections = [];
      if (trending.length) {
        sections.push({ id: 'sad-featured', title: 'Featured', style: 'hero', items: trending.slice(0, 8) });
      }
      if (trending.length) {
        sections.push({ id: 'sad-trending', title: 'Trending Now', style: 'poster', items: trending, viewAll: { mode: 'feed', feedId: 'trending' } });
      }
      if (popular.length) {
        sections.push({ id: 'sad-popular', title: 'Popular', style: 'poster', items: popular, viewAll: { mode: 'feed', feedId: 'popular' } });
      }
      if (top.length) {
        sections.push({ id: 'sad-top', title: 'Top Rated', style: 'poster', items: top, viewAll: { mode: 'feed', feedId: 'top' } });
      }
      return { sections: sections };
    } catch (error) {
      log('discovery failed: ' + (error && error.message ? error.message : error));
      try {
        var jk = await jikan('/top/anime?limit=24', session);
        var items = (jk.data || []).map(jikanCard).filter(Boolean);
        return items.length ? { sections: [{ id: 'sad-popular', title: 'Popular', style: 'poster', items: items }] } : { sections: [] };
      } catch (_) {
        return { sections: [] };
      }
    }
  }

  async function discoveryFeed(feedId, page) {
    var pageNumber = Math.max(1, Number(page) || 1);
    var sort = "TRENDING_DESC";
    var id = String(feedId || 'trending');
    if (id.indexOf('popular') >= 0) sort = 'POPULARITY_DESC';
    else if (id.indexOf('top') >= 0) sort = 'SCORE_DESC';
    var session = { closed: false, deadline: Date.now() + 9000 };
    try {
      var data = await anilist(
        'query($page:Int, $sort:[MediaSort]){ Page(page:$page, perPage:' + FEED_PAGE + '){ pageInfo { hasNextPage } media(type:ANIME, sort:$sort, isAdult:false){ ' + MEDIA_FIELDS + ' } } }',
        { page: pageNumber, sort: [sort] },
        session,
      );
      var items = ((data.Page && data.Page.media) || []).map(mediaCard).filter(Boolean);
      return { feedId: id, page: pageNumber, items: items, hasMore: Boolean(data.Page && data.Page.pageInfo && data.Page.pageInfo.hasNextPage) };
    } catch (error) {
      throw new Error('Catalogue page temporarily unavailable. Retry this page.');
    }
  }

  // ------------------------------------------------------------------ exports
  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  // Test/diagnostic hook: read-only view of what this module actually requested.
  globalThis.__sadTrace = function () {
    return {
      requests: trace.requests.slice(),
      blocked: trace.blocked.slice(),
      probes: trace.probes,
      cooldowns: trace.cooldowns,
      cooldownHosts: Object.keys(cooldownUntil).filter(function (h) {
        return hostParked(h);
      }),
    };
  };
})();
