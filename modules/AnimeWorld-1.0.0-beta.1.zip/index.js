// AnimeWorld (animeworld.ac) — Italian anime. SUB ITA (Japanese audio, Italian
// subtitles) and ITA (Italian dub) are separate entries on the site; the module
// pairs them so one series offers both, and never substitutes one for the other.
// Episodes play as MP4 files from the site's own server.
(function () {
  'use strict';

  var SITE = 'https://www.animeworld.ac';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';
  var HEADERS = { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,application/json,*/*;q=0.8', 'Accept-Language': 'it-IT,it;q=0.9,en;q=0.6', Referer: SITE + '/' };
  var pageCache = Object.create(null);

  function log(m) { try { console.log('[AnimeWorld] ' + m); } catch (_) {} }

  function decode(s) {
    return String(s == null ? '' : s)
      .replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ' ')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'")
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(Number(n)); })
      .replace(/&#x([0-9a-f]+);/gi, function (_, n) { return String.fromCharCode(parseInt(n, 16)); })
      .replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
  }

  function withTimeout(p, ms) {
    var t;
    return Promise.race([p, new Promise(function (r) { t = setTimeout(function () { r(null); }, ms); })])
      .then(function (v) { try { clearTimeout(t); } catch (_) {} return v; });
  }

  function headerValue(headers, name) {
    if (!headers) return '';
    if (typeof headers.get === 'function') return headers.get(name) || '';
    var key = Object.keys(headers).filter(function (k) { return k.toLowerCase() === name; })[0];
    return key ? String(headers[key] || '') : '';
  }

  async function request(url, extra, opts) {
    var o = opts || {};
    try {
      var res = await withTimeout(fetchv2(url, Object.assign({}, HEADERS, extra || {}), 'GET', null,
        { timeoutMs: o.timeoutMs || 15000, maxBytesHint: o.maxBytes || 3145728 }), (o.timeoutMs || 15000) + 2000);
      if (!res) return null;
      var text = typeof res.body === 'string' ? res.body : '';
      if (!text && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
      var json;
      if (!text && o.json) {
        if (typeof res.json === 'function') { try { json = await res.json(); } catch (_) {} }
        else if (res.json && typeof res.json === 'object') json = res.json;
      }
      if (o.json && json === undefined && text) { try { json = JSON.parse(text); } catch (_) {} }
      return { status: Number(res.status || res.statusCode || 0), text: text || '', json: json, headers: res.headers || {} };
    } catch (e) {
      log('request failed: ' + (e && e.message ? e.message : e));
      return null;
    }
  }

  // ───────────────────────── Listings & pairing ─────────────────────────

  function baseTitle(t) {
    return String(t || '').replace(/\s*\(ITA\)\s*$/i, '').trim();
  }

  function slugOf(href) {
    var m = String(href || '').match(/\/play\/([^/?#"]+)/);
    return m ? m[1] : '';
  }

  // Cards: <a href="/play/slug" class="poster"><img src=...> [DUB badge] ... <a class="name" data-jtitle=...>
  function parseCards(html) {
    var out = [];
    var re = /<a href="\/play\/([^"]+)" class="poster"[^>]*>\s*<img[^>]+src="([^"]+)"[^>]*alt="([^"]*)"[^>]*\/?>([\s\S]*?)<\/a>\s*<a href="\/play\/[^"]+"[^>]*class="name"[^>]*>([\s\S]*?)<\/a>/g;
    var m;
    while ((m = re.exec(html))) {
      var title = decode(m[5]) || decode(m[3]);
      out.push({ slug: m[1], image: m[2], title: title, dub: /class="dub"/.test(m[4]) || /\(ITA\)\s*$/i.test(title) });
    }
    return out;
  }

  // One card per series: the SUB ITA entry and the ITA dub entry are paired by title.
  function pairCards(cards) {
    var groups = [];
    var byKey = Object.create(null);
    cards.forEach(function (c) {
      var key = baseTitle(c.title).toLowerCase();
      var g = byKey[key];
      if (!g) { g = byKey[key] = { title: baseTitle(c.title), image: c.image, sub: '', dub: '' }; groups.push(g); }
      if (c.dub) { if (!g.dub) g.dub = c.slug; }
      else if (!g.sub) { g.sub = c.slug; g.image = c.image || g.image; }
    });
    return groups;
  }

  function seriesHref(g) {
    return 'animeworld:' + (g.sub || '') + '|' + (g.dub || '');
  }

  function parseSeriesRef(value) {
    var s = String(value || '');
    var m = s.match(/animeworld:([^|\s]*)\|([^|\s]*)/);
    if (m) return { sub: m[1], dub: m[2] };
    var slug = slugOf(s);
    if (!slug) return null;
    return /-ita\./.test(slug) ? { sub: '', dub: slug } : { sub: slug, dub: '' };
  }

  function card(g) {
    return { title: g.title, href: seriesHref(g), image: g.image };
  }

  async function listing(path, page) {
    var p = Math.max(1, Number(page) || 1);
    var url = SITE + path + (p > 1 ? (path.indexOf('?') >= 0 ? '&' : '?') + 'page=' + p : '');
    var res = await request(url);
    if (!res || res.status !== 200) throw new Error('AnimeWorld listing HTTP ' + (res ? res.status : 0));
    return { cards: parseCards(res.text), hasMore: new RegExp('page=' + (p + 1) + '\\b').test(res.text) };
  }

  function rankFor(title, terms) {
    var t = String(title).toLowerCase();
    var best = 9;
    terms.forEach(function (q) {
      var r = t === q ? 0 : t.indexOf(q) === 0 ? (/\d\s*$/.test(t.slice(q.length)) ? 2 : 1) : t.indexOf(q) >= 0 ? 3 : 9;
      if (r < best) best = r;
    });
    return best;
  }

  // AnimeWorld indexes Japanese/Italian titles. For English names (e.g.
  // "Attack on Titan") ask AniList for the romaji title and search again.
  async function anilistTitles(query) {
    try {
      var body = JSON.stringify({ query: 'query($s:String){Page(perPage:3){media(search:$s,type:ANIME){title{romaji english}}}}', variables: { s: query } });
      var res = await withTimeout(fetchv2('https://graphql.anilist.co', { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': UA }, 'POST', body, { timeoutMs: 8000 }), 9000);
      if (!res) return [];
      var data = res.json && typeof res.json === 'object' ? res.json : null;
      if (!data) {
        var text = typeof res.body === 'string' ? res.body : (typeof res.text === 'function' ? await res.text() : '');
        if (!text && typeof res.json === 'function') data = await res.json(); else data = JSON.parse(text || '{}');
      }
      var media = (((data || {}).data || {}).Page || {}).media || [];
      var out = [];
      media.forEach(function (m) { if (m && m.title && m.title.romaji && out.indexOf(m.title.romaji) < 0) out.push(m.title.romaji); });
      return out.slice(0, 2);
    } catch (_) { return []; }
  }

  async function searchResults(query, page) {
    var q = String(query || '').trim();
    var res = await listing(q ? '/search?keyword=' + encodeURIComponent(q) : '/updated', page);
    var groups = pairCards(res.cards);
    if (!q) return groups.map(card);
    var terms = [q.toLowerCase()];
    var matched = groups.some(function (g) { return rankFor(g.title, terms) <= 3; });
    if ((!groups.length || !matched) && (Number(page) || 1) === 1) {
      var alts = await anilistTitles(q);
      for (var i = 0; i < alts.length; i++) {
        var more = await listing('/search?keyword=' + encodeURIComponent(alts[i]), 1).catch(function () { return { cards: [] }; });
        var extra = pairCards(more.cards);
        terms.push(alts[i].toLowerCase());
        var seen = Object.create(null);
        groups.forEach(function (g) { seen[g.title.toLowerCase()] = true; });
        groups = extra.filter(function (g) { return !seen[g.title.toLowerCase()]; }).concat(groups);
      }
    }
    groups = groups.map(function (g, i) { return { g: g, i: i, r: rankFor(g.title, terms) }; })
      .sort(function (a, b) { return a.r - b.r || a.i - b.i; })
      .map(function (x) { return x.g; });
    return groups.map(card);
  }

  // ───────────────────────── Series pages ─────────────────────────

  async function loadPlayPage(slug) {
    var hit = pageCache[slug];
    if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit;
    var res = await request(SITE + '/play/' + slug);
    if (!res || res.status !== 200 || !/class="episode"/.test(res.text)) throw new Error('AnimeWorld page unavailable (HTTP ' + (res ? res.status : 0) + ')');
    var html = res.text;
    var title = decode((html.match(/<h2 class="title"[^>]*>([\s\S]*?)<\/h2>/) || [])[1] || (html.match(/data-jtitle="([^"]+)"/) || [])[1] || '');
    var info = function (label) {
      var m = html.match(new RegExp('<dt>' + label + ':</dt>\\s*<dd>([\\s\\S]*?)</dd>'));
      return m ? m[1] : '';
    };
    // Episodes from the first server block only (the page repeats lists per server).
    var block = (html.match(/<div class="server active"[\s\S]*?(?=<div class="server |<\/div>\s*<\/div>\s*<\/div>\s*<div class="widget)/) || [html])[0];
    var eps = [];
    var seen = Object.create(null);
    var re = /<a[^>]*data-id="([A-Za-z0-9_-]+)"[^>]*data-num="([^"]+)"/g;
    var m;
    while ((m = re.exec(block))) {
      if (seen[m[1]]) continue;
      seen[m[1]] = true;
      eps.push({ id: m[1], num: m[2] });
    }
    var titleForImage = title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var poster = (html.match(new RegExp('<img[^>]+src="([^"]+)"[^>]*alt="' + titleForImage + '"')) || [])[1] || '';
    var page = {
      at: Date.now(),
      title: title,
      description: decode((html.match(/<div class="desc">([\s\S]*?)<\/div>/) || [])[1] || ''),
      poster: poster,
      genres: (info('Genere').match(/>[^<]+<\/a>/g) || []).map(function (g) { return decode(g.replace(/^>/, '')); }).filter(Boolean),
      status: decode(info('Stato')),
      released: decode(info('Data di Uscita')),
      episodes: eps
    };
    var keys = Object.keys(pageCache);
    if (keys.length > 30) delete pageCache[keys[0]];
    pageCache[slug] = page;
    return page;
  }

  async function extractDetails(urlOrId) {
    var ref = parseSeriesRef(urlOrId);
    if (!ref) return { title: '', description: '' };
    var page = await loadPlayPage(ref.sub || ref.dub);
    var langs = [];
    if (ref.sub) langs.push('SUB ITA');
    if (ref.dub) langs.push('ITA');
    return {
      title: baseTitle(page.title),
      description: page.description || [page.status, page.released, langs.join(' / ')].filter(Boolean).join(' · '),
      image: page.poster,
      poster: page.poster,
      genres: page.genres,
      status: page.status,
      airdate: page.released,
      languages: langs
    };
  }

  function toNumber(n, i) {
    var v = Number(n);
    return isFinite(v) && v >= 1 && Math.floor(v) === v ? v : i + 1;
  }

  async function extractEpisodes(seriesId) {
    var ref = parseSeriesRef(seriesId);
    if (!ref) return [];
    var pages = await Promise.all([
      ref.sub ? loadPlayPage(ref.sub).catch(function () { return null; }) : null,
      ref.dub ? loadPlayPage(ref.dub).catch(function () { return null; }) : null
    ]);
    var byNum = Object.create(null);
    var order = [];
    function add(list, kind) {
      (list || []).forEach(function (e, i) {
        var n = toNumber(e.num, i);
        if (!byNum[n]) { byNum[n] = { n: n, sub: '', dub: '' }; order.push(n); }
        if (!byNum[n][kind]) byNum[n][kind] = e.id;
      });
    }
    add(pages[0] && pages[0].episodes, 'sub');
    add(pages[1] && pages[1].episodes, 'dub');
    order.sort(function (a, b) { return a - b; });
    return order.map(function (n) {
      var e = byNum[n];
      return {
        number: n,
        title: 'Episodio ' + n,
        href: 'animeworld-ep:' + (e.sub || '') + ':' + (e.dub || '') + ':' + n,
        subAvailable: !!e.sub,
        dubAvailable: !!e.dub
      };
    });
  }

  // ───────────────────────── Streams ─────────────────────────

  async function grabberFor(id) {
    for (var alt = 0; alt <= 1; alt++) {
      var res = await request(SITE + '/api/episode/info?id=' + encodeURIComponent(id) + '&alt=' + alt,
        { Accept: 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest' },
        { json: true, timeoutMs: 12000, maxBytes: 65536 });
      var url = res && res.json && res.json.grabber;
      if (url && /^https:\/\/[a-z0-9.-]+\//i.test(url) && /\.mp4(?:[?#]|$)/i.test(url)) return url;
    }
    return '';
  }

  async function extractStreamUrl(episodeHref, lang) {
    var m = String(episodeHref || '').match(/animeworld-ep:([A-Za-z0-9_-]*):([A-Za-z0-9_-]*):(\d+)/);
    var wanted = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';
    var empty = { streams: [], subtitles: [], lang: wanted };
    if (!m) return empty;
    // Never substitute: SUB ITA requests use the SUB ITA episode, ITA the dub.
    var id = wanted === 'dub' ? m[2] : m[1];
    if (!id) return empty;
    var url = await grabberFor(id);
    if (!url) { log('no file for episode ' + id); return empty; }
    var headers = { 'User-Agent': UA, Referer: SITE + '/', Accept: 'video/mp4,video/*,*/*' };
    var probe = await request(url, Object.assign({}, headers, { Range: 'bytes=0-1023' }), { timeoutMs: 12000, maxBytes: 65536 });
    var ct = probe ? headerValue(probe.headers, 'content-type') : '';
    if (!probe || (probe.status !== 206 && probe.status !== 200) || !/video\/|octet-stream/i.test(ct)) {
      log('file check failed for ' + id + ' (HTTP ' + (probe ? probe.status : 0) + ' ' + ct + ')');
      return empty;
    }
    var label = wanted === 'dub' ? 'ITA' : 'SUB ITA';
    var server = { id: 'server-1', name: 'AnimeWorld ' + label, url: url, headers: headers, streamType: 'mp4', lang: wanted,
      qualities: [{ label: 'Auto', url: url, headers: headers }], streams: ['Auto', url], subtitles: [] };
    return {
      url: url,
      streams: ['Auto', url],
      headers: headers,
      streamType: 'mp4',
      qualities: server.qualities,
      servers: [server],
      subtitles: [],
      lang: wanted,
      audioLanguage: wanted === 'dub' ? 'it' : 'ja',
      // SUB ITA subtitles are burned into the video.
      hardsubLanguage: wanted === 'dub' ? undefined : 'it'
    };
  }

  // ───────────────────────── Discovery ─────────────────────────

  var FEEDS = {
    updated: { title: 'Ultimi episodi', path: '/updated', style: 'hero' },
    ongoing: { title: 'In corso', path: '/ongoing', style: 'poster' },
    newest: { title: 'Nuovi anime', path: '/newest', style: 'poster' },
    dubbed: { title: 'Doppiati in italiano', path: '/filter?language=it', style: 'poster' }
  };

  async function discoveryHome() {
    var keys = Object.keys(FEEDS);
    var results = await Promise.all(keys.map(function (k) {
      return listing(FEEDS[k].path, 1).catch(function () { return { cards: [] }; });
    }));
    var sections = [];
    keys.forEach(function (k, i) {
      var items = pairCards(results[i].cards).slice(0, 24).map(card);
      if (items.length) sections.push({ id: k, title: FEEDS[k].title, style: FEEDS[k].style, items: items, viewAll: { mode: 'feed', feedId: k } });
    });
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    var id = FEEDS[String(feedId || '')] ? String(feedId) : 'updated';
    var p = Math.max(1, Number(page) || 1);
    try {
      var res = await listing(FEEDS[id].path, p);
      return { feedId: id, page: p, items: pairCards(res.cards).map(card), hasMore: res.hasMore };
    } catch (e) {
      return { feedId: id, page: p, items: [], hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
