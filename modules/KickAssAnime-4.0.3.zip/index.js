(() => {
  'use strict';

  const MODULE_NAME = 'KickAssAnime';
  const BASE_URL = 'https://kaa.lt';
  const IMG_BASE = BASE_URL + '/image/poster/';
  const KRUSS_ORIGIN = 'https://krussdomi.com';
  const MAX_EPISODES = 1500;
  const PAGE_FETCH_TIMEOUT_MS = 9000;
  const EMBED_TIMEOUT_MS = 8000;
  const STREAM_DEADLINE_MS = 18000;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const defaultHeaders = {
    'User-Agent': USER_AGENT,
    Accept: '*/*',
    Referer: BASE_URL + '/',
    Origin: BASE_URL,
  };

  const HLS_HEADERS = {
    'User-Agent': USER_AGENT,
    Referer: KRUSS_ORIGIN + '/',
    Origin: KRUSS_ORIGIN,
    Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/mp4,*/*',
  };

  const searchResultCache = {};
  const showCache = {};
  const catalogCache = {};
  let catalogMaxPage = 0;

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, Math.max(1, Number(ms) || 0));
    });
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(function () { return fallback; })]);
  }

  function decodeHtml(str) {
    return String(str || '')
      .replace(/\\u([0-9a-f]{4})/gi, function (_, h) {
        return String.fromCharCode(parseInt(h, 16));
      })
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#039;/g, "'")
      .replace(/&#39;/g, "'")
      .replace(/&#038;/g, '&')
      .replace(/^"|"$/g, '')
      .trim();
  }

  function safeJsonParse(text) {
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  function isResponseOk(res, status) {
    if (res && (res.ok === true || res.ok === 1)) return true;
    if (res && (res.ok === false || res.ok === 0)) return false;
    return status >= 200 && status < 300;
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try {
        return JSON.stringify(res.json);
      } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        return typeof text === 'string' ? text : '';
      } catch (_) {
        return '';
      }
    }
    return '';
  }

  async function readResponseJson(res, textBody) {
    if (res && res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      return res.json;
    }
    let json = safeJsonParse(textBody);
    if (json != null) return json;
    if (res && typeof res.json === 'function') {
      try {
        json = await res.json();
        if (json != null) return json;
      } catch (_) {}
    }
    return null;
  }

  function headerMap(headers) {
    const out = {};
    if (!headers) return out;
    if (typeof headers.forEach === 'function') {
      headers.forEach(function (value, key) {
        out[String(key).toLowerCase()] = value;
      });
      return out;
    }
    const keys = Object.keys(headers);
    for (let i = 0; i < keys.length; i += 1) {
      out[String(keys[i]).toLowerCase()] = headers[keys[i]];
    }
    return out;
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign({}, defaultHeaders, cfg.headers || {});
    let body = cfg.body == null ? null : cfg.body;
    if (body && typeof body === 'object') {
      body = JSON.stringify(body);
      if (!headers['Content-Type'] && !headers['content-type']) {
        headers['Content-Type'] = 'application/json';
      }
    }
    const fetchOpts = {};
    if (cfg.followRedirects === false) fetchOpts.followRedirects = false;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body, fetchOpts);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        const hdrs = headerMap(res && res.headers);
        return {
          ok: isResponseOk(res, status),
          status,
          body: textBody,
          json: await readResponseJson(res, textBody),
          headers: hdrs,
          finalUrl: (res && res.finalUrl) || '',
        };
      }

      if (typeof fetch === 'function') {
        const res = await fetch(url, {
          method,
          headers,
          body,
          redirect: cfg.followRedirects === false ? 'manual' : 'follow',
        });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
          headers: headerMap(res.headers),
          finalUrl: res.url || '',
        };
      }

      return { ok: false, status: 0, body: '', json: null, headers: {}, finalUrl: '' };
    } catch (error) {
      log('request error: ' + (error && error.message ? error.message : String(error)));
      return { ok: false, status: 0, body: '', json: null, headers: {}, finalUrl: '' };
    }
  }

  function buildPosterUrl(poster) {
    if (!poster) return '';
    const key = poster.hq || poster.sm || '';
    if (!key) return '';
    return IMG_BASE + key + '.webp';
  }

  function cardFromItem(item) {
    const slug = String((item && item.slug) || '').trim();
    if (!slug) return null;
    return {
      title: decodeHtml((item && (item.title_en || item.title)) || slug),
      href: slug,
      image: buildPosterUrl(item && item.poster),
    };
  }

  function normalizeSlug(href) {
    const parsed = parseEpisodeRef(href);
    return parsed.slug || '';
  }

  function slugifyQuery(query) {
    return String(query || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function normForMatch(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .replace(/[’'`´:;.!?&,+()\[\]{}<>/\\|–—"]/g, ' ')
      .replace(/[\u2010-\u2015\u00b7]/g, ' ')
      .replace(/\bs\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function compactForMatch(value) {
    return normForMatch(value).replace(/[^a-z0-9]/g, '');
  }

  function isLowValueTitle(item) {
    const title = decodeHtml((item && (item.title_en || item.title)) || '').toLowerCase();
    const type = String((item && item.type) || '').toLowerCase();
    if (type === 'cm') return true;
    return /\b(recaps?|digest|collab|campaign|snickers|picture drama)\b/i.test(title);
  }

  function rankSearchItem(item, query) {
    const q = String(query || '').trim().toLowerCase();
    const slugQ = slugifyQuery(q);
    const normQ = normForMatch(q);
    const compactQ = compactForMatch(q);
    const title = decodeHtml((item && (item.title || item.title_en)) || '').toLowerCase();
    const titleEn = decodeHtml((item && (item.title_en || item.title)) || '').toLowerCase();
    const slug = String((item && item.slug) || '').toLowerCase();
    const type = String((item && item.type) || '').toLowerCase();
    if (!q) return 5;
    if (isLowValueTitle(item)) return 14;
    if (item && item._noLocales) return 13;

    const titleNorm = normForMatch(title);
    const titleEnNorm = normForMatch(titleEn);
    const titleCompact = compactForMatch(title);
    const slugCompact = compactForMatch(slug);

    if (compactQ && compactQ.length >= 3) {
      if (titleEnNorm === normQ || titleNorm === normQ || titleCompact === compactQ) {
        if (type === 'tv' || type === 'ona' || type === 'ova') return 0;
        return 1;
      }
      if (/\(2011\)/.test(titleEn) && compactQ === 'hunterxhunter') return 0;
      if (titleCompact.includes(compactQ) && compactQ.length >= 4) return 2;
    }
    if (slug === slugQ) return 3;
    if (new RegExp('^' + slugQ.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-[a-z0-9]+$').test(slug)) {
      return 4;
    }
    if (titleEnNorm.includes(normQ) || titleNorm.includes(normQ)) return 5;
    if (slugCompact.includes(compactQ) && compactQ.length >= 3) return 6;
    if (titleEn.includes(q) || title.includes(q)) return 7;
    if (slug.startsWith(slugQ + '-')) return 8;
    if (slug.includes(slugQ)) return 9;
    return 10;
  }

  function sortSearchItems(items, query) {
    const ranked = [];
    const seen = new Set();
    for (let i = 0; i < (items || []).length; i += 1) {
      const item = items[i];
      const slug = String((item && item.slug) || '').trim();
      if (!slug || seen.has(slug)) continue;
      seen.add(slug);
      ranked.push({
        item: item,
        rank: rankSearchItem(item, query),
        slugLen: slug.length,
      });
    }
    ranked.sort(function (a, b) {
      if (a.rank !== b.rank) return a.rank - b.rank;
      return a.slugLen - b.slugLen;
    });
    const out = [];
    for (let i = 0; i < ranked.length && out.length < 30; i += 1) {
      const card = cardFromItem(ranked[i].item);
      if (card) out.push(card);
    }
    return out;
  }

  async function fetchCatalogPage(page) {
    if (catalogCache[page] !== undefined) return catalogCache[page];
    const res = await settleWithin(
      request(BASE_URL + '/api/anime?page=' + page + '&perPage=30', {
        headers: { Accept: 'application/json' },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json || !Array.isArray(res.json.result)) {
      delete catalogCache[page];
      return null;
    }
    catalogCache[page] = res.json.result;
    const maxPage = Number(res.json.maxPage || 0);
    if (maxPage > catalogMaxPage) catalogMaxPage = maxPage;
    return res.json.result;
  }

  async function fsearch(query, page) {
    const res = await settleWithin(
      request(BASE_URL + '/api/fsearch', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: { query: String(query || ''), page: Math.max(1, Number(page) || 1) },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json) return [];
    if (Array.isArray(res.json.result)) return res.json.result;
    if (Array.isArray(res.json)) return res.json;
    return [];
  }

  async function quickSearch(query) {
    const res = await settleWithin(
      request(BASE_URL + '/api/search', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: { query: String(query || '') },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json) return [];
    if (Array.isArray(res.json)) return res.json;
    if (Array.isArray(res.json.result)) return res.json.result;
    return [];
  }

  async function fetchShowDetails(slug) {
    const key = String(slug || '').trim();
    if (!key) return null;
    if (showCache[key]) return showCache[key];
    const res = await settleWithin(
      request(BASE_URL + '/api/show/' + encodeURIComponent(key), {
        headers: { Accept: 'application/json' },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json || !res.json.slug) return null;
    showCache[key] = res.json;
    return res.json;
  }

  function queryVariants(query) {
    const q = String(query || '').trim();
    const lower = q.toLowerCase();
    const out = [q];
    const aliases = {
      'steins gate': ['steins;gate'],
      'fullmetal alchemist brotherhood': [
        'fullmetal alchemist: brotherhood',
        'fullmetal alchemist',
      ],
      'dr stone': ['dr. stone'],
      'mushishi': ['mushi-shi'],
      'hunter x hunter': ['hunter x hunter'],
    };
    const extra = aliases[lower] || [];
    for (let i = 0; i < extra.length; i += 1) out.push(extra[i]);
    if (lower.indexOf('.') < 0 && /\bdr\b/i.test(q)) {
      out.push(q.replace(/\bdr\b/i, 'dr.'));
    }
    if (lower.indexOf(';') < 0 && /\bgate\b/i.test(lower)) {
      out.push(q.replace(/\s+gate/i, ';gate'));
    }
    const uniq = [];
    const seen = {};
    for (let i = 0; i < out.length; i += 1) {
      const key = String(out[i] || '').toLowerCase();
      if (!key || seen[key]) continue;
      seen[key] = true;
      uniq.push(out[i]);
    }
    return uniq;
  }

  async function markUnplayable(items) {
    const slice = (items || []).slice(0, 8);
    await Promise.all(
      slice.map(function (item) {
        const slug = String((item && item.slug) || '').trim();
        if (!slug) return null;
        return fetchShowDetails(slug).then(function (show) {
          const locales = show && Array.isArray(show.locales) ? show.locales : [];
          item._noLocales = !locales.length;
          return show;
        });
      }),
    );
    return items;
  }

  async function searchByQuery(query) {
    const q = String(query || '').trim();
    if (!q) {
      const pageItems = await fetchCatalogPage(1);
      const out = [];
      for (let i = 0; i < (pageItems || []).length && out.length < 30; i += 1) {
        const card = cardFromItem(pageItems[i]);
        if (card) out.push(card);
      }
      return out;
    }

    const variants = queryVariants(q);
    let items = [];
    for (let i = 0; i < variants.length; i += 1) {
      const found = await fsearch(variants[i], 1);
      if (!found.length) continue;
      const usable = found.filter(function (item) { return !isLowValueTitle(item); });
      if (usable.length) {
        items = found;
        break;
      }
      if (!items.length) items = found;
    }
    if (!items.length) items = await quickSearch(q);
    if (!items.length) {
      const direct = await fetchShowDetails(slugifyQuery(q));
      if (direct) items = [direct];
    }
    if (!items.length) {
      const pageItems = await fetchCatalogPage(1);
      const compactQ = compactForMatch(q);
      const normQ = normForMatch(q);
      items = (pageItems || []).filter(function (item) {
        const title = decodeHtml(item.title_en || item.title || '');
        return (
          compactForMatch(title).indexOf(compactQ) >= 0 ||
          normForMatch(title).indexOf(normQ) >= 0
        );
      });
    }
    await markUnplayable(items);
    const playable = items.filter(function (item) { return !item._noLocales; });
    if (playable.length) items = playable;
    return sortSearchItems(items, q);
  }

  function unescapeManifest(text) {
    let t = String(text || '');
    t = t.replace(/\\u0026/g, '&').replace(/\\u002F/g, '/').replace(/\\\//g, '/');
    t = t.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
    return t;
  }

  function familyKey(title) {
    let t = normForMatch(title);
    t = t.replace(/\b(season|part|cour|series)\s*\d+\b/g, ' ');
    t = t.replace(/\b\d+(st|nd|rd|th)\s+season\b/g, ' ');
    t = t.replace(/\b(final season|the final chapters|the missing pieces)\b/g, ' ');
    t = t.replace(/\b(movie|film|ova|special|recaps?)\b/g, ' ');
    t = t.replace(/\b(ii|iii|iv)\b/g, ' ');
    t = t.replace(/\s+([1-9]|1[0-9]|20)$/g, ' ');
    return compactForMatch(t);
  }

  function uniqueCards(items, limit, usedHrefs, usedFamilies) {
    const out = [];
    const hrefs = usedHrefs || new Set();
    const families = usedFamilies || new Set();
    for (let i = 0; i < (items || []).length; i += 1) {
      const card = items[i] && items[i].href ? items[i] : cardFromItem(items[i]);
      if (!card || !card.href || hrefs.has(card.href)) continue;
      if (isLowValueTitle({ title: card.title, title_en: card.title, type: items[i] && items[i].type })) {
        continue;
      }
      const fam = familyKey(card.title);
      if (fam && families.has(fam)) continue;
      hrefs.add(card.href);
      if (fam) families.add(fam);
      out.push(card);
      if (limit && out.length >= limit) break;
    }
    return out;
  }

  function normalizeStreamUrl(url) {
    let raw = String(url || '').trim().replace(/\\u002F/gi, '/').replace(/\\\//g, '/');
    if (!raw) return '';
    raw = raw.replace(/^https:\/\/\//i, 'https://').replace(/^http:\/\/\//i, 'http://');
    if (raw.startsWith('//')) return 'https:' + raw;
    if (/^\/subbl\.|^\/subst\./i.test(raw)) return 'https://' + raw.slice(1);
    return raw;
  }

  function absoluteUrl(base, maybe) {
    const value = normalizeStreamUrl(maybe);
    if (!value) return '';
    if (/^https?:\/\//i.test(value)) return value;
    const root = String(base || '');
    try {
      return new URL(value, root).href;
    } catch (_) {
      const cut = root.lastIndexOf('/');
      return cut >= 0 ? root.slice(0, cut + 1) + value.replace(/^\//, '') : value;
    }
  }

  function extractKaaServers(html) {
    const source = decodeHtml(String(html || ''));
    const match = source.match(/servers:\[(\{.+?\}(?:,\{.+?\})*)\]/s);
    if (!match) return [];
    const raw = match[1];
    const nameMatches = [];
    const srcMatches = [];
    const nameRe = /name:"([^"]+)"/g;
    const srcRe = /src:"([^"]+)"/g;
    let nameHit = nameRe.exec(raw);
    while (nameHit) {
      nameMatches.push(nameHit[1]);
      nameHit = nameRe.exec(raw);
    }
    let srcHit = srcRe.exec(raw);
    while (srcHit) {
      srcMatches.push(srcHit[1]);
      srcHit = srcRe.exec(raw);
    }
    const servers = [];
    for (let i = 0; i < srcMatches.length; i += 1) {
      const src = normalizeStreamUrl(decodeHtml(srcMatches[i]));
      if (!src || !src.startsWith('http')) continue;
      const name = nameMatches[i] ? decodeHtml(nameMatches[i]) : 'Server ' + (i + 1);
      const isDash = /[?&]type=dash\b/i.test(src) || /\/dash\b/i.test(src);
      servers.push({ name: name, src: src, dash: isDash });
    }
    servers.sort(function (a, b) {
      if (a.dash !== b.dash) return a.dash ? 1 : -1;
      const aVid = /vidstream/i.test(a.name + a.src) ? 0 : 1;
      const bVid = /vidstream/i.test(b.name + b.src) ? 0 : 1;
      return aVid - bVid;
    });
    return servers;
  }

  function pickStreamFromHtml(html) {
    const text = unescapeManifest(decodeHtml(String(html || '')));
    const manifestMatch =
      text.match(/"manifest"\s*:\s*\[[^\]]*"(https?:\/\/[^"]+?\.m3u8[^"]*)"/i) ||
      text.match(/"manifest"\s*:\s*\[[^\]]*"(\/\/[^"]+?\.m3u8[^"]*)"/i) ||
      text.match(/manifest\s*:\s*\[[^\]]*"(https?:\/\/[^"]+?\.m3u8[^"]*)"/i) ||
      text.match(/manifest\s*:\s*\[[^\]]*"(\/\/[^"]+?\.m3u8[^"]*)"/i);
    if (manifestMatch && manifestMatch[1]) {
      return { url: normalizeStreamUrl(manifestMatch[1]), streamType: 'hls' };
    }
    const m3u8 =
      text.match(/https?:\/\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i) ||
      text.match(/\/\/[a-z0-9.-]+\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i);
    if (m3u8 && m3u8[0]) return { url: normalizeStreamUrl(m3u8[0]), streamType: 'hls' };
    const mp4 =
      text.match(/https?:\/\/[^"'\s<>]+?\.mp4(?:\?[^"'\s<>]*)?/i) ||
      text.match(/\/\/[a-z0-9.-]+\/[^"'\s<>]+?\.mp4(?:\?[^"'\s<>]*)?/i);
    if (mp4 && mp4[0]) return { url: normalizeStreamUrl(mp4[0]), streamType: 'mp4' };
    return null;
  }

  function pickSubtitlesFromHtml(html, embedUrl) {
    const text = unescapeManifest(decodeHtml(String(html || '')));
    const found = [];
    const seen = new Set();
    function pushSub(url, language, label) {
      const cleaned = normalizeStreamUrl(url);
      if (!cleaned || !/^https?:\/\//i.test(cleaned) || seen.has(cleaned)) return;
      if (!/\.(srt|vtt)(\?|$)/i.test(cleaned)) return;
      seen.add(cleaned);
      found.push({
        url: cleaned,
        file: cleaned,
        language: String(language || 'eng').toLowerCase(),
        label: decodeHtml(label || 'English'),
        kind: 'captions',
      });
    }
    const re =
      /"language"\s*:\s*(?:\[[^\]]*\])?\s*"?([a-zA-Z-]+)"?[\s\S]{0,220}?"name"\s*:\s*(?:\[[^\]]*\])?\s*"?([^"]+)"?[\s\S]{0,220}?"src"\s*:\s*(?:\[[^\]]*\])?\s*"(https?:\/\/\/?[^"]+)"/gi;
    let match;
    while ((match = re.exec(text))) {
      pushSub(match[3], match[1], match[2]);
    }
    const loose = text.match(/https?:\/\/\/?[^\s"']+\.(?:vtt|srt)(?:\?[^\s"']*)?/gi) || [];
    for (let i = 0; i < loose.length; i += 1) {
      pushSub(loose[i], 'eng', 'English');
    }
    void embedUrl;
    return found;
  }

  function parseAudioLanguages(masterBody) {
    const languages = [];
    const re = /#EXT-X-MEDIA:[^\r\n]*TYPE=AUDIO[^\r\n]*/gi;
    let match;
    while ((match = re.exec(String(masterBody || '')))) {
      const line = match[0];
      const lang = ((line.match(/LANGUAGE\s*=\s*"([^"]+)"/i) || [])[1] || '').toLowerCase();
      const name = ((line.match(/NAME\s*=\s*"([^"]+)"/i) || [])[1] || '').toLowerCase();
      const isDefault = /DEFAULT\s*=\s*YES/i.test(line);
      languages.push({ lang: lang, name: name, isDefault: isDefault, line: line });
    }
    return languages;
  }

  function hasEnglishAudio(languages) {
    for (let i = 0; i < (languages || []).length; i += 1) {
      const item = languages[i];
      if (
        /^(en|eng|english)(-|$)/i.test(item.lang) ||
        item.name === 'english' ||
        item.name.indexOf('english') >= 0
      ) {
        return true;
      }
    }
    return false;
  }

  function hasJapaneseAudio(languages) {
    for (let i = 0; i < (languages || []).length; i += 1) {
      const item = languages[i];
      if (
        /^(ja|jp|jpn|japanese)(-|$)/i.test(item.lang) ||
        item.name === 'japanese' ||
        item.name.indexOf('japanese') >= 0
      ) {
        return true;
      }
    }
    return false;
  }

  async function resolveRedirect(url, headers) {
    const raw = String(url || '').trim();
    if (!raw) return raw;
    const res = await settleWithin(
      request(raw, {
        headers: Object.assign({}, headers || {}, { Range: 'bytes=0-1' }),
        followRedirects: false,
      }),
      5000,
      null,
    );
    if (!res) return raw;
    const loc = (res.headers && (res.headers.location || res.headers.Location)) || '';
    if (loc) return absoluteUrl(raw, loc);
    if (res.finalUrl && /^https?:\/\//i.test(res.finalUrl) && res.finalUrl !== raw) {
      return res.finalUrl;
    }
    return raw;
  }

  async function inspectMaster(url) {
    const res = await settleWithin(
      request(url, { headers: HLS_HEADERS }),
      EMBED_TIMEOUT_MS,
      null,
    );
    if (!res || !res.body || String(res.body).indexOf('#EXTM3U') < 0) return null;
    const languages = parseAudioLanguages(res.body);
    return { body: res.body, languages: languages };
  }

  function withPlayerLang(embedUrl, wantDub) {
    let url = String(embedUrl || '');
    const ln = wantDub ? 'en-US' : 'ja-JP';
    if (/[?&]ln=/i.test(url)) {
      return url.replace(/([?&]ln=)[^&]*/i, '$1' + ln);
    }
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + 'ln=' + ln;
  }

  async function resolveEmbedStream(embedUrl, wantDub) {
    const candidates = [];
    const rewritten = withPlayerLang(embedUrl, wantDub);
    candidates.push(rewritten);
    if (rewritten !== embedUrl) candidates.push(String(embedUrl || ''));
    let lastBody = '';
    let playerUrl = rewritten;
    let picked = null;
    for (let i = 0; i < candidates.length && !picked; i += 1) {
      playerUrl = candidates[i];
      const res = await settleWithin(
        request(playerUrl, {
          headers: {
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*',
            Referer: BASE_URL + '/',
            Origin: BASE_URL,
          },
        }),
        EMBED_TIMEOUT_MS,
        null,
      );
      if (!res || !res.ok || !res.body) continue;
      lastBody = res.body;
      picked = pickStreamFromHtml(res.body);
    }
    if (!picked || !picked.url) return null;
    const subtitles = pickSubtitlesFromHtml(lastBody, playerUrl);
    let streamUrl = picked.url;
    if (picked.streamType === 'mp4') {
      streamUrl = await resolveRedirect(streamUrl, {
        'User-Agent': USER_AGENT,
        Referer: playerUrl,
        Origin: KRUSS_ORIGIN,
        Range: 'bytes=0-1',
      });
    }
    const inspection =
      picked.streamType === 'hls' ? await inspectMaster(streamUrl) : { languages: [] };
    const languages = (inspection && inspection.languages) || [];
    return {
      url: streamUrl,
      streamType: picked.streamType,
      headers: Object.assign({}, HLS_HEADERS),
      subtitles: subtitles,
      audioLanguages: languages.map(function (item) {
        return item.lang || item.name;
      }),
      hasEnglishAudio: hasEnglishAudio(languages),
      hasJapaneseAudio: hasJapaneseAudio(languages) || languages.length === 0,
    };
  }

  function parseEpisodeRef(raw) {
    let value = String(raw || '').trim();
    if (!value) return { slug: '', epSlug: '', epString: '', ja: '', en: '' };
    if (
      (value.charAt(0) === '{' && value.charAt(value.length - 1) === '}') ||
      (value.charAt(0) === '"' && value.indexOf('{') >= 0)
    ) {
      const json = safeJsonParse(value.charAt(0) === '"' ? safeJsonParse(value) || value : value);
      if (json && typeof json === 'object') {
        return {
          slug: String(json.s || json.slug || '').replace(/^\//, ''),
          epSlug: String(json.ep || json.ja || json.en || ''),
          epString: String(json.e || json.n || ''),
          ja: String(json.ja || ''),
          en: String(json.en || ''),
        };
      }
    }
    value = value.replace(/^https?:\/\/[^/]+/i, '');
    let query = '';
    const qIdx = value.indexOf('?');
    if (qIdx >= 0) {
      query = value.slice(qIdx + 1);
      value = value.slice(0, qIdx);
    }
    value = value.replace(/^\//, '');
    const parts = value.split('/');
    const slug = parts[0] || '';
    const epPart = parts[1] || '';
    const epMatch = epPart.match(/^ep-([^-]+)(?:-(.+))?$/i);
    const params = {};
    query.split('&').forEach(function (pair) {
      const bits = pair.split('=');
      if (bits[0]) params[decodeURIComponent(bits[0])] = decodeURIComponent(bits[1] || '');
    });
    return {
      slug: slug,
      epSlug: epMatch ? String(epMatch[2] || '') : '',
      epString: epMatch ? String(epMatch[1] || '') : '',
      ja: params.ja || '',
      en: params.en || '',
    };
  }

  function buildEpisodeHref(slug, epString, jaSlug, enSlug) {
    const primary = jaSlug || enSlug || '';
    let href = '/' + slug + '/ep-' + epString + (primary ? '-' + primary : '');
    const q = [];
    if (jaSlug) q.push('ja=' + encodeURIComponent(jaSlug));
    if (enSlug) q.push('en=' + encodeURIComponent(enSlug));
    if (q.length) href += '?' + q.join('&');
    return href;
  }

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    const cacheKey = 'q:' + q;
    try {
      let all = searchResultCache[cacheKey];
      if (!all) {
        all = await searchByQuery(q);
        searchResultCache[cacheKey] = all;
      }
      if (pageNumber <= 1) return all;
      if (q) {
        const extra = await fsearch(q, pageNumber);
        return sortSearchItems(extra, q);
      }
      const start = (pageNumber - 1) * 30;
      return all.slice(start, start + 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    const slug = normalizeSlug(urlOrId);
    if (!slug) {
      return { title: 'Unknown', description: 'No description available.' };
    }
    const data = await fetchShowDetails(slug);
    if (data) {
      const locales = Array.isArray(data.locales) ? data.locales : [];
      return {
        title: decodeHtml(data.title_en || data.title || slug),
        description: decodeHtml(data.synopsis || ''),
        airdate: data.year ? String(data.year) : '',
        image: buildPosterUrl(data.poster),
        locales: locales,
      };
    }
    return { title: slug, description: 'No description available.' };
  }

  async function fetchEpisodesPage(slug, page, lang) {
    const res = await settleWithin(
      request(
        BASE_URL +
          '/api/show/' +
          encodeURIComponent(slug) +
          '/episodes?page=' +
          page +
          '&lang=' +
          encodeURIComponent(lang),
        { headers: { Accept: 'application/json' } },
      ),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json) return null;
    return res.json;
  }

  async function fetchAllEpisodeRows(slug, lang) {
    const first = await fetchEpisodesPage(slug, 1, lang);
    if (!first || !Array.isArray(first.result) || !first.result.length) return [];
    const rows = first.result.slice();
    const pagesN = Array.isArray(first.pages) ? first.pages.length : 1;
    const remaining = [];
    for (let page = 2; page <= pagesN && page <= 40; page += 1) remaining.push(page);
    for (let i = 0; i < remaining.length; i += 4) {
      const batch = remaining.slice(i, i + 4);
      const parts = await Promise.all(
        batch.map(function (page) {
          return fetchEpisodesPage(slug, page, lang);
        }),
      );
      for (let p = 0; p < parts.length; p += 1) {
        if (parts[p] && Array.isArray(parts[p].result)) rows.push.apply(rows, parts[p].result);
      }
    }
    return rows;
  }

  function rowEpisodeNumber(row) {
    const n = Number(row && (row.episode_number || row.episodeNumber));
    return Number.isFinite(n) && n > 0 ? n : 0;
  }

  async function extractEpisodes(seriesId) {
    const slug = normalizeSlug(seriesId);
    if (!slug) return [];

    const pair = await Promise.all([
      fetchAllEpisodeRows(slug, 'ja-JP'),
      fetchAllEpisodeRows(slug, 'en-US'),
    ]);
    const subRows = pair[0] || [];
    const dubRows = pair[1] || [];
    const byNumber = {};

    function absorb(rows, langKey) {
      for (let i = 0; i < rows.length; i += 1) {
        const row = rows[i];
        const epNum = rowEpisodeNumber(row);
        if (epNum < 1) continue;
        const epSlug = String(row.slug || '').trim();
        const epString = String(row.episode_string || String(epNum));
        if (!byNumber[epNum]) {
          byNumber[epNum] = {
            number: epNum,
            epString: epString,
            title: String(row.title || '').trim(),
            ja: '',
            en: '',
          };
        }
        if (langKey === 'ja' && epSlug) byNumber[epNum].ja = epSlug;
        if (langKey === 'en' && epSlug) byNumber[epNum].en = epSlug;
        if (!byNumber[epNum].title && row.title) {
          byNumber[epNum].title = String(row.title).trim();
        }
      }
    }
    absorb(subRows, 'ja');
    absorb(dubRows, 'en');

    const numbers = Object.keys(byNumber)
      .map(Number)
      .sort(function (a, b) {
        return a - b;
      });
    const dubSamples = [];
    for (let i = 0; i < numbers.length && dubSamples.length < 2; i += 1) {
      const row = byNumber[numbers[i]];
      if (row.en) dubSamples.push(row);
    }
    for (let i = numbers.length - 1; i >= 0 && dubSamples.length < 2; i -= 1) {
      const row = byNumber[numbers[i]];
      if (row.en && dubSamples.indexOf(row) < 0) dubSamples.push(row);
    }
    let dubPlayersExist = dubSamples.length === 0;
    for (let i = 0; i < dubSamples.length; i += 1) {
      const row = dubSamples[i];
      const dubPath = '/' + slug + '/ep-' + row.epString + '-' + row.en;
      const resolved = await resolveEpisodeServers(dubPath);
      if (resolved.servers && resolved.servers.length) {
        dubPlayersExist = true;
        break;
      }
    }
    if (dubSamples.length && !dubPlayersExist) dubPlayersExist = false;

    const episodes = [];
    for (let i = 0; i < numbers.length && episodes.length < MAX_EPISODES; i += 1) {
      const row = byNumber[numbers[i]];
      episodes.push({
        number: row.number,
        href: buildEpisodeHref(slug, row.epString, row.ja, row.en),
        title: row.title,
        subAvailable: !!row.ja,
        dubAvailable: !!row.en && dubPlayersExist,
      });
    }
    if (episodes.length) return episodes;

    const show = await fetchShowDetails(slug);
    const watchUri = show && show.watch_uri ? String(show.watch_uri) : '';
    if (watchUri) {
      return [
        {
          number: 1,
          href: watchUri.charAt(0) === '/' ? watchUri : '/' + watchUri,
          subAvailable: true,
          dubAvailable: Array.isArray(show.locales) && show.locales.indexOf('en-US') >= 0,
        },
      ];
    }
    return [];
  }

  async function resolveEpisodeServers(episodePath) {
    const currentPath = String(episodePath || '').trim();
    if (!currentPath) return { servers: [], epPath: '', epUrl: '' };
    const epUrl = currentPath.startsWith('http')
      ? currentPath
      : BASE_URL + (currentPath.startsWith('/') ? currentPath : '/' + currentPath);
    const epRes = await settleWithin(
      request(epUrl, {
        headers: { Accept: 'text/html,application/xhtml+xml' },
      }),
      7000,
      null,
    );
    if (!epRes || !epRes.ok || !epRes.body) return { servers: [], epPath: currentPath, epUrl: epUrl };
    return { servers: extractKaaServers(epRes.body), epPath: currentPath, epUrl: epUrl };
  }

  function episodeWatchPath(ref, wantDub) {
    const epSlug = wantDub ? ref.en || ref.ja || ref.epSlug : ref.ja || ref.en || ref.epSlug;
    if (!ref.slug) return '';
    if (!epSlug) return '/' + ref.slug;
    const epString = ref.epString || '1';
    return '/' + ref.slug + '/ep-' + epString + '-' + epSlug;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseEpisodeRef(episodeHref);
    if (!ref.slug && !String(episodeHref || '').trim()) return { streams: [] };
    const wantDub = String(lang || '').toLowerCase() === 'dub';
    const label = wantDub ? 'dub' : 'sub';

    return settleWithin(
      (async function () {
        const paths = [];
        const preferred = episodeWatchPath(ref, wantDub);
        const fallback = episodeWatchPath(ref, !wantDub);
        if (preferred) paths.push(preferred);
        if (fallback && fallback !== preferred) paths.push(fallback);
        const raw = String(episodeHref || '').trim();
        if (raw && raw.indexOf('{') !== 0) {
          const stripped = raw.replace(/^https?:\/\/[^/]+/i, '');
          const noQuery = stripped.split('?')[0];
          if (noQuery && paths.indexOf(noQuery) < 0 && paths.indexOf(noQuery.replace(/^\//, '/')) < 0) {
            paths.push(noQuery.charAt(0) === '/' ? noQuery : '/' + noQuery);
          }
        }

        const collected = [];
        const seenSrc = {};
        for (let i = 0; i < paths.length; i += 1) {
          const resolved = await resolveEpisodeServers(paths[i]);
          const servers = (resolved && resolved.servers) || [];
          const fromDubPage = wantDub && i === 0;
          for (let s = 0; s < servers.length; s += 1) {
            const src = String(servers[s].src || '');
            if (!src || seenSrc[src]) continue;
            seenSrc[src] = true;
            collected.push(Object.assign({ fromDubPage: fromDubPage }, servers[s]));
          }
        }
        collected.sort(function (a, b) {
          if (a.dash !== b.dash) return a.dash ? 1 : -1;
          if (!!a.fromDubPage !== !!b.fromDubPage) return a.fromDubPage ? -1 : 1;
          const aVid = /vidstream|catstream/i.test(a.name + a.src) ? 0 : 1;
          const bVid = /vidstream|catstream/i.test(b.name + b.src) ? 0 : 1;
          return aVid - bVid;
        });
        if (!collected.length) return { streams: [] };

        let englishPayload = null;
        let dubPagePayload = null;
        for (let i = 0; i < collected.length; i += 1) {
          const server = collected[i];
          if (server.dash) continue;
          const embed = await resolveEmbedStream(server.src, wantDub);
          if (!embed || !embed.url) continue;
          const payload = {
            streams: [label, embed.url],
            headers: embed.headers,
            quality: 'auto',
            lang: label,
            streamType: embed.streamType || 'hls',
            subtitles: embed.subtitles || [],
            audioLanguages: embed.audioLanguages || [],
          };
          if (!wantDub) return payload;
          if (embed.hasEnglishAudio) {
            englishPayload = payload;
            break;
          }
          if (server.fromDubPage && !dubPagePayload) dubPagePayload = payload;
        }
        return englishPayload || dubPagePayload || { streams: [] };
      })(),
      STREAM_DEADLINE_MS,
      { streams: [] },
    );
  }

  async function discoveryHome() {
    const sections = [];
    const usedHrefs = new Set();
    const usedFamilies = new Set();
    try {
      const trendingRes = await settleWithin(
        request(BASE_URL + '/api/anime_trending', { headers: { Accept: 'application/json' } }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      const trendingJson = trendingRes && trendingRes.json;
      const trendingList = Array.isArray(trendingJson)
        ? trendingJson
        : trendingJson && Array.isArray(trendingJson.result)
          ? trendingJson.result
          : [];
      const featured = uniqueCards(trendingList, 8, usedHrefs, usedFamilies);
      if (featured.length) {
        sections.push({
          id: 'featured',
          title: 'Featured',
          style: 'hero',
          items: featured,
        });
      }
      const trendingCards = uniqueCards(trendingList, 16, usedHrefs, usedFamilies);
      if (trendingCards.length) {
        sections.push({
          id: 'trending',
          title: 'Trending',
          style: 'poster',
          items: trendingCards,
          viewAll: { mode: 'feed', feedId: 'trending' },
        });
      }

      const pageItems = await fetchCatalogPage(1);
      const browseCards = uniqueCards(pageItems || [], 24, usedHrefs, usedFamilies);
      if (browseCards.length) {
        sections.push({
          id: 'browse',
          title: 'Browse',
          style: 'poster',
          items: browseCards,
          viewAll: { mode: 'feed', feedId: 'browse' },
        });
      }
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
    }
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    const key = String(feedId || '').trim().toLowerCase();
    const pageNumber = Math.max(1, Number(page) || 1);
    const items = [];
    if (key === 'trending' || key === 'trend') {
      const trendingRes = await settleWithin(
        request(BASE_URL + '/api/anime_trending', { headers: { Accept: 'application/json' } }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      const trendingJson = trendingRes && trendingRes.json;
      const trendingList = Array.isArray(trendingJson)
        ? trendingJson
        : trendingJson && Array.isArray(trendingJson.result)
          ? trendingJson.result
          : [];
      for (let i = 0; i < trendingList.length; i += 1) {
        const card = cardFromItem(trendingList[i]);
        if (card) items.push(card);
      }
      return { items: items, page: 1, hasMore: false };
    }

    const pageItems = await fetchCatalogPage(pageNumber);
    if (Array.isArray(pageItems)) {
      for (let i = 0; i < pageItems.length; i += 1) {
        const card = cardFromItem(pageItems[i]);
        if (card) items.push(card);
      }
    }
    const maxPage = catalogMaxPage || pageNumber;
    return { items: items, page: pageNumber, hasMore: pageNumber < maxPage };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults: searchResults,
      extractDetails: extractDetails,
      extractEpisodes: extractEpisodes,
      extractStreamUrl: extractStreamUrl,
      discoveryHome: discoveryHome,
      discoveryFeed: discoveryFeed,
    };
  }
})();
