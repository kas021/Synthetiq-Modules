(function () {
  'use strict';

  const BASE_URL = 'https://www.animeunity.so';
  const VIX_BASE = 'https://vixcloud.co';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

  let sessionCache = null;
  const showCache = {};

  function log(msg) {
    if (typeof console !== 'undefined' && console.log) {
      console.log('[AnimeUnity] ' + msg);
    }
  }

  function cleanText(t) {
    if (!t) return '';
    return String(t)
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#039;/g, "'")
      .trim();
  }

  async function getSession(forceRefresh = false) {
    if (!forceRefresh && sessionCache && Date.now() - sessionCache.timestamp < 25 * 60 * 1000) {
      return sessionCache;
    }
    try {
      const res = await globalThis.fetchv2(BASE_URL + '/', { 'User-Agent': USER_AGENT });
      const html = (res && res.body) || '';
      const csrf = (html.match(/<meta name="csrf-token" content="([^"]+)"/i) || [])[1] || '';

      const rawCookies = (res && res.headers && res.headers['set-cookie']) || '';
      const cookies = [];
      if (Array.isArray(rawCookies)) {
        for (let i = 0; i < rawCookies.length; i++) {
          cookies.push(rawCookies[i].split(';')[0]);
        }
      } else if (typeof rawCookies === 'string' && rawCookies) {
        const parts = rawCookies.split(/,(?=[^;]+=[^;]+)/);
        for (let i = 0; i < parts.length; i++) {
          cookies.push(parts[i].split(';')[0].trim());
        }
      }

      sessionCache = {
        csrf: csrf,
        cookieHeader: cookies.join('; '),
        timestamp: Date.now()
      };
      return sessionCache;
    } catch (e) {
      log('getSession error: ' + (e && e.message ? e.message : e));
      return { csrf: '', cookieHeader: '', timestamp: Date.now() };
    }
  }

  async function postArchive(payload, retry = true) {
    const session = await getSession();
    const headers = {
      'User-Agent': USER_AGENT,
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/plain, */*',
      'X-CSRF-TOKEN': session.csrf,
      'Cookie': session.cookieHeader,
      'X-Requested-With': 'XMLHttpRequest',
      'Origin': BASE_URL,
      'Referer': BASE_URL + '/archivio'
    };

    const res = await globalThis.fetchv2(
      BASE_URL + '/archivio/get-animes',
      headers,
      'POST',
      JSON.stringify(payload)
    );

    if (res && res.status === 419 && retry) {
      log('CSRF token expired (419), refreshing session...');
      await getSession(true);
      return postArchive(payload, false);
    }

    try {
      return JSON.parse((res && res.body) || '{}');
    } catch (e) {
      log('postArchive JSON parse error: ' + (e && e.message ? e.message : e));
      return {};
    }
  }

  function mapRecordToCard(r, rank) {
    const rawTitle = cleanText(r.title_eng || r.title || r.title_it || r.slug || '');
    const isDub = r.dub === 1;
    const tag = isDub && rawTitle.indexOf('ITA') < 0 ? ' [ITA DUB]' : '';
    const href = '/anime/' + r.id + '-' + (r.slug || 'anime');
    const poster = r.imageurl || r.imageurl_cover || '';
    const banner = r.imageurl_cover || r.imageurl || '';

    // Prime cache
    showCache[href] = {
      id: String(r.id),
      slug: r.slug || '',
      episodesCount: r.real_episodes_count || r.episodes_count || 0,
      title: rawTitle + tag,
      plot: r.plot || '',
      poster: poster,
      banner: banner,
      date: r.date || '',
      status: r.status || '',
      score: r.score || undefined,
      dub: isDub,
      type: r.type || 'TV',
      savedAt: Date.now()
    };

    return {
      id: String(r.id),
      title: rawTitle + tag,
      href: href,
      image: poster,
      poster: poster,
      banner: banner,
      type: r.type || 'TV',
      status: r.status === 'Terminato' ? 'Completed' : (r.status === 'In corso' ? 'Ongoing' : (r.status || '')),
      score: r.score ? String(r.score) : undefined,
      description: r.plot || '',
      language: isDub ? 'Italian (Dub)' : 'Italian (Sub)',
      rank: rank
    };
  }

  async function searchResults(keyword, page = 0) {
    try {
      const q = typeof keyword === 'string' ? keyword.trim() : '';
      if (!q) {
        const json = await postArchive({
          title: '',
          type: false,
          year: false,
          order: 'popolarita',
          status: false,
          genres: false,
          offset: (page || 0) * 30,
          dubbed: false,
          season: false
        });
        const records = (json && json.records) || [];
        return records.map((r, idx) => mapRecordToCard(r, idx + 1));
      }

      // First try exact query
      const exactJson = await postArchive({
        title: q,
        type: false,
        year: false,
        order: 'popolarita',
        status: false,
        genres: false,
        offset: (page || 0) * 30,
        dubbed: false,
        season: false
      });
      const exactRecords = (exactJson && exactJson.records) || [];
      if (exactRecords.length) {
        return exactRecords.map((r, idx) => mapRecordToCard(r, idx + 1));
      }

      // Multi-word fallback & fuzzy rank
      const words = q.split(/\s+/).filter(w => w.length > 1);
      if (words.length <= 1) {
        return [];
      }

      const subQueries = [];
      if (words.length >= 2) subQueries.push(words.slice(0, 2).join(' '));
      if (words.length >= 3) subQueries.push(words.slice(0, 3).join(' '));
      subQueries.push(words[words.length - 1]);
      subQueries.push(words[0]);

      const candidateMap = {};
      for (let s = 0; s < subQueries.length; s++) {
        const sq = subQueries[s];
        const subJson = await postArchive({
          title: sq,
          type: false,
          year: false,
          order: 'popolarita',
          status: false,
          genres: false,
          offset: 0,
          dubbed: false,
          season: false
        });
        const subRecs = (subJson && subJson.records) || [];
        for (let j = 0; j < subRecs.length; j++) {
          const r = subRecs[j];
          if (r && r.id && !candidateMap[r.id]) {
            candidateMap[r.id] = r;
          }
        }
      }

      const candidates = Object.values(candidateMap);
      const qLower = q.toLowerCase();
      const qWords = words.map(w => w.toLowerCase());

      candidates.sort((a, b) => {
        const aTitle = ((a.title_eng || a.title || a.title_it || a.slug || '')).toLowerCase();
        const bTitle = ((b.title_eng || b.title || b.title_it || b.slug || '')).toLowerCase();
        let aScore = 0;
        let bScore = 0;
        for (let k = 0; k < qWords.length; k++) {
          const w = qWords[k];
          if (aTitle.indexOf(w) >= 0) aScore += 10;
          if (bTitle.indexOf(w) >= 0) bScore += 10;
        }
        if (aTitle.indexOf(qLower) >= 0) aScore += 50;
        if (bTitle.indexOf(qLower) >= 0) bScore += 50;
        return bScore - aScore;
      });

      const filtered = candidates.filter(c => {
        const t = ((c.title_eng || c.title || c.title_it || c.slug || '')).toLowerCase();
        let matchCount = 0;
        for (let k = 0; k < qWords.length; k++) {
          if (t.indexOf(qWords[k]) >= 0) matchCount++;
        }
        return matchCount >= Math.min(2, qWords.length);
      });

      return filtered.slice(0, 30).map((r, idx) => mapRecordToCard(r, idx + 1));
    } catch (e) {
      log('searchResults error: ' + (e && e.message ? e.message : e));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    try {
      let slug = '';
      let id = '';
      const str = String(urlOrId).replace(/^https?:\/\/[^\/]+/i, '');
      const m = str.match(/\/anime\/(\d+)(?:-([^/?#]+))?/i) || str.match(/^(\d+)(?:-([^/?#]+))?$/);
      if (m) {
        id = m[1];
        slug = m[2] || '';
      } else {
        id = str;
      }

      const cacheKey = '/anime/' + id + (slug ? '-' + slug : '');
      const cached = showCache[cacheKey];

      let anime = {};
      let totalEpisodes = 0;

      const pageUrl = BASE_URL + '/anime/' + id + (slug ? '-' + slug : '');
      const res = await globalThis.fetchv2(pageUrl, { 'User-Agent': USER_AGENT });
      const html = (res && res.body) || '';

      const playerM = html.match(/<video-player anime="([^"]+)"/i);
      if (playerM) {
        try {
          anime = JSON.parse(
            playerM[1]
              .replace(/&quot;/g, '"')
              .replace(/&#039;/g, "'")
              .replace(/&amp;/g, '&')
          );
        } catch (_) {}
      }

      const countM = html.match(/episodes_count="(\d+)"/i);
      if (countM) {
        totalEpisodes = parseInt(countM[1], 10);
      } else {
        totalEpisodes = anime.real_episodes_count || anime.episodes_count || (cached && cached.episodesCount) || 0;
      }

      const rawTitle = cleanText(anime.title_eng || anime.title || anime.title_it || (cached && cached.title) || slug || '');
      const isDub = anime.dub === 1 || (cached && cached.dub);
      const tag = isDub && rawTitle.indexOf('ITA') < 0 ? ' [ITA DUB]' : '';

      const detailsObj = {
        id: String(id),
        title: rawTitle + tag,
        description: anime.plot || (cached && cached.plot) || '',
        synopsis: anime.plot || (cached && cached.plot) || '',
        poster: anime.imageurl || anime.imageurl_cover || (cached && cached.poster) || '',
        banner: anime.imageurl_cover || anime.imageurl || (cached && cached.banner) || '',
        status: anime.status === 'Terminato' ? 'Completed' : (anime.status === 'In corso' ? 'Ongoing' : (anime.status || '')),
        year: anime.date ? parseInt(anime.date, 10) : undefined,
        genres: Array.isArray(anime.genres) ? anime.genres.map(g => g.name || g) : [],
        rating: anime.score ? parseFloat(anime.score) : undefined,
        episodesCount: totalEpisodes,
        type: anime.type || (cached && cached.type) || 'TV',
        slug: anime.slug || slug || (cached && cached.slug) || ''
      };

      showCache[cacheKey] = Object.assign({}, detailsObj, { savedAt: Date.now() });
      return detailsObj;
    } catch (e) {
      log('extractDetails error: ' + (e && e.message ? e.message : e));
      return {
        id: String(urlOrId),
        title: 'Anime',
        description: '',
        episodesCount: 1,
        genres: []
      };
    }
  }

  async function extractEpisodes(seriesId) {
    try {
      const details = await extractDetails(seriesId);
      const id = details.id;
      const slug = details.slug || 'anime';
      const total = Math.max(1, details.episodesCount || 1);

      const chunkSize = 120;
      const totalChunks = Math.ceil(total / chunkSize);
      const chunkPromises = [];

      for (let i = 0; i < totalChunks; i++) {
        const start = 1 + i * chunkSize;
        const end = Math.min(total, (i + 1) * chunkSize);
        const chunkUrl = BASE_URL + '/info_api/' + id + '/' + slug + '?start_range=' + start + '&end_range=' + end;
        chunkPromises.push(
          globalThis.fetchv2(chunkUrl, {
            'User-Agent': USER_AGENT,
            'X-Requested-With': 'XMLHttpRequest'
          }).then(res => {
            try {
              return JSON.parse((res && res.body) || '{}');
            } catch (_) {
              return {};
            }
          }).catch(() => ({}))
        );
      }

      const chunkResults = await Promise.all(chunkPromises);
      const allEpisodes = [];

      for (let c = 0; c < chunkResults.length; c++) {
        const eps = (chunkResults[c] && chunkResults[c].episodes) || [];
        for (let j = 0; j < eps.length; j++) {
          const ep = eps[j];
          if (!ep || !ep.id) continue;
          const cleanName = ep.file_name
            ? ep.file_name.replace(/\.mkv$/i, '').replace(/\.mp4$/i, '').replace(/_/g, ' ')
            : 'Episodio ' + ep.number;
          const num = parseFloat(ep.number) || (allEpisodes.length + 1);

          allEpisodes.push({
            id: String(ep.id),
            number: num,
            episodeNumber: num,
            season: 1,
            seasonNumber: 1,
            name: cleanName,
            title: cleanName,
            href: '/embed-url/' + ep.id + '?scws=' + (ep.scws_id || '')
          });
        }
      }

      if (!allEpisodes.length) {
        allEpisodes.push({
          id: String(id),
          number: 1,
          episodeNumber: 1,
          season: 1,
          seasonNumber: 1,
          name: details.title || 'Movie / Special',
          title: details.title || 'Movie / Special',
          href: '/embed-url/' + id
        });
      }

      return allEpisodes;
    } catch (e) {
      log('extractEpisodes error: ' + (e && e.message ? e.message : e));
      return [];
    }
  }

  async function extractStreamUrl(episodeHref, lang = 'sub') {
    try {
      const m = String(episodeHref).match(/\/embed-url\/(\d+)/i) || String(episodeHref).match(/(\d+)/);
      if (!m) return { streams: [] };
      const episodeId = m[1];

      const embedRes = await globalThis.fetchv2(BASE_URL + '/embed-url/' + episodeId, {
        'User-Agent': USER_AGENT,
        'Referer': BASE_URL + '/'
      });

      const embedUrl = ((embedRes && embedRes.body) || '').trim();
      if (!embedUrl || !embedUrl.startsWith('http')) {
        log('embed-url not available for episode: ' + episodeId);
        return { streams: [] };
      }

      const vixRes = await globalThis.fetchv2(embedUrl, {
        'User-Agent': USER_AGENT,
        'Referer': BASE_URL + '/'
      });

      const html = (vixRes && vixRes.body) || '';
      const tokenM = html.match(/'token':\s*'([^']+)'/i);
      const expiresM = html.match(/'expires':\s*'([^']+)'/i);
      const videoIdM = html.match(/id:\s*'(\d+)'/i) || embedUrl.match(/\/embed\/(\d+)/);
      const downloadUrlM = html.match(/window\.downloadUrl\s*=\s*'([^']+)'/i);
      const thumbsM = html.match(/window\.thumbnailsUrl\s*=\s*'([^']+)'/i);

      if (!tokenM || !expiresM || !videoIdM) {
        log('Could not extract VixCloud parameters from embed HTML');
        return { streams: [] };
      }

      const token = tokenM[1];
      const expires = expiresM[1];
      const scwsId = videoIdM[1];
      const masterUrl = VIX_BASE + '/playlist/' + scwsId + '?token=' + token + '&expires=' + expires + '&h=1';

      const playRes = await globalThis.fetchv2(masterUrl, {
        'User-Agent': USER_AGENT,
        'Referer': VIX_BASE + '/embed/' + scwsId
      });

      const masterM3u8 = (playRes && playRes.body) || '';
      const streams = [];
      const qualities = [];

      const lines = masterM3u8.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.startsWith('#EXT-X-STREAM-INF:')) {
          const resMatch = line.match(/RESOLUTION=(\d+)x(\d+)/i);
          const height = resMatch ? parseInt(resMatch[2], 10) : 720;
          const renditionUrl = (lines[i + 1] || '').trim();
          if (renditionUrl && renditionUrl.startsWith('http')) {
            streams.push({
              label: 'AnimeUnity · ' + height + 'p',
              url: renditionUrl,
              quality: height,
              streamType: 'hls',
              kind: 'hls',
              provider: 'animeunity-vixcloud',
              headers: {
                'User-Agent': USER_AGENT,
                'Referer': VIX_BASE + '/',
                'Origin': VIX_BASE
              }
            });
            qualities.push({
              label: height + 'p · AnimeUnity HD',
              url: renditionUrl,
              height: height,
              headers: {
                'User-Agent': USER_AGENT,
                'Referer': VIX_BASE + '/',
                'Origin': VIX_BASE
              }
            });
          }
        }
      }

      if (!streams.length && masterM3u8.indexOf('#EXTM3U') >= 0) {
        streams.push({
          label: 'AnimeUnity · Auto HD',
          url: masterUrl,
          quality: 1080,
          streamType: 'hls',
          kind: 'hls',
          provider: 'animeunity-vixcloud',
          headers: {
            'User-Agent': USER_AGENT,
            'Referer': VIX_BASE + '/',
            'Origin': VIX_BASE
          }
        });
      }

      if (downloadUrlM && downloadUrlM[1]) {
        const dlUrl = downloadUrlM[1];
        streams.push({
          label: 'AnimeUnity · Direct MP4 (1080p)',
          url: dlUrl,
          quality: 1080,
          streamType: 'mp4',
          kind: 'mp4',
          provider: 'animeunity-vixcloud-mp4',
          headers: {
            'User-Agent': USER_AGENT,
            'Referer': VIX_BASE + '/',
            'Origin': VIX_BASE
          }
        });
      }

      const subtitles = [];
      if (thumbsM && thumbsM[1]) {
        subtitles.push({
          label: 'Thumbnails',
          file: thumbsM[1],
          kind: 'thumbnails',
          default: false
        });
      }

      const primary = streams[0] || {};
      return {
        streams: streams,
        qualities: qualities,
        subtitles: subtitles,
        url: primary.url || '',
        stream: primary.url || '',
        headers: primary.headers || {
          'User-Agent': USER_AGENT,
          'Referer': VIX_BASE + '/',
          'Origin': VIX_BASE
        },
        streamType: primary.streamType || 'hls',
        quality: primary.quality || 1080,
        lang: lang
      };
    } catch (e) {
      log('extractStreamUrl error: ' + (e && e.message ? e.message : e));
      return { streams: [] };
    }
  }

  async function discoveryHome() {
    try {
      const [popRes, dubRes, latestRes] = await Promise.all([
        postArchive({
          title: '',
          type: false,
          year: false,
          order: 'popolarita',
          status: false,
          genres: false,
          offset: 0,
          dubbed: false,
          season: false
        }),
        postArchive({
          title: '',
          type: false,
          year: false,
          order: 'popolarita',
          status: false,
          genres: false,
          offset: 0,
          dubbed: true,
          season: false
        }),
        postArchive({
          title: '',
          type: false,
          year: false,
          order: 'data',
          status: false,
          genres: false,
          offset: 0,
          dubbed: false,
          season: false
        })
      ]);

      const popRecords = (popRes && popRes.records) || [];
      const dubRecords = (dubRes && dubRes.records) || [];
      const latestRecords = (latestRes && latestRes.records) || [];

      const sections = [];

      if (popRecords.length) {
        sections.push({
          id: 'featured',
          title: 'In Evidenza',
          style: 'hero',
          items: popRecords.slice(0, 8).map((r, i) => mapRecordToCard(r, i + 1))
        });

        sections.push({
          id: 'popular',
          title: 'I Più Popolari',
          style: 'poster',
          items: popRecords.slice(0, 24).map((r, i) => mapRecordToCard(r, i + 1)),
          viewAll: { mode: 'feed', feedId: 'popular' }
        });
      }

      if (dubRecords.length) {
        sections.push({
          id: 'dubbed',
          title: 'Doppiati in Italiano (ITA)',
          style: 'poster',
          items: dubRecords.slice(0, 24).map((r, i) => mapRecordToCard(r, i + 1)),
          viewAll: { mode: 'feed', feedId: 'dubbed' }
        });
      }

      if (latestRecords.length) {
        sections.push({
          id: 'latest',
          title: 'Ultime Uscite',
          style: 'poster',
          items: latestRecords.slice(0, 24).map((r, i) => mapRecordToCard(r, i + 1)),
          viewAll: { mode: 'feed', feedId: 'latest' }
        });
      }

      return { sections: sections };
    } catch (e) {
      log('discoveryHome error: ' + (e && e.message ? e.message : e));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page = 1) {
    try {
      const p = Math.max(1, Number(page) || 1);
      const isDub = feedId === 'dubbed';
      const order = feedId === 'latest' ? 'data' : 'popolarita';

      const json = await postArchive({
        title: '',
        type: false,
        year: false,
        order: order,
        status: false,
        genres: false,
        offset: (p - 1) * 30,
        dubbed: isDub,
        season: false
      });

      const records = (json && json.records) || [];
      const total = (json && json.tot) || 0;

      return {
        items: records.map((r, i) => mapRecordToCard(r, (p - 1) * 30 + i + 1)),
        page: p,
        hasMore: p * 30 < total
      };
    } catch (e) {
      log('discoveryFeed error: ' + (e && e.message ? e.message : e));
      return { items: [], page: Number(page) || 1, hasMore: false };
    }
  }

  // Export to global scope
  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults: searchResults,
      extractDetails: extractDetails,
      extractEpisodes: extractEpisodes,
      extractStreamUrl: extractStreamUrl,
      discoveryHome: discoveryHome,
      discoveryFeed: discoveryFeed
    };
  }
})();
