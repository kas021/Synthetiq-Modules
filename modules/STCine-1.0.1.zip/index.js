(() => {
  'use strict';

  const MODULE_NAME = 'STCine';
  const SITE = 'https://stcine.com';
  const API = SITE + '/api';
  const TMDB_IMG = 'https://image.tmdb.org/t/p/w500';
  const VIDEASY_ORIGIN = 'https://player.videasy.to';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  // Public TMDB key used by many free frontends (including STCine SPA). Catalogue fallback only.
  const TMDB_KEY = '9801b6b0548ad57581d111ea690c85c8';

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function encodeQuery(params) {
    const parts = [];
    Object.keys(params || {}).forEach((k) => {
      const v = params[k];
      if (v === undefined || v === null || v === '') return;
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
    });
    return parts.join('&');
  }


  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        return JSON.stringify(await res.json());
      } catch (_) {}
    }
    return '';
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          body: textBody,
          json: safeJsonParse(textBody),
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null };
  }

  function posterUrl(path) {
    const p = cleanText(path || '');
    if (!p) return '';
    if (/^https?:\/\//i.test(p)) return p;
    return TMDB_IMG + (p.startsWith('/') ? p : '/' + p);
  }

  function cardFromStcine(item) {
    if (!item) return null;
    const tmdbId = item.tmdbId || item.id;
    if (!tmdbId) return null;
    const type = String(item.type || 'movie').toLowerCase() === 'tv' ? 'tv' : 'movie';
    const href = type === 'tv' ? ('tv:' + tmdbId) : ('movie:' + tmdbId);
    return {
      href: href,
      id: href,
      title: cleanText(item.title || item.name || ('TMDB ' + tmdbId)),
      image: posterUrl(item.poster_path || item.backdrop_path),
      poster: posterUrl(item.poster_path || item.backdrop_path),
    };
  }

  function cardFromTmdb(item, typeHint) {
    if (!item) return null;
    const isTv = typeHint === 'tv' || item.media_type === 'tv' || (!!item.name && !item.title);
    const tmdbId = item.id;
    if (!tmdbId) return null;
    const href = isTv ? ('tv:' + tmdbId) : ('movie:' + tmdbId);
    return {
      href: href,
      id: href,
      title: cleanText(item.title || item.name || ('TMDB ' + tmdbId)),
      image: posterUrl(item.poster_path),
      poster: posterUrl(item.poster_path),
    };
  }

  function parseHref(raw) {
    const s = String(raw || '').trim();
    // movie:123 | tv:456 | tv:456:1:3 | legacy stcine player urls
    let m = s.match(/^(movie|tv):(\d+)(?::(\d+):(\d+))?$/i);
    if (m) {
      return {
        type: m[1].toLowerCase(),
        tmdbId: m[2],
        season: m[3] ? Number(m[3]) : 1,
        episode: m[4] ? Number(m[4]) : 1,
      };
    }
    m = s.match(/[?&]id=(\d+)/i);
    if (m) {
      const type = /type=tv/i.test(s) ? 'tv' : 'movie';
      return { type: type, tmdbId: m[1], season: 1, episode: 1 };
    }
    m = s.match(/\/(movie|tv)\/(\d+)/i);
    if (m) return { type: m[1].toLowerCase(), tmdbId: m[2], season: 1, episode: 1 };
    if (/^\d+$/.test(s)) return { type: 'movie', tmdbId: s, season: 1, episode: 1 };
    return null;
  }

  async function stcineList(type, page, search) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const qs = encodeQuery({
      status: 'published',
      type: type === 'tv' ? 'tv' : 'movie',
      limit: '24',
      page: String(pageNumber),
      search: search || undefined,
    });
    const res = await settleWithin(
      request(API + '/movies?' + qs, {
        headers: { Accept: 'application/json', Referer: SITE + '/' },
      }),
      15000,
      null,
    );
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : Array.isArray(data) ? data : [];
    return results.map(cardFromStcine).filter(Boolean);
  }

  async function tmdbSearch(query) {
    const q = encodeURIComponent(query);
    const url =
      'https://api.themoviedb.org/3/search/multi?api_key=' +
      TMDB_KEY +
      '&query=' +
      q +
      '&include_adult=false&language=en-US&page=1';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results
      .filter((r) => r && (r.media_type === 'movie' || r.media_type === 'tv'))
      .map((r) => cardFromTmdb(r))
      .filter(Boolean)
      .slice(0, 30);
  }

  async function tmdbPopular(kind) {
    const type = kind === 'tv' ? 'tv' : 'movie';
    const url =
      'https://api.themoviedb.org/3/' +
      type +
      '/popular?api_key=' +
      TMDB_KEY +
      '&language=en-US&page=1';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results.map((r) => cardFromTmdb(r, type)).filter(Boolean).slice(0, 20);
  }

  async function searchResults(query, page) {
    const q = cleanText(query || '');
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      if (!q) {
        const movies = await stcineList('movie', pageNumber, '');
        if (movies.length) return movies;
        return await tmdbPopular('movie');
      }
      // STCine search first, then TMDB if thin
      let cards = await stcineList('movie', pageNumber, q);
      const tv = await stcineList('tv', pageNumber, q);
      cards = cards.concat(tv);
      // Prefer exact-ish matches
      const lower = q.toLowerCase();
      cards.sort((a, b) => {
        const as = a.title.toLowerCase() === lower ? 0 : a.title.toLowerCase().includes(lower) ? 1 : 2;
        const bs = b.title.toLowerCase() === lower ? 0 : b.title.toLowerCase().includes(lower) ? 1 : 2;
        return as - bs;
      });
      if (cards.length < 5) {
        const tmdb = await tmdbSearch(q);
        const seen = new Set(cards.map((c) => c.href));
        for (const c of tmdb) {
          if (!seen.has(c.href)) {
            cards.push(c);
            seen.add(c.href);
          }
        }
      }
      return cards.slice(0, 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    const ref = parseHref(urlOrId);
    if (!ref) return { title: 'Unknown', description: '' };
    try {
      // Prefer TMDB for reliable metadata
      const path = ref.type === 'tv' ? 'tv' : 'movie';
      const url =
        'https://api.themoviedb.org/3/' +
        path +
        '/' +
        ref.tmdbId +
        '?api_key=' +
        TMDB_KEY +
        '&language=en-US';
      const res = await settleWithin(request(url), 12000, null);
      const d = (res && (res.json || safeJsonParse(res.body))) || {};
      const title = cleanText(d.title || d.name || ('TMDB ' + ref.tmdbId));
      return {
        title: title,
        description: cleanText(d.overview || ''),
        image: posterUrl(d.poster_path || d.backdrop_path),
        href: ref.type === 'tv' ? ('tv:' + ref.tmdbId) : ('movie:' + ref.tmdbId),
        year: cleanText((d.release_date || d.first_air_date || '').slice(0, 4)),
      };
    } catch (e) {
      log('details error: ' + (e && e.message ? e.message : String(e)));
      return {
        title: ref.type + ' ' + ref.tmdbId,
        description: '',
        href: ref.type + ':' + ref.tmdbId,
      };
    }
  }

  async function extractEpisodes(seriesId) {
    const ref = parseHref(seriesId);
    if (!ref) return [];
    if (ref.type === 'movie') {
      return [{
        number: 1,
        href: 'movie:' + ref.tmdbId,
        title: 'Movie',
        subAvailable: true,
        dubAvailable: false,
      }];
    }
    // TV: expand seasons from TMDB
    try {
      const infoUrl =
        'https://api.themoviedb.org/3/tv/' +
        ref.tmdbId +
        '?api_key=' +
        TMDB_KEY +
        '&language=en-US';
      const infoRes = await settleWithin(request(infoUrl), 12000, null);
      const info = (infoRes && (infoRes.json || safeJsonParse(infoRes.body))) || {};
      const seasons = Array.isArray(info.seasons) ? info.seasons : [];
      const eps = [];
      // Cap seasons to keep payload reasonable
      const usable = seasons
        .filter((s) => s && Number(s.season_number) > 0)
        .slice(0, 8);
      for (const season of usable) {
        const sn = Number(season.season_number) || 1;
        const sUrl =
          'https://api.themoviedb.org/3/tv/' +
          ref.tmdbId +
          '/season/' +
          sn +
          '?api_key=' +
          TMDB_KEY +
          '&language=en-US';
        const sRes = await settleWithin(request(sUrl), 12000, null);
        const sData = (sRes && (sRes.json || safeJsonParse(sRes.body))) || {};
        const list = Array.isArray(sData.episodes) ? sData.episodes : [];
        for (const ep of list) {
          const en = Number(ep.episode_number) || eps.length + 1;
          eps.push({
            number: eps.length + 1,
            seasonNumber: sn,
            episodeNumber: en,
            href: 'tv:' + ref.tmdbId + ':' + sn + ':' + en,
            title: 'S' + sn + 'E' + en + (ep.name ? ' · ' + cleanText(ep.name) : ''),
            subAvailable: true,
            dubAvailable: false,
          });
          if (eps.length >= 500) break;
        }
        if (eps.length >= 500) break;
      }
      if (!eps.length) {
        return [{
          number: 1,
          href: 'tv:' + ref.tmdbId + ':1:1',
          title: 'S1E1',
          subAvailable: true,
          dubAvailable: false,
        }];
      }
      return eps;
    } catch (e) {
      log('episodes error: ' + (e && e.message ? e.message : String(e)));
      return [{
        number: 1,
        href: 'tv:' + ref.tmdbId + ':1:1',
        title: 'S1E1',
        subAvailable: true,
        dubAvailable: false,
      }];
    }
  }

  function qualityHeight(q) {
    const s = String(q || '');
    const m = s.match(/(\d{3,4})/);
    return m ? Number(m[1]) : 0;
  }

  async function resolveVideasy(ref) {
    const headers = {
      'User-Agent': USER_AGENT,
      Referer: VIDEASY_ORIGIN + '/',
      Origin: VIDEASY_ORIGIN,
    };
    const tmdbId = ref.tmdbId;
    const mediaType = ref.type === 'tv' ? 'tv' : 'movie';
    const seasonId = ref.season || 1;
    const episodeId = ref.episode || 1;

    const seedRes = await settleWithin(
      request('https://api.speedracelight.com/seed?mediaId=' + encodeURIComponent(tmdbId), {
        headers: headers,
      }),
      15000,
      null,
    );
    if (!seedRes || !seedRes.ok) return [];
    const seedJson = seedRes.json || safeJsonParse(seedRes.body) || {};
    const seed = seedJson.seed;
    if (!seed) return [];

    const servers = [
      { name: 'cdn', endpoint: 'cdn' },
      { name: 'm4uhd', endpoint: 'm4uhd' },
      { name: 'lamovie', endpoint: 'lamovie' },
    ];
    const streams = [];
    const seen = new Set();

    for (let si = 0; si < servers.length; si++) {
      const server = servers[si];
      try {
        const fullUrl =
          'https://api.speedracelight.com/' +
          server.endpoint +
          '/sources-with-title?title=&mediaType=' +
          mediaType +
          '&year=&episodeId=' +
          episodeId +
          '&seasonId=' +
          seasonId +
          '&tmdbId=' +
          tmdbId +
          '&imdbId=&enc=2&seed=' +
          encodeURIComponent(seed);
        const encRes = await settleWithin(
          request(fullUrl, { headers: headers }),
          20000,
          null,
        );
        if (!encRes || !encRes.ok || !encRes.body) continue;
        if (/Attention Required|Just a moment/i.test(encRes.body)) continue;

        const postData = JSON.stringify({
          text: String(encRes.body).trim(),
          id: String(tmdbId),
          seed: seed,
        });
        const decRes = await settleWithin(
          request('https://enc-dec.app/api/dec-videasy', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Accept: 'application/json',
              'User-Agent': USER_AGENT,
            },
            body: postData,
          }),
          25000,
          null,
        );
        if (!decRes || !decRes.ok) continue;
        const dec = decRes.json || safeJsonParse(decRes.body) || {};
        if (dec.status !== 200 || !dec.result) continue;
        const sources = Array.isArray(dec.result.sources) ? dec.result.sources : [];
        for (let i = 0; i < sources.length; i++) {
          const src = sources[i];
          if (!src || !src.url) continue;
          if (String(src.quality || '').includes('HDR')) continue;
          if (seen.has(src.url)) continue;
          seen.add(src.url);
          const h = qualityHeight(src.quality);
          streams.push({
            label: 'STCine · Videasy ' + server.name + ' · ' + (src.quality || 'auto'),
            url: src.url,
            quality: h || src.quality || 'auto',
            streamType: /\.m3u8/i.test(src.url) ? 'hls' : 'mp4',
            kind: /\.m3u8/i.test(src.url) ? 'hls' : 'mp4',
            provider: 'stcine-videasy-' + server.name,
            headers: {
              'User-Agent': USER_AGENT,
              Referer: VIDEASY_ORIGIN + '/',
              Origin: VIDEASY_ORIGIN,
            },
          });
        }
        if (streams.length >= 4) break;
      } catch (e) {
        log('videasy server fail ' + server.name + ': ' + (e && e.message ? e.message : e));
      }
    }

    // Prefer seek-friendly ladders: 1080 first, then 720, then lower, then 4K last.
    // Free 4K HLS often seeks poorly (long GOPs / weak CDN range).
    streams.sort((a, b) => streamSeekScore(b) - streamSeekScore(a));
    return streams;
  }

  function streamSeekScore(s) {
    const h = qualityHeight(s && s.quality);
    let score = 0;
    if (h === 1080) score += 10000;
    else if (h === 720) score += 8000;
    else if (h > 0 && h < 720) score += 4000 + h;
    else if (h >= 2160) score += 2500; // keep available, not default
    else if (h > 1080) score += 3000;
    else score += 1000;
    if (s && (s.kind === 'hls' || s.streamType === 'hls' || /\.m3u8/i.test(s.url || ''))) score += 200;
    // Prefer primary cdn over exotic hosts for scrubbing
    if (s && /videasy-cdn/i.test(s.provider || '')) score += 150;
    return score;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseHref(episodeHref);
    if (!ref) return { streams: [] };
    log('extractStreamUrl ' + ref.type + ' ' + ref.tmdbId + ' s' + (ref.season || 1) + 'e' + (ref.episode || 1));
    let streams = await resolveVideasy(ref);
    if (!streams.length) return { streams: [] };
    // Cap returned ladder: lead with seek-friendly HD, keep one 4K backup if present
    const primary = streams.filter((s) => {
      const h = qualityHeight(s.quality);
      return h > 0 && h <= 1080;
    });
    const uhd = streams.filter((s) => qualityHeight(s.quality) >= 1440);
    streams = primary.concat(uhd).slice(0, 6);
    if (!streams.length) streams = await resolveVideasy(ref);
    const top = streams[0];
    return {
      streams: streams,
      subtitles: [],
      headers: top.headers,
      streamType: top.streamType || 'hls',
      quality: top.quality,
      lang: String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub',
    };
  }

  function sectionFrom(id, title, items, feedId, style, limit) {
    if (!items || !items.length) return null;
    const max = Math.max(1, Number(limit) || 24);
    const section = {
      id: id,
      title: title,
      style: style || 'poster',
      items: items.slice(0, max).map((c, i) => ({
        href: c.href,
        title: c.title,
        image: c.image || c.poster || c.backdrop || '',
        poster: c.poster || c.image || '',
        rank: i + 1,
      })),
    };
    if (feedId) section.viewAll = { mode: 'feed', feedId: feedId };
    return section;
  }

  async function tmdbTrending() {
    const url =
      'https://api.themoviedb.org/3/trending/all/week?api_key=' +
      TMDB_KEY +
      '&language=en-US';
    const res = await settleWithin(request(url), 12000, null);
    if (!res || !res.ok) return [];
    const data = res.json || safeJsonParse(res.body) || {};
    const results = Array.isArray(data.results) ? data.results : [];
    return results
      .filter((r) => r && (r.media_type === 'movie' || r.media_type === 'tv'))
      .map((r) => {
        const card = cardFromTmdb(r);
        if (!card) return null;
        // Hero prefers wide art when available
        const backdrop = posterUrl(r.backdrop_path);
        if (backdrop) {
          card.image = backdrop.replace('/w500/', '/w780/');
          card.backdrop = card.image;
        }
        return card;
      })
      .filter(Boolean)
      .slice(0, 12);
  }

  async function discoveryHome() {
    try {
      let movies = await stcineList('movie', 1, '');
      let tv = await stcineList('tv', 1, '');
      const popMovies = await tmdbPopular('movie');
      const popTv = await tmdbPopular('tv');
      const trending = await tmdbTrending();
      if (popMovies.length) movies = popMovies.concat(movies).slice(0, 24);
      if (popTv.length) tv = popTv.concat(tv).slice(0, 24);

      const sections = [];
      // Featured big cards (hero) — same pattern as X-Stream / Elisworld
      const featured = trending.length ? trending : movies.slice(0, 8);
      const sHero = sectionFrom('featured', 'Featured', featured, 'movies', 'hero', 8);
      const sTop = sectionFrom('top10', 'Top 10', (trending.length ? trending : movies).slice(0, 10), 'movies', 'top10', 10);
      const s1 = sectionFrom('popular-movies', 'Popular movies', movies, 'movies', 'poster', 24);
      const s2 = sectionFrom('popular-tv', 'Popular TV', tv, 'tv', 'poster', 24);
      if (sHero) sections.push(sHero);
      if (sTop) sections.push(sTop);
      if (s1) sections.push(s1);
      if (s2) sections.push(s2);
      return { sections };
    } catch (e) {
      log('home error: ' + (e && e.message ? e.message : String(e)));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const key = String(feedId || 'movies').toLowerCase();
    try {
      const type = key.includes('tv') ? 'tv' : 'movie';
      let items = await stcineList(type, pageNumber, '');
      if (!items.length && pageNumber === 1) {
        items = await tmdbPopular(type);
      }
      return {
        items: items.map((c) => ({
          href: c.href,
          title: c.title,
          image: c.image,
          poster: c.image,
        })),
        page: pageNumber,
        hasMore: items.length >= 12,
      };
    } catch (e) {
      log('feed error: ' + (e && e.message ? e.message : String(e)));
      return { items: [], page: pageNumber, hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
