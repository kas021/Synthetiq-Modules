/**
 * Movy 0.1.0-beta.3 - movies and TV from movy.sx.
 * Catalogue: TMDB (movy.sx uses TMDB ids; db.wecollege.net is the site's own
 * TMDB mirror and is used only when TMDB is unreachable).
 * Streams: the site's "original audio" servers on api.wecollege.net. Every
 * play fetches one short-lived seed, asks servers in small waves, decrypts the
 * answer and probes the stream before returning it.
 * German/French/Hindi/Spanish servers are not used: they are not English dub.
 */
(function () {
  'use strict';

  var MODULE = 'Movy';
  var SITE = 'https://www.movy.sx';
  var API = 'https://api.wecollege.net';
  var TMDB = 'https://api.themoviedb.org/3';
  var TMDB_KEY = 'e1a8efff4415028c5c266b3fcd50db6e';
  var TMDB_MIRROR = 'https://db.wecollege.net/3';
  var MAGIC = [109, 118, 109, 49];
  var UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  var FAKE = /tiktokcdn|ibyteimg|ad-site-i18n|\/obj\/ad-site|blank\.mp4|\.png(?:\?|$)/i;
  // Site order and labels ("Original audio"). Asked in waves so a play costs
  // one seed and a few requests; later waves run only when earlier ones fail.
  var SERVER_WAVES = [
    [
      { path: 'miami', name: 'Miami' },
      { path: 'boise', name: 'Boise' },
      { path: 'atlanta', name: 'Atlanta' },
      { path: 'phoenix', name: 'Phoenix' },
    ],
    [
      { path: 'oakland', name: 'Oakland' },
      { path: 'vegas', name: 'Vegas' },
      { path: 'reno', name: 'Reno' },
      { path: 'seattle', name: 'Seattle' },
    ],
    [
      { path: 'portland', name: 'Portland' },
      { path: 'austin', name: 'Austin' },
      { path: 'tampa', name: 'Tampa' },
      { path: 'orlando', name: 'Orlando' },
    ],
  ];
  // The site's language servers. For a film whose original language matches,
  // they carry the original audio and join the first wave. Otherwise they are
  // a labelled last resort when no original-audio stream exists.
  var LANGUAGE_SERVERS = [
    { path: 'delhi', name: 'Delhi', audio: 'hi', serves: ['hi', 'ta', 'te', 'ml', 'kn', 'bn', 'mr', 'pa'] },
    { path: 'cancun', name: 'Cancun', audio: 'es', serves: ['es'] },
    { path: 'paris', name: 'Paris', audio: 'fr', serves: ['fr'] },
    { path: 'munich', name: 'Munich', audio: 'de', serves: ['de'], extra: { language: 'german' } },
    { path: 'berlin', name: 'Berlin', audio: 'de', serves: ['de'], germanTitle: true },
  ];
  var ENOUGH_SERVERS = 2;
  var REQUEST_LIMIT = 48;
  var RESOLVE_MS = 26000;
  var SEED_COOLDOWN_MS = 120000;
  var metadataCache = {};
  var seedCache = {};
  var inflight = {};
  var seedRetryAt = 0;
  var mirrorPreferredUntil = 0;
  var hostRetryAt = {};
  var transportActive = 0;
  var transportQueue = [];

  function releaseTransport() {
    transportActive -= 1;
    while (transportQueue.length && transportActive < 4) {
      var entry = transportQueue.shift();
      if (entry.token.closed || !active(entry.ctx)) { entry.resolve(false); continue; }
      transportActive += 1;
      entry.resolve(true);
    }
  }

  function acquireTransport(ctx, token) {
    if (token.closed || !active(ctx)) return Promise.resolve(false);
    if (transportActive < 4) { transportActive += 1; return Promise.resolve(true); }
    return new Promise(function (resolve) { transportQueue.push({ ctx: ctx, token: token, resolve: resolve }); });
  }

  function cooldownUntil(response) {
    var value = String(header(response, 'retry-after') || '').trim();
    var delay = /^\d+$/.test(value) ? Number(value) * 1000 : Date.parse(value) - Date.now();
    return Date.now() + (isFinite(delay) && delay > 0 ? delay : SEED_COOLDOWN_MS);
  }

  function log(msg) {
    try { console.log('[' + MODULE + '] ' + String(msg || '')); } catch (_) {}
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function headers(extra) {
    var out = { 'User-Agent': UA, Accept: '*/*' };
    var src = extra || {};
    Object.keys(src).forEach(function (k) { out[k] = src[k]; });
    return out;
  }

  function apiHeaders() {
    return { 'User-Agent': UA, Accept: 'application/json,text/plain,*/*',
      Origin: SITE, Referer: SITE + '/' };
  }

  // Every Movy CDN answers 403 without the site's Origin and Referer.
  function streamHeaders() {
    return { 'User-Agent': UA,
      Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
      Origin: SITE, Referer: SITE + '/' };
  }

  async function readBody(response) {
    if (!response) return '';
    if (typeof response.body === 'string' && response.body) return response.body;
    if (response.json && typeof response.json !== 'function') {
      try { return JSON.stringify(response.json); } catch (_) {}
    }
    if (typeof response.text === 'function') {
      try {
        var text = await response.text();
        if (typeof text === 'string' && text) return text;
      } catch (_) {}
    }
    if (typeof response.json === 'function') {
      try {
        var json = await response.json();
        if (json != null) return typeof json === 'string' ? json : JSON.stringify(json);
      } catch (_) {}
    }
    return '';
  }

  function header(response, name) {
    var values = response && response.headers;
    if (!values) return '';
    if (typeof values.get === 'function') return values.get(name) || '';
    var key = Object.keys(values).filter(function (k) { return k.toLowerCase() === name; })[0];
    return key ? String(values[key]) : '';
  }

  function failure(code, stage, status, text) {
    return { ok: false, status: status || 0, text: text || '', json: null, code: code, stage: stage };
  }

  function active(ctx) {
    return !ctx || (!ctx.closed && Date.now() < ctx.deadline && ctx.requests < REQUEST_LIMIT);
  }

  function withTimeout(promise, ms, fallback) {
    var timer;
    return Promise.race([promise, new Promise(function (resolve) {
      timer = setTimeout(function () { resolve(fallback); }, Math.max(1, ms));
    })]).then(function (value) {
      if (typeof clearTimeout === 'function') clearTimeout(timer);
      return value;
    }, function (error) {
      if (typeof clearTimeout === 'function') clearTimeout(timer);
      throw error;
    });
  }

  async function request(url, extraHeaders, ctx, stage) {
    stage = stage || 'metadata';
    if (!active(ctx)) return failure('budget_exhausted', stage);
    if (!safeUrl(url)) return failure('invalid_url', stage);
    var host = String(url).match(/^https:\/\/([^/?#]+)/i)[1].toLowerCase();
    if (Date.now() < (hostRetryAt[host] || 0)) {
      if (ctx) ctx.failure = failure('rate_limited', stage, 429);
      return failure('rate_limited', stage, 429);
    }
    if (ctx) ctx.requests += 1;
    var start = Date.now();
    var cap = ctx && ctx.catalogue ? 3500 : (stage === 'segment' || stage === 'variant' || stage === 'playlist' ? 6000 : 9000);
    var timeout = Math.min(cap, ctx ? ctx.deadline - start : cap);
    var token = { closed: false };
    var result = await withTimeout((async function () {
      if (!(await acquireTransport(ctx, token))) return failure('budget_exhausted', stage);
      try {
        if (token.closed || !active(ctx)) return failure('budget_exhausted', stage);
        if (Date.now() < (hostRetryAt[host] || 0)) return failure('rate_limited', stage, 429);
        if (typeof fetchv2 !== 'function') return failure('transport_missing', stage);
        var response = await fetchv2(url, headers(extraHeaders), 'GET', null,
          { maxBytesHint: 1500000, responseClass: stage === 'segment' ? 'binary' : 'text' });
        var status = Number(response && response.status) || 0;
        if (status === 429 || (status === 503 && header(response, 'retry-after'))) {
          var until = cooldownUntil(response);
          hostRetryAt[host] = Math.max(hostRetryAt[host] || 0, until);
          if (host === 'api.wecollege.net') seedRetryAt = Math.max(seedRetryAt, until);
          if (ctx) ctx.failure = failure('rate_limited', stage, status);
          return failure('rate_limited', stage, status);
        }
        if (ctx && (ctx.closed || Date.now() >= ctx.deadline)) return failure('budget_exhausted', stage);
        var text = await readBody(response);
        if (ctx && (ctx.closed || Date.now() >= ctx.deadline)) return failure('budget_exhausted', stage);
        if (status < 200 || status >= 300) {
          return failure(status === 429 ? 'rate_limited' : 'http_error', stage, status, text.slice(0, 200));
        }
        var json = null;
        try { json = JSON.parse(text); } catch (_) {}
        return { ok: true, status: status, text: text, json: json, stage: stage,
          contentType: header(response, 'content-type') };
      } catch (_) { return failure('transport_error', stage); }
      finally { releaseTransport(); }
    })(), timeout, failure('timeout', stage));
    token.closed = true;
    if (ctx && !ctx.closed) {
      if (result.code === 'timeout' && (!ctx.failure || ctx.failure.code !== 'rate_limited')) {
        ctx.failure = result;
      }
      ctx.diagnostics.push({ stage: stage, status: result.status, code: result.code || 'ok',
        ms: Date.now() - start });
    }
    return result;
  }

  function safeUrl(value) {
    var match = String(value || '').match(/^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?#]|$)/i);
    if (!match || /[\s\\]/.test(value)) return false;
    var host = match[1].toLowerCase();
    return host.indexOf('.') > 0 && !/^[\d.]+$/.test(host) &&
      !/(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host);
  }

  // ---- Catalogue (TMDB) -------------------------------------------------

  async function tmdb(path, ctx) {
    if (!active(ctx)) throw new Error('Metadata request budget exhausted.');
    var cached = metadataCache[path];
    if (cached && cached.expires > Date.now()) return cached.data;
    var sep = path.indexOf('?') >= 0 ? '&' : '?';
    var urls = [
      TMDB + path + sep + 'api_key=' + encodeURIComponent(TMDB_KEY) + '&language=en-US',
      TMDB_MIRROR + path + sep + 'language=en',
    ];
    if (Date.now() < mirrorPreferredUntil) urls.reverse();
    var last = null;
    for (var i = 0; i < urls.length; i += 1) {
      if (!active(ctx)) break;
      var mirror = urls[i].indexOf(TMDB_MIRROR) === 0;
      var res = await request(urls[i], mirror ? apiHeaders() : { Accept: 'application/json' }, ctx, 'metadata');
      var identity = path.match(/^\/(?:movie|tv)\/(\d+)(?:\?|$)/);
      var seasonIdentity = path.match(/^\/tv\/\d+\/season\/(\d+)(?:\?|$)/);
      if (res.ok && res.json && ((identity && String(res.json.id) !== identity[1]) ||
          (seasonIdentity && (!Array.isArray(res.json.episodes) ||
            (res.json.season_number != null && Number(res.json.season_number) !== Number(seasonIdentity[1])))))) {
        res = failure('metadata_identity_mismatch', 'metadata', res.status);
      }
      if (res.ok && res.json && typeof res.json === 'object' && !res.json.status_code) {
        if (!active(ctx)) break;
        // TMDB failed and the mirror answered: try the mirror first for a while.
        if (mirror) mirrorPreferredUntil = Date.now() + 600000;
        var keys = Object.keys(metadataCache);
        if (keys.length >= 40) delete metadataCache[keys[0]];
        metadataCache[path] = { data: res.json, expires: Date.now() + 300000 };
        return res.json;
      }
      last = res.ok ? failure('invalid_json', 'metadata', res.status) : res;
    }
    var error = new Error('Metadata is unavailable.');
    error.result = last;
    throw error;
  }

  function href(type, id, season, episode) {
    var base = SITE + '/' + type + '/' + id;
    if (type === 'tv' && season && episode) return base + '/' + season + '/' + episode;
    return base;
  }

  /**
   * Accepts Movy links (with locale prefix and ?play=true), TMDB links and the
   * short "tv:ID:S:E" form, e.g. https://www.movy.sx/tv/247718/2/5?play=true.
   */
  function parseHref(value) {
    var raw = String(value || '').trim();
    var m = raw.match(/^(movie|tv):([1-9]\d*)(?::([1-9]\d*):([1-9]\d*))?$/i);
    if (!m) {
      m = raw.match(/^(?:https?:\/\/)?(?:www\.)?movy\.[a-z]+\/(?:[a-z]{2}\/)?(movie|tv)\/([1-9]\d*)(?:\/([1-9]\d*)\/([1-9]\d*))?\/?(?:[?#].*)?$/i);
    }
    if (!m) {
      var tm = raw.match(/^https:\/\/(?:www\.)?themoviedb\.org\/(movie|tv)\/([1-9]\d*)\/?(?:\?season=([1-9]\d*)&episode=([1-9]\d*))?(?:#.*)?$/i);
      if (tm) m = tm;
    }
    if (!m) return null;
    var type = m[1].toLowerCase();
    if (type === 'movie' && (m[3] || m[4])) return null;
    return {
      type: type,
      id: String(m[2]),
      season: m[3] ? Number(m[3]) : null,
      episode: m[4] ? Number(m[4]) : null,
    };
  }

  function image(path, size) {
    return path ? 'https://image.tmdb.org/t/p/' + (size || 'w500') + path : '';
  }

  function mapItem(row, forcedType) {
    if (!row) return null;
    var type = String(forcedType || row.media_type || '').toLowerCase();
    if (type !== 'movie' && type !== 'tv') return null;
    if (row.adult === true) return null;
    var id = Number(row.id);
    var title = clean(row.title || row.name || row.original_title || row.original_name);
    if (!Number.isSafeInteger(id) || id < 1 || !title) return null;
    var year = String(row.release_date || row.first_air_date || '').slice(0, 4);
    var poster = image(row.poster_path);
    return {
      id: href(type, id),
      href: href(type, id),
      title: title + (year ? ' (' + year + ')' : ''),
      image: poster,
      poster: poster,
      backdrop: image(row.backdrop_path, 'w1280'),
      type: type,
      mediaType: type,
      year: year || undefined,
      tmdbId: id,
    };
  }

  // ---- Source decryption (same scheme as the site's player) ---------------

  function u32(x) { return x >>> 0; }

  function imul(a, b) {
    if (typeof Math.imul === 'function') return Math.imul(a, b) >>> 0;
    a = a >>> 0;
    b = b >>> 0;
    var ah = (a >>> 16) & 0xffff, al = a & 0xffff;
    var bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
    return ((al * bl + (((ah * bl + al * bh) << 16) >>> 0)) >>> 0) >>> 0;
  }

  function mix(e) {
    e = u32(e);
    e ^= e >>> 16;
    e = imul(e, 2246822507);
    e ^= e >>> 13;
    e = imul(e, 3266489909);
    e ^= e >>> 16;
    return u32(e);
  }

  function rotl(e, t) {
    e = u32(e);
    t = t & 31;
    if (!t) return e;
    return u32((e << t) | (e >>> (32 - t)));
  }

  function b64Decode(input) {
    var s = String(input || '').replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '');
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var out = [], buf = 0, bits = 0;
    for (var i = 0; i < s.length; i += 1) {
      var ch = s.charAt(i);
      if (ch === '=') break;
      var v = alphabet.indexOf(ch);
      if (v < 0) continue;
      buf = ((buf << 6) | v) & 0xffffff;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out.push((buf >>> bits) & 0xff);
      }
    }
    return out;
  }

  function utf8Decode(bytes) {
    var out = '';
    var i = 0;
    while (i < bytes.length) {
      var c = bytes[i];
      i += 1;
      if (c < 0x80) out += String.fromCharCode(c);
      else if (c < 0xe0) {
        out += String.fromCharCode(((c & 0x1f) << 6) | (bytes[i] & 0x3f));
        i += 1;
      } else if (c < 0xf0) {
        out += String.fromCharCode(((c & 0x0f) << 12) | ((bytes[i] & 0x3f) << 6) | (bytes[i + 1] & 0x3f));
        i += 2;
      } else {
        var cp = ((c & 7) << 18) | ((bytes[i] & 0x3f) << 12) | ((bytes[i + 1] & 0x3f) << 6) | (bytes[i + 2] & 0x3f);
        i += 3;
        cp -= 0x10000;
        out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
      }
    }
    return out;
  }

  function keystate(seed, mediaId) {
    var S = Object.create(null);
    var fnv = 2166136261;
    var seedStr = String(seed || '');
    for (var i = 0; i < seedStr.length; i += 1) fnv = imul(fnv ^ seedStr.charCodeAt(i), 16777619);
    var a = mix(mix(fnv) ^ mix(u32(Number(mediaId) || 0) ^ 2654435769));
    for (var e = 0; e < 8; e += 1) {
      var slot = a % 61;
      a = rotl(u32(a + 2654435769), 7 + (7 & e));
      S[slot] = u32(a ^ mix(a));
      a = mix(u32(a + slot));
    }
    return { S: S, acc: mix(u32(2779096485 ^ a)) };
  }

  function nextWord(state, counter) {
    var r = state.S;
    var o = state.acc;
    var n = o % 61;
    var present = Object.prototype.hasOwnProperty.call(r, n);
    var mask = present ? 0xffffffff : 0;
    var l = present ? u32(r[n]) : 0;
    var aVal = u32(l ^ imul(2654435769, counter + 1));
    var d = u32(u32(o ^ aVal) | u32(o & aVal & mask));
    d = u32(rotl(u32(d + o), 31 & n) ^ rotl(o, 31 & imul(n, 7)));
    o = mix(u32(d + 2654435769));
    r[n] = o;
    state.acc = o;
    return o;
  }

  function decrypt(payload, seed, mediaId) {
    var raw = b64Decode(String(payload || '').trim().replace(/^"|"$/g, ''));
    if (raw.length <= MAGIC.length) throw new Error('empty payload');
    var state = keystate(seed, mediaId);
    var counter = 0;
    for (var i = 0; i < raw.length;) {
      var w = nextWord(state, counter);
      counter += 1;
      raw[i] ^= w & 255; i += 1;
      if (i < raw.length) { raw[i] ^= (w >>> 8) & 255; i += 1; }
      if (i < raw.length) { raw[i] ^= (w >>> 16) & 255; i += 1; }
      if (i < raw.length) { raw[i] ^= (w >>> 24) & 255; i += 1; }
    }
    for (var m = 0; m < MAGIC.length; m += 1) {
      if (raw[m] !== MAGIC[m]) throw new Error('decrypt magic mismatch');
    }
    return utf8Decode(raw.slice(MAGIC.length));
  }

  // ---- Seeds ------------------------------------------------------------

  /** One seed per title for its lifetime, as the site does; /seed is rate limited. */
  async function getSeed(mediaId, ctx, fresh) {
    if (Date.now() < seedRetryAt) {
      ctx.failure = failure('rate_limited', 'seed', 429);
      return '';
    }
    var cached = seedCache[mediaId];
    if (!fresh && cached && cached.expires > Date.now()) return cached.seed;
    var res = await request(API + '/seed?mediaId=' + encodeURIComponent(mediaId), apiHeaders(), ctx, 'seed');
    var seed = res.ok && res.json && res.json.seed ? String(res.json.seed) : '';
    if (!seed) {
      var limited = res.status === 429 || /rate_limited/.test(res.text || '');
      if (limited) seedRetryAt = Math.max(seedRetryAt, hostRetryAt['api.wecollege.net'] || Date.now() + SEED_COOLDOWN_MS);
      ctx.failure = limited ? failure('rate_limited', 'seed', res.status || 429) :
        (res.ok ? failure('empty_seed', 'seed', res.status) : res);
      return '';
    }
    var ttl = Number(res.json.ttlMs) || 30000;
    var keys = Object.keys(seedCache);
    if (keys.length >= 16) delete seedCache[keys[0]];
    seedCache[mediaId] = { seed: seed, expires: Date.now() + Math.max(5000, ttl - 5000) };
    return seed;
  }

  // ---- Streams ----------------------------------------------------------

  function attributes(line) {
    var out = {};
    var pattern = /([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))/g;
    var match;
    while ((match = pattern.exec(line))) out[match[1]] = match[2] == null ? match[3] : match[2];
    return out;
  }

  function joinUrl(base, rel) {
    rel = String(rel || '').trim();
    if (!rel || /[\s\\]/.test(rel)) return '';
    if (/^[a-z][a-z0-9+.-]*:/i.test(rel)) return safeUrl(rel) ? rel : '';
    var match = String(base).match(/^(https:\/\/[^/]+)(\/[^?#]*)?(?:\?[^#]*)?/i);
    if (!match) return '';
    if (rel.indexOf('//') === 0) return safeUrl('https:' + rel) ? 'https:' + rel : '';
    var path = match[2] || '/';
    if (rel.charAt(0) === '?') return match[1] + path + rel;
    if (rel.charAt(0) !== '/') rel = path.slice(0, path.lastIndexOf('/') + 1) + rel;
    var suffix = rel.match(/[?#].*$/);
    var parts = rel.replace(/[?#].*$/, '').split('/');
    var normalized = [];
    parts.forEach(function (part) {
      if (part === '..') normalized.pop();
      else if (part !== '.' && part !== '') normalized.push(part);
    });
    var result = match[1] + '/' + normalized.join('/') + (suffix ? suffix[0] : '');
    return safeUrl(result) ? result : '';
  }

  function firstVariant(text, base) {
    var lines = String(text || '').split(/\r?\n/);
    var best = '', bestHeight = -1;
    for (var i = 0; i < lines.length; i += 1) {
      if (lines[i].indexOf('#EXT-X-STREAM-INF') !== 0) continue;
      var size = String(attributes(lines[i]).RESOLUTION || '').split('x');
      var h = Number(size[1]) || 0;
      for (var j = i + 1; j < lines.length; j += 1) {
        var next = lines[j].trim();
        if (!next || next.charAt(0) === '#') continue;
        // Probe a 1080p-or-lower rendition: cheaper than 4K, same token.
        var score = h > 1080 ? 0 : h;
        if (score > bestHeight) { bestHeight = score; best = joinUrl(base, next); }
        break;
      }
    }
    return best;
  }

  function firstSegment(text, base) {
    var lines = String(text || '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i += 1) {
      var line = lines[i].trim();
      if (!line || line.charAt(0) === '#') continue;
      return joinUrl(base, line);
    }
    return '';
  }

  function looksLikeMedia(segment) {
    var sample = segment.text || '';
    if (!sample || sample.length < 16) return 'seg_empty';
    if (/^\s*(?:#EXTM3U|\{|\[)/.test(sample)) return 'seg_not_media';
    if (/^\s*<(?:!doctype|html|\?xml)/i.test(sample)) return 'seg_html';
    var ts = sample.charCodeAt(0) === 0x47;
    var mp4 = /^(?:ftyp|styp|moof|sidx)$/.test(sample.slice(4, 8));
    if (/PNG|JFIF|GIF8|WEBP/.test(sample.slice(0, 64)) && !ts && !mp4) return 'seg_image';
    if (/^(?:text\/|application\/(?:json|vnd.apple.mpegurl|x-mpegurl))/i.test(segment.contentType || '') &&
        !ts && !mp4) return 'seg_wrong_type';
    return '';
  }

  /** Checks the link answers like video: playlist, media playlist and a first segment. */
  async function probe(url, streamType, hdrs, ctx) {
    if (!url || FAKE.test(url)) return { ok: false, reason: 'fake_url' };
    if (streamType === 'mp4') {
      var head = await request(url, Object.assign({}, hdrs, { Range: 'bytes=0-4095' }), ctx, 'segment');
      if (!head.ok) return { ok: false, reason: 'mp4_' + (head.status || head.code) };
      var bad = looksLikeMedia(head);
      return bad ? { ok: false, reason: bad } : { ok: true };
    }
    var playlist = await request(url, hdrs, ctx, 'playlist');
    if (!playlist.ok || playlist.text.indexOf('#EXTM3U') < 0) {
      return { ok: false, reason: 'not_hls', status: playlist.status };
    }
    var body = playlist.text, mediaUrl = url;
    if (body.indexOf('#EXT-X-STREAM-INF') >= 0) {
      mediaUrl = firstVariant(body, url);
      if (!mediaUrl) return { ok: false, reason: 'no_variant' };
      var variant = await request(mediaUrl, hdrs, ctx, 'variant');
      if (!variant.ok || variant.text.indexOf('#EXTM3U') < 0) return { ok: false, reason: 'variant_fail' };
      body = variant.text;
    }
    var seg = firstSegment(body, mediaUrl);
    if (!seg || FAKE.test(seg)) return { ok: false, reason: 'no_segment' };
    var segment = await request(seg, Object.assign({}, hdrs, { Range: 'bytes=0-4095' }), ctx, 'segment');
    if (!segment.ok) return { ok: false, reason: 'seg_' + (segment.status || segment.code) };
    var reason = looksLikeMedia(segment);
    return reason ? { ok: false, reason: reason } : { ok: true };
  }

  function heightOf(value) {
    var text = String(value || '');
    if (/4k|2160|uhd/i.test(text)) return 2160;
    var m = text.match(/(\d{3,4})p/i);
    return m ? Number(m[1]) : 0;
  }

  function streamTypeOf(url) {
    return /\/mp4\/|\.mp4(?:[?#]|$)/i.test(url) ? 'mp4' : 'hls';
  }

  var LANG_CODES = { english: 'en', spanish: 'es', french: 'fr', german: 'de', italian: 'it',
    portuguese: 'pt', arabic: 'ar', japanese: 'ja', korean: 'ko', chinese: 'zh', russian: 'ru',
    hindi: 'hi', turkish: 'tr', dutch: 'nl', polish: 'pl', swedish: 'sv', greek: 'el',
    thai: 'th', vietnamese: 'vi', indonesian: 'id', romanian: 'ro', ukrainian: 'uk',
    czech: 'cs', danish: 'da', finnish: 'fi', hebrew: 'he', hungarian: 'hu', norwegian: 'no',
    eng: 'en', spa: 'es', fre: 'fr', fra: 'fr', ger: 'de', deu: 'de', ita: 'it', por: 'pt',
    ara: 'ar', jpn: 'ja', kor: 'ko', chi: 'zh', zho: 'zh', rus: 'ru', hin: 'hi', tur: 'tr' };
  ['en','es','fr','de','it','pt','ar','ja','ko','zh','ru','hi','tr','nl','pl','sv','el','th','vi','id','ro','uk','cs','da','fi','he','hu','no'].forEach(function (code) { LANG_CODES[code] = code; });

  function subtitleLanguage(row, url) {
    var text = String(row.lang || row.language || row.label || '').toLowerCase();
    var words = text.split(/[^a-z]+/).filter(Boolean);
    for (var i = 0; i < words.length; i += 1) {
      if (LANG_CODES[words[i]]) return LANG_CODES[words[i]];
    }
    var ext = String(url).match(/\.([a-z]{2,3})\.(?:srt|vtt)(?:[?#]|$)/i);
    if (ext && LANG_CODES[ext[1].toLowerCase()]) return LANG_CODES[ext[1].toLowerCase()];
    if (LANG_CODES[words[0]]) return LANG_CODES[words[0]];
    return 'und';
  }

  var LANG_NAMES = {};
  Object.keys(LANG_CODES).forEach(function (name) {
    if (name.length > 3) LANG_NAMES[LANG_CODES[name]] = name.charAt(0).toUpperCase() + name.slice(1);
  });

  // "Original--English-United-Kingdom--SDH" -> "English (United Kingdom) SDH";
  // "eng (forced)" -> "English (forced)".
  function subtitleLabel(row, lang) {
    var raw = clean(row.label || row.lang || row.language || 'Subtitle');
    var label;
    if (/\s-\s/.test(raw)) {
      // "Arabic - Arabic" -> "Arabic"; "Chinese - Chinese Simplified" -> "Chinese Simplified"
      var halves = raw.split(/\s-\s/);
      label = halves[1].indexOf(halves[0]) === 0 ? halves[1] : halves.join(' - ');
    } else {
      var parts = raw.replace(/^Original--/i, '').split('--');
      var main = parts[0].split('-');
      label = main[0] + (main.length > 1 ? ' (' + main.slice(1).join(' ') + ')' : '');
      label = clean(label + (parts.length > 1 ? ' ' + parts.slice(1).join(' ') : '')) || 'Subtitle';
    }
    var code = label.match(/^([a-z]{2,3})\b(.*)$/i);
    if (code && LANG_CODES[code[1].toLowerCase()] && LANG_NAMES[lang]) label = LANG_NAMES[lang] + code[2];
    return label;
  }

  // Full English first, then SDH, then forced-only tracks, then other languages.
  function captionRank(track) {
    var forced = /forced/i.test(track.label) ? 2 : /sdh|cc\b/i.test(track.label) ? 1 : 0;
    return (track.lang === 'en' ? 0 : 10) + forced;
  }

  function mapCaptions(rawList, seen, out) {
    (Array.isArray(rawList) ? rawList : []).forEach(function (row) {
      if (!row || typeof row !== 'object') return;
      var file = String(row.url || row.file || row.src || '').trim();
      if (!safeUrl(file) || seen[file] || /thumb|sprite|\.m3u8(?:[?#]|$)/i.test(file)) return;
      var declared = String(row.format || '').toLowerCase();
      declared = { webvtt: 'vtt', 'text/vtt': 'vtt', subrip: 'srt', 'application/x-subrip': 'srt' }[declared] || declared;
      if ((declared && declared !== 'srt' && declared !== 'vtt') || /\.(?:ass|ssa|ttml|xml|json)(?:[?#]|$)/i.test(file)) return;
      var extension = file.match(/\.(srt|vtt)(?:[?#]|$)/i);
      seen[file] = true;
      var lang = subtitleLanguage(row, file);
      var captionHeaders = streamHeaders();
      Object.keys(row.headers || {}).forEach(function (name) {
        var value = row.headers[name];
        if (/^[A-Za-z0-9-]+$/.test(name) && typeof value === 'string' && !/[\r\n]/.test(value)) captionHeaders[name] = value;
      });
      out.push({
        id: file,
        url: file,
        file: file,
        label: subtitleLabel(row, lang),
        language: lang,
        lang: lang,
        kind: 'subtitles',
        format: extension ? extension[1].toLowerCase() : (declared || undefined),
        headers: captionHeaders,
      });
    });
    return out;
  }

  // Austin and Delhi label sources by audio language ("Hindi", "Tamil")
  // instead of resolution.
  function qualityLanguage(value) {
    var word = String(value || '').trim().toLowerCase();
    return /^[a-z]{4,}$/.test(word) && LANG_CODES[word] ? LANG_CODES[word] : '';
  }

  function audioLabel(code) {
    return LANG_NAMES[code] ? LANG_NAMES[code] + ' audio' : 'audio ' + code;
  }

  async function buildGroup(server, list, hdrs, master, audio, original, ctx) {
    var qualities = list.map(function (src) {
      var url = String(src.url);
      var height = heightOf(src.quality);
      return { label: height ? height + 'p' : 'Auto', height: height, url: url, headers: hdrs,
        streamType: streamTypeOf(url) };
    }).sort(function (a, b) { return b.height - a.height; });
    // Unlabelled links (no height) become "Source 2", "Source 3" in the menu.
    var unnamed = 0;
    qualities.forEach(function (q) {
      if (!q.height) { unnamed += 1; q.label = 'Source ' + unnamed; }
    });
    // The site's master playlist lets the player switch quality on its own.
    var primary = master ? { url: master, streamType: 'hls' } :
      (qualities.filter(function (q) { return q.height && q.height <= 1080; })[0] || qualities[0]);
    var check = await probe(primary.url, primary.streamType, hdrs, ctx);
    if (!check.ok && !master && qualities.length > 1 && active(ctx)) {
      var fallback = qualities.filter(function (q) { return q.url !== primary.url; })[0];
      var second = await probe(fallback.url, fallback.streamType, hdrs, ctx);
      if (second.ok) { primary = fallback; check = second; }
    }
    if (!check.ok) return { server: null, reason: check.reason || 'probe_failed' };
    return {
      server: {
        name: server.name + (original ? ' (original audio)' : ' (' + audioLabel(audio) + ')'),
        url: primary.url,
        headers: hdrs,
        streamType: primary.streamType,
        lang: 'sub',
        audioLanguage: audio,
        original: original,
        qualities: qualities,
      },
    };
  }

  /** One server's answer -> playable server entries, one per audio language. */
  async function buildServers(server, data, hdrs, originalLanguage, ctx) {
    var list = (Array.isArray(data.sources) ? data.sources : []).filter(function (src) {
      var url = String(src && src.url || '');
      return safeUrl(url) && !FAKE.test(url) && !/\.(?:json|mpd)(?:[?#]|$)/i.test(url);
    }).slice(0, 8);
    if (!list.length) return [{ server: null, reason: 'no_sources' }];
    var groups = {}, order = [];
    list.forEach(function (src) {
      var lang = qualityLanguage(src.quality) || server.audio || originalLanguage;
      var key = lang + ':' + streamTypeOf(String(src.url));
      if (!groups[key]) { groups[key] = []; order.push(key); }
      groups[key].push(src);
    });
    var master = safeUrl(data.playlist) && !FAKE.test(data.playlist) && order.length === 1 && /:hls$/.test(order[0])
      ? String(data.playlist) : '';
    // Original language first; at most two other languages per server.
    order.sort(function (a, b) { return (a.split(':')[0] === originalLanguage ? 0 : 1) - (b.split(':')[0] === originalLanguage ? 0 : 1); });
    return Promise.all(order.slice(0, 3).map(function (key) {
      var lang = key.split(':')[0];
      var labelled = order.length > 1 ? Object.assign({}, server, { name: server.name + ' ' + key.split(':')[1].toUpperCase() }) : server;
      return buildGroup(labelled, groups[key], hdrs, master, lang,
        lang === originalLanguage || originalLanguage === 'und', ctx);
    }));
  }

  async function askServer(server, ref, params, mediaId, hdrs, originalLanguage, ctx) {
    var stage = 'sources:' + server.name;
    for (var attempt = 0; attempt < 2 && active(ctx); attempt += 1) {
      var seed = await getSeed(mediaId, ctx, attempt > 0);
      if (!seed) return [];
      var query = Object.assign({}, params, server.extra || {}, { enc: '2', seed: seed });
      if (server.germanTitle && params.germanTitle) query.altTitle = params.germanTitle;
      delete query.germanTitle;
      var q = Object.keys(query).filter(function (k) {
        return query[k] != null && query[k] !== '';
      }).map(function (k) {
        return encodeURIComponent(k) + '=' + encodeURIComponent(String(query[k]));
      }).join('&');
      var res = await request(API + '/' + server.path + '/sources?' + q, apiHeaders(), ctx, stage);
      // An expired or reused seed: fetch a new one once, like the site.
      if (!res.ok && res.status === 401 && attempt === 0) { delete seedCache[mediaId]; continue; }
      if (!res.ok || !res.text) return [];
      var data;
      try {
        data = res.json && Array.isArray(res.json.sources) ? res.json : JSON.parse(decrypt(res.text, seed, mediaId));
      } catch (_) {
        ctx.diagnostics.push({ stage: stage, code: 'invalid_source_payload', status: res.status });
        return [];
      }
      if (!data || !Array.isArray(data.sources)) return [];
      if (data.tmdbId != null && String(data.tmdbId) !== ref.id) return [];
      if (data.mediaType != null && String(data.mediaType) !== ref.type) return [];
      if (ref.type === 'tv' && ((data.seasonId != null && Number(data.seasonId) !== ref.season) ||
          (data.episodeId != null && Number(data.episodeId) !== ref.episode))) return [];
      ctx.captionRows.push(data.subtitles || data.subs || []);
      var built = await buildServers(server, data, hdrs, originalLanguage, ctx);
      built.forEach(function (row) {
        if (!row.server) ctx.diagnostics.push({ stage: 'media:' + server.name, code: row.reason });
      });
      return built.map(function (row) { return row.server; }).filter(Boolean);
    }
    return [];
  }

  async function resolve(ref, ctx) {
    var meta = await tmdb('/' + ref.type + '/' + ref.id + '?append_to_response=external_ids,translations', ctx);
    if (!meta || String(meta.id) !== ref.id) throw new Error('metadata_identity_mismatch');
    var title = clean(meta.title || meta.name || meta.original_title || meta.original_name);
    var year = String(meta.release_date || meta.first_air_date || '').slice(0, 4);
    var imdbId = clean((meta.external_ids && meta.external_ids.imdb_id) || meta.imdb_id);
    var original = clean(meta.original_language).toLowerCase() || 'und';
    var params = { title: title, mediaType: ref.type, year: year, tmdbId: ref.id, imdbId: imdbId };
    var german = ((meta.translations && meta.translations.translations) || []).filter(function (t) {
      return t && t.iso_639_1 === 'de' && t.data && (t.data.title || t.data.name);
    })[0];
    if (german) params.germanTitle = clean(german.data.title || german.data.name);
    if (ref.type === 'tv') {
      params.totalSeasons = Number(meta.number_of_seasons) || '';
      params.seasonId = Number(ref.season || 1);
      params.episodeId = Number(ref.episode || 1);
    }
    var hdrs = streamHeaders();
    // Fetch the seed before the parallel wave so all servers share it.
    if (!(await getSeed(ref.id, ctx, false))) return [];
    var native = LANGUAGE_SERVERS.filter(function (s) { return s.serves.indexOf(original) >= 0; });
    var foreign = LANGUAGE_SERVERS.filter(function (s) { return native.indexOf(s) < 0; });
    var waves = [SERVER_WAVES[0].concat(native)].concat(SERVER_WAVES.slice(1));
    var servers = [];
    function originals() { return servers.filter(function (s) { return s.original; }).length; }
    async function run(list) {
      var rows = await Promise.all(list.map(function (server) {
        return askServer(server, ref, params, ref.id, hdrs, original, ctx);
      }));
      rows.forEach(function (group) {
        group.forEach(function (row) {
          if (!servers.some(function (s) { return s.url === row.url; })) servers.push(row);
        });
      });
    }
    function timeLeft() { return ctx.deadline - Date.now() > 7000; }
    for (var w = 0; w < waves.length && active(ctx) && timeLeft(); w += 1) {
      // After the first wave one working original route is enough.
      if (originals() >= (w === 0 ? ENOUGH_SERVERS : 1)) break;
      await run(waves[w]);
      if (Date.now() < seedRetryAt) break;
    }
    // No original audio anywhere: offer dubbed servers, labelled, rather than nothing.
    if (!originals() && active(ctx) && timeLeft() && Date.now() >= seedRetryAt) await run(foreign);
    servers.sort(function (a, b) { return (a.original ? 0 : 1) - (b.original ? 0 : 1); });
    var seen = {}, captions = [];
    ctx.captionRows.forEach(function (rows) { mapCaptions(rows, seen, captions); });
    captions = captions.map(function (track, i) { return { track: track, i: i }; })
      .sort(function (a, b) { return captionRank(a.track) - captionRank(b.track) || a.i - b.i; })
      .map(function (row) { return row.track; });
    servers.forEach(function (row) { row.subtitles = captions; });
    return servers;
  }

  function pack(servers, ctx) {
    var primary = servers && servers[0];
    if (!primary || !primary.url) {
      var limited = Date.now() < seedRetryAt || (ctx && ctx.failure && ctx.failure.code === 'rate_limited');
      return {
        streams: [],
        subtitles: [],
        lang: 'sub',
        error: {
          code: ctx && ctx.failure ? ctx.failure.code : 'no_verified_stream',
          stage: ctx && ctx.failure ? ctx.failure.stage : 'resolution',
          message: limited
            ? 'Movy is limiting requests right now. Wait a little before trying again.'
            : 'Movy found no working stream for this title. Try again later or choose another source.',
        },
        diagnostics: ctx ? ctx.diagnostics : [],
      };
    }
    // Older app builds race stream candidates and keep the fastest, which can
    // be 360p. Only offer 720p and up for automatic choice; every rendition
    // stays in `qualities` for manual selection.
    var others = primary.qualities.filter(function (q) { return q.url !== primary.url; });
    var sharp = others.filter(function (q) { return q.height >= 720; });
    return {
      url: primary.url,
      streams: [{ url: primary.url, label: 'Auto', headers: primary.headers, streamType: primary.streamType }]
        .concat(sharp.length || !others.length ? sharp : others.slice(0, 1)),
      headers: primary.headers,
      streamType: primary.streamType,
      lang: 'sub',
      audioLanguage: primary.audioLanguage,
      quality: 'Auto',
      defaultQuality: 'Auto',
      qualities: [{ label: 'Auto', url: primary.url, headers: primary.headers }].concat(others),
      subtitles: primary.subtitles || [],
      servers: servers.map(function (row) {
        return {
          name: row.name,
          label: row.name,
          url: row.url,
          headers: row.headers,
          streamType: row.streamType,
          lang: 'sub',
          audioLanguage: row.audioLanguage,
          subtitles: row.subtitles || [],
          qualities: row.qualities || [],
        };
      }),
      provider: 'movy',
      diagnostics: ctx ? ctx.diagnostics : [],
    };
  }

  // ---- Module API -------------------------------------------------------

  async function catalogueOperation(work, milliseconds) {
    var ctx = { catalogue: true, deadline: Date.now() + milliseconds, closed: false,
      requests: 0, diagnostics: [] };
    var timedOut = {};
    try {
      var result = await withTimeout(work(ctx), milliseconds, timedOut);
      if (result === timedOut) throw new Error('Movy catalogue is taking too long. Please retry.');
      return result;
    } finally { ctx.closed = true; }
  }

  async function catalogueMap(values, work, ctx) {
    var next = 0, results = [];
    async function worker() {
      while (next < values.length) {
        if (!active(ctx)) throw new Error('Movy catalogue request budget exhausted.');
        var at = next++;
        results[at] = await work(values[at]);
      }
    }
    var workers = [];
    for (var i = 0; i < Math.min(3, values.length); i += 1) workers.push(worker());
    await Promise.all(workers);
    return results;
  }

  async function searchResults(query, page) {
    var q = clean(query);
    var direct = parseHref(q);
    return catalogueOperation(async function (ctx) {
      if (direct) {
        var item = mapItem(await tmdb('/' + direct.type + '/' + direct.id, ctx), direct.type);
        return item ? [item] : [];
      }
      var p = Math.max(1, Number(page) || 1);
      var path = q
        ? '/search/multi?query=' + encodeURIComponent(q) + '&include_adult=false&page=' + p
        : '/trending/all/week?page=' + p;
      var data = await tmdb(path, ctx);
      if (!Array.isArray(data.results)) throw new Error('Movy returned an invalid catalogue response.');
      return ((data && data.results) || []).map(function (row) { return mapItem(row); }).filter(Boolean).slice(0, 40);
    }, 10000);
  }

  async function extractDetails(urlOrId) {
    var ref = parseHref(urlOrId);
    if (!ref) return { title: 'Unavailable', description: 'Select an exact catalogue entry.' };
    return catalogueOperation(async function (ctx) {
      var meta = await tmdb('/' + ref.type + '/' + ref.id, ctx);
      if (String(meta.id) !== ref.id) throw new Error('Movy catalogue identity mismatch.');
      var item = mapItem(meta, ref.type);
      if (!item) return { title: 'Unavailable', description: '', href: urlOrId };
      item.description = clean(meta.overview);
      item.synopsis = item.description;
      item.genres = (meta.genres || []).map(function (g) { return g && g.name; }).filter(Boolean);
      item.status = clean(meta.status);
      item.aliases = clean(meta.original_title || meta.original_name);
      item.airdate = clean(meta.release_date || meta.first_air_date);
      return item;
    }, 10000);
  }

  async function extractEpisodes(seriesId) {
    var ref = parseHref(seriesId);
    if (!ref) return [];
    if (ref.type === 'movie') {
      return [{ id: href('movie', ref.id), href: href('movie', ref.id), number: 1, episodeNumber: 1,
        title: 'Movie', subAvailable: true, dubAvailable: false }];
    }
    return catalogueOperation(async function (ctx) {
      var meta = await tmdb('/tv/' + ref.id, ctx);
      if (String(meta.id) !== ref.id || !Array.isArray(meta.seasons)) throw new Error('Movy returned an invalid series identity.');
      var seasons = meta.seasons.filter(function (row) {
        return row && Number.isSafeInteger(Number(row.season_number)) && Number(row.season_number) > 0;
      });
      var today = new Date().toISOString().slice(0, 10);
      var rows = await catalogueMap(seasons, async function (row) {
        var num = Number(row.season_number);
        var season = await tmdb('/tv/' + ref.id + '/season/' + num, ctx);
        if (!Array.isArray(season.episodes) || (season.season_number != null && Number(season.season_number) !== num)) {
          throw new Error('Movy returned an invalid season identity.');
        }
        var out = [], seen = {};
        var episodes = season.episodes;
        episodes.forEach(function (ep) {
          var n = Number(ep && ep.episode_number);
          if (!Number.isSafeInteger(n) || n < 1 || seen[n] ||
              (ep.season_number != null && Number(ep.season_number) !== num) ||
              (ep.show_id != null && String(ep.show_id) !== ref.id)) throw new Error('Movy returned an invalid episode identity.');
          seen[n] = true;
          // Unaired episodes have no stream yet.
          if (ep.air_date && ep.air_date > today) return;
          out.push({
            id: href('tv', ref.id, num, n),
            href: href('tv', ref.id, num, n),
            season: num,
            number: n,
            episodeNumber: n,
            title: clean(ep.name) || ('S' + num + 'E' + n),
            description: clean(ep.overview),
            image: image(ep.still_path, 'w300'),
            subAvailable: true,
            dubAvailable: false,
          });
        });
        return out.sort(function (a, b) { return a.number - b.number; });
      }, ctx);
      return [].concat.apply([], rows).slice(0, 600);
    }, 24000);
  }

  async function extractStreamUrl(episodeHref, lang) {
    var want = String(lang || 'sub').toLowerCase();
    if (want === 'dub' || want === 'vf') {
      return { streams: [], subtitles: [], lang: want,
        error: { code: 'dub_unavailable', message: 'Movy provides original audio only.' } };
    }
    var ref = parseHref(episodeHref);
    if (!ref) return { streams: [], subtitles: [], error: { message: 'Invalid Movy link.' } };
    if (ref.type === 'tv' && (!ref.season || !ref.episode)) {
      return { streams: [], subtitles: [], error: { message: 'Choose an episode to play.' } };
    }
    var key = ref.type + ':' + ref.id + ':' + ref.season + ':' + ref.episode;
    if (inflight[key]) return JSON.parse(JSON.stringify(await inflight[key]));
    if (Object.keys(inflight).length >= 2) {
      return { streams: [], subtitles: [],
        error: { code: 'busy', message: 'Another title is still loading. Try again in a moment.' } };
    }
    var ctx = { deadline: Date.now() + RESOLVE_MS, closed: false, requests: 0, diagnostics: [], captionRows: [] };
    var pending = (async function () {
      try {
        var servers = await withTimeout(resolve(ref, ctx), RESOLVE_MS, null);
        if (!servers) ctx.failure = failure('timeout', 'resolution');
        return pack(servers, ctx);
      } catch (error) {
        ctx.failure = error.result || failure('resolution_error', 'resolution');
        return pack(null, ctx);
      } finally { ctx.closed = true; }
    })();
    inflight[key] = pending;
    try { return JSON.parse(JSON.stringify(await pending)); }
    finally { delete inflight[key]; }
  }

  var FEEDS = {
    'movy-trending': { title: 'Trending this week', path: '/trending/all/week', style: 'hero' },
    'movy-movies': { title: 'Trending movies', path: '/trending/movie/week', type: 'movie' },
    'movy-tv': { title: 'Trending series', path: '/trending/tv/week', type: 'tv' },
    'movy-top-movies': { title: 'Top rated movies', path: '/movie/top_rated', type: 'movie' },
    'movy-top-tv': { title: 'Top rated series', path: '/tv/top_rated', type: 'tv' },
  };

  async function discoveryHome() {
    var ids = Object.keys(FEEDS);
    return catalogueOperation(async function (ctx) {
    var sections = await catalogueMap(ids, async function (id) {
      var feed = FEEDS[id];
      try {
        var data = await tmdb(feed.path + '?page=1', ctx);
        var items = (data.results || []).map(function (r) { return mapItem(r, feed.type); }).filter(Boolean);
        return { id: id, title: feed.title, style: feed.style || 'poster',
          items: feed.style === 'hero' ? items.slice(0, 8) : items };
      } catch (_) { return null; }
    }, ctx);
    return { sections: sections.filter(function (s) { return s && s.items.length; }) };
    }, 12000);
  }

  async function discoveryFeed(feedId, page) {
    var p = Math.max(1, Number(page) || 1);
    var feed = FEEDS[feedId] || FEEDS['movy-trending'];
    return catalogueOperation(async function (ctx) {
      var data = await tmdb(feed.path + '?page=' + p, ctx);
      var items = (data.results || []).map(function (r) { return mapItem(r, feed.type); }).filter(Boolean);
      return { feedId: feedId || 'movy-trending', page: p, items: items, hasMore: items.length >= 18 };
    }, 10000);
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
