const MODULE_NAME = 'WeebCentralV400';
const BASE_URL = 'https://weebcentral.com';
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

function log(message) {
  console.log('[' + MODULE_NAME + '] ' + message);
}

function toAbsoluteUrl(url) {
  const value = String(url || '').trim();
  if (!value) return '';
  if (value.startsWith('http://') || value.startsWith('https://')) return value;
  if (value.startsWith('//')) return 'https:' + value;
  if (value.startsWith('/')) return BASE_URL + value;
  return BASE_URL + '/' + value;
}

function decodeHtmlEntities(text) {
  return String(text || '')
    .replace(/&#039;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&#8217;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&#x27;/g, "'");
}

function stripHtml(html) {
  return decodeHtmlEntities(String(html || ''))
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseDetailListItem(html, labelPattern) {
  const re = new RegExp('<li[^>]*>\\s*<strong>\\s*' + labelPattern + '\\s*:\\s*<\\/strong>([\\s\\S]*?)<\\/li>', 'i');
  const block = (String(html || '').match(re) || [])[1] || '';
  if (!block) return [];
  const values = [];
  const linkRe = /<a[^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = linkRe.exec(block)) !== null) {
    const value = stripHtml(match[1]).replace(/,+$/g, '').trim();
    if (value && !values.includes(value)) values.push(value);
  }
  if (values.length) return values;
  const fallback = stripHtml(block).replace(/,+$/g, '').trim();
  return fallback ? [fallback] : [];
}

function parseSimpleDetailValue(html, labelPattern) {
  const values = parseDetailListItem(html, labelPattern);
  return values.length ? values[0] : '';
}

function parseChapterTitleFromAnchor(rawInner) {
  const raw = String(rawInner || '');
  const preferred =
    (raw.match(/<span[^>]*class=""[^>]*>([\s\S]*?Chapter[\s\S]*?)<\/span>/i) || [])[1] ||
    (raw.match(/<span[^>]*>(\s*Chapter\s*\d+(?:\.\d+)?[\s\S]*?)<\/span>/i) || [])[1] ||
    (raw.match(/>\s*(Chapter\s*\d+(?:\.\d+)?[^<]*)</i) || [])[1] ||
    '';
  return stripHtml(preferred || raw);
}

function cleanChapterTitle(raw, chapterNumber) {
  let title = stripHtml(raw)
    .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/g, ' ')
    .replace(/\bLast Read\b[\s\S]*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();

  const fallback = chapterNumber ? 'Chapter ' + chapterNumber : 'Chapter';
  if (!title) return fallback;
  const chapterMatch = title.match(/Chapter\s*\d+(?:\.\d+)?(?:\s*[-:–—]\s*[^|]{1,120})?/i);
  if (chapterMatch) return chapterMatch[0].trim();
  if (/fill:|stroke:|font-family|viewBox|xmlns|M\d/i.test(title) || title.length > 140) {
    return fallback;
  }
  return title;
}


async function request(url, opts) {
  const options = opts || {};
  const method = options.method || 'GET';
  const headers = options.headers || {
    'User-Agent': USER_AGENT,
    Accept: '*/*',
    Referer: BASE_URL + '/',
  };
  const body = options.body == null ? null : options.body;
  const fetchOptions =
    options.fetchOptions && typeof options.fetchOptions === 'object'
      ? options.fetchOptions
      : {};

  try {
    if (typeof fetchv2 === 'function') {
      const res = await fetchv2(url, headers, method, body, fetchOptions);
      const text =
        typeof res.text === 'function'
          ? await res.text()
          : typeof res.body === 'string'
            ? res.body
            : '';
      return {
        ok: !!(res && res.ok === true),
        status: (res && res.status) || 0,
        body: text,
        bodyDropped: !!(res && res.bodyDropped),
        dropReason: res && res.dropReason ? String(res.dropReason) : '',
        bodyBytes: (res && res.bodyBytes) || 0,
        error: (res && res.ok === true) ? '' : 'HTTP ' + ((res && res.status) || 0),
      };
    }
    if (typeof fetch === 'function') {
      const res = await fetch(url, { method, headers, body });
      return {
        ok: res.ok,
        status: res.status || 0,
        body: await res.text(),
        error: res.ok ? '' : 'HTTP ' + (res.status || 0),
      };
    }
    return { ok: false, status: 0, body: '', error: 'No fetch bridge' };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      body: '',
      error: (err && err.message) ? err.message : String(err),
    };
  }
}

function parsePopularPageToken(query) {
  const raw = String(query || '').trim();
  const match = raw.match(/^__popular_page_(\d+)$/);
  if (!match) return null;
  return Math.max(1, parseInt(match[1], 10) || 1);
}

function parseSearchCards(html) {
  const text = String(html || '');
  const marker = '<article class="bg-base-300 flex gap-4 p-4">';
  const blocks = [];
  let start = text.indexOf(marker);
  while (start !== -1) {
    const next = text.indexOf(marker, start + marker.length);
    blocks.push(text.slice(start, next === -1 ? text.length : next));
    start = next;
  }

  const results = [];
  const seen = new Set();
  for (const block of blocks) {
    const hrefMatch = block.match(/href="https:\/\/weebcentral\.com\/series\/([A-Z0-9]{20,})\/([^"]+)"/i);
    if (!hrefMatch) continue;

    const id = hrefMatch[1];
    const slug = hrefMatch[2];
    const href = id + '/' + slug;
    if (seen.has(href)) continue;

    const title =
      stripHtml((block.match(/class="line-clamp-1 link link-hover">([\s\S]*?)<\/a>/i) || [])[1]) ||
      stripHtml((block.match(/class="text-ellipsis truncate text-white text-center text-lg z-20 w-\[90%\]">([\s\S]*?)<\/div>/i) || [])[1]) ||
      stripHtml((block.match(/alt="([^"]+?)\s+cover"/i) || [])[1]) ||
      slug.replace(/-/g, ' ').replace(/\b\w/g, function (ch) { return ch.toUpperCase(); });

    const imageMatch =
      block.match(/<img[^>]+src="([^"]+)"[^>]*>/i) ||
      block.match(/<source[^>]+srcset="([^"]+)"[^>]*>/i);
    const imageValue = imageMatch ? String(imageMatch[1] || '').split(/\s+/)[0] : '';
    const image = toAbsoluteUrl(imageValue);

    seen.add(href);
    results.push({ href, title, image });
  }
  return results;
}

function parseHomeCards(html) {
  const results = [];
  const seen = new Set();
  const anchorRegex = /<a[^>]*href="https:\/\/weebcentral\.com\/series\/([^"#?]+)"[^>]*>/gi;
  let match;
  while ((match = anchorRegex.exec(String(html || ''))) !== null) {
    const href = String(match[1] || '').trim();
    if (!href || seen.has(href) || href === 'random') continue;
    const start = Math.max(0, match.index - 400);
    const end = Math.min(String(html).length, match.index + 1200);
    const context = String(html).slice(start, end);
    const title =
      stripHtml((context.match(/data-tip="([^"]+)"/i) || [])[1]) ||
      stripHtml((context.match(/alt="([^"]+?)\s+cover"/i) || [])[1]) ||
      href.split('/')[1] ||
      'Unknown';
    const image = toAbsoluteUrl((context.match(/<img[^>]+src="([^"]+)"[^>]*alt="[^"]+?\s+cover"/i) || [])[1]);
    seen.add(href);
    results.push({ href, title, image });
  }
  return results;
}

async function warmDiscoverySession() {
  let response = await request(BASE_URL + '/', {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: BASE_URL + '/',
    },
  });
  if (/Cloudflare|Attention Required|cf-browser-verification/i.test(response.body)) {
    response = await request(BASE_URL + '/', {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,*/*',
        Referer: BASE_URL + '/',
      },
    });
  }
  if (!response.ok) {
    throw new Error('Discovery warm-up failed: HTTP ' + (response.status || 0));
  }
  return response;
}

async function fetchDiscoveryPage(sort, page) {
  const limit = 30;
  const pageNumber = Math.max(1, parseInt(page, 10) || 1);
  const offset = (pageNumber - 1) * limit;
  const url =
    BASE_URL +
    '/search/data?limit=' + limit +
    '&offset=' + offset +
    '&display_mode=Full%20Display' +
    '&sort=' + encodeURIComponent(sort) +
    '&text=';
  const response = await request(url, {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: BASE_URL + '/search',
      'HX-Request': 'true',
      'HX-Current-URL': BASE_URL + '/search',
    },
  });
  if (!response.ok) {
    throw new Error('Discovery feed failed: HTTP ' + (response.status || 0));
  }
  if (/Cloudflare|Attention Required|cf-browser-verification/i.test(response.body)) {
    throw new Error('WeebCentral is temporarily blocked by Cloudflare. Please retry in a moment.');
  }
  return parseSearchCards(response.body).slice(0, limit);
}

async function safeDiscoveryPage(sort, page) {
  try {
    return await fetchDiscoveryPage(sort, page);
  } catch (error) {
    log('discovery section failed sort=' + sort + ': ' + ((error && error.message) || String(error)));
    return [];
  }
}

async function discoveryHome() {
  const home = await warmDiscoverySession();
  const featured = parseHomeCards(home.body).slice(0, 8);
  const pages = await Promise.all([
    safeDiscoveryPage('Popularity', 1),
    safeDiscoveryPage('Latest Updates', 1),
    safeDiscoveryPage('Recently Added', 1),
  ]);
  const sections = [
    {
      id: 'featured',
      title: 'Featured',
      style: 'poster',
      items: featured,
    },
    {
      id: 'popular',
      title: 'Popular',
      style: 'poster',
      items: pages[0],
      viewAll: { mode: 'search', query: '__wc_sort:Popularity' },
    },
    {
      id: 'latest-updates',
      title: 'Latest Updates',
      style: 'poster',
      items: pages[1],
      viewAll: { mode: 'feed', feedId: 'reader-all' },
    },
    {
      id: 'recently-added',
      title: 'Recently Added',
      style: 'poster',
      items: pages[2],
      viewAll: { mode: 'search', query: '__wc_sort:Recently Added' },
    },
  ].filter(function (section) {
    return Array.isArray(section.items) && section.items.length > 0;
  });
  return { sections: sections };
}

async function discoveryFeed(feedId, page) {
  if (String(feedId || '') !== 'reader-all') {
    return { items: [], page: Math.max(1, parseInt(page, 10) || 1), hasMore: false };
  }
  const pageNumber = Math.max(1, parseInt(page, 10) || 1);
  await warmDiscoverySession();
  const items = await fetchDiscoveryPage('Latest Updates', pageNumber);
  return {
    items: items,
    page: pageNumber,
    hasMore: items.length >= 30,
  };
}

async function searchResults(query, page) {
  const pageFromToken = parsePopularPageToken(query);
  const pageNumber = pageFromToken || Math.max(1, parseInt(page, 10) || 1);

  let text = String(query || '').trim();
  let sort = 'Best Match';
  const limit = 30;

  if (pageFromToken) {
    text = '';
  } else if (text.startsWith('__wc_sort:')) {
    sort = text.substring('__wc_sort:'.length).trim() || 'Best Match';
    text = '';
  }

  const warmUp = await request(BASE_URL + '/', {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: BASE_URL + '/',
    },
  });

  if (!warmUp.ok || /Cloudflare|Attention Required|cf-browser-verification/i.test(warmUp.body)) {
    log('Cloudflare detected on warm-up, retrying immediately...');
    await request(BASE_URL + '/', {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,*/*',
        Referer: BASE_URL + '/',
      },
    });
  }

  // Handle Home Feed pagination (Static)
  if (!text && sort === 'Best Match') {
    const homeRes = await request(BASE_URL + '/', {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,*/*',
        Referer: BASE_URL + '/',
      },
    });
    if (!homeRes.ok) {
      throw new Error('Home feed failed: HTTP ' + (homeRes.status || 0));
    }
    const cards = parseHomeCards(homeRes.body).slice((pageNumber - 1) * limit, pageNumber * limit);
    log('home results=' + cards.length + ' page=' + pageNumber);
    return cards;
  }

  // Handle Paginated Search (Text or Sort)
  const offset = (pageNumber - 1) * limit;
  const url =
    BASE_URL +
    '/search/data?limit=' + limit +
    '&offset=' + offset +
    '&display_mode=Full%20Display' +
    '&sort=' + encodeURIComponent(sort) +
    '&text=' + encodeURIComponent(text);

  const doSearch = async () => {
    const res = await request(url, {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,*/*',
        Referer: BASE_URL + '/search',
        'HX-Request': 'true',
        'HX-Current-URL': BASE_URL + '/search',
      },
    });

    if (!res.ok) {
      throw new Error('Search failed: HTTP ' + (res.status || 0) + ' — the source may be temporarily unavailable');
    }
    if (/Cloudflare|Attention Required|cf-browser-verification/i.test(res.body)) {
      throw new Error('WeebCentral is temporarily blocked by Cloudflare. Please retry in a moment.');
    }
    return res;
  };

  let res;
  try {
    res = await doSearch();
  } catch (err) {
    log('Search failed, retrying immediately: ' + ((err && err.message) || String(err)));
    res = await doSearch();
  }

  const parsed = parseSearchCards(res.body).slice(0, limit);
  log('paginated results=' + parsed.length + ' query="' + text + '" sort="' + sort + '" page=' + pageNumber);
  return parsed;
}

function normalizeSeriesPath(seriesId) {
  const raw = String(seriesId || '').trim();
  if (!raw) return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) {
    const m = raw.match(/\/series\/([^/?#]+)/i);
    return m ? m[1] : raw;
  }
  return raw.replace(/^\/+/, '').replace(/^series\//i, '');
}

async function extractDetails(seriesId) {
  const seriesPath = normalizeSeriesPath(seriesId);
  if (!seriesPath) throw new Error('Invalid series id');
  const seriesUrl = BASE_URL + '/series/' + seriesPath;

  const res = await request(seriesUrl, {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: BASE_URL + '/',
    },
  });
  if (!res.ok) throw new Error('Details failed: ' + res.error);

  const html = res.body;
  const title =
    stripHtml((html.match(/<meta property="og:title" content="([^"]+)"/i) || [])[1]) ||
    stripHtml((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1]) ||
    seriesPath.split('/')[1] ||
    'Unknown';
  const description = stripHtml((html.match(/<meta name="description" content="([^"]+)"/i) || [])[1]);
  const image = toAbsoluteUrl((html.match(/<meta property="og:image" content="([^"]+)"/i) || [])[1]);
  const authors = parseDetailListItem(html, 'Author\\(s\\)');
  const genres = parseDetailListItem(html, 'Tags\\(s\\)');
  const type = parseSimpleDetailValue(html, 'Type');
  const status = parseSimpleDetailValue(html, 'Status');
  const released = parseSimpleDetailValue(html, 'Released');

  return {
    title,
    description: description || 'No description available.',
    image: image || undefined,
    author: authors.join(', ') || undefined,
    genres: genres.length ? genres : undefined,
    status: status || undefined,
    type: type || undefined,
    airdate: released || undefined,
  };
}

function parseChaptersFromHtml(html) {
  const chapters = [];
  const seen = new Set();
  const anchorMatches = String(html || '').matchAll(
    /<a[^>]*href="[^"]*\/chapters\/([A-Z0-9]+)[^"]*"[^>]*>([\s\S]*?)<\/a>/gi
  );

  for (const match of anchorMatches) {
    const chapterId = match[1];
    if (!chapterId || seen.has(chapterId)) continue;
    seen.add(chapterId);
    const rawInner = String(match[2] || '');
    const inner = parseChapterTitleFromAnchor(rawInner);
    const numMatch = inner.match(
      /\b(?:chapter|chap|ch\.?)\s*[:#-]?\s*(\d+(?:\.\d+)?)/i
    );
    const chapterNumber = numMatch ? parseFloat(numMatch[1]) : 0;
    chapters.push({
      href: chapterId,
      number: chapterNumber || undefined,
      title: cleanChapterTitle(inner, chapterNumber || undefined),
    });
  }

  chapters.sort(function (a, b) {
    const aa = typeof a.number === 'number' ? a.number : -1;
    const bb = typeof b.number === 'number' ? b.number : -1;
    if (aa !== bb) return bb - aa;
    const at = String(a.title || '');
    const bt = String(b.title || '');
    if (at !== bt) return at.localeCompare(bt);
    return String(a.href || '').localeCompare(String(b.href || ''));
  });
  return chapters;
}

async function extractChapters(seriesId) {
  const seriesPath = normalizeSeriesPath(seriesId);
  if (!seriesPath) throw new Error('Invalid series id');

  const idOnly = seriesPath.split('/')[0];
  const seriesUrl = BASE_URL + '/series/' + seriesPath;
  const fullListUrl = BASE_URL + '/series/' + idOnly + '/full-chapter-list';

  const res = await request(fullListUrl, {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: seriesUrl,
      'HX-Request': 'true',
      'HX-Current-URL': seriesUrl,
    },
    fetchOptions: {
      responseClass: 'chapter_list_html',
      maxBytesHint: 12 * 1024 * 1024,
    },
  });

  if (!res.ok) {
    throw new Error('Chapter list request failed: ' + (res.error || 'HTTP ' + res.status));
  }
  if (res.bodyDropped) {
    throw new Error('Chapter list too large for bridge. Retry in a moment.');
  }
  const html = res.body || '';
  if (!html || html.length < 1000 || /Cloudflare|Attention Required/i.test(html)) {
    throw new Error('Chapter list is unavailable right now. Please retry.');
  }

  const chapters = parseChaptersFromHtml(html);
  if (!chapters.length) {
    throw new Error('No chapters parsed from full chapter list. Please retry.');
  }
  const limited = chapters.slice(0, 2000);
  log('chapters parsed=' + limited.length + ' series=' + seriesPath + ' bytes=' + (res.bodyBytes || 0));
  return limited;
}

async function extractImages(chapterId) {
  const id = String(chapterId || '').trim();
  if (!id) throw new Error('Invalid chapter id');
  const url = BASE_URL + '/chapters/' + id + '/images?reading_style=long_strip';

  const res = await request(url, {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,*/*',
      Referer: BASE_URL + '/',
      'HX-Request': 'true',
    },
  });
  if (!res.ok) throw new Error('Images failed: ' + res.error);

  const html = res.body;
  const urls = [];
  const seen = new Set();
  const regex = /(data-src|src|srcset)="([^"]+)"/gi;
  let match = null;
  while ((match = regex.exec(html)) !== null) {
    const value = String(match[2] || '').trim();
    if (!value) continue;
    const first = value.split(/\s+/)[0];
    const finalUrl = toAbsoluteUrl(first);
    if (!/\.(jpg|jpeg|png|webp|avif)(\?|$)/i.test(finalUrl)) continue;
    if (/logo|icon|sprite/i.test(finalUrl)) continue;
    if (seen.has(finalUrl)) continue;
    seen.add(finalUrl);
    urls.push(finalUrl);
  }

  log('images parsed=' + urls.length + ' chapter=' + id);
  return urls;
}

// Compatibility handlers required by current V2 validator.
async function extractEpisodes(seriesId) {
  return extractChapters(seriesId);
}

async function extractStreamUrl(chapterId) {
  const images = await extractImages(chapterId);
  if (!images.length) return '';
  return images[0];
}

globalThis.searchResults = searchResults;
globalThis.extractDetails = extractDetails;
globalThis.extractChapters = extractChapters;
globalThis.extractImages = extractImages;
globalThis.extractEpisodes = extractEpisodes;
globalThis.extractStreamUrl = extractStreamUrl;
globalThis.discoveryHome = discoveryHome;
globalThis.discoveryFeed = discoveryFeed;

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    searchResults,
    extractDetails,
    extractChapters,
    extractImages,
    extractEpisodes,
    extractStreamUrl,
    discoveryHome,
    discoveryFeed,
  };
}
