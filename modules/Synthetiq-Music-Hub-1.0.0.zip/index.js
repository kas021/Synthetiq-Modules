(function () {
  'use strict';

  // Audius is the only source in this initial Hub. The app owns local listening
  // statistics; this package sends only the current source request or search.
  const API_BASE = 'https://api.audius.co/v1';
  const HOME_LIMIT = 18;
  const SEARCH_LIMIT = 20;
  const MAX_ITEMS = 24;
  const REQUEST_GAP_MS = 160;

  function ok(data) {
    return { ok: true, data: JSON.stringify(data) };
  }

  function fail(message) {
    return {
      ok: false,
      error: { message: String(message || 'Synthetiq Music Hub request failed') },
    };
  }

  function text(value, fallback) {
    const result = String(value == null ? '' : value).trim();
    return result || String(fallback || '');
  }

  function number(value) {
    const result = Number(value);
    return Number.isFinite(result) && result > 0 ? Math.floor(result) : undefined;
  }

  function pause(milliseconds) {
    return new Promise(function (resolve) {
      setTimeout(resolve, milliseconds);
    });
  }

  async function fetchJson(path) {
    const response = await fetchv2(
      API_BASE + path,
      { Accept: 'application/json' },
      'GET',
    );
    const status = Number((response && (response.status || response.statusCode)) || 0);
    let parsed = null;
    if (response && typeof response.json === 'function') {
      try {
        parsed = await response.json();
      } catch (_) {
        parsed = null;
      }
    }
    let body = String((response && response.body) || '');
    if (!body && response && typeof response.text === 'function') {
      try {
        body = await response.text();
      } catch (_) {
        body = '';
      }
    }
    if (status === 429) {
      throw new Error('Audius is busy. Please try again shortly.');
    }
    if (status < 200 || status >= 300) {
      throw new Error('Audius returned HTTP ' + status);
    }
    if (parsed && typeof parsed === 'object') return parsed;
    if (!body || /^\s*</.test(body)) {
      throw new Error('Audius returned an empty or non-JSON response');
    }
    try {
      return JSON.parse(body);
    } catch (_) {
      throw new Error('Audius returned malformed JSON');
    }
  }

  function rows(payload) {
    if (payload && Array.isArray(payload.data)) return payload.data;
    if (Array.isArray(payload)) return payload;
    return [];
  }

  function artwork(raw) {
    const source = raw && raw.artwork;
    if (!source || typeof source !== 'object') return '';
    return text(
      source['480x480'] || source['1000x1000'] || source['150x150'],
      '',
    );
  }

  function artist(raw) {
    const user = raw && raw.user;
    return text(user && (user.name || user.handle), 'Unknown Artist');
  }

  function stripTrackId(value) {
    const raw = text(value, '');
    const prefix = 'audius:track:';
    return raw.indexOf(prefix) === 0 ? raw.slice(prefix.length) : raw;
  }

  function mapTrack(raw) {
    const id = text(raw && raw.id, '');
    if (!id) return null;
    return {
      type: 'track',
      id: 'audius:track:' + id,
      title: text(raw && raw.title, 'Untitled Track'),
      artist: artist(raw),
      album: text(raw && (raw.album_title || raw.playlist_name), 'Single'),
      image: artwork(raw),
      durationSeconds: number(raw && raw.duration),
    };
  }

  function mapTracks(payload, maxItems) {
    const seen = {};
    return rows(payload)
      .map(mapTrack)
      .filter(Boolean)
      .filter(function (track) {
        if (seen[track.id]) return false;
        seen[track.id] = true;
        return true;
      })
      .slice(0, maxItems || MAX_ITEMS);
  }

  function albumFromTrack(track, raw) {
    return {
      type: 'album',
      id: track.id,
      title: track.title,
      artist: track.artist,
      image: track.image,
      description: text(raw && raw.description, 'Streamed from Audius.'),
      genre: text(raw && raw.genre, 'Music'),
      trackCount: 1,
      tracks: [track],
    };
  }

  async function getTrack(trackId) {
    const id = stripTrackId(trackId);
    if (!id) throw new Error('A track identifier is required');
    const payload = await fetchJson('/tracks/' + encodeURIComponent(id));
    const raw = payload && payload.data;
    const track = mapTrack(raw);
    if (!track) throw new Error('Audius returned no track metadata');
    return { raw: raw, track: track };
  }

  async function searchTracks(query, page) {
    const term = text(query, 'music');
    const offset = Math.max(0, Number(page || 0)) * SEARCH_LIMIT;
    const payload = await fetchJson(
      '/tracks/search?query=' +
        encodeURIComponent(term) +
        '&limit=' +
        encodeURIComponent(SEARCH_LIMIT) +
        '&offset=' +
        encodeURIComponent(offset),
    );
    return mapTracks(payload, MAX_ITEMS);
  }

  async function relatedTracks(seed) {
    const topic = text(seed.raw && seed.raw.genre, seed.track.artist);
    if (!topic) return [];
    try {
      const found = await searchTracks(topic, 0);
      return found.filter(function (candidate) {
        return candidate.id !== seed.track.id;
      });
    } catch (_) {
      return [];
    }
  }

  async function searchResults(query, page) {
    try {
      return ok(await searchTracks(query, page));
    } catch (error) {
      return fail('Music search failed: ' + text(error && error.message, error));
    }
  }

  async function homeSections(page) {
    try {
      const pageNumber = Math.max(0, Number(page || 0));
      const lanes = pageNumber === 0
        ? [
            ['Trending on Audius', '/tracks/trending?limit=' + HOME_LIMIT],
            ['Electronic Discovery', '/tracks/trending?limit=' + HOME_LIMIT + '&genre=Electronic'],
            ['Hip-Hop Discovery', '/tracks/trending?limit=' + HOME_LIMIT + '&genre=Hip-Hop'],
          ]
        : pageNumber === 1
          ? [
              ['House Discovery', '/tracks/trending?limit=' + HOME_LIMIT + '&genre=House'],
              ['Ambient Discovery', '/tracks/trending?limit=' + HOME_LIMIT + '&genre=Ambient'],
              ['Indie Discovery', '/tracks/trending?limit=' + HOME_LIMIT + '&genre=Indie'],
            ]
          : [];
      if (!lanes.length) return ok([]);

      const sections = [];
      for (let index = 0; index < lanes.length; index += 1) {
        if (index > 0) await pause(REQUEST_GAP_MS);
        const lane = lanes[index];
        try {
          const tracks = mapTracks(await fetchJson(lane[1]), HOME_LIMIT);
          if (tracks.length) {
            sections.push({ title: lane[0], type: 'track', items: tracks });
          }
        } catch (_) {
          // A single discovery lane must not erase the rest of the Home page.
        }
      }
      if (!sections.length) throw new Error('No discovery results are available');
      return ok(sections);
    } catch (error) {
      return fail('Music discovery failed: ' + text(error && error.message, error));
    }
  }

  async function extractDetails(id) {
    try {
      const seed = await getTrack(id);
      return ok(albumFromTrack(seed.track, seed.raw));
    } catch (error) {
      return fail('Track details failed: ' + text(error && error.message, error));
    }
  }

  async function extractTracks(containerId) {
    try {
      const seed = await getTrack(containerId);
      const related = await relatedTracks(seed);
      return ok([seed.track].concat(related).slice(0, MAX_ITEMS));
    } catch (error) {
      return fail('Track list failed: ' + text(error && error.message, error));
    }
  }

  async function getRelatedTracks(seedId) {
    try {
      return ok(await relatedTracks(await getTrack(seedId)));
    } catch (error) {
      return fail('Related tracks failed: ' + text(error && error.message, error));
    }
  }

  async function extractAudioUrl(trackId) {
    try {
      // Resolve just-in-time because Audius stream URLs are intentionally short lived.
      const seed = await getTrack(trackId);
      const raw = seed.raw || {};
      const stream = raw.stream && typeof raw.stream === 'object' ? raw.stream : {};
      const url = text(stream.url, '');
      if (raw.is_streamable === false || raw.is_stream_gated === true || !/^https:\/\//i.test(url)) {
        throw new Error('This track is not available for public streaming');
      }
      return ok({
        url: url,
        headers: {},
        mimeType: 'audio/mpeg',
        extension: 'mp3',
        title: seed.track.title,
        artist: seed.track.artist,
        album: seed.track.album,
        artwork: seed.track.image,
        durationSeconds: seed.track.durationSeconds,
        quality: 'stream',
      });
    } catch (error) {
      return fail('Audio stream failed: ' + text(error && error.message, error));
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.homeSections = homeSections;
  globalThis.extractDetails = extractDetails;
  globalThis.extractTracks = extractTracks;
  globalThis.getRelatedTracks = getRelatedTracks;
  globalThis.extractAudioUrl = extractAudioUrl;
})();
