// Documentary Area (documentaryarea.com) — free documentaries in SD with subtitles.
// The site serves its own MP4 files. A play link is a short-lived token tied to
// the anonymous browsing session the site sets when its player page is opened,
// so the session cookie is returned with the stream for the player and downloads.
// HD is for paying subscribers and is not offered here.
(function () {
  'use strict';

  var SITE = 'https://www.documentaryarea.com';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';
  // The site ties each play token to a PHP session. It accepts a session id the
  // client picks, and when several are sent it uses the first. The module picks
  // its own id and sends it on every request, so the site never issues another
  // cookie into the app's shared cookie store and the player and downloader can
  // be given exactly the session the token belongs to.
  function newSessionId() {
    var chars = 'abcdefghijklmnopqrstuvwxyz0123456789', out = 'sq';
    for (var i = 0; i < 24; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
  }
  var SID = newSessionId();
  var PAGE_HEADERS = { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,*/*;q=0.8', 'Accept-Language': 'en-GB,en;q=0.9', Referer: SITE + '/', Cookie: 'PHPSESSID=' + SID };
  var LANGS = { eng: 'en', spa: 'es', fre: 'fr', fra: 'fr', ger: 'de', deu: 'de', ita: 'it', por: 'pt', ara: 'ar', rus: 'ru', jpn: 'ja', chi: 'zh', zho: 'zh', kor: 'ko', dut: 'nl', nld: 'nl', pol: 'pl', tur: 'tr' };
  var pageCache = Object.create(null);

  function log(m) { try { console.log('[DocumentaryArea] ' + m); } catch (_) {} }

  function decode(s) {
    return String(s == null ? '' : s)
      .replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ' ')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'")
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(Number(n)); })
      .replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
  }

  function absolute(u) {
    var s = String(u || '').trim();
    if (!s) return '';
    if (/^https?:\/\//i.test(s)) return s.replace(/^http:/i, 'https:');
    if (s.indexOf('//') === 0) return 'https:' + s;
    return SITE + (s.charAt(0) === '/' ? '' : '/') + s;
  }

  function withTimeout(p, ms) {
    var t;
    return Promise.race([p, new Promise(function (r) { t = setTimeout(function () { r(null); }, ms); })])
      .then(function (v) { try { clearTimeout(t); } catch (_) {} return v; });
  }

  function headerValue(headers, name) {
    if (!headers) return '';
    if (typeof headers.get === 'function') return headers.get(name) || '';
    var key = Object.keys(headers).filter(function (k) { return k.toLowerCase() === name; })[0];
    var v = key ? headers[key] : '';
    return Array.isArray(v) ? v.join(', ') : String(v || '');
  }

  async function request(url, extra, opts) {
    var o = opts || {};
    var h = Object.assign({}, PAGE_HEADERS, extra || {});
    try {
      var res = await withTimeout(fetchv2(url, h, 'GET', null, { timeoutMs: o.timeoutMs || 15000, maxBytesHint: o.maxBytes || 2097152 }), (o.timeoutMs || 15000) + 2000);
      if (!res) return null;
      var text = typeof res.body === 'string' ? res.body : '';
      if (!text && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
      return { status: Number(res.status || res.statusCode || 0), text: text || '', headers: res.headers || {}, url: res.finalUrl || res.url || url };
    } catch (e) {
      log('request failed: ' + (e && e.message ? e.message : e));
      return null;
    }
  }

  // ───────────────────────── Listings ─────────────────────────

  function titleFromHref(href) {
    var m = String(href || '').match(/player\.php\?title=([^"&#]+)/);
    return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : '';
  }

  function itemHref(title) {
    return SITE + '/player.php?title=' + encodeURIComponent(title).replace(/%20/g, '+');
  }

  // Main listing cards only: an image card followed by an <h2> title, year and category.
  function parseCards(html) {
    var out = [];
    var seen = Object.create(null);
    var re = /<a[^>]+href="\/player\.php\?title=([^"]+)"[^>]*>\s*<img[^>]+?(?:data-src|src)="([^"]+)"[^>]*>[\s\S]*?<h2>\s*<a[^>]*>([\s\S]*?)<\/a>\s*<\/h2>([\s\S]*?)<div class="comments-space">([\s\S]*?)<\/div>/g;
    var m;
    while ((m = re.exec(html))) {
      var title = decodeURIComponent(m[1].replace(/\+/g, ' '));
      if (!title || seen[title]) continue;
      seen[title] = true;
      var meta = decode(m[4]);
      var year = (meta.match(/\b(19|20)\d{2}\b/) || [])[0];
      var category = decode(meta.replace(/\b(19|20)\d{2}\b/, '')).trim();
      out.push({
        title: decode(m[3]) || title,
        href: itemHref(title),
        image: absolute(m[2]),
        year: year ? Number(year) : undefined,
        category: category || undefined,
        description: decode(m[5]).slice(0, 400)
      });
    }
    return out;
  }

  // The site numbers pages from 0 ("page=0" is the first page).
  function hasNextPage(html, page) {
    return new RegExp('page=' + page + '&').test(html);
  }

  async function listing(path, page) {
    var p = Math.max(1, Number(page) || 1);
    var url = SITE + path + (path.indexOf('?') >= 0 ? '&' : '?') + 'page=' + (p - 1);
    var res = await request(url);
    if (!res || res.status !== 200) throw new Error('Documentary Area listing HTTP ' + (res ? res.status : 0));
    return { items: parseCards(res.text), hasMore: hasNextPage(res.text, p) };
  }

  function card(it) {
    return { title: it.title, href: it.href, image: it.image, year: it.year, type: 'movie', isMovie: true };
  }

  async function searchResults(query, page) {
    var q = String(query || '').trim();
    var path = q ? '/results.php?search=' + encodeURIComponent(q) : '/results-recent.php';
    var res = await listing(path, page);
    var items = res.items;
    if (q) {
      // The site matches descriptions too; put title matches first.
      var nq = q.toLowerCase();
      var rank = function (it) {
        var t = String(it.title).toLowerCase();
        return t === nq ? 0 : t.indexOf(nq) === 0 ? 1 : t.indexOf(nq) >= 0 ? 2 : 3;
      };
      items = items.map(function (it, i) { return { it: it, i: i }; })
        .sort(function (a, b) { return rank(a.it) - rank(b.it) || a.i - b.i; })
        .map(function (x) { return x.it; });
    }
    return items.map(card);
  }

  // ───────────────────────── Details & episodes ─────────────────────────

  function parseTitleRef(input) {
    var s = String(input || '');
    var t = titleFromHref(s);
    if (t) return t;
    var v = s.match(/\/video\/([^/?#]+)\/?/);
    return v ? decodeURIComponent(v[1].replace(/\+/g, ' ')) : '';
  }

  // Opens the player page. Its MP4 token and the session cookie that unlocks it
  // are only valid together, so a fresh page is fetched for every play.
  async function loadPage(title, fresh) {
    var hit = pageCache[title];
    if (!fresh && hit && Date.now() - hit.at < 10 * 60 * 1000) return hit;
    var res = await request(itemHref(title));
    if (!res || res.status !== 200 || !/jwplayer\(/.test(res.text)) {
      throw new Error('Documentary Area page unavailable (HTTP ' + (res ? res.status : 0) + ')');
    }
    var html = res.text;
    var ld = {};
    var j = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
    if (j) { try { ld = JSON.parse(j[1]); } catch (_) { ld = {}; } }
    var page = { at: Date.now(), html: html, ld: ld, sid: SID, url: res.url };
    var keys = Object.keys(pageCache);
    if (keys.length > 30) delete pageCache[keys[0]];
    pageCache[title] = page;
    return page;
  }

  function isoDuration(d) {
    var m = String(d || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!m) return '';
    var h = Number(m[1] || 0), mi = Number(m[2] || 0);
    return h ? h + 'h ' + mi + 'm' : mi + 'm';
  }

  async function extractDetails(urlOrId) {
    var title = parseTitleRef(urlOrId);
    if (!title) return { title: '', description: '' };
    var page = await loadPage(title, false);
    var ld = page.ld || {};
    var desc = decode((page.html.match(/<meta name="Description" content="([^"]*)"/) || [])[1] || ld.description || '');
    var poster = 'https://www.documentaryarea.com/iconos/' + encodeURIComponent(title).replace(/%20/g, '%20') + '.jpg';
    return {
      title: decode(ld.name || title),
      description: desc.replace(/\.{3,}$/, '…'),
      image: poster,
      poster: poster,
      banner: absolute(ld.thumbnailUrl || ''),
      duration: isoDuration(ld.duration),
      airdate: ld.uploadDate ? String(ld.uploadDate).slice(0, 10) : '',
      isMovie: true,
      type: 'movie'
    };
  }

  async function extractEpisodes(seriesId) {
    var title = parseTitleRef(seriesId);
    if (!title) return [];
    return [{ number: 1, season: 1, title: title, href: itemHref(title), subAvailable: true, dubAvailable: false, isMovie: true }];
  }

  // ───────────────────────── Stream ─────────────────────────

  function subtitleTracks(html, headers) {
    var out = [];
    var re = /file:\s*"(https:\/\/www\.documentaryarea\.com\/webvtt\/[^"]+)"\s*,\s*label:\s*"([^"]+)"/g;
    var m;
    while ((m = re.exec(html))) {
      var code = (m[1].match(/\.([a-z]{3})\.(?:srt|vtt)$/i) || [])[1];
      var lang = LANGS[String(code || '').toLowerCase()] || 'und';
      out.push({ url: m[1], file: m[1], label: decode(m[2]), lang: lang, language: lang, kind: 'subtitles', format: /\.vtt$/i.test(m[1]) ? 'vtt' : 'srt', headers: headers });
    }
    out.sort(function (a, b) { return (a.lang === 'en' ? 0 : 1) - (b.lang === 'en' ? 0 : 1); });
    return out;
  }

  async function extractStreamUrl(episodeHref, lang) {
    var wanted = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';
    var empty = { streams: [], subtitles: [], lang: wanted };
    if (wanted === 'dub') return empty; // original-language documentaries only
    var title = parseTitleRef(episodeHref);
    if (!title) return empty;
    var page = await loadPage(title, true);
    // The page lists the files this visitor may play: SD, HD or both.
    var sources = [];
    var sre = /file:\s*"(https:\/\/www\.documentaryarea\.com\/video(?:HD)?\.php\?playback=[a-f0-9]+)"[^}]*?label\s*:\s*"([^"]+)"/g;
    var sm;
    while ((sm = sre.exec(page.html))) sources.push({ url: sm[1], label: /HD/i.test(sm[2]) || /videoHD/.test(sm[1]) ? 'HD' : 'SD' });
    if (!sources.length) { log('no playable file listed for ' + title); return empty; }
    var headers = {
      'User-Agent': UA,
      Referer: SITE + '/video/' + encodeURIComponent(title).replace(/%20/g, '%20') + '/',
      Cookie: 'PHPSESSID=' + page.sid,
      Accept: 'video/mp4,video/*,*/*'
    };
    // Offer only files that really serve video for this session (a file locked to
    // subscribers fails this check and is left out).
    var checks = await Promise.all(sources.map(async function (src) {
      var probe = await request(src.url, Object.assign({}, headers, { Range: 'bytes=0-1023' }), { timeoutMs: 12000, maxBytes: 65536 });
      var ct = probe ? headerValue(probe.headers, 'content-type') : '';
      return probe && (probe.status === 206 || probe.status === 200) && /video\/|octet-stream/i.test(ct) ? src : null;
    }));
    var ok = checks.filter(Boolean);
    if (!ok.length) { log('no file served video for ' + title); return empty; }
    ok.sort(function (a, b) { return (a.label === 'HD' ? 0 : 1) - (b.label === 'HD' ? 0 : 1); });
    var file = ok[0].url;
    var qualities = ok.map(function (src) { return { label: src.label, url: src.url, headers: headers }; });
    var subtitleHeaders = { 'User-Agent': UA, Referer: headers.Referer, Cookie: headers.Cookie };
    var subtitles = subtitleTracks(page.html, subtitleHeaders);
    var server = {
      id: 'server-1',
      name: 'Documentary Area ' + ok[0].label,
      url: file,
      headers: headers,
      cookies: { PHPSESSID: page.sid },
      streamType: 'mp4',
      lang: 'sub',
      qualities: qualities,
      streams: qualities.reduce(function (a, q) { return a.concat([q.label, q.url]); }, []),
      subtitles: subtitles
    };
    return {
      url: file,
      streams: server.streams,
      headers: headers,
      cookies: { PHPSESSID: page.sid },
      streamType: 'mp4',
      quality: ok[0].label,
      defaultQuality: ok[0].label,
      qualities: server.qualities,
      servers: [server],
      subtitles: subtitles,
      lang: 'sub'
    };
  }

  // ───────────────────────── Discovery ─────────────────────────

  var FEEDS = {
    recent: { title: 'Recently Added', path: '/results-recent.php', style: 'hero' },
    popular: { title: 'Most Viewed', path: '/results-mostviewed.php', style: 'poster' },
    history: { title: 'History', path: '/results.php?genre=History', style: 'poster' },
    war: { title: 'War', path: '/results.php?genre=War', style: 'poster' },
    nature: { title: 'Nature', path: '/results.php?genre=Nature', style: 'poster' },
    wildlife: { title: 'Wildlife', path: '/results.php?genre=Wildlife', style: 'poster' },
    space: { title: 'Space', path: '/results.php?genre=Space', style: 'poster' },
    science: { title: 'Science', path: '/results.php?genre=Science', style: 'poster' },
    biographies: { title: 'Biographies', path: '/results.php?genre=Biographies', style: 'poster' },
    ancient: { title: 'Ancient', path: '/results.php?genre=Ancient', style: 'poster' }
  };

  async function discoveryHome() {
    var keys = Object.keys(FEEDS);
    var results = await Promise.all(keys.map(function (k) {
      return listing(FEEDS[k].path, 1).catch(function () { return { items: [] }; });
    }));
    var sections = [];
    keys.forEach(function (k, i) {
      var items = results[i].items.slice(0, 20).map(card);
      if (items.length) sections.push({ id: k, title: FEEDS[k].title, style: FEEDS[k].style, items: items, viewAll: { mode: 'feed', feedId: k } });
    });
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    var id = FEEDS[String(feedId || '')] ? String(feedId) : 'recent';
    var p = Math.max(1, Number(page) || 1);
    try {
      var res = await listing(FEEDS[id].path, p);
      return { feedId: id, page: p, items: res.items.map(card), hasMore: res.hasMore };
    } catch (e) {
      return { feedId: id, page: p, items: [], hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
