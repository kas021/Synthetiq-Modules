/**
 * Anikoto Video Module
 *
 * Playback flow (reverse-engineered from /watch/ pages):
 * 1. ajax/episode/list/{showId} -> episode anchors with data-ids tokens
 * 2. ajax/server/list?servers={data-ids} -> server list (SUB/DUB/HSUB)
 * 3. ajax/server?get={data-link-id} -> embed player URL (VidTube / MegaPlay / VidWish)
 * 4. Fetch embed page, read data-id, call {playerHost}/stream/getSources?id={data-id}
 * 5. Return direct HLS + VTT subtitles with player Referer/Origin headers
 */

const MODULE_NAME = 'AnikotoV300';
const DOMAINS = ['https://anikototv.to', 'https://anikoto.cz'];
const HIANIME_FALLBACK_BASE = 'https://hianimes.ru';
const SEARCH_MAX_RESULTS = 60;
const FILTER_PAGE_SIZE = 30;
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

// Vidstream/MegaPlay often resolves to cdn.mewstream.buzz which 403s in native players.
// Prefer VidPlay first: current native probes show its nekostream route serves
// normal media segments, while the VidCloud route can expose image-only paths.
const SERVER_PRIORITY = {
  sub: ['vidplay', 'vidtube', 'vidcloud', 'vidwish', 'hd', 'vidstream', 'megaplay', 'vibe', 'kiwi'],
  // MegaPlay/Vidstream remain later fallbacks because their tickets often fail
  // in native playback even when the master playlist is reachable.
  dub: ['vidplay', 'vidtube', 'vidcloud', 'vidwish', 'hd', 'vidstream', 'megaplay', 'vibe', 'kiwi'],
  hsub: ['vidplay', 'vidtube', 'vidcloud', 'vidwish', 'hd', 'vidstream', 'megaplay', 'vibe', 'kiwi'],
};
const BLOCKED_STREAM_HOSTS = ['cdn.mewstream.buzz', 'mewstream.buzz', 'vibeplayer.site'];
const PLAYER_HOSTS = [
  { pattern: /megaplay\.|vidstream/i, getSourcesPath: '/stream/getSources' },
  { pattern: /vidtube\.site/i, getSourcesPath: '/stream/getSources' },
  { pattern: /vidwish\.live/i, getSourcesPath: '/stream/getSources' },
];

function log(message) {
  try {
    console.log('[' + MODULE_NAME + '] ' + String(message || ''));
  } catch (_) {}
}

function safeJsonParse(text) {
  if (typeof text !== 'string' || !text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch (_) {
    return null;
  }
}

function decodeHtml(value) {
  return String(value || '')
    .replace(/&#0*38;/g, '&')
    .replace(/&amp;/g, '&')
    .replace(/&#0*39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function decodeBase64Url(value) {
  const input = String(value || '').replace(/[\r\n\s]/g, '');
  if (!input) return '';
  const padded = input + '='.repeat((4 - (input.length % 4)) % 4);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let output = '';
  let buffer = 0;
  let bits = 0;
  for (let i = 0; i < padded.length; i += 1) {
    const ch = padded.charAt(i);
    if (ch === '=') break;
    const idx = chars.indexOf(ch);
    if (idx < 0) continue;
    buffer = (buffer << 6) | idx;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      output += String.fromCharCode((buffer >> bits) & 0xff);
    }
  }
  return output;
}

function absoluteUrl(url, base) {
  const raw = String(url || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;
  const root = String(base || DOMAINS[0]).replace(/\/+$/, '');
  if (raw.startsWith('/')) return root + raw;
  return root + '/' + raw.replace(/^\//, '');
}

function originFromUrl(url) {
  const match = String(url || '').match(/^(https?:\/\/[^/]+)/i);
  return match ? match[1] : '';
}

function normalizeLang(lang) {
  const value = String(lang || 'sub').toLowerCase().trim();
  if (value === 'dub' || value.includes('dub')) return 'dub';
  if (value === 'hsub' || value.includes('hsub') || value.includes('hard')) return 'hsub';
  return 'sub';
}

function normalizeTitleForMatch(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/\(\s*\d{4}\s*\)\s*$/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function titleFromWatchHtml(html, slug) {
  const source = String(html || '');
  const match =
    source.match(/<h1[^>]+itemprop=["']name["'][^>]*>([\s\S]*?)<\/h1>/i) ||
    source.match(/<h1[^>]*class=["'][^"']*title[^"']*["'][^>]*>([\s\S]*?)<\/h1>/i) ||
    source.match(/<title>Watch\s+(.+?)\s+Episode\s+/i);
  if (match && match[1]) {
    return decodeHtml(String(match[1]).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '));
  }
  return String(slug || '')
    .replace(/-[a-z]{5}$/i, '')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, function (letter) { return letter.toUpperCase(); })
    .trim();
}

function langToServerType(lang) {
  const normalized = normalizeLang(lang);
  if (normalized === 'dub') return 'dub';
  if (normalized === 'hsub') return 'hsub';
  return 'sub';
}

function makeEpisodeHref(showId, slug, epNum) {
  return String(showId || '').trim() + '|' + String(slug || '').trim() + '|' + String(epNum || '').trim();
}

function normalizeSlug(raw) {
  return String(raw || '')
    .trim()
    .replace(/^https?:\/\/[^/]+\/?/i, '')
    .replace(/^\/+/, '')
    .replace(/^watch\//i, '')
    .replace(/\/ep-[^/?#]+$/i, '')
    .replace(/\/$/, '')
    .trim();
}

function parseEpisodeHref(raw) {
  const value = String(raw || '').trim();
  if (!value) return { showId: '', slug: '', epNum: '', base: '' };

  const json = safeJsonParse(value);
  if (json && typeof json === 'object') {
    return {
      showId: String(json.showId || json.id || '').trim(),
      slug: String(json.slug || json.watchSlug || '').trim(),
      epNum: String(json.epNum || json.number || json.episode || '').trim(),
      base: String(json.base || '').trim(),
    };
  }

  if (value.indexOf('|') !== -1) {
    const parts = value.split('|');
    return {
      showId: String(parts[0] || '').trim(),
      slug: String(parts[1] || '').trim(),
      epNum: String(parts[2] || '').trim(),
      base: String(parts[3] || '').trim(),
    };
  }

  const watchMatch = value.match(/\/watch\/([^/]+)(?:\/ep-([^/?#]+))?/i);
  if (watchMatch) {
    return {
      showId: '',
      slug: decodeURIComponent(watchMatch[1] || '').trim(),
      epNum: decodeURIComponent(watchMatch[2] || '').trim(),
      base: '',
    };
  }

  if (value.indexOf('::') !== -1) {
    const parts = value.split('::');
    return {
      showId: String(parts[0] || '').trim(),
      slug: String(parts[1] || '').trim(),
      epNum: String(parts[2] || '').trim(),
      base: '',
    };
  }

  return { showId: '', slug: value, epNum: '', base: '' };
}

async function readResponsePayload(res) {
  let textBody = '';
  let jsonBody = null;

  if (res && res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
    jsonBody = res.json;
    textBody = JSON.stringify(jsonBody);
  } else if (res && typeof res.json === 'function') {
    try {
      jsonBody = await res.json();
      if (jsonBody != null) {
        textBody = JSON.stringify(jsonBody);
      }
    } catch (_) {
      jsonBody = null;
    }
  }

  if (!textBody && res && typeof res.text === 'function') {
    try {
      textBody = await res.text();
    } catch (_) {
      textBody = '';
    }
  }
  if (!textBody && res && typeof res.body === 'string') {
    textBody = res.body;
  }
  if (jsonBody == null) {
    jsonBody = safeJsonParse(textBody);
  }
  return { text: textBody, json: jsonBody };
}

async function request(url, options) {
  const cfg = options || {};
  const method = cfg.method || 'GET';
  const headers = Object.assign(
    {
      'User-Agent': USER_AGENT,
      'Accept-Language': 'en-US,en;q=0.9',
    },
    cfg.headers || {},
  );
  const body = cfg.body == null ? null : cfg.body;

  if (typeof fetchv2 === 'function') {
    const res = await fetchv2(url, headers, method, body);
    const payload = await readResponsePayload(res);
    const status = Number((res && res.status) || 0);
    const responseHeaders = (res && res.headers) || {};
    return {
      ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
      status: status,
      text: payload.text,
      json: payload.json,
      contentType: String(
        (res && res.contentType) ||
          responseHeaders['content-type'] ||
          responseHeaders['Content-Type'] ||
          '',
      ),
      bodyBytes: Number((res && res.bodyBytes) || 0),
    };
  }

  if (typeof fetch === 'function') {
    const res = await fetch(url, { method, headers, body });
    const textBody = await res.text();
    return {
      ok: !!res.ok,
      status: Number(res.status || 0),
      text: textBody,
      json: safeJsonParse(textBody),
      contentType: String((res.headers && res.headers.get('content-type')) || ''),
      bodyBytes: textBody.length,
    };
  }

  throw new Error('No HTTP runtime available');
}

async function requestJson(url, headers) {
  const res = await request(url, {
    headers: Object.assign(
      {
        Accept: 'application/json, text/plain, */*',
        'X-Requested-With': 'XMLHttpRequest',
      },
      headers || {},
    ),
  });
  if (!res.ok) throw new Error('HTTP ' + res.status + ' for ' + url);
  const json = res.json || safeJsonParse(res.text);
  if (!json) throw new Error('Invalid JSON from ' + url);
  return json;
}

async function requestHtml(url, headers) {
  const res = await request(url, {
    headers: Object.assign(
      {
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      },
      headers || {},
    ),
  });
  if (!res.ok || !res.text) throw new Error('HTTP ' + res.status + ' for ' + url);
  return res.text;
}

async function withDomainFallback(task) {
  let lastError = null;
  for (let i = 0; i < DOMAINS.length; i += 1) {
    const base = DOMAINS[i];
    try {
      return await task(base);
    } catch (error) {
      lastError = error;
      log('domain failed ' + base + ': ' + (error && error.message ? error.message : String(error)));
    }
  }
  throw lastError || new Error('All Anikoto domains failed');
}

function slugFromWatchHref(href) {
  const normalized = normalizeSlug(href);
  if (!normalized) return '';
  const watchMatch = normalized.match(/(?:^|\/)watch\/([^/?#]+)/i);
  if (watchMatch && watchMatch[1]) return String(watchMatch[1]).trim();
  return normalized.split('/')[0].trim();
}

function appendSearchCard(out, seen, card, limit) {
  const slug = slugFromWatchHref(card.href);
  const title = decodeHtml(card.title);
  if (!title || !slug || seen[slug]) return false;
  seen[slug] = true;
  out.push({
    title,
    href: slug,
    image: absoluteUrl(card.image || '', card.base || DOMAINS[0]),
  });
  return out.length >= (limit || SEARCH_MAX_RESULTS);
}

function parseAjaxSearchCards(html, base, limit, seen) {
  const out = [];
  const dedupe = seen || {};
  const source = String(html || '');
  const cap = limit || SEARCH_MAX_RESULTS;
  const ajaxRegex =
    /<a class="item" href="([^"]+)"[\s\S]*?<img\s+src="([^"]+)"[\s\S]*?<div class="name[^"]*"[^>]*>([^<]+)/gi;
  let match;
  while ((match = ajaxRegex.exec(source)) !== null) {
    if (
      appendSearchCard(
        out,
        dedupe,
        {
          href: match[1],
          image: match[2],
          title: match[3],
          base: base,
        },
        cap,
      )
    ) {
      return out;
    }
  }
  return out;
}

function parseFilterSearchCards(html, base, limit, seen) {
  const out = [];
  const dedupe = seen || {};
  const source = String(html || '');
  const cap = limit || SEARCH_MAX_RESULTS;
  const titleLinkRegex = /<a class="name d-title" href="([^"]+)"[^>]*>([^<]+)<\/a>/gi;
  let match;
  while ((match = titleLinkRegex.exec(source)) !== null) {
    const start = Math.max(0, match.index - 900);
    const chunk = source.slice(start, match.index + match[0].length);
    const imgMatch = chunk.match(/<img[^>]+src="([^"]+)"/i);
    if (
      appendSearchCard(
        out,
        dedupe,
        {
          href: match[1],
          image: imgMatch ? imgMatch[1] : '',
          title: match[2],
          base: base,
        },
        cap,
      )
    ) {
      return out;
    }
  }
  return out;
}

function parseWatchCards(html, base, limit, seen) {
  const out = [];
  const dedupe = seen || {};
  const cap = limit || SEARCH_MAX_RESULTS;
  const batches = [
    parseFilterSearchCards(html, base, cap, dedupe),
    parseAjaxSearchCards(html, base, cap, dedupe),
  ];
  for (let i = 0; i < batches.length; i += 1) {
    for (let j = 0; j < batches[i].length; j += 1) {
      out.push(batches[i][j]);
      if (out.length >= cap) return out;
    }
  }
  return out;
}

function parseFilterMaxPage(html) {
  const pages = [];
  const regex = /page=(\d+)/gi;
  let match;
  while ((match = regex.exec(String(html || ''))) !== null) {
    const page = parseInt(match[1], 10);
    if (!isNaN(page) && page > 0) pages.push(page);
  }
  return pages.length ? Math.max.apply(null, pages) : 1;
}

function normalizeSearchTerm(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function rankSearchResult(item, query) {
  const term = normalizeSearchTerm(query);
  if (!term) return 50;
  const title = normalizeSearchTerm(item && item.title);
  if (!title) return 80;
  if (title === term) return 0;
  if (title.indexOf(term) === 0) return 10;
  if (title.indexOf(term) !== -1) return 20;
  const tokens = term.split(' ').filter(Boolean);
  if (tokens.length && tokens.every(function (token) { return title.indexOf(token) !== -1; })) {
    return 30;
  }
  return 60;
}

function parseShowIdFromHtml(html) {
  const source = String(html || '');
  const patterns = [
    /name="show_id"\s+value="(\d+)"/i,
    /data-id="(\d+)"/i,
    /mangaId\s*=\s*(\d+)/i,
  ];
  for (let i = 0; i < patterns.length; i += 1) {
    const match = source.match(patterns[i]);
    if (match && match[1]) return String(match[1]).trim();
  }
  return '';
}

function parseDetailsFromHtml(html, base, slug) {
  const source = String(html || '');
  const ogTitle = (source.match(/property="og:title"\s+content="([^"]*)"/i) || [])[1];
  const ogImage = (source.match(/property="og:image"\s+content="([^"]*)"/i) || [])[1];
  const ogDescription = (source.match(/property="og:description"\s+content="([^"]*)"/i) || [])[1];
  const h1 = (source.match(/<h1[^>]*>\s*([^<]+?)\s*<\/h1>/i) || [])[1];
  const title = decodeHtml((h1 || ogTitle || '').replace(/Watch\s+/i, '').replace(/\s+Anime.*$/i, '').trim());
  if (!title) throw new Error('Could not parse series title');

  return {
    title,
    description: decodeHtml(ogDescription || ''),
    image: absoluteUrl(ogImage || '', base),
    href: slug,
    showId: parseShowIdFromHtml(source),
    aliases: (source.match(/data-jp="([^"]*)"/i) || [])[1] || '',
  };
}

function parseEpisodesFromHtml(html, showId, slug, base) {
  const source = String(html || '');
  const episodes = [];
  const seen = {};
  const regex = /<a href="#"[^>]*data-id="(\d+)"[^>]*data-num="([^"]*)"[^>]*data-slug="([^"]*)"[^>]*data-sub="([^"]*)"[^>]*data-dub="([^"]*)"[^>]*data-ids="([^"]*)"[^>]*>/gi;
  let match;
  while ((match = regex.exec(source)) !== null) {
    const epId = String(match[1] || '').trim();
    const epNum = String(match[2] || match[3] || '').trim();
    const epSlug = String(match[3] || epNum).trim();
    const subAvailable = String(match[4] || '') === '1';
    const dubAvailable = String(match[5] || '') === '1';
    const dataIds = String(match[6] || '').trim();
    const key = epId || epNum;
    if (!key || seen[key]) continue;
    seen[key] = true;
    episodes.push({
      number: Number(epNum) || episodes.length + 1,
      href: makeEpisodeHref(showId, slug, epNum || epSlug),
      title: 'Episode ' + (epNum || episodes.length + 1),
      season: 1,
      subAvailable,
      dubAvailable,
      epId,
      epSlug,
      dataIds,
    });
  }
  return episodes;
}

function parseServersFromHtml(html, lang) {
  const source = String(html || '');
  const targetType = langToServerType(lang);
  const typeRegex = new RegExp(
    '<div class="type"[^>]*data-type="' + targetType + '"[\\s\\S]*?<ul>([\\s\\S]*?)</ul>',
    'i',
  );
  const blockMatch = source.match(typeRegex);
  const block = blockMatch ? blockMatch[1] : source;
  const servers = [];
  const regex = /<li[^>]*data-link-id="([^"]+)"[^>]*>([^<]+)</gi;
  let match;
  while ((match = regex.exec(block)) !== null) {
    servers.push({
      linkId: String(match[1] || '').trim(),
      name: decodeHtml(match[2] || '').trim(),
    });
  }
  return servers;
}

function serverPriorityList(lang) {
  const key = langToServerType(lang);
  return SERVER_PRIORITY[key] || SERVER_PRIORITY.sub;
}

function serverRank(name, lang) {
  const lower = String(name || '').toLowerCase();
  const priorities = serverPriorityList(lang);
  for (let i = 0; i < priorities.length; i += 1) {
    if (lower.indexOf(priorities[i]) !== -1) return i;
  }
  return priorities.length;
}

function playerLangFromUrl(playerUrl) {
  const match = String(playerUrl || '').match(/\/(sub|dub|hsub)(?:[/?#]|$)/i);
  return match ? normalizeLang(match[1]) : '';
}

function parsePlayerPageMeta(html) {
  const source = String(html || '');
  const playerId =
    (source.match(/data-id=["'](\d+)["']/i) || [])[1] ||
    (source.match(/id:\s*["']?(\d+)["']?/i) || [])[1] ||
    '';
  const typeMatch = source.match(/type:\s*['"](sub|dub|hsub)['"]/i);
  return {
    playerId: String(playerId || '').trim(),
    type: typeMatch ? normalizeLang(typeMatch[1]) : '',
  };
}

function dedupeServers(servers) {
  const out = [];
  const seen = {};
  for (let i = 0; i < servers.length; i += 1) {
    const server = servers[i];
    const key = String(server.linkId || server.name || '').trim();
    if (!key || seen[key]) continue;
    seen[key] = true;
    out.push(server);
  }
  return out;
}

function sortServers(servers, lang) {
  const normalized = normalizeLang(lang);
  return servers.slice().sort(function (a, b) {
    return serverRank(a.name, normalized) - serverRank(b.name, normalized);
  });
}

function buildStreamHeaders(playerOrigin) {
  const origin = String(playerOrigin || '').replace(/\/+$/, '');
  return {
    Referer: origin + '/',
    Origin: origin,
    'User-Agent': USER_AGENT,
    Accept: '*/*',
  };
}

function isBlockedStreamUrl(url) {
  // JavaScriptCore does not guarantee the browser URL global. Parse the host
  // directly so blocklist enforcement is identical in Flutter and browsers.
  const match = String(url || '')
    .trim()
    .match(/^[a-z][a-z0-9+.-]*:\/\/([^\/?#:]+)/i);
  const host = match && match[1] ? String(match[1]).toLowerCase() : '';
  if (!host) return false;
  for (let i = 0; i < BLOCKED_STREAM_HOSTS.length; i += 1) {
    if (host === BLOCKED_STREAM_HOSTS[i] || host.endsWith('.' + BLOCKED_STREAM_HOSTS[i])) {
      return true;
    }
  }
  return false;
}

function looksLikeFakeHls(body) {
  const text = String(body || '');
  if (!text.includes('#EXTM3U')) return true;
  if (/ibyteimg\.com|\/obj\/ad-site|\.png[\s"']*$/im.test(text)) return true;
  return false;
}

async function validateHlsManifest(url, headers) {
  if (!url || isBlockedStreamUrl(url)) {
    return { ok: false, reason: 'blocked or missing stream host' };
  }

  const res = await request(url, {
    method: 'GET',
    headers: headers,
  });
  const body = String((res && res.text) || '');
  if (!res.ok) {
    return { ok: false, reason: 'manifest HTTP ' + res.status };
  }
  if (looksLikeFakeHls(body)) {
    return { ok: false, reason: 'manifest is not playable HLS' };
  }
  return { ok: true, body: body };
}

// A master can be valid while its media segments are ad images or placeholders.
// Probe a small range from one real segment before handing a server to AVPlayer.
async function validateHlsPlayback(url, headers) {
  const master = await validateHlsManifest(url, headers);
  if (!master.ok) return master;

  let playlistUrl = url;
  let playlistBody = master.body;
  const variants = parseHlsQualityVariants(url, master.body);
  if (variants.length) {
    const preferred = variants.slice().sort(function (a, b) {
      const aHeight = Number((String(a.quality || '').match(/(\d{3,4})p/i) || [])[1]) || 0;
      const bHeight = Number((String(b.quality || '').match(/(\d{3,4})p/i) || [])[1]) || 0;
      return bHeight - aHeight;
    })[0];
    playlistUrl = preferred.url;
    const playlist = await request(playlistUrl, { headers: headers });
    if (!playlist.ok || !String(playlist.text || '').includes('#EXTM3U')) {
      return { ok: false, reason: 'variant playlist unavailable' };
    }
    playlistBody = playlist.text;
  }

  const segmentUrl = firstHlsMediaUrl(playlistUrl, playlistBody);
  if (!segmentUrl) return { ok: false, reason: 'playlist has no media segments' };
  const probe = await request(segmentUrl, {
    headers: Object.assign({}, headers, { Range: 'bytes=0-4095' }),
  });
  if (!probe.ok) return { ok: false, reason: 'segment HTTP ' + probe.status };
  if (looksLikeImagePayload(probe.contentType, probe.text)) {
    return { ok: false, reason: 'segment is image placeholder' };
  }
  if (/^\s*<(?:!doctype|html)/i.test(String(probe.text || ''))) {
    return { ok: false, reason: 'segment is HTML instead of media' };
  }
  return { ok: true, body: master.body };
}

function parseHiAnimeSearchCards(html) {
  const source = String(html || '');
  const cards = [];
  const seen = {};
  const regex =
    /<div class="flw-item[^>]*>[\s\S]*?href="(\/info\/[^"]+)"[\s\S]*?<div class="film-detail">[\s\S]*?<a[^>]*data-jname="([^"]*)"[^>]*>([^<]*)<\/a>/gi;
  let match;
  while ((match = regex.exec(source)) !== null) {
    const href = HIANIME_FALLBACK_BASE + match[1];
    if (seen[href]) continue;
    seen[href] = true;
    cards.push({
      href: href,
      title: decodeHtml(match[3] || match[2] || ''),
    });
  }
  return cards;
}

function hiAnimeDetailId(url) {
  const match = String(url || '').split('?')[0].replace(/\/$/, '').match(/(?:^|\/)(?:info|watch)\/(?:[^/]+-)?(\d+)$/);
  return match ? match[1] : '';
}

function parseHiAnimeServers(html) {
  const source = String(html || '');
  const servers = [];
  const tagRegex = /<[^>]+data-id="([^"]+)"[^>]*>/gi;
  let match;
  while ((match = tagRegex.exec(source)) !== null) {
    const tag = match[0];
    const typeMatch = tag.match(/data-type="(sub|dub)"/i);
    servers.push({ id: match[1], type: typeMatch ? typeMatch[1].toLowerCase() : 'sub' });
  }
  return servers;
}

async function hiAnimeSources(serverId, lang) {
  const sourcePayload = await requestJson(
    HIANIME_FALLBACK_BASE + '/ajax/v2/episode/sources?id=' + encodeURIComponent(serverId),
    { Referer: HIANIME_FALLBACK_BASE + '/' },
  );
  if (!sourcePayload || sourcePayload.type !== 'iframe' || !sourcePayload.link) return null;

  const playerUrl = String(sourcePayload.link || '').trim();
  const echo = playerUrl.match(/^https?:\/\/(play\.echovideo\.ru|[^/]*echovideo[^/]*)\/(embed-[^/]+)\/([^?#]+)/i);
  if (!echo) return null;
  const playerOrigin = 'https://play.echovideo.ru';
  const playerPath = '/' + echo[2];
  const playerToken = echo[3];
  const playerHeaders = {
    Referer: playerOrigin + playerPath + '/' + playerToken,
    Origin: playerOrigin,
    'X-Requested-With': 'XMLHttpRequest',
    Accept: 'application/json, text/plain, */*',
  };
  const sourceData = await requestJson(
    playerOrigin + playerPath + '/getSources?id=' + encodeURIComponent(playerToken),
    playerHeaders,
  );
  const rawSources = sourceData && sourceData.sources;
  const candidates = [];
  function addCandidate(url, label, height) {
    const value = String(url || '').trim();
    if (!/^https?:\/\//i.test(value)) return;
    candidates.push({ url: value, label: label, height: height });
  }
  if (typeof rawSources === 'string') {
    addCandidate(rawSources, lang + ' Auto', 0);
  } else if (rawSources && typeof rawSources === 'object') {
    const qualities = ['HQ', 'HD', 'SD'];
    for (let i = 0; i < qualities.length; i += 1) {
      const quality = qualities[i];
      const values = Array.isArray(rawSources[quality]) ? rawSources[quality] : [rawSources[quality]];
      for (let j = 0; j < values.length; j += 1) {
        addCandidate(values[j], lang + ' ' + quality, quality === 'HQ' ? 1080 : quality === 'HD' ? 720 : 480);
      }
    }
  }

  const mediaHeaders = {
    Referer: playerOrigin + '/',
    Origin: playerOrigin,
    'User-Agent': USER_AGENT,
    Accept: '*/*',
  };
  for (let i = 0; i < candidates.length; i += 1) {
    const probe = await validateHlsPlayback(candidates[i].url, mediaHeaders);
    if (!probe.ok) {
      log('reject HiAnime fallback ' + candidates[i].url + ': ' + probe.reason);
      continue;
    }
    return {
      streams: [{
        label: candidates[i].label + ' (Fallback)',
        url: candidates[i].url,
        height: candidates[i].height,
        headers: mediaHeaders,
      }],
      qualities: [candidates[i]],
      quality: candidates[i].label,
      defaultQuality: candidates[i].label,
      headers: mediaHeaders,
      subtitles: [],
      streamType: 'hls',
      lang: lang,
      server: 'HiAnime fallback',
    };
  }
  return null;
}

async function resolveHiAnimeFallback(context, lang) {
  const title = String(context.seriesTitle || '').trim();
  const episodeNumber = Number(context.episode && context.episode.number);
  if (!title || !Number.isFinite(episodeNumber) || episodeNumber < 1) return null;

  const search = await requestHtml(
    HIANIME_FALLBACK_BASE + '/filter?keyword=' + encodeURIComponent(title),
    { Referer: HIANIME_FALLBACK_BASE + '/' },
  );
  const wantedTitle = normalizeTitleForMatch(title);
  const cards = parseHiAnimeSearchCards(search);
  const exact = cards.find(function (card) {
    return normalizeTitleForMatch(card.title) === wantedTitle;
  });
  if (!exact) {
    log('HiAnime fallback refused non-exact title match for ' + title);
    return null;
  }

  const showId = hiAnimeDetailId(exact.href);
  if (!showId) return null;
  const episodePayload = await requestJson(
    HIANIME_FALLBACK_BASE + '/ajax/v2/episode/list/' + encodeURIComponent(showId),
    { Referer: exact.href },
  );
  const episodes = Array.isArray(episodePayload && episodePayload.episodeData)
    ? episodePayload.episodeData
    : [];
  const matchedEpisode = episodes.find(function (episode) {
    return Number(episode && episode.episode_number) === episodeNumber;
  });
  const providerEpisodeId = Number(matchedEpisode && matchedEpisode.mal_id);
  if (!providerEpisodeId) return null;

  const serverPayload = await requestJson(
    HIANIME_FALLBACK_BASE + '/ajax/v2/episode/servers?episodeId=' +
      encodeURIComponent(providerEpisodeId) + '&mov_id=' + encodeURIComponent(showId),
    { Referer: exact.href },
  );
  const serverHtml = Array.isArray(serverPayload && serverPayload.html)
    ? serverPayload.html.join('')
    : String((serverPayload && serverPayload.html) || '');
  const servers = parseHiAnimeServers(serverHtml).filter(function (server) {
    return server.type === lang;
  });
  for (let i = 0; i < servers.length && i < 4; i += 1) {
    try {
      const resolved = await hiAnimeSources(servers[i].id, lang);
      if (resolved) {
        log('validated HiAnime fallback for ' + title + ' episode ' + episodeNumber + ' [' + lang + ']');
        return resolved;
      }
    } catch (error) {
      log('HiAnime fallback server failed: ' + (error && error.message ? error.message : String(error)));
    }
  }
  return null;
}

function directMediaFromPlayerUrl(playerUrl) {
  const url = String(playerUrl || '').trim();
  if (!url) return '';
  if (/\.m3u8(\?|$)|\.mp4(\?|$)/i.test(url)) return url;
  if (url.indexOf('#') !== -1) {
    const fragment = url.split('#')[1].replace(/#+$/, '').trim();
    if (!fragment) return '';
    if (/^https?:\/\//i.test(fragment)) return fragment;
    const decoded = decodeBase64Url(fragment);
    if (/^https?:\/\//i.test(decoded)) return decoded;
  }
  return '';
}

function playerConfigForUrl(playerUrl) {
  const origin = originFromUrl(playerUrl);
  for (let i = 0; i < PLAYER_HOSTS.length; i += 1) {
    if (PLAYER_HOSTS[i].pattern.test(playerUrl)) {
      return {
        origin: origin,
        getSourcesUrl: origin + PLAYER_HOSTS[i].getSourcesPath,
      };
    }
  }
  if (/vidtube|megaplay|vidwish/i.test(origin)) {
    return { origin: origin, getSourcesUrl: origin + '/stream/getSources' };
  }
  return null;
}

function normalizeSourceEntries(sourceData) {
  const streams = [];
  const raw = sourceData && sourceData.sources;
  if (!raw) return streams;

  if (typeof raw === 'string' && raw.trim()) {
    streams.push({ quality: 'Auto', url: raw.trim() });
    return streams;
  }

  if (Array.isArray(raw)) {
    for (let i = 0; i < raw.length; i += 1) {
      const item = raw[i] || {};
      const url = String(item.file || item.url || '').trim();
      if (!url) continue;
      streams.push({
        quality: String(item.label || item.quality || item.type || 'Auto').trim() || 'Auto',
        url,
      });
    }
    return streams;
  }

  if (typeof raw === 'object') {
    const url = String(raw.file || raw.url || '').trim();
    if (url) {
      streams.push({
        quality: String(raw.label || raw.quality || 'Auto').trim() || 'Auto',
        url,
      });
    }
  }
  return streams;
}

function resolveMediaUrl(reference, baseUrl) {
  const raw = String(reference || '').trim();
  const base = String(baseUrl || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;
  const origin = originFromUrl(base);
  if (!origin) return '';
  if (raw.startsWith('/')) return origin + raw;
  const cleanBase = base.split('#')[0].split('?')[0];
  const slash = cleanBase.lastIndexOf('/');
  const directory = slash >= 0 ? cleanBase.slice(0, slash + 1) : origin + '/';
  return directory + raw.replace(/^\.\//, '');
}

// A player often returns one HLS master URL even though that master contains
// its own 360p/720p/1080p variants. Expose those variants to the app so its
// generic quality picker can work without any Anikoto-specific UI.
function parseHlsQualityVariants(masterUrl, manifest) {
  const source = String(manifest || '');
  if (!source.includes('#EXTM3U')) return [];
  const variants = [];
  const seen = {};
  const lines = source.split(/\r?\n/);
  for (let i = 0; i < lines.length; i += 1) {
    const tag = String(lines[i] || '').trim();
    if (!tag.startsWith('#EXT-X-STREAM-INF:')) continue;
    let target = '';
    for (let next = i + 1; next < lines.length; next += 1) {
      const candidate = String(lines[next] || '').trim();
      if (!candidate) continue;
      if (!candidate.startsWith('#')) {
        target = resolveMediaUrl(candidate, masterUrl);
        break;
      }
    }
    if (!target || seen[target]) continue;
    const resolution = tag.match(/RESOLUTION=\d+x(\d+)/i);
    const height = resolution && resolution[1] ? String(resolution[1]) : '';
    seen[target] = true;
    variants.push({ quality: height ? height + 'p' : 'Auto', url: target });
  }
  return variants;
}

function firstHlsMediaUrl(playlistUrl, manifest) {
  const lines = String(manifest || '').split(/\r?\n/);
  for (let i = 0; i < lines.length; i += 1) {
    const line = String(lines[i] || '').trim();
    if (!line || line.startsWith('#')) continue;
    return resolveMediaUrl(line, playlistUrl);
  }
  return '';
}

function looksLikeImagePayload(contentType, body) {
  const type = String(contentType || '').toLowerCase();
  const sample = String(body || '').slice(0, 96);
  const upper = sample.toUpperCase();
  // fetchv2 exposes binary samples as UTF-8 text. A PNG header therefore
  // normally starts with replacement-char + PNG even when a CDN lies about
  // the MIME type. That is sufficient to reject the 1x1 ad placeholders seen
  // from some otherwise-valid HLS playlists without treating normal TS data
  // as an image.
  const hasPngSignature = sample.slice(0, 16).toUpperCase().includes('PNG');
  const hasJpegMarker =
    upper.indexOf('JFIF') >= 0 && upper.indexOf('JFIF') <= 16 ||
    upper.indexOf('EXIF') >= 0 && upper.indexOf('EXIF') <= 16;
  if (hasPngSignature || hasJpegMarker) return true;
  // PNG/GIF/WebP are never valid MPEG-TS payloads. fetchv2 can omit the
  // decoded binary body when it reaches its response cap, so retain this
  // narrow MIME fallback for the 1x1 TikTok ad placeholders seen in AniKoto
  // masters. Keep image/jpeg signature-based because some real TS hosts lie
  // with that MIME type.
  if (
    type.indexOf('image/png') >= 0 ||
    type.indexOf('image/gif') >= 0 ||
    type.indexOf('image/webp') >= 0
  ) {
    return true;
  }
  // Several valid HLS CDNs deliberately use `.jpg` paths and even label their
  // MPEG-TS segments as image/jpeg. MIME alone is not evidence of a bad
  // stream; only reject a real image signature or HTML above.
  return false;
}

function normalizeSubtitleEntries(sourceData, playerOrigin) {
  const tracks = Array.isArray(sourceData && sourceData.tracks) ? sourceData.tracks : [];
  const streamHeaders = buildStreamHeaders(playerOrigin);
  const subtitles = [];
  for (let i = 0; i < tracks.length; i += 1) {
    const track = tracks[i] || {};
    const file = String(track.file || track.url || '').trim();
    if (!file) continue;
    const kind = String(track.kind || '').toLowerCase();
    if (kind && kind.indexOf('caption') === -1 && kind.indexOf('subtitle') === -1 && kind.indexOf('sub') === -1) {
      continue;
    }
    subtitles.push({
      file: file,
      url: file,
      label: String(track.label || track.lang || 'Subtitles').trim() || 'Subtitles',
      lang: String(track.srclang || track.lang || track.label || 'und').trim(),
      kind: track.kind || 'captions',
      default: !!track.default,
      headers: streamHeaders,
    });
  }
  return subtitles;
}

function normalizeMarkerRange(marker) {
  if (!marker) return null;

  let start;
  let end;
  if (Array.isArray(marker)) {
    start = Number(marker[0]);
    end = Number(marker[1]);
  } else if (typeof marker === 'object') {
    start = Number(
      marker.start ??
        marker.from ??
        marker.startSeconds ??
        marker.start_seconds,
    );
    end = Number(
      marker.end ??
        marker.to ??
        marker.endSeconds ??
        marker.end_seconds,
    );
  }

  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return null;
  }
  return { start, end };
}

function pickMarkerRange(primary, fallback) {
  return normalizeMarkerRange(primary) || normalizeMarkerRange(fallback);
}

async function fetchPlayerSources(playerUrl, expectedLang) {
  const targetLang = normalizeLang(expectedLang);
  const direct = directMediaFromPlayerUrl(playerUrl);
  if (direct) {
    return {
      playerUrl,
      playerOrigin: originFromUrl(direct) || originFromUrl(playerUrl),
      streams: [{ quality: 'Auto', url: direct }],
      subtitles: [],
      intro: null,
      outro: null,
      playerType: playerLangFromUrl(playerUrl) || targetLang,
    };
  }

  const playerHtml = await requestHtml(playerUrl, {
    Referer: DOMAINS[0] + '/',
  });

  const playerMeta = parsePlayerPageMeta(playerHtml);
  const playerId = playerMeta.playerId;
  if (!playerId) throw new Error('Could not find player data-id on embed page');

  const config = playerConfigForUrl(playerUrl);
  if (!config) throw new Error('Unsupported player host: ' + playerUrl);

  const playerType = playerMeta.type || playerLangFromUrl(playerUrl) || targetLang;
  let sourceUrl =
    config.getSourcesUrl +
    '?id=' +
    encodeURIComponent(playerId) +
    '&id=' +
    encodeURIComponent(playerId);
  if (playerType) {
    sourceUrl += '&type=' + encodeURIComponent(playerType);
  }

  const sourceData = await requestJson(sourceUrl, {
    Referer: playerUrl,
    Origin: config.origin,
    Accept: 'application/json, text/javascript, */*; q=0.01',
  });

  const streams = normalizeSourceEntries(sourceData);
  if (!streams.length) throw new Error('Player returned no stream sources');

  const subtitles =
    targetLang === 'dub' ? [] : normalizeSubtitleEntries(sourceData, config.origin);

  return {
    playerUrl,
    playerOrigin: config.origin,
    streams,
    subtitles,
    intro: normalizeMarkerRange(sourceData.intro),
    outro: normalizeMarkerRange(sourceData.outro),
    playerType,
  };
}

async function resolveEpisodeContext(episodeHref) {
  const parsed = parseEpisodeHref(episodeHref);
  return withDomainFallback(async function (base) {
    let showId = parsed.showId;
    let slug = parsed.slug;
    let epNum = parsed.epNum;

    if (!slug && episodeHref) slug = String(episodeHref).trim();
    if (!slug) throw new Error('Missing series slug');

    const watchUrl = absoluteUrl('/watch/' + slug + (epNum ? '/ep-' + epNum : ''), base);
    const watchHtml = await requestHtml(watchUrl, { Referer: base + '/' });
    if (!showId) showId = parseShowIdFromHtml(watchHtml);
    if (!showId) throw new Error('Could not resolve show id for ' + slug);

    const episodeList = await requestJson(absoluteUrl('/ajax/episode/list/' + showId, base), {
      Referer: watchUrl,
    });
    if (Number(episodeList.status) !== 200 || !episodeList.result) {
      throw new Error(episodeList.message || 'Episode list unavailable');
    }

    const episodes = parseEpisodesFromHtml(episodeList.result, showId, slug, base);
    if (!episodes.length) throw new Error('No episodes found for ' + slug);

    let episode = null;
    if (epNum) {
      episode = episodes.find(function (item) {
        return String(item.number) === String(epNum) || String(item.epSlug) === String(epNum);
      });
    }
    if (!episode) episode = episodes[0];

    return {
      base,
      showId,
      slug,
      episode,
      watchUrl,
      seriesTitle: titleFromWatchHtml(watchHtml, slug),
    };
  });
}

async function extractStreamFromServer(base, watchUrl, server, lang, options) {
  const opts = options || {};
  const targetLang = normalizeLang(lang);
  const payload = await requestJson(
    absoluteUrl('/ajax/server?get=' + encodeURIComponent(server.linkId), base),
    { Referer: watchUrl },
  );
  if (Number(payload.status) !== 200 || !payload.result || !payload.result.url) {
    throw new Error((payload && payload.message) || 'Server link unavailable');
  }

  const playerUrl = String(payload.result.url || '').trim();
  const playerLang = playerLangFromUrl(playerUrl);
  if (playerLang && playerLang !== targetLang) {
    throw new Error('Player URL language mismatch (' + playerLang + ' != ' + targetLang + ')');
  }

  log('server ' + server.name + ' [' + targetLang + '] -> ' + playerUrl);
  const resolved = await fetchPlayerSources(playerUrl, targetLang);
  if (resolved.playerType && resolved.playerType !== targetLang) {
    throw new Error('Player page language mismatch (' + resolved.playerType + ' != ' + targetLang + ')');
  }

  const streamHeaders = buildStreamHeaders(resolved.playerOrigin);

  const streamEntries = [];
  const seenUrls = {};
  for (let i = 0; i < resolved.streams.length; i += 1) {
    const stream = resolved.streams[i];
    const probe = await validateHlsPlayback(stream.url, streamHeaders);
    if (!probe.ok) {
      log('reject stream ' + stream.url + ': ' + probe.reason);
      continue;
    }
    if (
      targetLang === 'dub' &&
      opts.subFingerprint &&
      stream.url === opts.subFingerprint
    ) {
      log('reject dub stream identical to sub fingerprint on ' + server.name);
      continue;
    }
    const variants = parseHlsQualityVariants(stream.url, probe.body);
    const playable = variants.length ? variants : [stream];
    for (let index = 0; index < playable.length; index += 1) {
      const item = playable[index];
      const url = String(item.url || '').trim();
      if (!url || seenUrls[url]) continue;
      seenUrls[url] = true;
      streamEntries.push({
        label: targetLang + ' ' + String(item.quality || stream.quality || 'Auto'),
        url: url,
        height: Number((String(item.quality || '').match(/(\d{3,4})p/i) || [])[1]) || undefined,
      });
    }
    // The first valid server is enough. Its master playlist provides all of
    // the quality variants and avoids additional server requests on startup.
    break;
  }

  if (!streamEntries.length) {
    throw new Error('No playable HLS manifest from ' + server.name);
  }

  streamEntries.sort(function (a, b) {
    return Number(b.height || 0) - Number(a.height || 0);
  });

  const skipData = (payload.result && payload.result.skip_data) || {};

  return {
    // Object entries preserve their individual player headers. This matters
    // when a later server is used as a fallback: the Flutter runtime can race
    // it without incorrectly reusing another host's Referer/Origin.
    streams: streamEntries.map(function (item) {
      return {
        label: item.label,
        url: item.url,
        height: item.height,
        headers: streamHeaders,
      };
    }),
    qualities: streamEntries,
    quality: streamEntries[0].label,
    defaultQuality: streamEntries[0].label,
    headers: streamHeaders,
    subtitles: resolved.subtitles,
    streamType: 'hls',
    lang: targetLang,
    intro: pickMarkerRange(resolved.intro, skipData.intro),
    outro: pickMarkerRange(resolved.outro, skipData.outro),
    server: server.name,
    playerUrl: resolved.playerUrl,
  };
}

async function resolveSubStreamFingerprint(base, watchUrl, dataIds) {
  const serverList = await requestJson(
    absoluteUrl('/ajax/server/list?servers=' + encodeURIComponent(dataIds), base),
    { Referer: watchUrl },
  );
  if (Number(serverList.status) !== 200 || !serverList.result) return '';

  let servers = parseServersFromHtml(serverList.result, 'sub');
  servers = sortServers(dedupeServers(servers), 'sub');
  for (let i = 0; i < servers.length && i < 2; i += 1) {
    try {
      const result = await extractStreamFromServer(base, watchUrl, servers[i], 'sub');
      const url = result.qualities && result.qualities.length
        ? String(result.qualities[0].url || '')
        : '';
      if (url) {
        log('sub fingerprint via ' + servers[i].name + ' -> ' + url);
        return url;
      }
    } catch (error) {
      log(
        'sub fingerprint probe failed ' +
          servers[i].name +
          ': ' +
          (error && error.message ? error.message : String(error)),
      );
    }
  }
  return '';
}

async function searchViaAjax(base, keyword, maxResults) {
  const res = await request(absoluteUrl('/ajax/anime/search?keyword=' + encodeURIComponent(keyword), base), {
    headers: {
      Accept: 'application/json, text/plain, */*',
      'X-Requested-With': 'XMLHttpRequest',
      Referer: base + '/',
    },
  });
  const data = res.json;
  if (!res.ok || !data || Number(data.status) !== 200 || !data.result || !data.result.html) {
    throw new Error('AJAX search unavailable');
  }
  return parseAjaxSearchCards(data.result.html, base, maxResults || SEARCH_MAX_RESULTS);
}

async function searchViaFilter(base, keyword, maxResults, pageIndex) {
  const limit = maxResults || SEARCH_MAX_RESULTS;
  const pageOffset = Math.max(0, parseInt(pageIndex, 10) || 0);
  const filterPagesPerBatch = Math.max(1, Math.ceil(limit / FILTER_PAGE_SIZE));
  const seen = {};
  const out = [];
  const filterUrl = absoluteUrl('/filter?keyword=' + encodeURIComponent(keyword), base);
  const firstHtml = await requestHtml(filterUrl, { Referer: base + '/' });
  const maxPage = parseFilterMaxPage(firstHtml);
  const startPage = pageOffset * filterPagesPerBatch + 1;
  const endPage = Math.min(maxPage, startPage + filterPagesPerBatch - 1);

  for (let page = startPage; page <= endPage; page += 1) {
    const html =
      page === 1
        ? firstHtml
        : await requestHtml(filterUrl + '&page=' + page, {
            Referer: filterUrl,
          });
    const batch = parseFilterSearchCards(html, base, limit - out.length, seen);
    for (let i = 0; i < batch.length; i += 1) {
      out.push(batch[i]);
      if (out.length >= limit) break;
    }
    if (out.length >= limit || batch.length === 0) break;
  }

  return out;
}

async function searchResults(query, page) {
  const keyword = String(query == null ? '' : query).trim();
  const pageIndex = Math.max(0, parseInt(page, 10) || 0);

  return withDomainFallback(async function (base) {
    if (!keyword) {
      if (pageIndex > 0) return [];
      const homeHtml = await requestHtml(base + '/home', { Referer: base + '/' });
      const homeResults = parseWatchCards(homeHtml, base, SEARCH_MAX_RESULTS);
      log('home browse -> ' + homeResults.length + ' results');
      return homeResults;
    }

    let results = [];
    try {
      results = await searchViaFilter(base, keyword, SEARCH_MAX_RESULTS, pageIndex);
      log('search filter "' + keyword + '" page ' + pageIndex + ' -> ' + results.length + ' results');
    } catch (filterError) {
      log(
        'filter search failed, using ajax fallback: ' +
          (filterError && filterError.message ? filterError.message : String(filterError)),
      );
      results = await searchViaAjax(base, keyword, SEARCH_MAX_RESULTS);
      log('search ajax "' + keyword + '" -> ' + results.length + ' results');
    }

    if (results.length < 10) {
      try {
        const ajaxResults = await searchViaAjax(base, keyword, SEARCH_MAX_RESULTS);
        const seen = {};
        const merged = [];
        for (let i = 0; i < results.length; i += 1) {
          seen[results[i].href] = true;
          merged.push(results[i]);
        }
        for (let j = 0; j < ajaxResults.length; j += 1) {
          if (seen[ajaxResults[j].href]) continue;
          seen[ajaxResults[j].href] = true;
          merged.push(ajaxResults[j]);
          if (merged.length >= SEARCH_MAX_RESULTS) break;
        }
        results = merged;
        log('search merged "' + keyword + '" -> ' + results.length + ' results');
      } catch (_) {}
    }

    results.sort(function (a, b) {
      return rankSearchResult(a, keyword) - rankSearchResult(b, keyword);
    });
    return results.slice(0, SEARCH_MAX_RESULTS);
  });
}

async function extractDetails(urlOrId) {
  const raw = String(urlOrId || '').trim();
  if (!raw) throw new Error('Missing series id');

  const slug = normalizeSlug(raw);
  if (!slug) throw new Error('Missing series slug');

  return withDomainFallback(async function (base) {
    const watchUrl = absoluteUrl('/watch/' + slug, base);
    const html = await requestHtml(watchUrl, { Referer: base + '/' });
    const details = parseDetailsFromHtml(html, base, slug);
    log('details ' + details.title + ' (' + details.showId + ')');
    return details;
  });
}

async function extractEpisodes(seriesId) {
  const parsed = parseEpisodeHref(seriesId);
  const slug = normalizeSlug(parsed.slug || seriesId);
  if (!slug) throw new Error('Missing series slug');

  return withDomainFallback(async function (base) {
    const watchUrl = absoluteUrl('/watch/' + slug, base);
    const watchHtml = await requestHtml(watchUrl, { Referer: base + '/' });
    const showId = parsed.showId || parseShowIdFromHtml(watchHtml);
    if (!showId) throw new Error('Could not resolve show id');

    const data = await requestJson(absoluteUrl('/ajax/episode/list/' + showId, base), {
      Referer: watchUrl,
    });
    if (Number(data.status) !== 200 || !data.result) {
      throw new Error(data.message || 'Episode list unavailable');
    }

    const episodes = parseEpisodesFromHtml(data.result, showId, slug, base);
    log('episodes ' + slug + ' -> ' + episodes.length);
    return episodes.map(function (episode) {
      return {
        number: episode.number,
        href: episode.href,
        title: episode.title,
        season: episode.season,
        subAvailable: episode.subAvailable,
        dubAvailable: episode.dubAvailable,
      };
    });
  });
}

async function extractStreamUrl(episodeHref, lang) {
  const targetLang = normalizeLang(lang);
  const context = await resolveEpisodeContext(episodeHref);
  const dataIds = context.episode.dataIds;
  if (!dataIds) throw new Error('Episode is missing server token');

  if (targetLang === 'dub' && !context.episode.dubAvailable) {
    throw new Error('Dub is not available for this episode');
  }
  if (targetLang === 'sub' && !context.episode.subAvailable) {
    throw new Error('Sub is not available for this episode');
  }

  const serverList = await requestJson(
    absoluteUrl('/ajax/server/list?servers=' + encodeURIComponent(dataIds), context.base),
    { Referer: context.watchUrl },
  );
  if (Number(serverList.status) !== 200 || !serverList.result) {
    throw new Error(serverList.message || 'Server list unavailable');
  }

  let servers = parseServersFromHtml(serverList.result, targetLang);
  servers = sortServers(dedupeServers(servers), targetLang);
  if (!servers.length) {
    throw new Error('No servers available for ' + targetLang);
  }

  let subFingerprint = '';
  if (targetLang === 'dub') {
    subFingerprint = await resolveSubStreamFingerprint(context.base, context.watchUrl, dataIds);
  }

  let lastError = null;
  let primary = null;
  const combinedStreams = [];
  const seenStreamUrls = {};
  for (let i = 0; i < servers.length; i += 1) {
    try {
      const result = await extractStreamFromServer(
        context.base,
        context.watchUrl,
        servers[i],
        targetLang,
        { subFingerprint: subFingerprint },
      );
      const entries = Array.isArray(result.streams) ? result.streams : [];
      if (!primary) {
        primary = result;
        for (let index = 0; index < entries.length; index += 1) {
          const entry = entries[index];
          const url = String(entry && entry.url ? entry.url : '').trim();
          if (!url || seenStreamUrls[url]) continue;
          seenStreamUrls[url] = true;
          combinedStreams.push(entry);
        }
        continue;
      }

      // Keep one independently validated server as a transport fallback. A
      // full quality ladder from the primary remains the quality picker; this
      // one extra master is only for recovery when the first ticket decays.
      const fallback = entries[0];
      const fallbackUrl = String(fallback && fallback.url ? fallback.url : '').trim();
      if (fallbackUrl && !seenStreamUrls[fallbackUrl]) {
        seenStreamUrls[fallbackUrl] = true;
        combinedStreams.push({
          label: targetLang + ' Backup (' + result.server + ')',
          url: fallbackUrl,
          headers: fallback.headers || result.headers || {},
        });
      }
      log(
        'playback fallback [' +
          targetLang +
          '] via ' +
          result.server +
          ' (' +
          fallbackUrl +
          ')',
      );
      break;
    } catch (error) {
      lastError = error;
      log(
        'server failed ' +
          servers[i].name +
          ': ' +
          (error && error.message ? error.message : String(error)),
      );
      // Once a primary route exists, one alternate attempt is enough. Do not
      // turn a playable startup into a scan of every provider.
      if (primary) break;
    }
  }

  if (!primary) {
    try {
      primary = await resolveHiAnimeFallback(context, targetLang);
    } catch (error) {
      log('HiAnime fallback failed: ' + (error && error.message ? error.message : String(error)));
    }
  }
  if (!primary) throw lastError || new Error('All stream servers failed');
  if (primary.server === 'HiAnime fallback') return primary;
  primary.streams = combinedStreams;
  log(
    'playback ready [' +
      targetLang +
      '] via ' +
      primary.server +
      ' with ' +
      Math.max(0, combinedStreams.length - primary.qualities.length) +
      ' fallback route(s)',
  );
  return primary;
}

async function discoveryHome() {
  return withDomainFallback(async function (base) {
    const homeHtml = await requestHtml(base + '/home', { Referer: base + '/' });
    const allCards = parseWatchCards(homeHtml, base, 100);

    if (!allCards.length) {
      throw new Error('Home page returned no cards');
    }

    const sections = [];
    const seen = {};
    let cardIndex = 0;

    // Spotlight section (hero style, ~6 items)
    const spotlightCards = [];
    while (spotlightCards.length < 6 && cardIndex < allCards.length) {
      const card = allCards[cardIndex];
      const href = card.href;
      if (!seen[href]) {
        seen[href] = true;
        spotlightCards.push(card);
      }
      cardIndex += 1;
    }

    if (spotlightCards.length > 0) {
      sections.push({
        id: 'spotlight',
        title: 'Spotlight',
        style: 'hero',
        items: spotlightCards.slice(0, 8),
      });
    }

    // Trending section (top10 style, exactly 10 items)
    const trendingCards = [];
    while (trendingCards.length < 10 && cardIndex < allCards.length) {
      const card = allCards[cardIndex];
      const href = card.href;
      if (!seen[href]) {
        seen[href] = true;
        trendingCards.push(card);
      }
      cardIndex += 1;
    }

    if (trendingCards.length > 0) {
      sections.push({
        id: 'trending',
        title: 'Trending Now',
        style: 'top10',
        items: trendingCards.slice(0, 10),
      });
    }

    // Latest section (poster style, remaining cards with feed viewAll)
    const latestCards = [];
    while (latestCards.length < 10 && cardIndex < allCards.length) {
      const card = allCards[cardIndex];
      const href = card.href;
      if (!seen[href]) {
        seen[href] = true;
        latestCards.push(card);
      }
      cardIndex += 1;
    }

    if (latestCards.length > 0) {
      sections.push({
        id: 'latest',
        title: 'Latest Anime',
        style: 'poster',
        items: latestCards.slice(0, 30),
        viewAll: {
          mode: 'feed',
          feedId: 'latest',
        },
      });
    }

    // Synthetic feed-backed "All Anime" row from /filter
    try {
      const filterHtml = await requestHtml(base + '/filter?keyword=', { Referer: base + '/' });
      const filterCards = parseFilterSearchCards(filterHtml, base, 30, seen);

      if (filterCards.length > 0) {
        sections.push({
          id: 'all_anime',
          title: 'All Anime',
          style: 'poster',
          items: filterCards.slice(0, 30),
          viewAll: {
            mode: 'feed',
            feedId: 'all',
          },
        });
      }
    } catch (_) {
      // Filter fetch is optional, continue with existing sections
    }

    if (sections.length === 0) {
      throw new Error('No valid discovery sections generated');
    }

    log('discovery home -> ' + sections.length + ' sections');
    return { sections: sections };
  });
}

async function discoveryFeed(feedId, page) {
  const pageNum = Math.max(1, parseInt(page, 10) || 1);

  // Map feedId to query parameters
  let keyword = '';
  switch (String(feedId || '').toLowerCase()) {
    case 'all':
      keyword = '';
      break;
    case 'latest':
      keyword = '';
      break;
    default:
      // Unknown feedId
      log('unknown feed id: ' + feedId);
      return { items: [], page: pageNum, hasMore: false };
  }

  return withDomainFallback(async function (base) {
    const filterUrl = absoluteUrl('/filter?keyword=' + encodeURIComponent(keyword), base);
    const pageUrl = pageNum === 1 ? filterUrl : filterUrl + '&page=' + pageNum;

    const html = await requestHtml(pageUrl, { Referer: base + '/' });
    const items = parseFilterSearchCards(html, base, 50);

    // Determine hasMore: try to parse max page from pagination
    const maxPage = parseFilterMaxPage(html);
    const hasMore = pageNum < maxPage;

    // Fallback: if no pagination found but items returned, assume more pages exist
    const hasMoreFallback = items.length > 0;

    log('discovery feed "' + feedId + '" page ' + pageNum + ' -> ' + items.length + ' items, hasMore=' + (hasMore || hasMoreFallback));

    return {
      items: items,
      page: pageNum,
      hasMore: hasMore || hasMoreFallback,
    };
  });
}

globalThis.searchResults = searchResults;
globalThis.extractDetails = extractDetails;
globalThis.extractEpisodes = extractEpisodes;
globalThis.extractStreamUrl = extractStreamUrl;
globalThis.discoveryHome = discoveryHome;
globalThis.discoveryFeed = discoveryFeed;
